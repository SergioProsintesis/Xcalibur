import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';

import express from 'express';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

// ===================================================
// Corrección: resolver correctamente el directorio actual
// ===================================================
const __dirname = dirname(fileURLToPath(import.meta.url));
const browserDistFolder = join(__dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

// ===================================================
// Endpoint simple para verificar que el servidor responde
// ===================================================
app.get('/ping', (req, res) => {
  res.send('pong 🟢 SSR server is alive!');
});

// ===================================================
// Servir archivos estáticos desde /browser
// ===================================================
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

// ===================================================
// Manejar todas las demás rutas con el render SSR
// ===================================================
app.use((req, res, next) => {
  // Sanitize URL to prevent CRLF injection
  const sanitizedUrl = req.url.replace(/[\r\n]/g, '');
  console.log(`➡️  Nueva petición: ${sanitizedUrl}`);

  angularApp
    .handle(req)
    .then((response) => {
      if (response) {
        console.log(`✅ SSR completado para ${req.url}`);
        writeResponseToNodeResponse(response, res);
      } else {
        next();
      }
    })
    .catch((err) => {
      console.error(`❌ Error procesando ${req.url}:`, err);
      next(err);
    });
});

// ===================================================
// Iniciar el servidor solo si es el módulo principal
// ===================================================
if (isMainModule(import.meta.url)) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) throw error;
    console.log(`🚀 Node Express server listening on http://localhost:${port}`);
  });
}

// ===================================================
// Exportar manejador para Angular CLI o Firebase Functions
// ===================================================
export const reqHandler = createNodeRequestHandler(app);
