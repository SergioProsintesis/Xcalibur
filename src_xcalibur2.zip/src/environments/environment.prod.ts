export const environment = {
  production: true,
  apiBaseUrl: 'http://u2zepcaosswv002.pwcglb.com:8810',
  apiServicePath: '/XcaliburWeb/rest/ServiciosXcaliburWeb',
  apiUrl: 'http://u2zepcaosswv002.pwcglb.com:8810/XcaliburWeb/rest/ServiciosXcaliburWeb'
};
