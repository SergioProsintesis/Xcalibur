/**
 * Security utility functions for preventing common vulnerabilities
 * Veracode vuln fixes: CWE-117 (CRLF Injection), CWE-601 (Open Redirect)
 */

/**
 * Sanitize strings for logging to prevent CRLF injection attacks
 * Removes carriage returns (\r) and line feeds (\n) from input
 * 
 * @param input - String to sanitize
 * @returns Sanitized string safe for logging
 * 
 * CWE-117: Improper Output Neutralization for Logs
 */
export function sanitizeForLogging(input: string | undefined | null): string {
  if (!input) return '';
  return String(input).replace(/[\r\n]/g, '');
}

/**
 * Validates URL before redirecting to prevent Open Redirect attacks
 * Checks against whitelist of allowed domains
 * 
 * @param redirectUrl - URL to validate
 * @param allowedDomains - Array of allowed domain patterns
 * @returns true if URL is safe to redirect to, false otherwise
 * 
 * CWE-601: URL Redirection to Untrusted Site
 */
export function isValidRedirectUrl(
  redirectUrl: string | undefined,
  allowedDomains: string[] = [window.location.hostname]
): boolean {
  if (!redirectUrl) return false;

  try {
    // Handle relative URLs (same origin)
    if (redirectUrl.startsWith('/')) {
      return true;
    }

    // Handle absolute URLs - validate domain
    const url = new URL(redirectUrl);
    return allowedDomains.some(domain => 
      url.hostname === domain || url.hostname.endsWith('.' + domain)
    );
  } catch {
    // Invalid URL format
    return false;
  }
}

/**
 * Safe redirect function that validates URL before redirecting
 * 
 * @param redirectUrl - URL to redirect to
 * @param allowedDomains - Array of allowed domain patterns
 * 
 * CWE-601: URL Redirection to Untrusted Site
 */
export function safeRedirect(
  redirectUrl: string | undefined,
  allowedDomains: string[] = [window.location.hostname]
): void {
  if (isValidRedirectUrl(redirectUrl, allowedDomains)) {
    window.location.href = redirectUrl!;
  } else {
    console.warn('⚠️ Invalid redirect URL blocked:', sanitizeForLogging(redirectUrl));
    // Fallback to home or safe page
    window.location.href = '/';
  }
}

/**
 * Remove hard-coded and sensitive information from environment
 * Should be used to prevent CWE-259 (Hard-coded Password) vulnerabilities
 */
export const ENVIRONMENT_CONFIG = {
  // Never store passwords here - use environment variables from .env
  // All sensitive data should use process.env['VARIABLE_NAME']
  apiBaseUrl: typeof window !== 'undefined' ? window.location.origin : '',
  allowedRedirectDomains: [
    'localhost',
    'localhost:4200',
    'localhost:4000',
    // Add your domain here, not hardcoded URLs
  ]
};

/**
 * Validates API response to ensure no sensitive data logging
 * 
 * @param response - API response object
 * @param sensitiveFields - Field names to exclude from logging
 * @returns Sanitized response copy safe for logging
 */
export function sanitizeResponseForLogging(
  response: any,
  sensitiveFields: string[] = ['password', 'token', 'secret', 'key']
): any {
  if (!response) return null;

  const sanitized = { ...response };
  
  sensitiveFields.forEach(field => {
    if (field in sanitized) {
      sanitized[field] = '[REDACTED]';
    }
  });

  return sanitized;
}
