export interface CompaniaRecord {
  "Agrega-Cias": string;
  cia: number;
  "ClaveResolucion": string;
  "date-ctrl": string;
  "direc-cia": string;
  "DS_BRANCH_ID": string;
  "DS_ClaveResolucion": number;
  "DS_FechaFinResolucion": string;
  "DS_FechaIniResolucion": string;
  "DS_MatMercantil": string;
  "DS_NroResolucionDian": string;
  "DS_Prefijo": string;
  "DS_RangoFinResolucion": number;
  "DS_RangoIniResolucion": number;
  "fax-cia": string;
  "FechaFinResolucion": string;
  "FechaIniResolucion": string;
  "login-ctrl": string;
  "MatMercantil": string;
  nit: string;
  "nombre-cia": string;
  "nomrep-cia": string;
  "NroResolucionDian": string;
  "ObserParametros": string;
  "Prefijo01": string;
  "Prefijo02": string;
  "Prefijo03": string;
  "RangoFinResolucion": number;
  "RangoIniResolucion": number;
  "Resolucion01": string;
  "Resolucion03": string;
  "Resolucion04": string;
  "Resolucion05": string;
  "rif-cia": string;
  "RutaFormatos": string;
  "telefo-cia": string;
  "telex-cia": string;
  "text-cia": string;
  "zonpos-cia": string;
  "fecperi-his": string | null;
  "fecmov-his": string | null;
  cuadre: boolean;
  tparent: string;
}

export interface CompaniasResponse {
  dsRespuesta: {
    tgecias: CompaniaRecord[];
  };
}

export interface ReporteOption {
  pcPrograma: string;
  pcSecuencia: number;
  "pcNombre-pro": string;
  "pcProg-Sel": string;
  pcFecha: string;
  "Login-ctrl": string;
  pcSuper: boolean;
  pcToken: string;
  tparent: string;
}

export interface ReportesResponse {
  dsRespuesta: {
    tSelect: ReporteOption[];
  };
}

export interface ConversionMonetariaResponse {
  dsRespuesta: {
    tSelectConv: ReporteOption[];
  };
}

export interface GenerarReporteResponse {
  response: {
    pcArchCSV?: string;
    pcArchPDF?: string;
    pcArchXLS?: string;
  };
}

export interface TipoClienteRecord {
  "Agrega-Tipc": string;
  cia: number;
  "nombre-cia": string;
  "date-ctrl": string;
  "login-ctrl": string;
  "nombre-tipc": string;
  "text-tipc": string;
  tipocli: string | number;
  tparent: string;
  terrores?: Array<{
    codigo: string;
    descripcion: string;
    tPARENT: string;
  }>;
}

export interface TipoClienteResponse {
  dsRespuesta: {
    tcctipcli: TipoClienteRecord[];
  };
}

// Interfaces para Tipos de Documento
export interface TipoDocumentoRecord {
  "afecxc-tdoc": boolean;
  "afeinv-tdoc": boolean;
  "afesta-tdoc": boolean;
  "Agrega-Tipd": string | null;
  auxiliarm1: number;
  centrom1: number;
  cia: number;
  "clase-tdoc": number;
  cuentam1: string;
  "date-ctrl": string;
  "login-ctrl": string;
  "nombre-tdoc": string;
  "numfac-tdoc": number;
  "numped-tdoc": number;
  "profac-tdoc": number;
  "siglas-tdoc": string;
  "text-tdoc": string;
  tipcomi: number;
  tipodoc: number;
  ubicacionm1: number;
  "agrega-numcon": number | null;
  tparent: string;
  terrores?: Array<{
    codigo: string;
    descripcion: string;
    tPARENT: string;
  }>;
}

export interface TipoDocumentoResponse {
  dsRespuesta: {
    tcctipdoc: TipoDocumentoRecord[];
  };
}

// Interfaces para Clasificación de Ventas
export interface ClasificacionVentaRecord {
  "Agrega-Clav": string;
  cia: number;
  claven: string;
  "date-ctrl": string;
  "login-ctrl": string;
  "nombre-cven": string;
  "text-cven": string;
  "ventad-cven": number;
  "ventah-cven": number;
  tparent: string;
  terrores?: Array<{
    codigo: string;
    descripcion: string;
    tPARENT: string;
  }>;
}

export interface ClasificacionVentaResponse {
  dsRespuesta: {
    tccclaven: ClasificacionVentaRecord[];
  };
}

// Interfaces para Banco/Tarjeta
export interface BancoTarjetaRecord {
  "Agrega-Bant": string;
  bantar: number;
  cia: number;
  "date-ctrl": string;
  "login-ctrl": string;
  "nombre-bant": string;
  "text-bant": string;
  "agrega-banswift": string;
  tparent: string;
  terrores?: Array<{
    codigo: string;
    descripcion: string;
    tPARENT: string;
  }>;
}

export interface BancoTarjetaResponse {
  dsRespuesta: {
    tccbantar: BancoTarjetaRecord[];
  };
}

// Interfaces para Vendedor (CC5016)
export interface VendedorRecord {
  vendedor: number;
  cia: number;
  'nombre-cia': string;
  'nombre-vend': string;
  'text-vend': string;
  codsuper: number;
  'nombre-sup': string;
  ubicacion: number;
  'nombre-ubic': string;
  centro: number;
  'nombre-cen': string;
  zona: number;
  'nombre-zon': string;
  'comisi-vend'?: number;
  'comis1-vend'?: number;
  'comis2-vend'?: number;
  'comcob-vend'?: number;
  'comisi_vend'?: number;
  'comis1_vend'?: number;
  'comis2_vend'?: number;
  'comcob_vend'?: number;
  tipvend?: number;
  'auxiliarcp'?: number;
  'auxiliargc'?: number;
  'auxiliargv'?: number;
  'centrocp'?: number;
  'centrogc'?: number;
  'centrogv'?: number;
  'cuentacp'?: string;
  'cuentagc'?: string;
  'cuentagv'?: string;
  'ubicacioncp'?: number;
  'ubicaciongc'?: number;
  'ubicaciongv'?: number;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'Agrega-Vend'?: string;
  'agrega-palm'?: string;
  'agrega-cosreg'?: string;
  tparent?: string;
  terrores?: Array<{
    codigo: string;
    descripcion: string;
    tPARENT: string;
  }>;
}

export interface VendedorResponse {
  dsRespuesta: {
    tccvended: VendedorRecord[];
  };
}
