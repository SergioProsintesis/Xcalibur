export interface GeparameRecord {
  "Agrega-Para": string;
  "bgcolfil-gen": number; // Fondo Campo caja de texto numerica
  "bgcolfra-gen": number; // Fondo caja de texto numerica
  "bgcoltex-gen": number; // Fondo Texto caja de texto numerica
  "decimal-gen": boolean; // Decimales SI/NO
  "Dias-Aviso": number; // Dias Aviso
  "Dias-Pass": number; // Dias contraseña
  "fgcolfil-gen": number;
  "fgcolfra-gen": number; // Letras
  "fgcolre1-gen": number; // Rectangulo1
  "fgcolre2-gen": number; // Rectangulo2
  "fgcoltex-gen": number; // letras Texto
  "fueenc-gen": boolean; // Fuentes SI/NO
  "Historia": number; // Historia Texto
  "idioma-gen": string; // Idioma ESPAÑOL/INGLES
  "Intentos": number; // Intentos
  "runlog-gen": boolean; // Logs SI/NO
  "runpel-gen": boolean; // Animacion SI/NO
  "runson-gen": boolean; // Sonido SI/NO
  "agrega-RepPDF": string; // Ruta PDF
  "agrega-login": string;
  "tparent": string;
  "terrores"?: { codigo: string; descripcion: string; tPARENT: string }[];
}

export interface GeparameResponse {
  dsRespuesta: {
    tgeparame: GeparameRecord[];
  };
}
