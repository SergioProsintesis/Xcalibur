export interface GeclavesRecord {
  "Agrega": string;
  "Agrega-Clav": string;
  "bgcolfil-gen": number;
  "bgcolfra-gen": number;
  "bgcoltex-gen": number;
  "Bloqueo": boolean;
  "Codper": string | null;
  "Contador": number;
  "CrudCons": boolean;
  "CrudElim": boolean;
  "CrudMod": boolean;
  "CrudSave": boolean;
  "date-ctrl": string | null;
  "fecfin-clav": string | null;
  "fecini-clav": string | null;
  "Fecpass": string | null;
  "fgcolfil-gen": number;
  "fgcolfra-gen": number;
  "fgcolre1-gen": number;
  "fgcolre2-gen": number;
  "fgcoltex-gen": number;
  "idioma-gen": string;
  "login": string | null;
  "login-ctrl": string;
  "nombre-clav": string;
  "Nuevo": boolean;
  "password-clav": string;
  "password-clav2": string;
  "Perfil": boolean;
  "runpel-gen": boolean;
  "runson-gen": boolean;
  "super-clav": boolean;
  "text-clav": string;
  "tperfil": string;
  "tparent": string;
  "agrega-userWin": string;
  "agrega-emailinter": string;
  "agrega-accinv": string;
  "agrega-indgen": string;
  "agrega-GUID": string;
  "agrega-CodEmpleado": string;
  terrores?: { codigo: string; descripcion: string; tPARENT: string }[];
}

export interface GeclavesResponse {
  dsRespuesta: {
    tgeclaves: GeclavesRecord[];
  };
}
