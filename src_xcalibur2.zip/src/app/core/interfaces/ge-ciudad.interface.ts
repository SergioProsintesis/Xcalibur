export interface CiudadRecord {
  'Agrega-Ciud': string;
  'ciudad': string;
  'date-ctrl': string | null;
  'login-ctrl': string;
  'nombre-ciu': string;
  'pais': string;
  'nombre-pai': string;
  'text-ciu': string;
  'idioma-ciu'?: string;
  'tparent': string;
  terrores?: { codigo: string; descripcion: string; tPARENT: string }[];
}

export interface PaisRecord {
  'Agrega-Pais': string;
  'date-ctrl': string | null;
  'idioma-pai': string;
  'login-ctrl': string;
  'moneda': number;
  'nombre-pai': string;
  'pais': string;
  'text-pai': string;
  'tparent': string;
}

export interface CiudadResponse {
  dsRespuesta: {
    tgeciudad: CiudadRecord[];
  };
}

export interface PaisResponse {
  dsRespuesta: {
    tgepais: PaisRecord[];
  };
}

export interface Ge2012Response {
  response: {
    pcArchCSV: string; // Base64 encoded CSV
    pcArchPDF: string; // Base64 encoded PDF
  };
}
