import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { AuthService } from './auth.service';
import { GeparameResponse, GeparameRecord } from '../interfaces/geparame.interface';

@Injectable({ providedIn: 'root' })
export class GeparameService {
  constructor(private http: HttpClient, private auth: AuthService) {}

  /** Obtiene parámetros generales GE0055 */
  getParams(): Observable<GeparameRecord | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Getgeparame-ge0055?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<GeparameResponse>(url).pipe(
      map(res => {
        const rec = res?.dsRespuesta?.tgeparame?.[0] || null;
        return rec;
      }),
      catchError(err => {
        console.error('Error getParams', err);
        return of(null);
      })
    );
  }

  /** Actualiza parámetros generales GE0055 */
  updateParams(record: GeparameRecord): Observable<GeparameRecord | null> {
    const url = `${environment.apiUrl}/UpdateGeparame-ge0055`;
    const payload = { tgeparame: [record] };
    return this.http.post<GeparameResponse>(url, payload).pipe(
      map(res => res?.dsRespuesta?.tgeparame?.[0] || null),
      catchError(err => {
        console.error('Error updateParams', err);
        return of(null);
      })
    );
  }
}
