import 'zone.js';
import 'zone.js/testing';
import { TestBed } from '@angular/core/testing';
import { MenuService } from './menu.service';

describe('MenuService (recents)', () => {
  let service: MenuService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MenuService);
    // ensure clean state
    try { localStorage.removeItem('menu.recent'); } catch (e) { /* ignore */ }
  });

  it('addRecentMenuItem persists unique items and caps at 8', () => {
    // add 10 items
    for (let i = 0; i < 10; i++) {
      service.addRecentMenuItem({ path: `/p${i}`, label: `P${i}` });
    }

    const recents = service.getRecentMenuItems();
    expect(recents.length).toBe(8);
    // most recent should be last inserted
    expect(recents[0].path).toBe('/p9');

    // adding an existing item moves it to the front
    service.addRecentMenuItem({ path: '/p5', label: 'P5' });
    const recents2 = service.getRecentMenuItems();
    expect(recents2[0].path).toBe('/p5');
    expect(recents2.length).toBe(8);
  });

  it('clearRecentMenuItems removes stored recents', () => {
    service.addRecentMenuItem({ path: '/x', label: 'X' });
    expect(service.getRecentMenuItems().length).toBeGreaterThan(0);
    service.clearRecentMenuItems();
    expect(service.getRecentMenuItems().length).toBe(0);
  });
});
