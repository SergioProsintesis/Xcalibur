import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { AuthService } from './auth.service';
import { CiudadResponse, CiudadRecord, PaisResponse, Ge2012Response } from '../interfaces/ge-ciudad.interface';

@Injectable({ providedIn: 'root' })
export class GeclavesCiudadService {
  constructor(private http: HttpClient, private auth: AuthService) {}

  /** GET GE0012: obtiene países para selector */
  getCEPais(): Observable<PaisResponse | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEGepais?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<PaisResponse>(url).pipe(
      catchError(err => {
        console.error('Error getCEPais', err);
        return of(null);
      })
    );
  }

  /** GET GE0012: valida país */
  getLeavePais(pcPais: string): Observable<PaisResponse | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeavePais?pcPais=${encodeURIComponent(pcPais)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<PaisResponse>(url).pipe(
      catchError(err => {
        console.error('Error getLeavePais', err);
        return of(null);
      })
    );
  }

  /** GET GE0012: obtiene ciudades para selector */
  getCECiudad(pcPais: string): Observable<CiudadResponse | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEGeciudad?pcPais=${encodeURIComponent(pcPais)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<CiudadResponse>(url).pipe(
      catchError(err => {
        console.error('Error getCECiudad', err);
        return of(null);
      })
    );
  }

  /** GET GE0012: valida ciudad */
  getLeaveCiudad(pcPais: string, pcCiudad: string): Observable<CiudadResponse | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCiudad?pcPais=${encodeURIComponent(pcPais)}&pcCiudad=${encodeURIComponent(pcCiudad)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<CiudadResponse>(url).pipe(
      catchError(err => {
        console.error('Error getLeaveCiudad', err);
        return of(null);
      })
    );
  }

  /** PUT GE0012: crear/actualizar ciudad */
  updateCiudad(payload: any): Observable<CiudadResponse | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Updategeciudad_ge0012?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.put<CiudadResponse>(url, payload).pipe(
      catchError(err => {
        console.error('Error updateCiudad', err);
        return of(null);
      })
    );
  }

  /** DELETE GE0012: eliminar ciudad */
  deleteCiudad(pcPais: string, pcCiudad: string): Observable<CiudadResponse | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/DelGeciudad_ge0012?pcPais=${encodeURIComponent(pcPais)}&pcCiudad=${encodeURIComponent(pcCiudad)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.delete<CiudadResponse>(url).pipe(
      catchError(err => {
        console.error('Error deleteCiudad', err);
        return of(null);
      })
    );
  }

  /** GET GE0012: genera reporte PDF */
  generateReport(pcPais: string, pcCiudad: string): Observable<any | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetGeneraReportesPD?pcPais=${encodeURIComponent(pcPais)}&pcCiudad=${encodeURIComponent(pcCiudad)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error generateReport', err);
        return of(null);
      })
    );
  }

  /** GET GE2012: Reporte de Ciudades - genera archivos CSV y PDF */
  getGe2012Report(pcFecha: string, pcCompania: string = '1'): Observable<Ge2012Response | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';
    // Si no se proporciona pcCompania, usar valor '1' por defecto
    const empresa = pcCompania || '1';

    const url = `${environment.apiUrl}/Getge2012?pcCompania=${encodeURIComponent(empresa)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<Ge2012Response>(url).pipe(
      catchError(err => {
        console.error('Error getGe2012Report', err);
        return of(null);
      })
    );
  }
}
