import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface ButtonThemeConfig {
  primary?: string;
  primaryHover?: string;
  primaryDark?: string;
  secondary?: string;
  danger?: string;
  success?: string;
  warning?: string;
  info?: string;
  white?: string;
  textPrimary?: string;
  textSecondary?: string;
  borderLight?: string;
  shadowMd?: string;
}

@Injectable({
  providedIn: 'root'
})
export class ButtonThemeService {
  private defaultTheme: ButtonThemeConfig = {
    primary: '#033481',
    primaryHover: '#4f66ad',
    primaryDark: '#033481',
    secondary: '#0299a3',
    danger: '#ef4444',
    success: '#10b981',
    warning: '#f59e0b',
    info: '#3b82f6',
    white: '#ffffff',
    textPrimary: '#111827',
    textSecondary: '#6b7280',
    borderLight: '#e5e7eb',
    shadowMd: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)'
  };

  private themeSubject = new BehaviorSubject<ButtonThemeConfig>(this.defaultTheme);
  public theme$: Observable<ButtonThemeConfig> = this.themeSubject.asObservable();

  constructor() {
    this.applyTheme(this.defaultTheme);
  }

  /**
   * Apply a new theme configuration
   * Updates CSS custom properties globally
   */
  public applyTheme(theme: Partial<ButtonThemeConfig>): void {
    const mergedTheme = { ...this.defaultTheme, ...theme };
    this.themeSubject.next(mergedTheme);
    this.updateCSSVariables(mergedTheme);
  }

  /**
   * Get current theme configuration
   */
  public getTheme(): ButtonThemeConfig {
    return this.themeSubject.getValue();
  }

  /**
   * Reset to default theme
   */
  public resetTheme(): void {
    this.applyTheme(this.defaultTheme);
  }

  /**
   * Update CSS custom properties in root element
   */
  private updateCSSVariables(theme: ButtonThemeConfig): void {
    const root = document.documentElement;
    
    if (theme.primary) {
      root.style.setProperty('--color-primary', theme.primary);
    }
    if (theme.primaryHover) {
      root.style.setProperty('--color-primary-hover', theme.primaryHover);
    }
    if (theme.primaryDark) {
      root.style.setProperty('--color-primary-dark', theme.primaryDark);
    }
    if (theme.secondary) {
      root.style.setProperty('--color-secondary', theme.secondary);
    }
    if (theme.danger) {
      root.style.setProperty('--color-danger', theme.danger);
    }
    if (theme.success) {
      root.style.setProperty('--color-success', theme.success);
    }
    if (theme.warning) {
      root.style.setProperty('--color-warning', theme.warning);
    }
    if (theme.info) {
      root.style.setProperty('--color-info', theme.info);
    }
    if (theme.white) {
      root.style.setProperty('--color-white', theme.white);
    }
    if (theme.textPrimary) {
      root.style.setProperty('--text-primary', theme.textPrimary);
    }
    if (theme.textSecondary) {
      root.style.setProperty('--text-secondary', theme.textSecondary);
    }
    if (theme.borderLight) {
      root.style.setProperty('--border-light', theme.borderLight);
    }
    if (theme.shadowMd) {
      root.style.setProperty('--shadow-md', theme.shadowMd);
    }
  }

  /**
   * Create a preset theme configuration
   */
  public createPreset(name: string, config: Partial<ButtonThemeConfig>): Partial<ButtonThemeConfig> {
    return { ...this.defaultTheme, ...config };
  }

  /**
   * Common presets
   */
  public getPresets() {
    return {
      light: this.defaultTheme,
      
      corporate: {
        primary: '#1e3a8a',
        primaryHover: '#3b82f6',
        primaryDark: '#1e3a8a',
        secondary: '#0369a1',
        danger: '#dc2626',
        success: '#059669',
        warning: '#d97706',
        info: '#0284c7'
      },

      modern: {
        primary: '#06b6d4',
        primaryHover: '#0891b2',
        primaryDark: '#06b6d4',
        secondary: '#8b5cf6',
        danger: '#f43f5e',
        success: '#10b981',
        warning: '#f59e0b',
        info: '#3b82f6'
      },

      warm: {
        primary: '#d97706',
        primaryHover: '#dc2626',
        primaryDark: '#b45309',
        secondary: '#c2410c',
        danger: '#dc2626',
        success: '#16a34a',
        warning: '#f59e0b',
        info: '#f97316'
      },

      minimal: {
        primary: '#000000',
        primaryHover: '#404040',
        primaryDark: '#000000',
        secondary: '#525252',
        danger: '#dc2626',
        success: '#16a34a',
        warning: '#ca8a04',
        info: '#2563eb'
      }
    };
  }
}
