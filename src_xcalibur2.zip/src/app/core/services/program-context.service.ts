import { Injectable, signal, computed } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { MenuService } from './menu.service';
import { filter } from 'rxjs/operators';

/**
 * Servicio para gestionar el contexto del programa actual (progra-men)
 * Extrae el código de programa de la ruta navegada y lo hace disponible globalmente
 */
@Injectable({
  providedIn: 'root'
})
export class ProgramContextService {
  private currentProgramCode = signal<string>('');
  private currentProgramName = signal<string>('');

  // Signal computado que concatena el código con el título base
  public readonly programCodeDisplay = computed(() => {
    const code = this.currentProgramCode();
    return code ? `${code} - ` : '';
  });

  constructor(
    private router: Router,
    private menuService: MenuService
  ) {
    this.initializeRouterListener();
    // Intentar cargar el código inicial después de que el menú se haya cargado
    // Hacer múltiples intentos porque el menú puede cargar con delay
    setTimeout(() => this.detectProgramCode(this.router.url), 500);
    setTimeout(() => this.detectProgramCode(this.router.url), 1000);
    setTimeout(() => this.detectProgramCode(this.router.url), 2000);
  }

  /**
   * Escucha los cambios de ruta y extrae el código de programa
   */
  private initializeRouterListener(): void {
    this.router.events
      .pipe(
        filter(event => event instanceof NavigationEnd)
      )
      .subscribe((event: any) => {
        const url = event.url;
        console.log('🔍 Navegando a:', url);
        
        // Extraer el código de programa basado en la ruta
        this.detectProgramCode(url);
      });
  }

  /**
   * Detecta el código de programa usando múltiples estrategias
   * @param url URL actual
   */
  private detectProgramCode(url: string): void {
    console.log('🔎 Intentando detectar código de programa para URL:', url);
    
    // Estrategia 1: Buscar en la jerarquía del menú (tiene los datos más frescos)
    const hierarchy = this.menuService.getMenuHierarchy();
    if (hierarchy && hierarchy.length > 0) {
      const code = this.findCodeInHierarchy(url, hierarchy);
      if (code) {
        this.currentProgramCode.set(code.code);
        this.currentProgramName.set(code.name);
        console.log('✅ Código encontrado en jerarquía:', code);
        return;
      }
    }

    // Estrategia 2: Buscar en el menú plano (getMenuData)
    const flatMenuData = this.menuService.getMenuData();
    if (flatMenuData && flatMenuData.length > 0) {
      const code = this.findCodeInFlatMenu(url, flatMenuData);
      if (code) {
        this.currentProgramCode.set(code.code);
        this.currentProgramName.set(code.name);
        console.log('✅ Código encontrado en menú plano:', code);
        return;
      }
    }

    console.log('⚠️ No se encontró código de programa en la URL:', url);
    console.log('   Estado del menú:', {
      hierarchyLength: hierarchy?.length || 0,
      flatMenuLength: flatMenuData?.length || 0,
      localStorageAvailable: typeof localStorage !== 'undefined'
    });
    this.currentProgramCode.set('');
    this.currentProgramName.set('');
  }

  /**
   * Busca el código en el menú plano
   */
  private findCodeInFlatMenu(url: string, menuData: any[]): { code: string; name: string } | null {
    // Normalizar URL: /cc/mant-descuentos → buscar coincidencias
    const urlSegments = url.split('/').filter(s => s);
    const lastSegment = urlSegments[urlSegments.length - 1]?.toLowerCase() || '';

    console.log('📍 Búsqueda en menú plano:', { url, urlSegments, lastSegment, itemCount: menuData.length });

    if (!lastSegment) return null;

    for (const item of menuData) {
      if (!item.progrMen) continue;

      // Comparar contra tparent, nombreMen, loginCtrl - normalizar todo
      const tparent = (item.tparent || '').toLowerCase().trim();
      const nombreMen = (item.nombreMen || '').toLowerCase().trim();
      const loginCtrl = (item.loginCtrl || '').toLowerCase().trim();
      
      // Convertir nombreMen a formato de URL: "Mantenimiento de Descuentos" → "mantenimiento-de-descuentos"
      const nombreMenUrl = nombreMen
        .replace(/\s+/g, '-')  // Espacios a guiones
        .replace(/[^a-z0-9\-]/g, '')  // Remover caracteres especiales
        .replace(/-+/g, '-');  // Remover guiones múltiples

      console.log('   📋 Item:', { nombreMen, loginCtrl, tparent, nombreMenUrl, lastSegment });

      // Búsqueda flexible con múltiples estrategias
      const matchTparent = tparent === lastSegment || tparent.includes(lastSegment) || lastSegment.includes(tparent);
      const matchNombre = nombreMen === lastSegment || nombreMen.includes(lastSegment) || lastSegment.includes(nombreMen);
      const matchNombreUrl = nombreMenUrl === lastSegment || nombreMenUrl.includes(lastSegment) || lastSegment.includes(nombreMenUrl);
      const matchLogin = loginCtrl === lastSegment || loginCtrl.includes(lastSegment) || lastSegment.includes(loginCtrl);

      if ((matchTparent || matchNombre || matchNombreUrl || matchLogin)) {
        console.log('   ✓ Match encontrado en menú plano:', {
          nombreMen: item.nombreMen,
          loginCtrl: item.loginCtrl,
          progrMen: item.progrMen,
          matchTparent,
          matchNombre,
          matchNombreUrl,
          matchLogin
        });
        return { code: item.progrMen, name: item.nombreMen };
      }
    }

    console.log('   ❌ No se encontró coincidencia en menú plano. Items disponibles:');
    menuData.slice(0, 10).forEach(item => {
      console.log(`      - ${item.nombreMen} (${item.loginCtrl}) → ${item.progrMen}`);
    });

    return null;
  }

  /**
   * Busca el código en la jerarquía del menú
   */
  private findCodeInHierarchy(url: string, hierarchy: any[]): { code: string; name: string } | null {
    const urlSegments = url.split('/').filter(s => s);
    const lastSegment = urlSegments[urlSegments.length - 1]?.toLowerCase() || '';

    console.log('📍 Búsqueda en jerarquía:', { url, lastSegment, systemCount: hierarchy.length });

    if (!lastSegment) return null;

    for (const sistema of hierarchy) {
      if (!sistema.grupos) continue;
      
      for (const grupo of sistema.grupos) {
        if (!grupo.items) continue;
        
        for (const item of grupo.items) {
          if (!item.progrMen) continue;

          // Normalizar valores
          const nombreMen = (item.nombreMen || '').toLowerCase().trim();
          const loginCtrl = (item.loginCtrl || '').toLowerCase().trim();
          const tparent = (item.tparent || '').toLowerCase().trim();

          // Convertir nombreMen a formato de URL
          const nombreMenUrl = nombreMen
            .replace(/\s+/g, '-')  // Espacios a guiones
            .replace(/[^a-z0-9\-]/g, '')  // Remover caracteres especiales
            .replace(/-+/g, '-');  // Remover guiones múltiples

          console.log('   📋 Item:', { nombreMen, loginCtrl, tparent, nombreMenUrl, lastSegment });

          // Búsqueda flexible: múltiples estrategias
          const matchNombre = nombreMen === lastSegment || nombreMen.includes(lastSegment) || lastSegment.includes(nombreMen);
          const matchLogin = loginCtrl === lastSegment || loginCtrl.includes(lastSegment) || lastSegment.includes(loginCtrl);
          const matchTparent = tparent === lastSegment || tparent.includes(lastSegment) || lastSegment.includes(tparent);
          const matchNombreUrl = nombreMenUrl === lastSegment || nombreMenUrl.includes(lastSegment) || lastSegment.includes(nombreMenUrl);

          if ((matchNombre || matchLogin || matchTparent || matchNombreUrl)) {
            console.log('   ✓ Match encontrado en jerarquía:', {
              nombreMen: item.nombreMen,
              loginCtrl: item.loginCtrl,
              progrMen: item.progrMen,
              matchNombre,
              matchLogin,
              matchTparent,
              matchNombreUrl
            });
            return { code: item.progrMen, name: item.nombreMen };
          }
        }
      }
    }

    console.log('   ❌ No se encontró en jerarquía. Items disponibles en primer grupo:');
    if (hierarchy[0]?.grupos[0]?.items) {
      hierarchy[0].grupos[0].items.slice(0, 10).forEach((item: any) => {
        console.log(`      - ${item.nombreMen} (${item.loginCtrl}) → ${item.progrMen}`);
      });
    }

    return null;
  }

  /**
   * Busca el código en localStorage como fallback
   */
  private findCodeInLocalStorage(url: string): { code: string; name: string } | null {
    try {
      if (typeof window === 'undefined' || !window.localStorage) {
        return null;
      }

      const savedMenuData = localStorage.getItem('xcalibur_menu_data');
      if (!savedMenuData) {
        console.log('   ℹ️ No hay datos de menú en localStorage');
        return null;
      }

      const menuData = JSON.parse(savedMenuData);
      const code = this.findCodeInFlatMenu(url, menuData);
      
      if (code) {
        console.log('   ✓ Encontrado en localStorage');
        return code;
      }
    } catch (error) {
      console.log('   ⚠️ Error buscando en localStorage:', error);
    }

    return null;
  }

  /**
   * Obtiene el código actual del programa
   * @returns Código del programa (ej: CC0046)
   */
  getCurrentProgramCode(): string {
    return this.currentProgramCode();
  }

  /**
   * Obtiene el nombre actual del programa
   * @returns Nombre del programa
   */
  getCurrentProgramName(): string {
    return this.currentProgramName();
  }

  /**
   * Establece manualmente el código del programa
   * @param code Código del programa
   * @param name Nombre del programa (opcional)
   */
  setProgramCode(code: string, name?: string): void {
    this.currentProgramCode.set(code);
    if (name) {
      this.currentProgramName.set(name);
    }
    console.log('📝 Código de programa establecido:', {
      code: code,
      name: name || this.currentProgramName()
    });
  }

  /**
   * Obtiene el prefijo para concatenar con títulos como SIGNAL REACTIVO
   * @returns Signal con el prefijo (ej: "CC0046 - ")
   */
  getTitlePrefixSignal() {
    return this.programCodeDisplay;
  }

  /**
   * Obtiene el prefijo para concatenar con títulos
   * @returns String para concatenar (ej: "CC0046 - ")
   */
  getTitlePrefix(): string {
    return this.programCodeDisplay();
  }

  /**
   * Limpia el contexto del programa
   */
  clearContext(): void {
    this.currentProgramCode.set('');
    this.currentProgramName.set('');
  }
}

