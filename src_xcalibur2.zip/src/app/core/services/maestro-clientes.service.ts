import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

/**
 * Interface para el response del servicio GetMaestroClientesT
 */
export interface ClienteData {
  codigo: string;
  nombre: string;
  codigoVendedor?: string;
  condicionPago?: string;
  direccion?: string;
  telefono?: string;
  fax?: string;
  telex?: string;
  zonaPostal?: string;
  rif?: string;
  nit?: string;
  fechaIngreso?: string;
  limite?: string;
  descuento?: string;
  personaContacto?: string;
  comentarios?: string;
  pais?: string;
  ciudad?: string;
  zona?: string;
  localidad?: string;
  negocio?: string;
  tipoCliente?: string;
  moneda?: string;
  cobrador?: string;
  clasificacionVenta?: string;
  clasificacionCobro?: string;
  tipoPrecio?: string;
  losLineOfService?: string;
  sublosSubline?: string;
  productGroup?: string;
  affinity?: string;
  codRetencion?: string;
  backOrder?: string;
  razonSocial?: string;
  codigoCep?: string;
  codigoSms?: string;
  transporte?: string;
  ruta?: string;
  sector?: string;
  email?: string;
  contribuyente?: string;
  direccionEntrega?: string;
  auxiliar?: string;
  codigoCartera?: string;
  [key: string]: any; // Para campos adicionales
}

export interface MaestroClientesResponse {
  response: {
    pcArchCSV: string; // Base64 encoded CSV
  };
}

@Injectable({
  providedIn: 'root'
})
export class MaestroClientesService {
  private readonly apiUrl = `${environment.apiUrl}/GetMaestroClientesT`;

  constructor(private http: HttpClient) {}

  /**
   * Obtiene el maestro de clientes del endpoint
   * @param pcCompania Código de la compañía
   * @param pcLogin Login del usuario
   * @param pcSuper Super usuario
   * @param pcToken Token de autenticación
   * @returns Observable con los datos del maestro de clientes
   */
  getMaestroClientes(
    pcCompania: string,
    pcLogin: string,
    pcSuper: string,
    pcToken: string
  ): Observable<MaestroClientesResponse> {
    const params = new HttpParams()
      .set('pcCompania', pcCompania)
      .set('pcLogin', pcLogin)
      .set('pcSuper', pcSuper)
      .set('pcToken', pcToken);

    return this.http.get<MaestroClientesResponse>(this.apiUrl, { params });
  }

  /**
   * Decodifica el CSV base64 y lo convierte en datos estructurados
   * @param base64CSV CSV codificado en base64
   * @returns Array de objetos ClienteData
   */
  parseCSVData(base64CSV: string): ClienteData[] {
    try {
      // Decodificar base64
      const csvString = atob(base64CSV);
      const lines = csvString.split('\n');

      if (lines.length < 2) {
        return [];
      }

      // Parsear el encabezado
      const headers = this.parseCSVLine(lines[0]);

      // Parsear las filas de datos
      const datos: ClienteData[] = [];
      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        const values = this.parseCSVLine(line);
        const cliente: any = {};

        headers.forEach((header, index) => {
          cliente[this.normalizaHeaderKey(header)] = values[index] || '';
        });

        datos.push(cliente as ClienteData);
      }

      return datos;
    } catch (error) {
      console.error('Error al parsear CSV:', error);
      return [];
    }
  }

  /**
   * Parsea una línea CSV considerando comillas y caracteres especiales
   * @param line Línea CSV
   * @returns Array de valores
   */
  private parseCSVLine(line: string): string[] {
    const result: string[] = [];
    let current = '';
    let insideQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      const nextChar = line[i + 1];

      if (char === '"') {
        if (insideQuotes && nextChar === '"') {
          current += '"';
          i++;
        } else {
          insideQuotes = !insideQuotes;
        }
      } else if (char === ';' && !insideQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }

    result.push(current.trim());
    return result;
  }

  /**
   * Normaliza las claves del header para usarlas como propiedades del objeto
   * @param header Header string
   * @returns Clave normalizada
   */
  private normalizaHeaderKey(header: string): string {
    return header
      .toLowerCase()
      .trim()
      .replace(/["\s]+/g, '')
      .replace(/\./g, '')
      .replace(/ó/g, 'o')
      .replace(/á/g, 'a')
      .replace(/é/g, 'e')
      .replace(/í/g, 'i')
      .replace(/ú/g, 'u');
  }

  /**
   * Exporta los datos a un archivo CSV
   * @param datos Array de datos a exportar
   * @param nombreArchivo Nombre del archivo a descargar
   */
  exportToCSV(datos: ClienteData[], nombreArchivo: string = 'maestro-clientes.csv'): void {
    if (!datos || datos.length === 0) {
      console.error('No hay datos para exportar');
      return;
    }

    try {
      // Obtener todas las claves posibles
      const allKeys = new Set<string>();
      datos.forEach(item => {
        Object.keys(item).forEach(key => allKeys.add(key));
      });
      const headers = Array.from(allKeys);

      // Crear el contenido CSV
      const csvContent = [
        headers.join(';'),
        ...datos.map(row =>
          headers.map(header => {
            const value = row[header] || '';
            // Escapar valores que contengan comillas o punto y coma
            if (typeof value === 'string' && (value.includes(';') || value.includes('"'))) {
              return `"${value.replace(/"/g, '""')}"`;
            }
            return value;
          }).join(';')
        )
      ].join('\n');

      // Crear y descargar el archivo
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      
      link.setAttribute('href', url);
      link.setAttribute('download', nombreArchivo);
      link.setAttribute('style', 'visibility:hidden');
      
      document.body.appendChild(link);
      
      // Pequeño delay para asegurar que el elemento está en el DOM
      setTimeout(() => {
        link.click();
        // Limpiar
        setTimeout(() => {
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
        }, 100);
      }, 10);
      
      console.log('✅ CSV generado y descargado:', nombreArchivo);
    } catch (error) {
      console.error('❌ Error al exportar CSV:', error);
    }
  }
}
