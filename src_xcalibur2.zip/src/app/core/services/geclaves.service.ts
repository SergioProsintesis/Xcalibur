import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { AuthService } from './auth.service';
import { GeclavesResponse, GeclavesRecord } from '../interfaces/geclaves.interface';

@Injectable({ providedIn: 'root' })
export class GeclavesService {
  constructor(private http: HttpClient, private auth: AuthService) {}

  /** GET GE0056: obtiene fecha de proceso y contexto de claves */
  getFechaProceso(pcFechaProceso: string | null = null): Observable<GeclavesRecord | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const base = `${environment.apiUrl}/GetLeaveFechaProceso-ge0056`;
    const params = new URLSearchParams();
    params.set('pcFechaProceso', pcFechaProceso ?? '');
    params.set('pcLogin', pcLogin);
    params.set('pcSuper', pcSuper);
    params.set('pcToken', pcToken);

    const url = `${base}?${params.toString()}`;

    return this.http.get<GeclavesResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tgeclaves?.[0] ?? null),
      catchError(err => {
        console.error('Error getFechaProceso', err);
        return of(null);
      })
    );
  }

  /** PUT GE0056: reinicia usando la fecha de proceso indicada */
  reiniciar(pcFechaProceso: string): Observable<GeclavesRecord | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const base = `${environment.apiUrl}/UpdateGeclaves-ge0056`;
    const params = new URLSearchParams();
    params.set('pcFechaProceso', pcFechaProceso);
    params.set('pcLogin', pcLogin);
    params.set('pcSuper', pcSuper);
    params.set('pcToken', pcToken);

    const url = `${base}?${params.toString()}`;

    return this.http.put<GeclavesResponse>(url, {}).pipe(
      map(res => res?.dsRespuesta?.tgeclaves?.[0] ?? null),
      catchError(err => {
        console.error('Error reiniciar', err);
        return of(null);
      })
    );
  }

  /** GE0058: valida nueva contraseña (NPassword2) para reglas (mayúsculas, especiales, números, longitud) */
  validarNuevaPassword(pcLoginP: string, pcNPassword2: string): Observable<GeclavesRecord[] | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';
    const base = `${environment.apiUrl}/GetLeaveNPassword2-ge0058`;
    const params = new URLSearchParams();
    params.set('pcLoginP', pcLoginP);
    params.set('pcNPassword2', pcNPassword2);
    params.set('pcLogin', pcLogin);
    params.set('pcSuper', pcSuper);
    params.set('pcToken', pcToken);
    const url = `${base}?${params.toString()}`;
    return this.http.get<GeclavesResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tgeclaves || null),
      catchError(err => { console.error('Error validarNuevaPassword', err); return of(null); })
    );
  }

  /** GE0058: valida fecha inicio para password */
  validarFechaInicio(pcLoginP: string, pcFechaInicio: string): Observable<GeclavesRecord | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';
    const base = `${environment.apiUrl}/GetLeaveFechaInicio-ge0058`;
    const params = new URLSearchParams();
    params.set('pcLoginP', pcLoginP);
    params.set('pcFechaInicio', pcFechaInicio);
    params.set('pcLogin', pcLogin);
    params.set('pcSuper', pcSuper);
    params.set('pcToken', pcToken);
    const url = `${base}?${params.toString()}`;
    return this.http.get<GeclavesResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tgeclaves?.[0] || null),
      catchError(err => { console.error('Error validarFechaInicio', err); return of(null); })
    );
  }

  /** GE0058: actualiza password (PUT) */
  actualizarPassword(paramsIn: { pcLoginP: string; pcNPassword1: string; pcNPassword2: string; pcFechaInicio: string }): Observable<GeclavesRecord | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';
    const base = `${environment.apiUrl}/UpdateGeclaves-ge0058`;
    const params = new URLSearchParams();
    params.set('pcLoginP', paramsIn.pcLoginP);
    params.set('pcNPassword1', paramsIn.pcNPassword1);
    params.set('pcNPassword2', paramsIn.pcNPassword2);
    params.set('pcFechaInicio', paramsIn.pcFechaInicio);
    params.set('pcLogin', pcLogin);
    params.set('pcSuper', pcSuper);
    params.set('pcToken', pcToken);
    const url = `${base}?${params.toString()}`;
    return this.http.put<GeclavesResponse>(url, {}).pipe(
      map(res => res?.dsRespuesta?.tgeclaves?.[0] || null),
      catchError(err => { console.error('Error actualizarPassword', err); return of(null); })
    );
  }
}
