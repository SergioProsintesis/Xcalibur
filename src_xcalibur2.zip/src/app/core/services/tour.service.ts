import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface TourStep {
  title: string;
  description: string;
  element?: string;
  position?: 'top' | 'bottom' | 'left' | 'right';
  action?: () => void;
  highlight?: boolean;
}

export interface Tour {
  id: string;
  name: string;
  description: string;
  steps: TourStep[];
  category: string;
}

@Injectable({
  providedIn: 'root'
})
export class TourService {
  private activeTourSubject = new BehaviorSubject<Tour | null>(null);
  private currentStepSubject = new BehaviorSubject<number>(0);
  private isRunningSubject = new BehaviorSubject<boolean>(false);
  private toursSubject = new BehaviorSubject<Tour[]>([]);

  public activeTour$ = this.activeTourSubject.asObservable();
  public currentStep$ = this.currentStepSubject.asObservable();
  public isRunning$ = this.isRunningSubject.asObservable();
  public tours$ = this.toursSubject.asObservable();

  constructor() {
    this.initializeTours();
  }

  private initializeTours(): void {
    const allTours: Tour[] = [
      // CRUD Tours
      {
        id: 'mant-tipo-cliente-tour',
        name: 'Mantenimiento de Tipo de Cliente',
        description: 'Aprenda a crear, editar y gestionar tipos de cliente',
        category: 'CC',
        steps: [
          {
            title: 'Seleccionar Compañía',
            description: 'Primero, debe seleccionar una compañía. Haga clic en el botón de búsqueda para elegir una compañía.',
            element: '[data-tour="cia-field"]',
            position: 'bottom',
            highlight: true
          },
          {
            title: 'Crear Nuevo Tipo de Cliente',
            description: 'Una vez seleccionada la compañía, puede crear un nuevo tipo de cliente haciendo clic en el botón "Crear".',
            element: '[data-tour="btn-create"]',
            position: 'bottom',
            highlight: true
          },
          {
            title: 'Completar Formulario',
            description: 'Complete los campos requeridos: código, descripción y comentarios opcionales.',
            element: '[data-tour="form-modal"]',
            position: 'top',
            highlight: true
          },
          {
            title: 'Guardar Cambios',
            description: 'Haga clic en "Crear" para guardar el nuevo tipo de cliente.',
            element: '[data-tour="btn-create-modal"]',
            position: 'bottom',
            highlight: true
          },
          {
            title: 'Consultar Registros',
            description: 'Ingrese el código de un tipo de cliente existente para consultarlo y editarlo.',
            element: '[data-tour="tipo-cliente-field"]',
            position: 'bottom',
            highlight: true
          },
          {
            title: 'Generar Reporte',
            description: 'Use el botón "Reporte" para descargar un PDF con todos los tipos de cliente de la compañía.',
            element: '[data-tour="btn-reporte"]',
            position: 'bottom',
            highlight: true
          }
        ]
      },
      {
        id: 'mant-tipo-negocio-tour',
        name: 'Mantenimiento de Tipo de Negocio',
        description: 'Aprenda a gestionar tipos de negocio',
        category: 'CC',
        steps: [
          {
            title: 'Seleccionar Compañía',
            description: 'Seleccione una compañía para empezar.',
            element: '[data-tour="cia-field"]',
            position: 'bottom',
            highlight: true
          },
          {
            title: 'Crear Nuevo',
            description: 'Haga clic en "Crear" para abrir el formulario de creación.',
            element: '[data-tour="btn-create"]',
            position: 'bottom',
            highlight: true
          },
          {
            title: 'Completar Datos',
            description: 'Ingrese el código y descripción del tipo de negocio.',
            element: '[data-tour="form-modal"]',
            position: 'top',
            highlight: true
          },
          {
            title: 'Guardar',
            description: 'Haga clic en "Crear" para guardar.',
            element: '[data-tour="btn-create-modal"]',
            position: 'bottom',
            highlight: true
          }
        ]
      },
      {
        id: 'mant-zona-venta-tour',
        name: 'Mantenimiento de Zona de Venta',
        description: 'Gestione zonas de venta',
        category: 'CC',
        steps: [
          {
            title: 'Seleccionar Compañía',
            description: 'Seleccione una compañía.',
            element: '[data-tour="cia-field"]',
            position: 'bottom',
            highlight: true
          },
          {
            title: 'Crear Zona',
            description: 'Haga clic en "Crear" para crear una nueva zona de venta.',
            element: '[data-tour="btn-create"]',
            position: 'bottom',
            highlight: true
          }
        ]
      }
    ];

    this.toursSubject.next(allTours);
  }

  public startTour(tourId: string): void {
    const tours = this.toursSubject.value;
    const tour = tours.find(t => t.id === tourId);
    
    if (tour) {
      this.activeTourSubject.next(tour);
      this.currentStepSubject.next(0);
      this.isRunningSubject.next(true);
    }
  }

  public nextStep(): void {
    const tour = this.activeTourSubject.value;
    const currentStep = this.currentStepSubject.value;
    
    if (tour && currentStep < tour.steps.length - 1) {
      this.currentStepSubject.next(currentStep + 1);
    }
  }

  public prevStep(): void {
    const currentStep = this.currentStepSubject.value;
    if (currentStep > 0) {
      this.currentStepSubject.next(currentStep - 1);
    }
  }

  public endTour(): void {
    this.activeTourSubject.next(null);
    this.currentStepSubject.next(0);
    this.isRunningSubject.next(false);
  }

  public getCurrentStep(): TourStep | null {
    const tour = this.activeTourSubject.value;
    const currentStep = this.currentStepSubject.value;
    
    if (tour) {
      return tour.steps[currentStep] || null;
    }
    return null;
  }

  public getTourProgress(): { current: number; total: number } {
    const tour = this.activeTourSubject.value;
    const currentStep = this.currentStepSubject.value;
    
    return {
      current: currentStep + 1,
      total: tour ? tour.steps.length : 0
    };
  }

  public getToursByCategory(category: string): Tour[] {
    return this.toursSubject.value.filter(tour => tour.category === category);
  }

  public addTour(tour: Tour): void {
    const currentTours = this.toursSubject.value;
    this.toursSubject.next([...currentTours, tour]);
  }
}
