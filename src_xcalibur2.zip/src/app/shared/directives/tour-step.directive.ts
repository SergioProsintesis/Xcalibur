import { Directive, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[appTourStep]',
  standalone: true
})
export class TourStepDirective {
  @Input() appTourStep!: string;
  @Input() tourHighlight: boolean = true;

  constructor(public elementRef: ElementRef) {}

  highlight(): void {
    if (this.tourHighlight) {
      this.elementRef.nativeElement.classList.add('tour-highlight');
    }
  }

  unhighlight(): void {
    this.elementRef.nativeElement.classList.remove('tour-highlight');
  }
}
