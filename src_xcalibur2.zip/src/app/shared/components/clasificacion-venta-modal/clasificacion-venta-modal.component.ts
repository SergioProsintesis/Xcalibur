import { Component, EventEmitter, Input, OnInit, OnChanges, Output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CCService } from '../../../core/services/cc.service';
import { ClasificacionVentaRecord } from '../../../core/interfaces/cc.interface';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-clasificacion-venta-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './clasificacion-venta-modal.component.html',
  styleUrls: ['./clasificacion-venta-modal.component.css']
})
export class ClasificacionVentaModalComponent implements OnInit, OnChanges {
  @Input() visible = false;
  @Input() companiaId: string = '';
  @Output() clasificacionSelected = new EventEmitter<ClasificacionVentaRecord>();
  @Output() modalClosed = new EventEmitter<void>();

  // Señales para el estado del componente
  isVisible = signal(false);
  isLoading = signal(false);
  error = signal<string | null>(null);
  clasificaciones = signal<ClasificacionVentaRecord[]>([]);
  filteredClasificaciones = signal<ClasificacionVentaRecord[]>([]);
  selectedClasificacion = signal<ClasificacionVentaRecord | null>(null);

  // Filtros
  searchTerm = '';

  constructor(
    private ccService: CCService,
    private toastService: ToastService
  ) {}

  ngOnInit() {
    if (this.companiaId) {
      this.loadClasificaciones();
    }
  }

  ngOnChanges() {
    this.isVisible.set(this.visible);
    if (this.visible && this.companiaId) {
      // Recargar si cambió la compañía
      this.loadClasificaciones();
    }
  }

  loadClasificaciones() {
    if (!this.companiaId) {
      this.error.set('No se ha especificado la compañía');
      return;
    }

    this.isLoading.set(true);
    this.error.set(null);
    
    this.ccService.getClasificacionesVenta(this.companiaId).subscribe({
      next: (data) => {
        this.clasificaciones.set(data);
        this.filterClasificaciones();
        this.isLoading.set(false);
      },
      error: (error) => {
        console.error('Error loading clasificaciones:', error);
        this.error.set('Error al cargar las clasificaciones de venta');
        this.toastService.showError('Error al cargar clasificaciones de venta');
        this.isLoading.set(false);
      }
    });
  }

  filterClasificaciones() {
    let filtered = [...this.clasificaciones()];
    
    // Filtrar por término de búsqueda
    if (this.searchTerm.trim()) {
      const term = this.searchTerm.toLowerCase().trim();
      filtered = filtered.filter(clasificacion => 
        clasificacion.claven.toLowerCase().includes(term) ||
        clasificacion['nombre-cven'].toLowerCase().includes(term) ||
        (clasificacion['text-cven'] && clasificacion['text-cven'].toLowerCase().includes(term))
      );
    }
    
    this.filteredClasificaciones.set(filtered);
  }

  selectClasificacion(clasificacion: ClasificacionVentaRecord) {
    this.selectedClasificacion.set(clasificacion);
  }

  selectAndClose(clasificacion: ClasificacionVentaRecord, event: Event) {
    event.stopPropagation();
    this.selectedClasificacion.set(clasificacion);
    this.confirmSelection();
  }

  confirmSelection() {
    const selected = this.selectedClasificacion();
    if (selected) {
      this.clasificacionSelected.emit(selected);
      this.closeModal();
    }
  }

  closeModal() {
    this.isVisible.set(false);
    this.selectedClasificacion.set(null);
    this.searchTerm = '';
    this.modalClosed.emit();
  }

  trackByClasificacion(index: number, clasificacion: ClasificacionVentaRecord): string {
    return clasificacion.claven;
  }
}