import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-help-icon',
  standalone: true,
  imports: [CommonModule],
  template: `
    <button
      type="button"
      class="help-icon-btn"
      [title]="tooltip"
      [attr.aria-label]="tooltip || 'Ayuda'"
      [class.help-icon-sm]="size === 'sm'"
      [class.help-icon-md]="size === 'md'"
      [class.help-icon-lg]="size === 'lg'"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        stroke-width="2"
        class="help-icon-svg"
      >
        <path
          stroke-linecap="round"
          stroke-linejoin="round"
          d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
        />
      </svg>
    </button>
  `,
  styles: [`
    .help-icon-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      background: none;
      border: none;
      cursor: help;
      padding: 0;
      color: #64748b;
      transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
      border-radius: 50%;
      flex-shrink: 0;
    }

    .help-icon-btn:hover {
      color: #3b82f6;
      background: rgba(59, 130, 246, 0.1);
      transform: scale(1.1);
    }

    .help-icon-btn:focus {
      outline: none;
      ring: 2px solid #3b82f6;
      ring-offset: 2px;
    }

    .help-icon-btn:active {
      transform: scale(0.95);
    }

    .help-icon-svg {
      width: 1em;
      height: 1em;
      stroke-width: 2;
    }

    /* Size variants */
    .help-icon-sm {
      font-size: 16px;
      width: 16px;
      height: 16px;
    }

    .help-icon-md {
      font-size: 20px;
      width: 20px;
      height: 20px;
    }

    .help-icon-lg {
      font-size: 24px;
      width: 24px;
      height: 24px;
    }

    /* Default: sm */
    .help-icon-btn {
      font-size: 16px;
      width: 16px;
      height: 16px;
    }
  `]
})
export class HelpIconComponent {
  @Input() tooltip: string = '';
  @Input() size: 'sm' | 'md' | 'lg' = 'sm';
}
