import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { trigger, transition, style, animate } from '@angular/animations';
import { TourService, TourStep } from '../../../core/services/tour.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-tour',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div *ngIf="showTour" class="tour-overlay" (click)="closeTour()">
      <div class="tour-spotlight" [style]="spotlightStyle"></div>
      
      <div class="tour-popup" [style]="popupStyle" [@popupAnimation]>
        <div class="tour-header">
          <h3>{{ tourTitle }}</h3>
          <button class="tour-close" (click)="closeTour()" aria-label="Cerrar tour">
            <span>×</span>
          </button>
        </div>

        <div class="tour-content">
          <h4>{{ currentStepTitle }}</h4>
          <p>{{ currentStepDescription }}</p>
        </div>

        <div class="tour-progress">
          <div class="progress-bar">
            <div class="progress-fill" [style.width.%]="progressPercent"></div>
          </div>
          <span>Paso {{ currentStepNumber }} de {{ totalSteps }}</span>
        </div>

        <div class="tour-actions">
          <button 
            class="btn-nav btn-prev" 
            (click)="prevStep()" 
            [disabled]="currentStepNumber === 1"
            aria-label="Paso anterior">
            ← Anterior
          </button>

          <button 
            class="btn-nav btn-skip" 
            (click)="closeTour()"
            aria-label="Saltar tour">
            Saltar
          </button>

          <button 
            class="btn-nav btn-next" 
            (click)="nextStep()" 
            [disabled]="currentStepNumber === totalSteps"
            aria-label="Siguiente paso">
            Siguiente →
          </button>
        </div>

        <div *ngIf="currentStepNumber === totalSteps" class="tour-finish">
          <button class="btn-finish" (click)="closeTour()">
            ¡Entendido! Empezar
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .tour-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.7);
      z-index: 9999;
      cursor: pointer;
    }

    .tour-spotlight {
      position: fixed;
      border-radius: 8px;
      box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.7);
      transition: all 0.3s ease-in-out;
      z-index: 10000;
    }

    .tour-popup {
      position: fixed;
      background: white;
      border-radius: 12px;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
      z-index: 10001;
      max-width: 400px;
      padding: 24px;
      color: #333;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }

    .tour-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
      padding-bottom: 12px;
      border-bottom: 2px solid #f0f0f0;
    }

    .tour-header h3 {
      margin: 0;
      font-size: 18px;
      color: #2c3e50;
      font-weight: 600;
    }

    .tour-close {
      background: none;
      border: none;
      font-size: 28px;
      cursor: pointer;
      color: #999;
      transition: color 0.2s;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .tour-close:hover {
      color: #333;
    }

    .tour-content {
      margin-bottom: 20px;
    }

    .tour-content h4 {
      margin: 0 0 8px 0;
      font-size: 16px;
      color: #2c3e50;
      font-weight: 600;
    }

    .tour-content p {
      margin: 0;
      font-size: 14px;
      color: #666;
      line-height: 1.6;
    }

    .tour-progress {
      margin-bottom: 20px;
    }

    .progress-bar {
      background: #f0f0f0;
      height: 4px;
      border-radius: 2px;
      margin-bottom: 8px;
      overflow: hidden;
    }

    .progress-fill {
      background: linear-gradient(90deg, #667ee6, #667ee6);
      height: 100%;
      transition: width 0.3s ease;
    }

    .tour-progress > span {
      font-size: 12px;
      color: #999;
    }

    .tour-actions {
      display: flex;
      gap: 8px;
      margin-bottom: 12px;
    }

    .btn-nav {
      flex: 1;
      padding: 10px 12px;
      border: 2px solid #ddd;
      background: white;
      border-radius: 6px;
      cursor: pointer;
      font-size: 13px;
      font-weight: 500;
      transition: all 0.2s;
      color: #333;
    }

    .btn-nav:hover:not(:disabled) {
      border-color: #667ee6;
      color: #667ee6;
      background: #f8f9ff;
    }

    .btn-nav:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .btn-prev, .btn-skip {
      flex: 0.8;
    }

    .btn-next {
      flex: 0.8;
    }

    .btn-finish {
      width: 100%;
      padding: 12px;
      background: linear-gradient(135deg, #667ee6, #5a69d8);
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
    }

    .btn-finish:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(102, 126, 234, 0.35);
    }

    .tour-finish {
      padding-top: 12px;
      border-top: 2px solid #f0f0f0;
    }

    .tour-highlight {
      position: relative;
      z-index: 10002;
    }
  `],
  animations: [
    trigger('popupAnimation', [
      transition(':enter', [
        style({ opacity: 0, transform: 'scale(0.9)' }),
        animate('300ms ease-out', style({ opacity: 1, transform: 'scale(1)' }))
      ]),
      transition(':leave', [
        animate('300ms ease-in', style({ opacity: 0, transform: 'scale(0.9)' }))
      ])
    ])
  ]
})
export class TourComponent implements OnInit, OnDestroy {
  private tourService = inject(TourService);
  private destroy$ = new Subject<void>();

  showTour = false;
  tourTitle = '';
  currentStepTitle = '';
  currentStepDescription = '';
  currentStepNumber = 0;
  totalSteps = 0;
  progressPercent = 0;
  spotlightStyle = '';
  popupStyle = '';

  ngOnInit(): void {
    this.tourService.isRunning$
      .pipe(takeUntil(this.destroy$))
      .subscribe((isRunning: any) => {
        this.showTour = isRunning;
      });

    this.tourService.activeTour$
      .pipe(takeUntil(this.destroy$))
      .subscribe((tour: any) => {
        if (tour) {
          this.tourTitle = tour.name;
        }
      });

    this.tourService.currentStep$
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        this.updateTourDisplay();
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private updateTourDisplay(): void {
    const step = this.tourService.getCurrentStep();
    const progress = this.tourService.getTourProgress();

    this.currentStepNumber = progress.current;
    this.totalSteps = progress.total;
    this.progressPercent = this.totalSteps > 0 ? (this.currentStepNumber / this.totalSteps) * 100 : 0;

    if (step) {
      this.currentStepTitle = step.title;
      this.currentStepDescription = step.description;
      this.updateSpotlight(step);
      this.updatePopupPosition(step);
    }
  }

  private updateSpotlight(step: TourStep): void {
    if (!step.element) {
      this.spotlightStyle = 'display: none;';
      return;
    }

    setTimeout(() => {
      const element = document.querySelector(step.element!);
      if (element) {
        const rect = element.getBoundingClientRect();
        const padding = 8;
        
        this.spotlightStyle = `
          top: ${rect.top - padding + window.scrollY}px;
          left: ${rect.left - padding + window.scrollX}px;
          width: ${rect.width + (padding * 2)}px;
          height: ${rect.height + (padding * 2)}px;
        `;
      }
    }, 50);
  }

  private updatePopupPosition(step: TourStep): void {
    if (!step.element) {
      this.popupStyle = `
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
      `;
      return;
    }

    setTimeout(() => {
      const element = document.querySelector(step.element!);
      if (element) {
        const rect = element.getBoundingClientRect();
        const padding = 20;
        let top: number;
        let left: number;

        switch (step.position || 'bottom') {
          case 'top':
            top = rect.top - 380 + window.scrollY;
            left = rect.left + (rect.width / 2) + window.scrollX;
            break;
          case 'bottom':
            top = rect.bottom + padding + window.scrollY;
            left = rect.left + (rect.width / 2) + window.scrollX;
            break;
          case 'left':
            top = rect.top + (rect.height / 2) + window.scrollY;
            left = rect.left - 420 + window.scrollX;
            break;
          case 'right':
            top = rect.top + (rect.height / 2) + window.scrollY;
            left = rect.right + padding + window.scrollX;
            break;
          default:
            top = rect.bottom + padding + window.scrollY;
            left = rect.left + (rect.width / 2) + window.scrollX;
        }

        this.popupStyle = `
          top: ${top}px;
          left: ${left}px;
          transform: translateX(-50%);
        `;
      }
    }, 50);
  }

  nextStep(): void {
    this.tourService.nextStep();
  }

  prevStep(): void {
    this.tourService.prevStep();
  }

  closeTour(): void {
    this.tourService.endTour();
  }
}
