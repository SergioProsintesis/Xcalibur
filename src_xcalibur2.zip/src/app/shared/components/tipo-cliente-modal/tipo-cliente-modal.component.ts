import { Component, Input, Output, EventEmitter, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TipoClienteRecord } from '../../../core/interfaces/cc.interface';

@Component({
  selector: 'app-tipo-cliente-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './tipo-cliente-modal.component.html',
  styleUrls: ['./tipo-cliente-modal.component.css']
})
export class TipoClienteModalComponent {
  @Input() visible: boolean = false;
  @Input() set tiposCliente(value: TipoClienteRecord[]) {
    this._tiposCliente.set(value);
  }
  
  @Output() tipoClienteSelected = new EventEmitter<TipoClienteRecord>();
  @Output() closed = new EventEmitter<void>();

  _tiposCliente = signal<TipoClienteRecord[]>([]);
  searchTerm = signal<string>('');

  filteredTiposCliente = computed(() => {
    const term = this.searchTerm().toLowerCase();
    const tipos = this._tiposCliente();
    
    if (!term) return tipos;
    
    return tipos.filter(tipo => 
      tipo.tipocli.toString().includes(term) ||
      tipo['nombre-tipc']?.toLowerCase().includes(term) ||
      tipo['text-tipc']?.toLowerCase().includes(term)
    );
  });

  selectTipoCliente(tipo: TipoClienteRecord): void {
    this.tipoClienteSelected.emit(tipo);
    this.close();
  }

  close(): void {
    this.searchTerm.set('');
    this.closed.emit();
  }

  onSearch(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.searchTerm.set(value);
  }

  clearSearch(): void {
    this.searchTerm.set('');
  }
}
