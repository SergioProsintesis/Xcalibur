import { Component, Input, Output, EventEmitter, signal, computed, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

export interface ZonaVentaRecord {
  zona: number;
  cia: number;
  'nombre-cia': string;
  'nombre-zon': string;
  'text-zon': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  tparent?: string;
}

@Component({
  selector: 'app-zona-venta-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="modal-backdrop" *ngIf="visible" (click)="close()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2 class="modal-title">Seleccionar Zona de Venta</h2>
          <button type="button" class="close-btn" (click)="close()">&times;</button>
        </div>

        <div class="modal-body">
          <div class="search-form">
            <div class="search-field">
              <label class="field-label">Buscar por código o nombre</label>
              <input 
                type="text" 
                placeholder="Escriba para buscar..." 
                class="search-input"
                [value]="searchTerm()"
                (input)="onSearch($event)">
            </div>
          </div>

          <div class="zonas-grid" *ngIf="filteredZonas().length > 0; else noResults">
            <div class="grid-header">
              <div class="header-cell">Código</div>
              <div class="header-cell">Nombre</div>
              <div class="header-cell">Comentario</div>
              <div class="header-cell">Acción</div>
            </div>
            <div class="grid-body">
              <div class="grid-row" *ngFor="let zona of filteredZonas(); trackBy: trackByZona">
                <div class="grid-cell">{{ zona.zona }}</div>
                <div class="grid-cell">{{ zona['nombre-zon'] }}</div>
                <div class="grid-cell">{{ zona['text-zon'] || '-' }}</div>
                <div class="grid-cell">
                  <button type="button" class="select-btn" (click)="selectZona(zona)">
                    Seleccionar
                  </button>
                </div>
              </div>
            </div>
          </div>

          <ng-template #noResults>
            <div class="no-results">
              <p>No se encontraron zonas de venta</p>
            </div>
          </ng-template>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn-secondary" (click)="close()">Cancelar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .modal-content {
      background: white;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 900px;
      max-height: 80vh;
      display: flex;
      flex-direction: column;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .modal-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: #003087;
      margin: 0;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #6b7280;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .close-btn:hover {
      color: #374151;
    }

    .modal-body {
      padding: 1.5rem;
      overflow-y: auto;
      flex: 1;
    }

    .search-form {
      margin-bottom: 1.5rem;
    }

    .search-field {
      display: flex;
      flex-direction: column;
    }

    .field-label {
      font-weight: 500;
      color: #374151;
      margin-bottom: 0.5rem;
    }

    .search-input {
      border: 1px solid #d1d5db;
      border-radius: 8px;
      padding: 0.75rem;
      font-size: 0.95rem;
      transition: all 0.2s;
    }

    .search-input:focus {
      outline: none;
      border-color: #003087;
      box-shadow: 0 0 0 2px rgba(0, 48, 135, 0.15);
    }

    .zonas-grid {
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      overflow: hidden;
    }

    .grid-header {
      display: grid;
      grid-template-columns: 80px 2fr 2fr 120px;
      background: #f9fafb;
      border-bottom: 1px solid #e5e7eb;
    }

    .header-cell {
      padding: 0.75rem;
      font-weight: 600;
      font-size: 0.875rem;
      color: #374151;
      border-right: 1px solid #e5e7eb;
    }

    .header-cell:last-child {
      border-right: none;
    }

    .grid-body {
      max-height: 400px;
      overflow-y: auto;
    }

    .grid-row {
      display: grid;
      grid-template-columns: 80px 2fr 2fr 120px;
      border-bottom: 1px solid #f3f4f6;
    }

    .grid-row:hover {
      background: #f9fafb;
    }

    .grid-cell {
      padding: 0.75rem;
      font-size: 0.875rem;
      color: #374151;
      border-right: 1px solid #f3f4f6;
      display: flex;
      align-items: center;
    }

    .grid-cell:last-child {
      border-right: none;
    }

    .select-btn {
      background-color: #003087;
      color: white;
      border: none;
      padding: 0.4rem 0.8rem;
      border-radius: 6px;
      font-size: 0.8rem;
      cursor: pointer;
      transition: background-color 0.2s;
      white-space: nowrap;
    }

    .select-btn:hover {
      background-color: #002066;
    }

    .no-results {
      text-align: center;
      padding: 2rem;
      color: #6b7280;
    }

    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 0.75rem;
      padding: 1.5rem;
      border-top: 1px solid #e5e7eb;
      background: #f9fafb;
    }

    .btn-secondary {
      background-color: #6b7280;
      color: white;
      border: none;
      padding: 0.5rem 1rem;
      border-radius: 6px;
      font-size: 0.875rem;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .btn-secondary:hover {
      background-color: #4b5563;
    }

    @media (max-width: 768px) {
      .modal-content {
        width: 98%;
        max-width: 95vw;
      }

      .grid-header,
      .grid-row {
        grid-template-columns: 70px 1fr 100px;
      }

      .header-cell:nth-child(3),
      .grid-cell:nth-child(3) {
        display: none;
      }
    }
  `]
})
export class ZonaVentaModalComponent {
  @Input() visible: boolean = false;
  @Input() set zonas(value: ZonaVentaRecord[]) {
    this._zonas.set(value);
  }
  
  @Output() zonaSelected = new EventEmitter<ZonaVentaRecord>();
  @Output() closed = new EventEmitter<void>();

  _zonas = signal<ZonaVentaRecord[]>([]);
  searchTerm = signal<string>('');

  filteredZonas = computed(() => {
    const term = this.searchTerm().toLowerCase();
    const zonas = this._zonas();
    
    if (!term) return zonas;
    
    return zonas.filter(zona => 
      zona.zona.toString().includes(term) ||
      zona['nombre-zon']?.toLowerCase().includes(term) ||
      zona['text-zon']?.toLowerCase().includes(term)
    );
  });

  selectZona(zona: ZonaVentaRecord): void {
    this.zonaSelected.emit(zona);
    this.close();
  }

  close(): void {
    this.searchTerm.set('');
    this.closed.emit();
  }

  onSearch(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.searchTerm.set(value);
  }

  trackByZona(index: number, zona: ZonaVentaRecord): number {
    return zona.zona;
  }
}

