import { Component, EventEmitter, Input, OnInit, OnChanges, Output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CCService } from '../../../core/services/cc.service';
import { TipoDocumentoRecord } from '../../../core/interfaces/cc.interface';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-tipo-documento-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <!-- Modal backdrop -->
    <div 
      class="modal-backdrop" 
      *ngIf="isVisible()"
      (click)="closeModal()">
      
      <!-- Modal content -->
      <div 
        class="modal-content"
        (click)="$event.stopPropagation()">
        
        <!-- Modal header -->
        <div class="modal-header">
          <h2 class="modal-title">Seleccionar Tipo de Documento</h2>
          <button 
            type="button" 
            class="close-btn" 
            (click)="closeModal()"
            title="Cerrar">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          
          <!-- Search Form -->
          <form class="search-form">
            <div class="search-field">
              <label class="field-label">Buscar por código o descripción</label>
              <input
                type="text"
                [(ngModel)]="searchTerm"
                (input)="filterDocuments()"
                name="search"
                class="search-input"
                placeholder="Escriba para buscar..."
                autocomplete="off">
            </div>
          </form>
          
          <!-- Loading -->
          <div *ngIf="isLoading()" class="loading-indicator">
            <div class="spinner"></div>
            <span>Cargando tipos de documento...</span>
          </div>
          
          <!-- Error -->
          <div *ngIf="error()" class="error-container">
            <p>{{ error() }}</p>
            <button type="button" class="btn-retry" (click)="loadTiposDocumento()">
              Reintentar
            </button>
          </div>
          
          <!-- Tabla de documentos -->
          <div *ngIf="!isLoading() && !error()" class="documentos-grid">
            
            <!-- Sin resultados -->
            <div *ngIf="filteredDocuments().length === 0" class="no-results">
              <p>No se encontraron tipos de documento</p>
            </div>
            
            <!-- Con resultados -->
            <div *ngIf="filteredDocuments().length > 0">
              <div class="grid-header">
                <div class="header-cell">Código</div>
                <div class="header-cell">Descripción</div>
                <div class="header-cell">Siglas</div>
                <div class="header-cell">Acción</div>
              </div>
              <div class="grid-body">
                <div 
                  *ngFor="let documento of filteredDocuments(); trackBy: trackByDocumento"
                  class="grid-row">
                  
                  <div class="grid-cell">
                    <strong>{{ documento.tipodoc }}</strong>
                  </div>
                  
                  <div class="grid-cell">
                    <div class="document-info">
                      <span class="document-name">{{ documento['nombre-tdoc'] }}</span>
                      <small *ngIf="documento['text-tdoc']" class="document-obs">{{ documento['text-tdoc'] }}</small>
                    </div>
                  </div>
                  
                  <div class="grid-cell">
                    {{ documento['siglas-tdoc'] || '-' }}
                  </div>
                  
                  <div class="grid-cell">
                    <button 
                      type="button"
                      class="select-btn"
                      (click)="selectAndClose(documento, $event)"
                      title="Seleccionar documento">
                      Seleccionar
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn-secondary" (click)="closeModal()">Cancelar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    /* Modal backdrop */
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .modal-content {
      background: white;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 800px;
      max-height: 80vh;
      display: flex;
      flex-direction: column;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .modal-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: #003087;
      margin: 0;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #6b7280;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .close-btn:hover {
      color: #374151;
    }

    .modal-body {
      padding: 1.5rem;
      overflow-y: auto;
      flex: 1;
    }

    .search-form {
      margin-bottom: 1.5rem;
    }

    .search-field {
      display: flex;
      flex-direction: column;
    }

    .field-label {
      font-weight: 500;
      color: #374151;
      margin-bottom: 0.5rem;
      font-size: 0.875rem;
    }

    .search-input {
      border: 1px solid #d1d5db;
      border-radius: 8px;
      padding: 0.75rem;
      font-size: 0.95rem;
      transition: all 0.2s;
    }

    .search-input:focus {
      outline: none;
      border-color: #003087;
      box-shadow: 0 0 0 2px rgba(0, 48, 135, 0.15);
    }

    .documentos-grid {
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      overflow: hidden;
    }

    .grid-header {
      display: grid;
      grid-template-columns: 80px 1fr 80px 120px;
      background: #f9fafb;
      border-bottom: 1px solid #e5e7eb;
    }

    .header-cell {
      padding: 0.75rem;
      font-weight: 600;
      font-size: 0.875rem;
      color: #374151;
      border-right: 1px solid #e5e7eb;
    }

    .header-cell:last-child {
      border-right: none;
    }

    .grid-body {
      max-height: 300px;
      overflow-y: auto;
    }

    .grid-row {
      display: grid;
      grid-template-columns: 80px 1fr 80px 120px;
      border-bottom: 1px solid #f3f4f6;
      transition: background 0.2s;
    }

    .grid-row:hover {
      background: #f9fafb;
    }

    .grid-row.selected {
      background: #f0f7ff;
      border-color: #003087;
    }

    .grid-cell {
      padding: 0.75rem;
      font-size: 0.875rem;
      color: #374151;
      border-right: 1px solid #f3f4f6;
      display: flex;
      align-items: center;
    }

    .grid-cell:last-child {
      border-right: none;
    }

    .document-info {
      display: flex;
      flex-direction: column;
      gap: 0.25rem;
    }

    .document-name {
      font-weight: 500;
      color: #374151;
    }

    .document-obs {
      color: #6b7280;
      font-size: 0.75rem;
    }

    .select-btn {
      background-color: #003087;
      color: white;
      border: none;
      padding: 0.4rem 0.8rem;
      border-radius: 6px;
      font-size: 0.8rem;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .select-btn:hover {
      background-color: #002066;
    }

    .no-results {
      text-align: center;
      padding: 2rem;
      color: #6b7280;
    }

    .loading-indicator {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      color: #6b7280;
    }

    .spinner {
      width: 20px;
      height: 20px;
      border: 2px solid #f3f4f6;
      border-top-color: #003087;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin-right: 0.5rem;
    }

    .error-container {
      text-align: center;
      padding: 2rem;
      color: #6b7280;
    }

    .btn-retry {
      margin-top: 1rem;
      padding: 0.5rem 1rem;
      background: #003087;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .btn-retry:hover {
      background: #002066;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 0.75rem;
      padding: 1.5rem;
      border-top: 1px solid #e5e7eb;
    }

    .btn-secondary {
      background-color: #f3f4f6;
      color: #374151;
      border: 1px solid #d1d5db;
      padding: 0.6rem 1.5rem;
      border-radius: 8px;
      font-weight: 500;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .btn-secondary:hover {
      background-color: #e5e7eb;
    }

    @media (max-width: 768px) {
      .modal-content {
        width: 95%;
        max-height: 90vh;
      }

      .grid-header, .grid-row {
        grid-template-columns: 60px 1fr 60px 100px;
        font-size: 0.75rem;
      }
    }
  `]
})
export class TipoDocumentoModalComponent implements OnInit, OnChanges {
  @Input() visible = false;
  @Input() compania: string | number = '';
  @Output() documentSelected = new EventEmitter<TipoDocumentoRecord>();
  @Output() modalClosed = new EventEmitter<void>();

  // Señales para el estado del componente
  isVisible = signal(false);
  isLoading = signal(false);
  error = signal<string | null>(null);
  tiposDocumento = signal<TipoDocumentoRecord[]>([]);
  filteredDocuments = signal<TipoDocumentoRecord[]>([]);
  loadedCompania = signal<string | number>('');

  // Filtro de búsqueda
  searchTerm = '';

  constructor(
    private ccService: CCService,
    private toastService: ToastService
  ) {}

  ngOnInit() {
    // No cargar en init, esperar a que se abra el modal con la compañía
  }

  ngOnChanges() {
    this.isVisible.set(this.visible);
    if (this.visible && this.compania && this.loadedCompania() !== this.compania) {
      console.log('📂 Abriendo modal con compañía:', this.compania);
      this.loadTiposDocumento();
    }
  }

  loadTiposDocumento() {
    if (!this.compania) {
      this.error.set('No se especificó compañía');
      console.error('❌ Compañía no especificada');
      return;
    }

    this.isLoading.set(true);
    this.error.set(null);
    
    const pcCompania = this.compania.toString();
    console.log('📡 Cargando tipos de documento para compañía:', pcCompania);
    
    this.ccService.getTiposDocumento(pcCompania).subscribe({
      next: (data) => {
        console.log('✅ Tipos de documento cargados:', data.length);
        this.tiposDocumento.set(data);
        this.loadedCompania.set(this.compania);
        this.filterDocuments();
        this.isLoading.set(false);
      },
      error: (error) => {
        console.error('Error loading tipos documento:', error);
        this.error.set('Error al cargar los tipos de documento');
        this.toastService.showError('Error al cargar tipos de documento');
        this.isLoading.set(false);
      }
    });
  }

  filterDocuments() {
    let filtered = [...this.tiposDocumento()];
    
    if (this.searchTerm.trim()) {
      const term = this.searchTerm.toLowerCase().trim();
      filtered = filtered.filter(doc => 
        doc.tipodoc.toString().includes(term) ||
        doc['nombre-tdoc'].toLowerCase().includes(term) ||
        doc['siglas-tdoc'].toLowerCase().includes(term) ||
        (doc['text-tdoc'] && doc['text-tdoc'].toLowerCase().includes(term))
      );
    }
    
    this.filteredDocuments.set(filtered);
  }

  selectAndClose(document: TipoDocumentoRecord, event: Event) {
    event.stopPropagation();
    this.documentSelected.emit(document);
    this.closeModal();
  }

  closeModal() {
    this.isVisible.set(false);
    this.searchTerm = '';
    this.modalClosed.emit();
  }

  trackByDocumento(index: number, documento: TipoDocumentoRecord): string {
    return documento.tipodoc.toString();
  }
}