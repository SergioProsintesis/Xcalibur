import { Component, Input, Output, EventEmitter, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface TabItem {
  id: string;
  label: string;
  title: string;
  disabled?: boolean;
}

@Component({
  selector: 'app-tabs',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="tabs-container">
      <div class="tabs-header">
        @for (tab of tabs; track tab.id; let i = $index) {
          <button
            type="button"
            class="tab-button"
            [class.active]="activeTabId === tab.id"
            [disabled]="tab.disabled"
            (click)="selectTab(tab.id)"
          >
            {{ tab.label }}
          </button>
        }
      </div>
    </div>
  `,
  styles: [`
    .tabs-container {
      margin: 0.8rem 0 1rem 0;
      background: transparent;
      border-bottom: 1px solid #e5e7eb;
      padding: 0;
      box-shadow: none;
      border: none;
    }

    .tabs-header {
      display: flex;
      gap: 0;
      overflow-x: auto;
      overflow-y: hidden;
      scrollbar-width: thin;
      scrollbar-color: #d1d5db #f9fafb;
      padding: 0;
    }

    .tabs-header::-webkit-scrollbar {
      height: 3px;
    }

    .tabs-header::-webkit-scrollbar-track {
      background: transparent;
      border-radius: 10px;
    }

    .tabs-header::-webkit-scrollbar-thumb {
      background: #d1d5db;
      border-radius: 10px;
    }

    .tabs-header::-webkit-scrollbar-thumb:hover {
      background: #9ca3af;
    }

    .tab-button {
      border-radius: 0;
      padding: 12px 16px;
      border: none;
      background: transparent;
      color: #6b7280;
      font-weight: 500;
      font-size: 0.9rem;
      cursor: pointer;
      transition: all 0.2s ease;
      position: relative;
      white-space: nowrap;
      flex-shrink: 0;
      box-shadow: none;
      letter-spacing: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: auto;
      border-bottom: 2px solid transparent;
    }

    .tab-button::before {
      content: '';
      position: absolute;
      bottom: -1px;
      left: 0;
      right: 0;
      height: 0;
      background: transparent;
      transition: all 0.2s ease;
    }

    .tab-button:hover:not(:disabled):not(.active) {
      background: transparent;
      color: #374151;
      box-shadow: none;
    }

    .tab-button.active {
      background: transparent;
      color: #1e40af;
      font-weight: 600;
      border-bottom-color: #1e40af;
      box-shadow: none;
    }

    .tab-button:disabled {
      background: transparent;
      color: #d1d5db;
      cursor: not-allowed;
      opacity: 1;
      box-shadow: none;
    }

    .tab-button:focus {
      outline: none;
    }

    @media (max-width: 768px) {
      .tabs-container {
        margin: 0.6rem 0 0.8rem 0;
      }

      .tab-button {
        padding: 10px 12px;
        font-size: 0.85rem;
      }
    }

    @media (max-width: 480px) {
      .tabs-container {
        margin: 0.5rem 0 0.6rem 0;
      }

      .tab-button {
        padding: 8px 10px;
        font-size: 0.8rem;
      }
    }
  `]
})
export class TabsComponent {
  @Input() tabs: TabItem[] = [];
  @Input() activeTabId: string = '';
  @Output() tabChanged = new EventEmitter<string>();

  selectTab(tabId: string): void {
    if (this.activeTabId !== tabId) {
      this.tabChanged.emit(tabId);
    }
  }
}
