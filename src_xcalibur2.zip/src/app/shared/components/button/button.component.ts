import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

export type ButtonType = 'primary' | 'secondary' | 'danger' | 'success' | 'warning' | 'info';
export type ButtonSize = 'sm' | 'md' | 'lg';
export type ButtonVariant = 'solid' | 'outline' | 'ghost';

@Component({
  selector: 'app-button',
  standalone: true,
  imports: [CommonModule],
  template: `
    <button
      [ngClass]="{
        'btn': true,
        'btn-primary': type === 'primary',
        'btn-secondary': type === 'secondary',
        'btn-danger': type === 'danger',
        'btn-success': type === 'success',
        'btn-warning': type === 'warning',
        'btn-info': type === 'info',
        'btn-sm': size === 'sm',
        'btn-md': size === 'md',
        'btn-lg': size === 'lg',
        'btn-solid': variant === 'solid',
        'btn-outline': variant === 'outline',
        'btn-ghost': variant === 'ghost',
        'btn-disabled': disabled
      }"
      [disabled]="disabled"
      (click)="onClick.emit($event)"
      [type]="htmlType"
    >
      <span class="btn-content">
        <ng-content></ng-content>
      </span>
    </button>
  `,
  styleUrls: ['./button.component.css']
})
export class ButtonComponent {
  @Input() type: ButtonType = 'primary';
  @Input() size: ButtonSize = 'md';
  @Input() variant: ButtonVariant = 'solid';
  @Input() disabled: boolean = false;
  @Input() htmlType: 'button' | 'submit' | 'reset' = 'button';
  @Output() onClick = new EventEmitter<MouseEvent>();
}
