import { Component, Input, Output, EventEmitter, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

export interface CausaSuspensionRecord {
  'causa-susp': number;
  cia: number;
  'nombre-cia': string;
  'nombre-caus': string;
  'text-caus': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  tparent?: string;
}

@Component({
  selector: 'app-causa-suspension-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './causa-suspension-modal.component.html',
  styleUrls: ['./causa-suspension-modal.component.css']
})
export class CausaSuspensionModalComponent {
  @Input() visible: boolean = false;
  @Input() set causas(value: CausaSuspensionRecord[]) {
    this._causas.set(value || []);
  }

  @Output() causaSelected = new EventEmitter<CausaSuspensionRecord>();
  @Output() closed = new EventEmitter<void>();

  private _causas = signal<CausaSuspensionRecord[]>([]);
  searchTerm = signal<string>('');

  filteredCausas = computed(() => {
    const term = this.searchTerm().toLowerCase().trim();
    const causas = this._causas();
    
    if (!term) return causas;
    
    return causas.filter(causa => 
      causa['causa-susp'].toString().includes(term) ||
      causa['nombre-caus'].toLowerCase().includes(term) ||
      causa['text-caus']?.toLowerCase().includes(term)
    );
  });

  selectCausa(causa: CausaSuspensionRecord): void {
    this.causaSelected.emit(causa);
    this.close();
  }

  close(): void {
    this.searchTerm.set('');
    this.closed.emit();
  }

  onSearch(): void {
    // El filtrado es reactivo, no necesita hacer nada aquí
  }

  clearSearch(): void {
    this.searchTerm.set('');
  }
}
