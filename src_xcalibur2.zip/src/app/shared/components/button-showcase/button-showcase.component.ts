import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-button-showcase',
  standalone: true,
  imports: [CommonModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  template: `
    <div class="showcase-container">
      <div class="showcase-header">
        <h1>Componente de Botón - Demostración</h1>
        <p>Sistema estándar y parametrizable de botones para toda la aplicación</p>
      </div>

      <!-- Tipos de Botones -->
      <section class="showcase-section">
        <h2>Tipos de Botones</h2>
        <div class="button-group">
          <app-button type="primary">Primary</app-button>
          <app-button type="secondary">Secondary</app-button>
          <app-button type="danger">Danger</app-button>
          <app-button type="success">Success</app-button>
          <app-button type="warning">Warning</app-button>
          <app-button type="info">Info</app-button>
        </div>
      </section>

      <!-- Variantes Solid -->
      <section class="showcase-section">
        <h2>Variante: Solid (Relleno)</h2>
        <div class="button-group">
          <app-button type="primary" variant="solid">Primary</app-button>
          <app-button type="secondary" variant="solid">Secondary</app-button>
          <app-button type="danger" variant="solid">Danger</app-button>
          <app-button type="success" variant="solid">Success</app-button>
          <app-button type="warning" variant="solid">Warning</app-button>
          <app-button type="info" variant="solid">Info</app-button>
        </div>
      </section>

      <!-- Variantes Outline -->
      <section class="showcase-section">
        <h2>Variante: Outline (Contorno)</h2>
        <div class="button-group">
          <app-button type="primary" variant="outline">Primary</app-button>
          <app-button type="secondary" variant="outline">Secondary</app-button>
          <app-button type="danger" variant="outline">Danger</app-button>
          <app-button type="success" variant="outline">Success</app-button>
          <app-button type="warning" variant="outline">Warning</app-button>
          <app-button type="info" variant="outline">Info</app-button>
        </div>
      </section>

      <!-- Variantes Ghost -->
      <section class="showcase-section">
        <h2>Variante: Ghost (Transparente)</h2>
        <div class="button-group">
          <app-button type="primary" variant="ghost">Primary</app-button>
          <app-button type="secondary" variant="ghost">Secondary</app-button>
          <app-button type="danger" variant="ghost">Danger</app-button>
          <app-button type="success" variant="ghost">Success</app-button>
          <app-button type="warning" variant="ghost">Warning</app-button>
          <app-button type="info" variant="ghost">Info</app-button>
        </div>
      </section>

      <!-- Tamaños -->
      <section class="showcase-section">
        <h2>Tamaños</h2>
        <div class="button-group">
          <app-button type="primary" size="sm">Small</app-button>
          <app-button type="primary" size="md">Medium (Default)</app-button>
          <app-button type="primary" size="lg">Large</app-button>
        </div>
      </section>

      <!-- Estados -->
      <section class="showcase-section">
        <h2>Estados</h2>
        <div class="button-group">
          <app-button type="primary">Normal</app-button>
          <app-button type="primary" [disabled]="true">Disabled</app-button>
        </div>
      </section>

      <!-- Grupos de Botones -->
      <section class="showcase-section">
        <h2>Grupos de Botones</h2>
        
        <h3>Horizontal</h3>
        <div class="button-group">
          <app-button type="primary">Guardar</app-button>
          <app-button type="secondary" variant="outline">Cancelar</app-button>
        </div>

        <h3>Vertical</h3>
        <div class="button-group-vertical">
          <app-button type="primary">Primera Acción</app-button>
          <app-button type="secondary">Segunda Acción</app-button>
          <app-button type="danger" variant="outline">Eliminar</app-button>
        </div>

        <h3>Form Actions (Final de Formulario)</h3>
        <div class="form-actions">
          <app-button type="secondary" variant="ghost">Limpiar</app-button>
          <app-button type="primary">Guardar Cambios</app-button>
        </div>

        <h3>Modal Actions</h3>
        <div class="modal-actions">
          <app-button type="secondary" variant="outline">Cerrar</app-button>
          <app-button type="primary">Confirmar</app-button>
        </div>
      </section>

      <!-- Temas Disponibles -->
      <section class="showcase-section">
        <h2>Aplicar Temas Predefinidos</h2>
        <div class="theme-selector">
          <app-button 
            type="primary" 
            (onClick)="applyTheme('light')">
            Light (Default)
          </app-button>
          <app-button 
            type="secondary" 
            (onClick)="applyTheme('corporate')">
            Corporate
          </app-button>
          <app-button 
            type="info" 
            (onClick)="applyTheme('modern')">
            Modern
          </app-button>
          <app-button 
            type="warning" 
            (onClick)="applyTheme('warm')">
            Warm
          </app-button>
          <app-button 
            type="success" 
            (onClick)="applyTheme('minimal')">
            Minimal
          </app-button>
        </div>
        <p class="theme-info">Tema actual: <strong>{{ currentThemeName }}</strong></p>
      </section>

      <!-- Ejemplos Comunes -->
      <section class="showcase-section">
        <h2>Ejemplos de Uso Común</h2>
        
        <h3>Botones de Acción de Tabla</h3>
        <div class="button-group">
          <app-button type="info" size="sm" variant="outline">Ver</app-button>
          <app-button type="warning" size="sm" variant="outline">Editar</app-button>
          <app-button type="danger" size="sm" variant="outline">Eliminar</app-button>
        </div>

        <h3>Botones de Confirmación</h3>
        <div class="button-group">
          <app-button type="danger">Eliminar Permanentemente</app-button>
          <app-button type="secondary" variant="outline">Cancelar</app-button>
        </div>

        <h3>Botones de Exportación</h3>
        <div class="button-group button-group-block">
          <app-button type="success">
            📊 Descargar Excel
          </app-button>
          <app-button type="danger">
            📄 Descargar PDF
          </app-button>
          <app-button type="info">
            🖥️ Ver en Pantalla
          </app-button>
        </div>

        <h3>Botones de Wizard/Navegación</h3>
        <div class="form-actions">
          <app-button type="secondary" variant="ghost">Anterior</app-button>
          <app-button type="primary">Siguiente</app-button>
        </div>
      </section>
    </div>
  `,
  styles: [`
    .showcase-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 2rem;
      background-color: var(--bg-primary);
    }

    .showcase-header {
      text-align: center;
      margin-bottom: 3rem;
    }

    .showcase-header h1 {
      font-size: 2.5rem;
      color: var(--text-primary);
      margin-bottom: 0.5rem;
    }

    .showcase-header p {
      font-size: 1.1rem;
      color: var(--text-secondary);
    }

    .showcase-section {
      margin-bottom: 3rem;
      padding: 2rem;
      background-color: var(--bg-secondary);
      border-radius: 0.5rem;
      border: 1px solid var(--border-light);
    }

    .showcase-section h2 {
      font-size: 1.5rem;
      color: var(--text-primary);
      margin-bottom: 1.5rem;
      padding-bottom: 0.5rem;
      border-bottom: 2px solid var(--border-medium);
    }

    .showcase-section h3 {
      font-size: 1.1rem;
      color: var(--text-secondary);
      margin-top: 1.5rem;
      margin-bottom: 1rem;
    }

    .theme-selector {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
      margin-bottom: 1rem;
    }

    .theme-info {
      color: var(--text-secondary);
      font-size: 0.95rem;
      margin-top: 1rem;
    }
  `]
})
export class ButtonShowcaseComponent {
  currentThemeName = 'Light (Default)';

  private presetNames: Record<string, string> = {
    light: 'Light (Default)',
    corporate: 'Corporate',
    modern: 'Modern',
    warm: 'Warm',
    minimal: 'Minimal'
  };

  constructor() {}

  applyTheme(themeName: string): void {
    // Theme application disabled - ButtonThemeService not available
    console.log('Theme application disabled');
  }
}
