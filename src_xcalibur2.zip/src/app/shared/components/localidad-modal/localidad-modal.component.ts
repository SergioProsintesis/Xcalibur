import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, signal, OnChanges, SimpleChanges, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { debounceTime, distinctUntilChanged, Subject, takeUntil } from 'rxjs';

export interface LocalidadRecord {
  localidad: number;
  cia: number;
  'nombre-cia': string;
  'nombre-loc': string;
  'text-loc': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'Agrega-Loca'?: string;
  tparent?: string;
}

@Component({
  selector: 'app-localidad-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  template: `
    <div class="modal-backdrop" *ngIf="show" (click)="onClose()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <!-- Modal Header -->
        <div class="modal-header">
          <h2 class="modal-title">Seleccionar Localidad</h2>
          <button type="button" class="close-btn" aria-label="Cerrar" (click)="onClose()">&times;</button>
        </div>

        <!-- Modal Body -->
        <div class="modal-body">
          <!-- Search Form -->
          <form [formGroup]="searchForm" class="search-form">
            <div class="search-field">
              <label class="field-label">Buscar localidad</label>
              <input 
                type="text" 
                formControlName="search" 
                class="search-input" 
                placeholder="Escriba código o nombre...">
            </div>
          </form>

          <!-- Localidades Container -->
          <div class="localidades-container">
            <!-- Loading State -->
            <div class="loading-state" *ngIf="isLoading()">
              <div class="spinner"></div>
              <span>Cargando localidades...</span>
            </div>

            <!-- Empty State -->
            <div class="empty-state" *ngIf="!isLoading() && filteredLocalidades().length === 0">
              <p>{{ localidades().length === 0 ? 'No hay localidades disponibles' : 'No se encontraron localidades' }}</p>
            </div>

            <!-- Localidades Grid -->
            <div class="localidades-grid" *ngIf="!isLoading() && filteredLocalidades().length > 0">
              <div class="grid-header">
                <div class="col-codigo">Código</div>
                <div class="col-nombre">Nombre</div>
                <div class="col-comentario">Comentario</div>
                <div class="col-accion">Acción</div>
              </div>
              <div class="grid-body">
                <div 
                  class="grid-row" 
                  *ngFor="let localidad of filteredLocalidades(); trackBy: trackByLocalidad"
                  role="button"
                  tabindex="0"
                  (click)="onSelectLocalidad(localidad)"
                  (keypress)="$event.key === 'Enter' && onSelectLocalidad(localidad)">
                  <div class="col-codigo">{{ localidad.localidad }}</div>
                  <div class="col-nombre">{{ localidad['nombre-loc'] }}</div>
                  <div class="col-comentario">{{ localidad['text-loc'] }}</div>
                  <div class="col-accion">
                    <button 
                      type="button" 
                      class="select-btn"
                      (click)="$event.stopPropagation(); onSelectLocalidad(localidad)"
                      title="Seleccionar localidad">
                      Seleccionar
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Modal Footer -->
        <div class="modal-footer">
          <button type="button" class="btn-cancel" (click)="onClose()">Cancelar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .modal-content {
      background: white;
      border-radius: 12px;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
      width: 90%;
      max-width: 900px;
      max-height: 80vh;
      display: flex;
      flex-direction: column;
    }

    /* Header */
    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .modal-title {
      margin: 0;
      font-size: 1.25rem;
      font-weight: 600;
      color: #1f2937;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #6b7280;
      padding: 0.25rem;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s;
      border-radius: 4px;
    }

    .close-btn:hover {
      color: #1f2937;
      background: #f3f4f6;
    }

    /* Body */
    .modal-body {
      padding: 1.5rem;
      overflow-y: auto;
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    /* Search Form */
    .search-form {
      margin-bottom: 0.5rem;
    }

    .search-field {
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }

    .field-label {
      font-size: 0.875rem;
      font-weight: 500;
      color: #374151;
    }

    .search-input {
      padding: 0.75rem;
      border: 1px solid #d1d5db;
      border-radius: 6px;
      font-size: 0.875rem;
      transition: all 0.2s;
    }

    .search-input:focus {
      outline: none;
      border-color: #003087;
      box-shadow: 0 0 0 3px rgba(0, 48, 135, 0.1);
    }

    /* Container */
    .localidades-container {
      flex: 1;
      display: flex;
      flex-direction: column;
      min-height: 300px;
    }

    /* States */
    .loading-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 1rem;
      flex: 1;
      color: #6b7280;
    }

    .empty-state {
      display: flex;
      align-items: center;
      justify-content: center;
      flex: 1;
      color: #6b7280;
      font-size: 0.95rem;
    }

    .spinner {
      width: 40px;
      height: 40px;
      border: 4px solid #e5e7eb;
      border-top-color: #003087;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    @keyframes spin {
      to {
        transform: rotate(360deg);
      }
    }

    /* Grid */
    .localidades-grid {
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      flex: 1;
    }

    .grid-header {
      display: grid;
      grid-template-columns: 0.7fr 1.5fr 2fr 0.5fr;
      gap: 1rem;
      padding: 1rem;
      background-color: #f3f4f6;
      border-bottom: 1px solid #e5e7eb;
      font-weight: 600;
      color: #111827;
      font-size: 0.875rem;
      position: sticky;
      top: 0;
    }

    .grid-body {
      overflow-y: auto;
      flex: 1;
    }

    .grid-row {
      display: grid;
      grid-template-columns: 0.7fr 1.5fr 2fr 0.5fr;
      gap: 1rem;
      padding: 0.75rem 1rem;
      border-bottom: 1px solid #e5e7eb;
      align-items: center;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .grid-row:hover {
      background-color: #f9fafb;
    }

    .grid-row:focus {
      outline: 2px solid #003087;
      outline-offset: -1px;
    }

    .col-codigo {
      font-weight: 500;
      color: #1f2937;
      font-size: 0.875rem;
    }

    .col-nombre {
      color: #374151;
      font-size: 0.875rem;
      font-weight: 500;
    }

    .col-comentario {
      color: #6b7280;
      font-size: 0.875rem;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .col-accion {
      display: flex;
      justify-content: flex-end;
    }

    .select-btn {
      padding: 0.4rem 0.8rem;
      background-color: #003087;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background-color 0.2s;
      font-size: 0.8rem;
    }

    .select-btn:hover {
      background-color: #002066;
    }

    .select-btn:active {
      background-color: #001a3d;
    }

    /* Footer */
    .modal-footer {
      padding: 1.5rem;
      border-top: 1px solid #e5e7eb;
      display: flex;
      justify-content: flex-end;
      gap: 0.75rem;
    }

    .btn-cancel {
      padding: 0.75rem 1.5rem;
      background-color: #e5e7eb;
      color: #1f2937;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 0.875rem;
      font-weight: 500;
      transition: background-color 0.2s;
    }

    .btn-cancel:hover {
      background-color: #d1d5db;
    }
  `]
})
export class LocalidadModalComponent implements OnInit, OnChanges, OnDestroy {
  @Input() show = false;
  @Input() set localidadesData(value: LocalidadRecord[]) {
    this.localidades.set(value);
  }
  @Output() selectLocalidad = new EventEmitter<LocalidadRecord>();
  @Output() close = new EventEmitter<void>();

  // Form
  searchForm!: FormGroup;

  // State Signals
  localidades = signal<LocalidadRecord[]>([]);
  filteredLocalidades = signal<LocalidadRecord[]>([]);
  isLoading = signal(false);

  private destroy$ = new Subject<void>();
  private fb = inject(FormBuilder);

  ngOnInit(): void {
    this.initializeForm();
    this.setupSearch();
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Populate filtered list when data changes
    if (changes['localidadesData'] && !changes['localidadesData'].firstChange) {
      this.filteredLocalidades.set(this.localidades());
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  // ==================== INITIALIZATION ====================
  private initializeForm(): void {
    this.searchForm = this.fb.group({
      search: ['']
    });
  }

  // ==================== SEARCH ====================
  private setupSearch(): void {
    this.searchForm.get('search')?.valueChanges
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe((searchTerm) => {
        this.filterLocalidades(searchTerm);
      });
  }

  private filterLocalidades(searchTerm: string): void {
    if (!searchTerm || !searchTerm.trim()) {
      this.filteredLocalidades.set(this.localidades());
      return;
    }

    const term = searchTerm.toLowerCase();
    const filtered = this.localidades().filter(localidad =>
      localidad.localidad?.toString().includes(term) ||
      localidad['nombre-loc']?.toLowerCase().includes(term) ||
      localidad['text-loc']?.toLowerCase().includes(term)
    );
    this.filteredLocalidades.set(filtered);
  }

  // ==================== SELECTION ====================
  onSelectLocalidad(localidad: LocalidadRecord): void {
    console.log('🎯 Localidad selected:', localidad);
    this.selectLocalidad.emit(localidad);
    this.onClose();
  }

  // ==================== CLOSE ====================
  onClose(): void {
    console.log('🔙 Closing localidad modal');
    this.searchForm.reset();
    this.filteredLocalidades.set([]);
    this.close.emit();
  }

  // ==================== TRACKING ====================
  trackByLocalidad(index: number, localidad: LocalidadRecord): number {
    return localidad.localidad;
  }
}
