import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { trigger, transition, style, animate } from '@angular/animations';
import { TourService, Tour } from '../../../core/services/tour.service';

@Component({
  selector: 'app-help-button',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="help-button-container">
      <!-- Help Icon Button -->
      <button
        (click)="toggleHelpMenu()"
        class="help-btn p-2 bg-white rounded-full shadow-sm hover:shadow-md border border-gray-200 text-gray-600 hover:text-gray-800 transition-colors"
        title="Ayuda (F1)"
        aria-label="Abrir ayuda"
      >
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      </button>

      <!-- Help Menu Dropdown -->
      @if (isMenuOpen()) {
        <div 
          class="help-menu absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-[0_12px_40px_-12px_rgba(0,0,0,0.45)] border border-gray-100 ring-1 ring-blue-500/10 overflow-hidden z-50"
          [@menuAnimation]
          (click)="$event.stopPropagation()"
        >
          <!-- Header -->
          <div class="h-1 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500"></div>
          
          <div class="px-6 py-4 bg-white border-b border-gray-100">
            <h3 class="font-semibold text-gray-900">¿Necesitas ayuda?</h3>
            <p class="text-xs text-gray-500 mt-1">Presiona F1 para iniciar un tour guiado en cualquier momento</p>
          </div>

          <!-- Tours List -->
          <div class="max-h-96 overflow-y-auto">
            <div class="p-3">
              <!-- Quick Help Section -->
              <div class="mb-4 pb-4 border-b border-gray-100">
                <p class="text-xs font-semibold text-gray-600 uppercase mb-3">Ayuda rápida</p>
                
                <button
                  (click)="openGeneralTour()"
                  class="w-full text-left px-3 py-2 rounded-md text-sm hover:bg-blue-50 transition-colors group"
                >
                  <div class="flex items-center gap-2">
                    <div class="w-8 h-8 flex items-center justify-center bg-blue-100 text-blue-600 rounded-lg group-hover:bg-blue-200">
                      <span>?</span>
                    </div>
                    <div class="flex-1 min-w-0">
                      <p class="font-medium text-gray-900 truncate">Tour General</p>
                      <p class="text-xs text-gray-500">Introducción al sistema</p>
                    </div>
                  </div>
                </button>
              </div>

              <!-- Tours by Category -->
              <p class="text-xs font-semibold text-gray-600 uppercase mb-3">Tours disponibles</p>
              
              <div class="space-y-2">
                @for (tour of availableTours(); track tour.id) {
                  <button
                    (click)="startTour(tour.id)"
                    class="w-full text-left px-3 py-2 rounded-md text-sm hover:bg-indigo-50 transition-colors group"
                    [title]="tour.description"
                  >
                    <div class="flex items-center gap-2">
                      <div class="w-8 h-8 flex items-center justify-center bg-indigo-100 text-indigo-600 rounded-lg group-hover:bg-indigo-200">
                        <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                          <path fill-rule="evenodd" d="M18 5v8a2 2 0 01-2 2h-5l-5 4v-4H4a2 2 0 01-2-2V5a2 2 0 012-2h12a2 2 0 012 2zm-11-1a1 1 0 11-2 0 1 1 0 012 0z" clip-rule="evenodd" />
                        </svg>
                      </div>
                      <div class="flex-1 min-w-0">
                        <p class="font-medium text-gray-900 truncate">{{ tour.name }}</p>
                        <p class="text-xs text-gray-500 line-clamp-1">{{ tour.description }}</p>
                      </div>
                    </div>
                  </button>
                }

                @if (availableTours().length === 0) {
                  <div class="px-3 py-4 text-center">
                    <p class="text-sm text-gray-500">No hay tours disponibles en este momento</p>
                  </div>
                }
              </div>
            </div>
          </div>

          <!-- Footer -->
          <div class="px-6 py-3 bg-gray-50 border-t border-gray-100">
            <p class="text-xs text-gray-600">
              <strong>💡 Consejo:</strong> Presiona <kbd class="px-2 py-1 bg-white border border-gray-300 rounded text-xs">F1</kbd> en cualquier página para iniciar el tour
            </p>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .help-button-container {
      position: relative;
    }

    .help-btn {
      transition: all 0.3s ease;
    }

    .help-btn:hover {
      background: #f3f4f6;
      border-color: #667ee6;
      color: #667ee6;
    }

    .help-menu {
      right: 0;
      top: 100%;
      margin-top: 8px;
      box-sizing: border-box;
    }

    kbd {
      font-family: monospace;
      font-weight: 500;
    }

    .line-clamp-1 {
      display: -webkit-box;
      -webkit-line-clamp: 1;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
  `],
  animations: [
    trigger('menuAnimation', [
      transition(':enter', [
        style({ opacity: 0, transform: 'scale(0.95) translateY(-8px)' }),
        animate('200ms ease-out', style({ opacity: 1, transform: 'scale(1) translateY(0)' }))
      ]),
      transition(':leave', [
        animate('150ms ease-in', style({ opacity: 0, transform: 'scale(0.95) translateY(-8px)' }))
      ])
    ])
  ]
})
export class HelpButtonComponent {
  private tourService = inject(TourService);

  isMenuOpen = signal(false);
  availableTours = signal<Tour[]>([]);

  constructor() {
    this.tourService.tours$.subscribe((tours: any) => {
      this.availableTours.set(tours.filter((t: any) => t.id !== 'general-tour'));
    });

    // F1 key listener
    document.addEventListener('keydown', (event) => {
      if (event.key === 'F1') {
        event.preventDefault();
        this.toggleHelpMenu();
      }
    });
  }

  toggleHelpMenu(): void {
    this.isMenuOpen.update(val => !val);
  }

  startTour(tourId: string): void {
    this.tourService.startTour(tourId);
    this.isMenuOpen.set(false);
  }

  openGeneralTour(): void {
    // Aquí puedes implementar un tour general del sistema
    alert('Tour general pronto disponible');
    this.isMenuOpen.set(false);
  }
}
