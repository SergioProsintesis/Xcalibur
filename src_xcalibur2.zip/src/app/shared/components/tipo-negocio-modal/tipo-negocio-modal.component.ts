import { Component, Input, Output, EventEmitter, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

export interface TipoNegocioRecord {
  negocio: number;
  cia: number;
  'nombre-cia': string;
  'nombre-neg': string;
  'text-neg': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'Agrega-Nego'?: string;
  tparent?: string;
}

@Component({
  selector: 'app-tipo-negocio-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './tipo-negocio-modal.component.html',
  styleUrls: ['./tipo-negocio-modal.component.css']
})
export class TipoNegocioModalComponent {
  @Input() visible: boolean = false;
  @Input() set negocios(value: TipoNegocioRecord[]) {
    this._negocios.set(value);
  }
  
  @Output() negocioSelected = new EventEmitter<TipoNegocioRecord>();
  @Output() closed = new EventEmitter<void>();

  _negocios = signal<TipoNegocioRecord[]>([]);
  searchTerm = signal<string>('');

  filteredNegocios = computed(() => {
    const term = this.searchTerm().toLowerCase();
    const negocios = this._negocios();
    
    if (!term) return negocios;
    
    return negocios.filter(negocio => 
      negocio.negocio.toString().includes(term) ||
      negocio['nombre-neg']?.toLowerCase().includes(term) ||
      negocio['text-neg']?.toLowerCase().includes(term)
    );
  });

  selectNegocio(negocio: TipoNegocioRecord): void {
    this.negocioSelected.emit(negocio);
    this.close();
  }

  close(): void {
    this.searchTerm.set('');
    this.closed.emit();
  }

  onSearch(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.searchTerm.set(value);
  }

  clearSearch(): void {
    this.searchTerm.set('');
  }
}
