import { Component, Input, Output, EventEmitter, signal, ChangeDetectorRef } from '@angular/core';
import { MenuService } from '../../core/services/menu.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import Fuse from 'fuse.js';

interface MenuItem {
  path: string;
  label: string;
  progrMen?: string; // Código del programa para búsqueda
  children?: MenuItem[];
}

@Component({
  selector: 'app-search-menu',
  standalone: true,
  // ✅ IMPORTANTE: compatibilidad con Angular + Vite
  imports: [CommonModule, FormsModule, RouterModule],

  templateUrl: 'search-menu.component.html',
  styleUrls: ['search-menu.component.css'],
})
export class SearchMenuComponent {
  /** When true the component renders an internal floating button (bottom-right). When embedded in a layout set this to false. */
  @Input() floating = false;
  /** Toggle para mostrar todos los resultados en vez de solo 6 */
  showAll = signal(false);
  private _menus: MenuItem[] = [];
  private fuse?: Fuse<MenuItem>;

  @Input()
  set menus(value: MenuItem[]) {
    this._menus = value || [];
    this.initFuse();
  }
  get menus(): MenuItem[] {
    return this._menus;
  }
  @Output() navigate = new EventEmitter<string>();

  searchTerm = signal('');
  filteredMenus = signal<MenuItem[]>([]);
  showModal = signal(false);
  recentItems = signal<MenuItem[]>([]);
  selectedIndex = signal<number>(-1);
  totalMatches = signal<number>(0);
  // Accessibility: announce result count changes
  liveMessage = signal<string>('');
  private keyboardNavigationEnabled = true;
  private prefersReducedMotion = false;
  constructor(private menuService: MenuService, private cdr: ChangeDetectorRef) {
    try {
      this.prefersReducedMotion = !!(globalThis as any).matchMedia && (globalThis as any).matchMedia('(prefers-reduced-motion: reduce)').matches;
    } catch (e) {
      this.prefersReducedMotion = false;
    }
  }
  private initFuse() {
    try {
      const flat = this.flattenMenus(this._menus);
      // create Fuse index for fuzzy searching on label, path, and progrMen (program code)
      this.fuse = new Fuse(flat, {
        keys: ['label', 'path', 'progrMen'],
        threshold: 0.4,
        ignoreLocation: true,
      });
    } catch (e) {
      this.fuse = undefined;
    }
  }
  openModal() {
    this.showModal.set(true);
    this.filteredMenus.set([]);
    this.searchTerm.set('');
    this.selectedIndex.set(-1);
    try {
      const recents = this.menuService.getRecentMenuItems();
      if (recents?.length) {
        this.recentItems.set(recents.map(r => ({ path: r.path, label: r.label })).slice(0, 8));
      }
    } catch {}
    this.cdr.detectChanges();
    setTimeout(() => {
      const input = document.getElementById('global-search-input') as HTMLInputElement;
      input?.focus();
    }, 60);
  }

  // Keyboard navigation handler for ArrowUp/ArrowDown/Enter/Escape
  onKeydown(event: KeyboardEvent) {
    if (!this.keyboardNavigationEnabled) return;

    const key = event.key;
    const list = this.filteredMenus();
    const len = list.length;

    if (key === 'ArrowDown') {
      event.preventDefault();
      if (len === 0) return;
      const next = (this.selectedIndex() + 1 + len) % len;
      this.selectedIndex.set(next);
      this.scrollToIndex(next);
    } else if (key === 'ArrowUp') {
      event.preventDefault();
      if (len === 0) return;
      const prev = (this.selectedIndex() - 1 + len) % len;
      this.selectedIndex.set(prev);
      this.scrollToIndex(prev);
    } else if (key === 'Enter') {
      event.preventDefault();
      const idx = this.selectedIndex();
      if (idx >= 0 && idx < len) {
        const item = list[idx];
        if (item) this.goTo(item.path);
      }
    } else if (key === 'Escape') {
      event.preventDefault();
      this.closeModal();
    }
  }

  private scrollToIndex(idx: number) {
    setTimeout(() => {
      const el = document.getElementById('search-result-' + idx);
      if (el && el.scrollIntoView) {
        try {
          const behavior: ScrollBehavior = this.prefersReducedMotion ? 'auto' : 'smooth';
          (el as HTMLElement).scrollIntoView({ block: 'nearest', behavior });
        } catch (e) {
          // fallback
          el.scrollIntoView();
        }
      }
    }, 10);
  }

  closeModal() {
    this.showModal.set(false);
    this.searchTerm.set('');
  }

onSearch(term: string) {
  this.searchTerm.set(term);
  if (!term.trim()) {
    this.filteredMenus.set(this.recentItems() || []);
    this.totalMatches.set(0);
    this.selectedIndex.set(this.filteredMenus().length ? 0 : -1);
    this.liveMessage.set('Mostrando recientes');
    return;
  }
  const allMenus = this.flattenMenus(this._menus);
  const MAX_RESULTS = 6;
  let totalMatches = 0;
  try {
    if (this.fuse) {
      const results = this.fuse.search(term, { limit: 30 }) as Array<Fuse.FuseResult<MenuItem>>;
      totalMatches = results.length;
      const mapped = results.map(r => r.item);
      this.filteredMenus.set(this.showAll() ? mapped : mapped.slice(0, MAX_RESULTS));
    } else {
      const normalized = term.toLowerCase();
      const filtered = allMenus.filter(m => m.label?.toLowerCase().includes(normalized));
      totalMatches = filtered.length;
      this.filteredMenus.set(this.showAll() ? filtered : filtered.slice(0, MAX_RESULTS));
    }
  } catch {
    const normalized = term.toLowerCase();
    const filtered = allMenus.filter(m => m.label?.toLowerCase().includes(normalized));
    totalMatches = filtered.length;
    this.filteredMenus.set(this.showAll() ? filtered : filtered.slice(0, MAX_RESULTS));
  }
  this.totalMatches.set(totalMatches);
  this.selectedIndex.set(this.filteredMenus().length ? 0 : -1);
  this.liveMessage.set(`${this.filteredMenus().length} resultado(s) mostrados de ${totalMatches}`);
}

  // Highlight matched term in label safely
  highlight(label: string): string {
    const term = this.searchTerm().trim();
    if (!term) return this.escapeHtml(label);
    try {
      const escapedTerm = term.replace(/[.*+?^${}()|[\]\\]/g, r => `\\${r}`);
      const re = new RegExp(escapedTerm, 'gi');
      return this.escapeHtml(label).replace(re, m => `<mark>${this.escapeHtml(m)}</mark>`);
    } catch {
      return this.escapeHtml(label);
    }
  }

  private escapeHtml(str: string): string {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
  toggleShowAll() {
    this.showAll.set(!this.showAll());
    // Forzar nueva búsqueda con estado expandido/contraído
    this.onSearch(this.searchTerm());
  }
  // 🧩 Convierte árbol en lista plana
  private flattenMenus(menus: MenuItem[]): MenuItem[] {
    let flat: MenuItem[] = [];
    for (const m of menus) {
      if (m.label && m.path) {
        flat.push({ 
          path: m.path, 
          label: m.label,
          progrMen: m.progrMen // Incluir código del programa
        });
      }
      if (m.children) flat = flat.concat(this.flattenMenus(m.children));
    }
    return flat;
  }

  // 🚀 Emite navegación
  goTo(path: string) {
    this.navigate.emit(path);
    this.closeModal();
    // Persist in recent via MenuService (most-recent first, unique)
    try {
      const all = this.flattenMenus(this.menus);
      const found = all.find(m => m.path === path) || { path, label: path };
      this.menuService.addRecentMenuItem({ path: found.path, label: found.label });
    } catch (e) {
      // ignore
    }
  }
}
