import 'zone.js';
import 'zone.js/testing';
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { SearchMenuComponent } from './search-menu.component';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';

describe('SearchMenuComponent', () => {
  let component: SearchMenuComponent;
  let fixture: ComponentFixture<SearchMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SearchMenuComponent, RouterTestingModule]
    }).compileComponents();

    fixture = TestBed.createComponent(SearchMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('openModal should show modal and focus input', fakeAsync(() => {
    component.openModal();
    fixture.detectChanges();
    tick(200);
    expect(component.showModal()).toBeTrue();
  }));

  it('onSearch filters menus correctly', () => {
    const menus = [
      { path: '/a', label: 'Alpha' },
      { path: '/b', label: 'Beta' },
      { path: '/ab', label: 'AB' }
    ];
    component.menus = menus as any;
    component.onSearch('a');
    expect(component.filteredMenus().length).toBeGreaterThan(0);
    expect(component.filteredMenus().some(m => m.label === 'Alpha')).toBeTrue();
  });

  it('keyboard navigation changes selectedIndex with ArrowDown/ArrowUp and Enter triggers navigation', () => {
    const menus = [
      { path: '/a', label: 'Alpha' },
      { path: '/b', label: 'Beta' },
      { path: '/c', label: 'Charlie' }
    ];
    component.menus = menus as any;
    component.onSearch(''); // empty -> recents (none) => no results
    // force a search that matches everything
    component.onSearch('a');
    fixture.detectChanges();

    // start: selectedIndex should be 0 if there are results
    expect(component.filteredMenus().length).toBeGreaterThan(0);
    const initial = component.selectedIndex();

    // ArrowDown
    component.onKeydown({ key: 'ArrowDown', preventDefault: () => {} } as unknown as KeyboardEvent);
    expect(component.selectedIndex()).toBe((initial + 1) % component.filteredMenus().length);

    // ArrowUp
    component.onKeydown({ key: 'ArrowUp', preventDefault: () => {} } as unknown as KeyboardEvent);
    expect(component.selectedIndex()).toBe(initial);

    // Enter should emit navigate
    spyOn(component.navigate, 'emit');
    // ensure selectedIndex points to first
    component.selectedIndex.set(0);
    component.onKeydown({ key: 'Enter', preventDefault: () => {} } as unknown as KeyboardEvent);
    expect(component.navigate.emit).toHaveBeenCalled();
  });

  it('goTo emits navigation and stores recent', () => {
    spyOn(component.navigate, 'emit');
    // ensure menus available
    component.menus = [ { path: '/x', label: 'X' } ] as any;
    component.goTo('/x');
    expect(component.navigate.emit).toHaveBeenCalledWith('/x');
  });
});
