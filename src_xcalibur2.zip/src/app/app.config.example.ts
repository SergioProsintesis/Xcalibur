import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';

// Services
import { ButtonThemeService } from './core/services/button-theme.service';

// Routes & Config
import { routes } from './app.routes';

/**
 * Initialize Button Theme on App Start
 * This function sets up the global button theme based on configuration
 */
export function initializeButtonTheme(themeService: ButtonThemeService) {
  return () => {
    // Option 1: Use default theme (Light)
    themeService.resetTheme();

    // Option 2: Apply a preset (uncomment to use)
    // const corporateTheme = themeService.getPresets().corporate;
    // themeService.applyTheme(corporateTheme);

    // Option 3: Apply custom theme (uncomment to use)
    // themeService.applyTheme({
    //   primary: '#FF6B6B',
    //   primaryHover: '#FF5252',
    //   primaryDark: '#C41E1E',
    //   secondary: '#4ECDC4',
    //   danger: '#E74C3C',
    //   success: '#2ECC71',
    //   warning: '#F39C12',
    //   info: '#3498DB'
    // });

    console.log('✅ Button Theme initialized:', themeService.getTheme());
  };
}

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient()
  ]
};
