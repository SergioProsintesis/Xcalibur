import { Component, OnDestroy, OnInit, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Observable, Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';

import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CCService } from '../../../core/services/cc.service';
import { CompaniaRecord, GenerarReporteResponse } from '../../../core/interfaces/cc.interface';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { EmpresaModalComponent } from '../reporte-movimiento-del-dia/empresa-modal/empresa-modal.component';

interface EmpresaRecord {
  empresa: number;
  'nombre-emp': string;
  nit: string;
  cia: number;
}

@Component({
  selector: 'app-estado-ctahist-consolidado',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, CompaniaModalComponent, EmpresaModalComponent],
  templateUrl: './estado-ctahist-consolidado.component.html',
  styleUrls: ['./estado-ctahist-consolidado.component.css']
})
export class EstadoCthhistConsolidadoComponent implements OnInit, OnDestroy {
  form: FormGroup;
  searchForm: FormGroup;
  isLoading = signal(false);
  showCompaniaModal = signal(false);
  showEmpresaModal = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  selectedEmpresa = signal<EmpresaRecord | null>(null);
  isGeneratingReport = signal(false);
  
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Estado de Cuenta Histórico Consolidado`);
  
  companiasList = signal<CompaniaRecord[]>([]);
  filteredCompaniasList = signal<CompaniaRecord[]>([]);
  isLoadingCompanias = signal(false);
  
  empresasList = signal<any[]>([]);
  filteredEmpresasList = signal<any[]>([]);
  isLoadingEmpresas = signal(false);

  // Opciones de reporte disponibles
  reportOptions = signal<Array<{ value: string; label: string }>>([
    { value: '1', label: 'Opción 1 - Detalle General' },
    { value: '2', label: 'Opción 2 - Resumen' },
    { value: '3', label: 'Opción 3 - Analítico' }
  ]);
  
  private destroy$ = new Subject<void>();
  private programContext = inject(ProgramContextService);

  private escapeHtml(text: string): string {
    const map: { [key: string]: string } = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, (char) => map[char]);
  }

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
    private loading: LoadingService,
    private ccService: CCService,
    private router: Router
  ) {
    this.form = this.fb.group({
      compania: ['', Validators.required],
      empresa: ['', Validators.required],
      fecha: ['', Validators.required],
      opcion: ['1', Validators.required]
    });

    this.searchForm = this.fb.group({
      search: ['']
    });
  }

  ngOnInit(): void {
    this.loadCompanias();
  }

  private loadCompanias(): void {
    this.isLoadingCompanias.set(true);
    
    this.ccService.getCompanias()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (companias) => {
          this.companiasList.set(companias);
          this.filteredCompaniasList.set(companias);
          this.isLoadingCompanias.set(false);
        },
        error: (err) => {
          console.error('Error loading companies:', err);
          this.toast.showError('Error al cargar las compañías');
          this.isLoadingCompanias.set(false);
        }
      });
  }

  private loadEmpresas(): void {
    const pcCompania = this.form.get('compania')?.value;
    if (!pcCompania) {
      this.toast.showError('Por favor seleccione una compañía primero');
      return;
    }

    this.isLoadingEmpresas.set(true);
    
    this.ccService.getCEEmpresa(pcCompania)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (empresas: any[]) => {
          this.empresasList.set(empresas);
          this.filteredEmpresasList.set(empresas);
          this.isLoadingEmpresas.set(false);
        },
        error: (err: any) => {
          console.error('Error loading empresas:', err);
          this.toast.showError('Error al cargar las empresas');
          this.isLoadingEmpresas.set(false);
        }
      });
  }

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
    this.searchForm.reset();
    this.filteredCompaniasList.set(this.companiasList());
  }

  onSelectCompania(compania: CompaniaRecord): void {
    this.form.patchValue({
      compania: compania.cia,
      empresa: ''
    });
    this.selectedCompania.set(compania);
    this.selectedEmpresa.set(null);
    this.showCompaniaModal.set(false);
    
    // Load empresas for the selected company
    this.loadEmpresas();
  }

  onCloseModal(): void {
    this.showCompaniaModal.set(false);
    this.showEmpresaModal.set(false);
    this.searchForm.reset();
  }

  onOpenEmpresaModal(): void {
    const compania = this.form.get('compania')?.value;
    if (!compania) {
      this.toast.showWarning('Por favor seleccione una compañía primero');
      return;
    }
    this.showEmpresaModal.set(true);
  }

  onSelectEmpresa(empresa: EmpresaRecord): void {
    this.form.patchValue({
      empresa: empresa.empresa.toString(),
      nombreEmpresa: empresa['nombre-emp'] || ''
    });
    this.selectedEmpresa.set(empresa);
    this.showEmpresaModal.set(false);
    this.validateEmpresa(empresa.empresa.toString());
  }

  onEmpresaBlur(): void {
    const value = this.form.get('empresa')?.value;
    if (value && value.toString().length > 0) {
      this.validateEmpresa(value);
    }
  }

  private validateEmpresa(codigo: string): void {
    const compania = this.form.get('compania')?.value;
    if (!compania) return;

    this.ccService.validateEmpresa(compania, codigo).subscribe({
      next: (empresa) => {
        if (empresa) {
          this.selectedEmpresa.set(empresa);
          this.form.patchValue({ 
            empresa: empresa.empresa.toString()
          });
          const ctrl = this.form.get('empresa');
          if (ctrl?.hasError('notFound')) {
            const errors = { ...(ctrl.errors || {}) };
            delete errors['notFound'];
            ctrl.setErrors(Object.keys(errors).length ? errors : null);
          }
        } else {
          this.selectedEmpresa.set(null);
          this.form.get('empresa')?.setErrors({ notFound: true });
        }
      },
      error: (err) => {
        console.error('Error validating empresa:', err);
        this.toast.showError('Error al validar la empresa');
      }
    });
  }

  onCloseEmpresaModal(): void {
    this.showEmpresaModal.set(false);
    this.searchForm.reset();
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getErrorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (!field) return '';

    if (field.hasError('required')) return 'Este campo es requerido';
    if (field.hasError('pattern')) return 'Formato inválido';
    
    return 'Error en el campo';
  }

  trackByCompania(index: number, compania: CompaniaRecord): number {
    return compania.cia;
  }

  trackByEmpresa(index: number, empresa: any): number {
    return empresa.empresa;
  }

  onGenerarReporte(formato: 'excel' | 'pdf' | 'pantalla'): void {
    if (!this.form.valid) {
      this.toast.showError('Por favor complete los campos requeridos');
      return;
    }

    this.isGeneratingReport.set(true);
    const pcCompania = this.form.get('compania')?.value;
    const pcEmpresa = this.form.get('empresa')?.value;
    const pcFecha = this.form.get('fecha')?.value;
    const pcOpcion = this.form.get('opcion')?.value;

    // Call the service with the CC2224 endpoint parameters
    const reportCall = this.ccService.getCC2224(pcCompania, pcEmpresa, pcFecha, pcOpcion);

    reportCall
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isGeneratingReport.set(false);
          if (response) {
            this.handleReporteResponse(response, formato);
            this.toast.showSuccess(`Reporte generado en formato ${formato}`);
          } else {
            this.toast.showError('No se pudo generar el reporte');
          }
        },
        error: (err: any) => {
          this.isGeneratingReport.set(false);
          console.error('Error generating report:', err);
          this.toast.showError('Error al generar el reporte');
        }
      });
  }

  private handleReporteResponse(response: any, formato: string): void {
    if (response) {
      if (formato === 'excel') {
        if (response.pcArchCSV) {
          this.downloadBase64File(response.pcArchCSV, 'text/csv', 'reporte.csv');
        }
      } else if (formato === 'pdf' && response.pcArchPDF) {
        this.downloadBase64File(response.pcArchPDF, 'application/pdf', 'reporte.pdf');
      } else if (formato === 'pantalla') {
        if (response.pcArchCSV) {
          this.viewCSVInBrowser(response.pcArchCSV);
        } else if (response.pcArchPDF) {
          this.viewPDFInBrowser(response.pcArchPDF);
        }
      }
    }
  }

  private viewPDFInBrowser(base64Data: string): void {
    try {
      const pdfData = 'data:application/pdf;base64,' + base64Data;
      const newWindow = window.open();
      if (newWindow) {
        newWindow.location.href = pdfData;
      }
    } catch (error) {
      console.error('Error mostrando PDF:', error);
      this.toast.showError('Error al mostrar el PDF');
    }
  }

  private viewCSVInBrowser(base64Data: string): void {
    try {
      const csvText = atob(base64Data);
      const escapedText = this.escapeHtml(csvText);
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head>
              <title>Reporte CSV</title>
              <style>
                body { 
                  font-family: 'Courier New', monospace; 
                  padding: 20px; 
                  background: #f5f5f5;
                }
                .content {
                  background: white;
                  padding: 20px;
                  border-radius: 4px;
                  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                  white-space: pre-wrap;
                  word-wrap: break-word;
                  max-width: 1200px;
                  margin: 0 auto;
                }
                .print-btn {
                  margin-bottom: 20px;
                  padding: 10px 20px;
                  background: #003087;
                  color: white;
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
                  font-size: 14px;
                }
                .print-btn:hover {
                  background: #002060;
                }
              </style>
            </head>
            <body>
              <button class="print-btn" onclick="window.print()">Imprimir</button>
              <div class="content">${escapedText}</div>
            </body>
          </html>
        `);
        newWindow.document.close();
      }
    } catch (error) {
      console.error('Error mostrando CSV:', error);
      this.toast.showError('Error al mostrar el CSV');
    }
  }

  private downloadBase64File(base64Data: string, mimeType: string, fileName: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error descargando archivo:', error);
      this.toast.showError('Error al descargar el archivo');
    }
  }

  onClear(): void {
    this.form.reset();
    this.form.patchValue({ opcion: '1' });
    this.selectedCompania.set(null);
    this.selectedEmpresa.set(null);
  }


  goBack(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
