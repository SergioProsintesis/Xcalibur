import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, signal, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { debounceTime, distinctUntilChanged, Subject, takeUntil } from 'rxjs';

import { CCService } from '../../../../core/services/cc.service';
import { CompaniaRecord } from '../../../../core/interfaces/cc.interface';

@Component({
  selector: 'app-compania-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  template: `
    <div class="modal-backdrop" *ngIf="show" (click)="onClose()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2 class="modal-title">Buscar Compañía</h2>
          <button type="button" class="close-btn" (click)="onClose()">&times;</button>
        </div>

        <div class="modal-body">
          <form [formGroup]="searchForm" class="search-form">
            <div class="search-field">
              <label class="field-label">Buscar por nombre o NIT</label>
              <input type="text" formControlName="search" class="search-input" placeholder="Escriba para buscar...">
            </div>
          </form>

          <div class="companias-grid" *ngIf="filteredCompanias().length > 0; else noResults">
            <div class="grid-header">
              <div class="header-cell">Código</div>
              <div class="header-cell">NIT</div>
              <div class="header-cell">Nombre</div>
              <div class="header-cell">Acción</div>
            </div>
            <div class="grid-body">
              <div class="grid-row" *ngFor="let compania of filteredCompanias(); trackBy: trackByCompania">
                <div class="grid-cell">{{ compania.cia }}</div>
                <div class="grid-cell">{{ compania.nit }}</div>
                <div class="grid-cell">{{ compania['nombre-cia'] }}</div>
                <div class="grid-cell">
                  <button type="button" class="select-btn" (click)="onSelectCompania(compania)">
                    Seleccionar
                  </button>
                </div>
              </div>
            </div>
          </div>

          <ng-template #noResults>
            <div class="no-results" *ngIf="!isLoading()">
              <p>No se encontraron compañías</p>
            </div>
          </ng-template>

          <div class="loading-indicator" *ngIf="isLoading()">
            <div class="spinner"></div>
            <span>Cargando compañías...</span>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn-secondary" (click)="onClose()">Cancelar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .modal-content {
      background: white;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 800px;
      max-height: 80vh;
      display: flex;
      flex-direction: column;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .modal-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: #003087;
      margin: 0;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #6b7280;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .close-btn:hover {
      color: #374151;
    }

    .modal-body {
      padding: 1.5rem;
      overflow-y: auto;
      flex: 1;
    }

    .search-form {
      margin-bottom: 1.5rem;
    }

    .search-field {
      display: flex;
      flex-direction: column;
    }

    .field-label {
      font-weight: 500;
      color: #374151;
      margin-bottom: 0.5rem;
    }

    .search-input {
      border: 1px solid #d1d5db;
      border-radius: 8px;
      padding: 0.75rem;
      font-size: 0.95rem;
      transition: all 0.2s;
    }

    .search-input:focus {
      outline: none;
      border-color: #003087;
      box-shadow: 0 0 0 2px rgba(0, 48, 135, 0.15);
    }

    .companias-grid {
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      overflow: hidden;
    }

    .grid-header {
      display: grid;
      grid-template-columns: 80px 120px 1fr 120px;
      background: #f9fafb;
      border-bottom: 1px solid #e5e7eb;
    }

    .header-cell {
      padding: 0.75rem;
      font-weight: 600;
      font-size: 0.875rem;
      color: #374151;
      border-right: 1px solid #e5e7eb;
    }

    .header-cell:last-child {
      border-right: none;
    }

    .grid-body {
      max-height: 300px;
      overflow-y: auto;
    }

    .grid-row {
      display: grid;
      grid-template-columns: 80px 120px 1fr 120px;
      border-bottom: 1px solid #f3f4f6;
    }

    .grid-row:hover {
      background: #f9fafb;
    }

    .grid-cell {
      padding: 0.75rem;
      font-size: 0.875rem;
      color: #374151;
      border-right: 1px solid #f3f4f6;
      display: flex;
      align-items: center;
    }

    .grid-cell:last-child {
      border-right: none;
    }

    .select-btn {
      background-color: #003087;
      color: white;
      border: none;
      padding: 0.4rem 0.8rem;
      border-radius: 6px;
      font-size: 0.8rem;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .select-btn:hover {
      background-color: #002066;
    }

    .no-results {
      text-align: center;
      padding: 2rem;
      color: #6b7280;
    }

    .loading-indicator {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      color: #6b7280;
    }

    .spinner {
      width: 20px;
      height: 20px;
      border: 2px solid #f3f4f6;
      border-top-color: #003087;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin-right: 0.5rem;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 0.75rem;
      padding: 1.5rem;
      border-top: 1px solid #e5e7eb;
    }

    .btn-secondary {
      background-color: #f3f4f6;
      color: #374151;
      border: 1px solid #d1d5db;
      padding: 0.6rem 1.5rem;
      border-radius: 8px;
      font-weight: 500;
      cursor: pointer;
    }

    .btn-secondary:hover {
      background-color: #e5e7eb;
    }
  `]
})
export class CompaniaModalComponent implements OnInit, OnDestroy, OnChanges {
  @Input() show = false;
  @Output() companiaSelected = new EventEmitter<CompaniaRecord>();
  @Output() closeModal = new EventEmitter<void>();

  searchForm: FormGroup;
  companias = signal<CompaniaRecord[]>([]);
  filteredCompanias = signal<CompaniaRecord[]>([]);
  isLoading = signal(false);

  private destroy$ = new Subject<void>();

  constructor(
    private fb: FormBuilder,
    private ccService: CCService
  ) {
    this.searchForm = this.fb.group({
      search: ['']
    });
  }

  ngOnInit(): void {
    // Cargar compañías al inicializar
    this.loadCompanias();

    // Filtrar compañías según búsqueda
    this.searchForm.get('search')!.valueChanges.pipe(
      takeUntil(this.destroy$),
      debounceTime(300),
      distinctUntilChanged()
    ).subscribe(searchTerm => this.filterCompanias(searchTerm));
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['show'] && changes['show'].currentValue === true) {
      console.log('🔍 Modal de compañías abierto, cargando datos...');
      // Recargar compañías cuando el modal se abre
      this.loadCompanias();
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private async loadCompanias(): Promise<void> {
    try {
      this.isLoading.set(true);
      console.log('📡 Iniciando carga de compañías...');
      const companias = await this.ccService.getCompanias().toPromise();
      console.log('📦 Respuesta del servidor:', companias);
      if (companias && companias.length > 0) {
        console.log('✅ Compañías cargadas:', companias.length);
        this.companias.set(companias);
        this.filteredCompanias.set(companias);
      } else {
        console.warn('⚠️ No se encontraron compañías');
      }
    } catch (err) {
      console.error('❌ Error loading companias:', err);
    } finally {
      this.isLoading.set(false);
    }
  }

  private filterCompanias(searchTerm: string): void {
    if (!searchTerm) {
      this.filteredCompanias.set(this.companias());
      return;
    }

    const filtered = this.companias().filter(compania => 
      compania['nombre-cia'].toLowerCase().includes(searchTerm.toLowerCase()) ||
      compania.nit.includes(searchTerm) ||
      compania.cia.toString().includes(searchTerm)
    );
    
    this.filteredCompanias.set(filtered);
  }

  onSelectCompania(compania: CompaniaRecord): void {
    this.companiaSelected.emit(compania);
  }

  onClose(): void {
    this.closeModal.emit();
  }

  trackByCompania(index: number, compania: CompaniaRecord): number {
    return compania.cia;
  }
}