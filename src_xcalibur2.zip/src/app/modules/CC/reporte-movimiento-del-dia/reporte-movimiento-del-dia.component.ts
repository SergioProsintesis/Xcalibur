import { Component, OnDestroy, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { combineLatest, debounceTime, distinctUntilChanged, filter, startWith, Subject, takeUntil } from 'rxjs';

import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CCService } from '../../../core/services/cc.service';
import { CompaniaRecord, ReporteOption, GenerarReporteResponse } from '../../../core/interfaces/cc.interface';
import { CompaniaModalComponent } from './compania-modal/compania-modal.component';

@Component({
  selector: 'app-reporte-movimiento-del-dia',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, CompaniaModalComponent],
  templateUrl: './reporte-movimiento-del-dia.component.html',
  styleUrl: './reporte-movimiento-del-dia.component.css'
})
export class ReporteMovimientoDelDiaComponent implements OnInit, OnDestroy {
  form: FormGroup;
  isLoading = signal(false);
  showCompaniaModal = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  reportesOptions = signal<ReporteOption[]>([]);
  isGeneratingReport = signal(false);
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Reporte Movimiento del Día`);
  
  private destroy$ = new Subject<void>();
  private loadingReportes = false;
  private programContext = inject(ProgramContextService);

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
    private loading: LoadingService,
    private ccService: CCService
  ) {
    this.form = this.fb.group({
      compania: ['', Validators.required],
      fechaProceso: ['', Validators.required],
      reporte: [{ value: '', disabled: true }, Validators.required]
    });
  }

  ngOnInit(): void {
    // Fecha por defecto: hoy
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    this.form.patchValue({ fechaProceso: `${yyyy}-${mm}-${dd}` });

    // Validación de compañía con backend
    this.form.get('compania')!.valueChanges.pipe(
      takeUntil(this.destroy$),
      debounceTime(400),
      distinctUntilChanged(),
      filter(v => !!v && v.length > 0)
    ).subscribe(value => this.validateCompania(value));

    // Cargar reportes cuando cambien compañía o fecha (evitar loop con reporte)
    combineLatest([
      this.form.get('compania')!.valueChanges.pipe(startWith(this.form.get('compania')?.value)),
      this.form.get('fechaProceso')!.valueChanges.pipe(startWith(this.form.get('fechaProceso')?.value))
    ]).pipe(
      takeUntil(this.destroy$),
      debounceTime(300),
      filter(([compania, fechaProceso]) => !!(compania && fechaProceso && this.form.get('compania')?.valid && this.form.get('fechaProceso')?.valid))
    ).subscribe(() => this.loadReportesOptions());
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private validateCompania(codigo: string) {
    this.ccService.validateCompania(codigo).subscribe(compania => {
      if (compania) {
        this.selectedCompania.set(compania);
        const ctrl = this.form.get('compania');
        if (ctrl?.hasError('notFound')) {
          const errors = { ...(ctrl.errors || {}) };
          delete errors['notFound'];
          ctrl.setErrors(Object.keys(errors).length ? errors : null);
        }
      } else {
        this.selectedCompania.set(null);
        this.form.get('compania')?.setErrors({ notFound: true });
      }
    });
  }

  private loadReportesOptions() {
    const { compania, fechaProceso } = this.form.value;
    if (!compania || !fechaProceso || this.loadingReportes) {
      this.form.get('reporte')?.disable();
      return;
    }

    // Evitar múltiples llamadas simultáneas
    this.loadingReportes = true;
    console.log('Loading reportes for:', { compania, fechaProceso });

    this.ccService.getReportesOptions(compania, fechaProceso, 'cc2201').subscribe({
      next: (reportes) => {
        console.log('Reportes loaded:', reportes.length);
        this.reportesOptions.set(reportes);
        
        // Resetear selección de reporte sin disparar valueChanges
        const reporteControl = this.form.get('reporte');
        if (reporteControl) {
          reporteControl.setValue('', { emitEvent: false });
        }
        
        // Habilitar o deshabilitar el control según si hay opciones
        if (reportes.length > 0) {
          reporteControl?.enable();
        } else {
          reporteControl?.disable();
        }
        
        this.loadingReportes = false;
      },
      error: (error) => {
        console.error('Error loading reportes:', error);
        this.loadingReportes = false;
        this.form.get('reporte')?.disable();
      }
    });
  }

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.selectedCompania.set(compania);
    this.form.patchValue({ compania: compania.cia.toString() });
    this.showCompaniaModal.set(false);
    this.validateCompania(compania.cia.toString());
  }

  onCloseModal(): void {
    this.showCompaniaModal.set(false);
  }

  onGenerarReporte(formato: 'excel' | 'pdf' | 'pantalla'): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.toast.showWarning('Complete todos los campos obligatorios');
      return;
    }

    const { compania, fechaProceso, reporte } = this.form.value;
    
    this.isGeneratingReport.set(true);
    this.loading.show();
    
    this.ccService.generarReporte(compania, fechaProceso, reporte).subscribe({
      next: (response) => {
        this.isGeneratingReport.set(false);
        this.loading.hide();
        
        if (response) {
          this.handleReporteGenerated(response, formato);
        } else {
          this.toast.showError('No se pudo generar el reporte');
        }
      },
      error: (err) => {
        this.isGeneratingReport.set(false);
        this.loading.hide();
        console.error('Error generando reporte:', err);
        this.toast.showError('Error al generar el reporte');
      }
    });
  }

  private handleReporteGenerated(response: GenerarReporteResponse['response'], formato: 'excel' | 'pdf' | 'pantalla'): void {
    console.log('🎯 Respuesta completa recibida:', {
      csvExists: !!response.pcArchCSV,
      pdfExists: !!response.pcArchPDF,
      csvLength: response.pcArchCSV?.length || 0,
      pdfLength: response.pcArchPDF?.length || 0,
      csvStart: response.pcArchCSV?.substring(0, 50) || 'N/A',
      pdfStart: response.pcArchPDF?.substring(0, 50) || 'N/A'
    });
    
    switch (formato) {
      case 'excel':
        if (response.pcArchCSV) {
          console.log('📊 Procesando Excel con CSV');
          this.downloadExcelFile(response.pcArchCSV);
        } else {
          console.error('❌ CSV no disponible para Excel');
          this.toast.showError('No se pudo obtener el archivo CSV');
          return;
        }
        break;
      case 'pdf':
        if (response.pcArchPDF) {
          console.log('📄 Procesando PDF');
          this.downloadPdfFile(response.pcArchPDF);
        } else {
          console.error('❌ PDF no disponible');
          console.log('🔍 Contenido completo de respuesta:', response);
          this.toast.showError('No se pudo obtener el archivo PDF');
          return;
        }
        break;
      case 'pantalla':
        if (response.pcArchCSV) {
          console.log('🖥️ Procesando vista en pantalla con CSV');
          this.showReportInModal(response.pcArchCSV);
        } else {
          console.error('❌ CSV no disponible para pantalla');
          this.toast.showError('No se pudo obtener los datos para mostrar');
          return;
        }
        break;
    }
    
    const selectedReporte = this.reportesOptions().find(r => r["pcProg-Sel"] === this.form.value.reporte);
    this.toast.showSuccess(`Reporte "${selectedReporte?.["pcNombre-pro"] || 'generado'}" ${formato === 'pantalla' ? 'mostrado' : 'descargado'} exitosamente`);
  }

  private downloadExcelFile(content: string): void {
    try {
      let csvContent: string;
      
      if (this.isBase64(content)) {
        console.log('Contenido base64 detectado, decodificando a texto...');
        // Decodificar base64 a texto
        csvContent = atob(content);
      } else {
        console.log('Contenido de texto detectado...');
        csvContent = content;
      }

      // Convertir a formato CSV separado por punto y coma
      const csvWithSemicolons = this.convertToCsvWithSemicolons(csvContent);
      console.log('CSV convertido (primeras 200 chars):', csvWithSemicolons.substring(0, 200));
      
      // Crear blob como CSV para Excel con BOM UTF-8
      const bom = '\uFEFF'; // BOM para UTF-8
      const finalContent = bom + csvWithSemicolons;
      
      // Crear el blob directamente en lugar de usar base64
      const selectedReporte = this.reportesOptions().find(r => r["pcProg-Sel"] === this.form.value.reporte);
      const filename = `${selectedReporte?.["pcNombre-pro"] || 'reporte'}_${this.form.value.fechaProceso}.csv`;
      
      // Crear blob directamente con UTF-8
      const blob = new Blob([finalContent], { 
        type: 'text/csv;charset=utf-8' 
      });
      
      // Crear enlace de descarga
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;

      // Simular click para descargar
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Limpiar URL
      window.URL.revokeObjectURL(url);

      console.log(`✅ Archivo CSV ${filename} descargado exitosamente`);
      
    } catch (error) {
      console.error('Error procesando archivo Excel:', error);
      this.toast.showError('Error al procesar el archivo Excel');
    }
  }

  private convertToCsvWithSemicolons(content: string): string {
    try {
      // Si el contenido ya tiene formato de filas, procesarlo línea por línea
      const lines = content.split(/\r?\n/);
      const convertedLines: string[] = [];

      for (const line of lines) {
        if (line.trim()) {
          // Si la línea ya tiene separadores, convertir comas/tabs a punto y coma
          let convertedLine = line;
          
          // Detectar separador actual y convertir a punto y coma
          if (line.includes('\t')) {
            // Separado por tabulaciones
            convertedLine = line.split('\t').join(';');
          } else if (line.includes(',') && !line.includes(';')) {
            // Separado por comas (pero solo si no hay punto y coma ya)
            convertedLine = line.split(',').join(';');
          } else if (line.includes('|')) {
            // Separado por pipes
            convertedLine = line.split('|').join(';');
          }
          // Si ya tiene punto y coma, mantenerlo tal como está
          
          convertedLines.push(convertedLine);
        }
      }

      return convertedLines.join('\n');
    } catch (error) {
      console.error('Error convirtiendo a CSV con punto y coma:', error);
      // Si falla la conversión, devolver el contenido original
      return content;
    }
  }

  private downloadPdfFile(content: string): void {
    try {
      const selectedReporte = this.reportesOptions().find(r => r["pcProg-Sel"] === this.form.value.reporte);
      const filename = `${selectedReporte?.["pcNombre-pro"] || 'reporte'}_${this.form.value.fechaProceso}.pdf`;
      
      console.log(`📄 Descargando PDF: ${filename}`);
      console.log(`📊 Contenido (primeros 200 chars):`, content.substring(0, 200));
      console.log(`📏 Longitud del contenido:`, content.length);
      console.log(`🔍 Es base64 válido:`, this.isBase64(content));
      
      // Si el contenido está vacío o es null
      if (!content || content.trim().length === 0) {
        console.error('❌ El contenido del PDF está vacío');
        this.toast.showError('No se recibió contenido para el PDF');
        return;
      }
      
      // Limpiar el contenido (quitar posibles espacios o saltos de línea)
      const cleanContent = content.trim().replace(/\s/g, '');
      console.log(`🧹 Contenido limpiado - Longitud: ${cleanContent.length}`);
      
      // Validar que el contenido sea base64 válido
      if (!this.isBase64(cleanContent)) {
        console.error('❌ El contenido no es base64 válido');
        console.log('📄 Contenido completo recibido:', content);
        this.toast.showError('El contenido del PDF no es válido (no es base64)');
        return;
      }
      
      // Validar que el contenido decodificado tenga la cabecera PDF
      try {
        const decoded = atob(cleanContent);
        console.log(`📐 Contenido decodificado - Longitud: ${decoded.length} bytes`);
        console.log(`🔍 Primeros bytes del PDF:`, decoded.substring(0, 20));
        
        if (!decoded.startsWith('%PDF-')) {
          console.error('❌ El contenido decodificado no es un PDF válido');
          console.log('❌ Inicio del contenido:', decoded.substring(0, 100));
          this.toast.showError('El archivo decodificado no es un PDF válido');
          return;
        }
        console.log('✅ PDF válido detectado con cabecera correcta');
      } catch (decodeError) {
        console.error('❌ Error al decodificar base64:', decodeError);
        this.toast.showError('Error al decodificar el contenido PDF');
        return;
      }
      
      this.downloadFile(cleanContent, filename, 'application/pdf');
      
    } catch (error) {
      console.error('Error procesando archivo PDF:', error);
      this.toast.showError('Error al procesar el archivo PDF');
    }
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    try {
      console.log(`🔄 Iniciando descarga de ${filename} (${mimeType})`);
      console.log(`📏 Tamaño base64: ${base64Data.length} caracteres`);
      
      // Convertir base64 a blob (mismo método que balance-comprobacion)
      const byteCharacters = atob(base64Data);
      console.log(`📐 Tamaño decodificado: ${byteCharacters.length} bytes`);
      
      const byteNumbers = new Array(byteCharacters.length);

      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      
      console.log(`📦 Blob creado: ${blob.size} bytes, tipo: ${blob.type}`);

      // Crear enlace de descarga
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;

      // Simular click para descargar
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Limpiar URL
      window.URL.revokeObjectURL(url);

      console.log(`✅ Archivo ${filename} descargado exitosamente`);
    } catch (error) {
      console.error(`❌ Error al descargar ${filename}:`, error);
      if (error instanceof DOMException) {
        console.error('❌ Error DOM:', error.message);
      }
      this.toast.showError(`Error al descargar el archivo ${filename}`);
    }
  }



  private escapeHtml(text: string): string {
    const div = document.createElement('div');
    div.textContent = text || '';
    return div.innerHTML;
  }

  private isBase64(str: string): boolean {
    try {
      return btoa(atob(str)) === str;
    } catch (err) {
      return false;
    }
  }



  private showReportInModal(content: string): void {
    try {
      // Procesar contenido
      let csvData: string;
      if (this.isBase64(content)) {
        csvData = atob(content);
      } else {
        csvData = content;
      }

      // Convertir a formato estructurado
      const processedData = this.convertToCsvWithSemicolons(csvData);
      const lines = processedData.split('\n').filter(line => line.trim());
      
      if (lines.length === 0) {
        this.toast.showWarning('No hay datos para mostrar');
        return;
      }

      const headers = lines[0].split(';').map(h => h.trim());
      const rows = lines.slice(1).map(line => line.split(';').map(cell => cell.trim()));

      // Abrir ventana nueva con tabla interactiva
      const newWindow = window.open('', '_blank', 'width=1200,height=800');
      if (newWindow) {
        newWindow.document.write(this.generateInteractiveTableHTML(headers, rows));
        newWindow.document.close();
      }
    } catch (error) {
      console.error('Error mostrando reporte en pantalla:', error);
      this.toast.showError('Error al procesar los datos para visualización');
    }
  }

  private generateInteractiveTableHTML(headers: string[], rows: string[][]): string {
    const selectedReporte = this.reportesOptions().find(r => r["pcProg-Sel"] === this.form.value.reporte);
    const reportTitle = selectedReporte?.["pcNombre-pro"] || 'Reporte Movimiento del Día';
    
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>${reportTitle}</title>
        <style>
          * { box-sizing: border-box; }
          body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            margin: 0; 
            padding: 20px; 
            background-color: #f5f5f5;
          }
          
          .container { 
            background: white; 
            border-radius: 8px; 
            padding: 20px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
          }
          
          .header { 
            text-align: center; 
            margin-bottom: 20px; 
            padding-bottom: 15px;
            border-bottom: 2px solid #003087;
          }
          
          .header h1 { 
            color: #003087; 
            margin: 0; 
            font-size: 1.8rem;
          }
          
          .report-info { 
            display: flex; 
            justify-content: space-between; 
            margin: 15px 0; 
            font-size: 0.9rem; 
            color: #666;
          }
          
          .controls { 
            margin: 20px 0; 
            display: flex; 
            gap: 15px; 
            align-items: center; 
            flex-wrap: wrap;
          }
          
          .search-box { 
            flex: 1; 
            min-width: 200px; 
            padding: 8px 12px; 
            border: 1px solid #ddd; 
            border-radius: 4px; 
            font-size: 14px;
          }
          
          .pagination { 
            display: flex; 
            gap: 5px; 
            align-items: center;
          }
          
          .pagination button { 
            padding: 6px 12px; 
            border: 1px solid #ddd; 
            background: white; 
            cursor: pointer; 
            border-radius: 4px;
          }
          
          .pagination button:hover { background: #f0f0f0; }
          .pagination button:disabled { opacity: 0.5; cursor: not-allowed; }
          .pagination button.active { background: #003087; color: white; }
          
          .table-container { 
            overflow-x: auto; 
            border: 1px solid #ddd; 
            border-radius: 4px;
          }
          
          table { 
            width: 100%; 
            border-collapse: collapse; 
            font-size: 13px;
          }
          
          th { 
            background: #003087; 
            color: white; 
            padding: 12px 8px; 
            text-align: left; 
            font-weight: 600; 
            position: sticky; 
            top: 0; 
            z-index: 10;
            cursor: pointer;
            user-select: none;
          }
          
          th:hover { background: #002066; }
          
          td { 
            padding: 8px; 
            border-bottom: 1px solid #eee;
          }
          
          tbody tr:hover { background: #f8f9fa; }
          tbody tr:nth-child(even) { background: #fafbfc; }
          tbody tr:nth-child(even):hover { background: #f0f1f2; }
          
          .stats { 
            margin: 15px 0; 
            padding: 10px; 
            background: #f8f9fa; 
            border-radius: 4px; 
            font-size: 14px;
          }
          
          .no-results { 
            text-align: center; 
            padding: 40px; 
            color: #666; 
            font-style: italic;
          }
          
          .sort-indicator { 
            margin-left: 5px; 
            opacity: 0.6;
          }
          
          @media (max-width: 768px) {
            .controls { flex-direction: column; align-items: stretch; }
            .search-box { min-width: auto; }
            th, td { padding: 6px 4px; font-size: 12px; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>${reportTitle}</h1>
            <div class="report-info">
              <span><strong>Compañía:</strong> ${this.selectedCompania()?.["nombre-cia"] || this.form.value.compania}</span>
              <span><strong>Fecha:</strong> ${this.form.value.fechaProceso}</span>
              <span><strong>Generado:</strong> ${new Date().toLocaleString()}</span>
            </div>
          </div>
          
          <div class="controls">
            <input type="text" id="searchBox" class="search-box" placeholder="Buscar en todos los campos...">
            <div class="pagination" id="pagination"></div>
          </div>
          
          <div class="stats" id="stats"></div>
          
          <div class="table-container">
            <table id="dataTable">
              <thead>
                <tr>
                  ${headers.map((header, index) => 
                    `<th onclick="sortTable(${index})" title="Hacer clic para ordenar">
                      ${header}
                      <span class="sort-indicator" id="sort-${index}">↕️</span>
                     </th>`
                  ).join('')}
                </tr>
              </thead>
              <tbody id="tableBody">
              </tbody>
            </table>
            <div class="no-results" id="noResults" style="display: none;">
              No se encontraron resultados para la búsqueda actual
            </div>
          </div>
        </div>
        
        <script>
          const originalData = ${JSON.stringify(rows)};
          let currentData = [...originalData];
          let currentPage = 1;
          const rowsPerPage = 50;
          let sortColumn = -1;
          let sortDirection = 'asc';
          
          function renderTable() {
            const tbody = document.getElementById('tableBody');
            const start = (currentPage - 1) * rowsPerPage;
            const end = start + rowsPerPage;
            const pageData = currentData.slice(start, end);
            
            if (pageData.length === 0 && currentData.length > 0) {
              currentPage = 1;
              renderTable();
              return;
            }
            
            tbody.innerHTML = pageData.map(row => 
              '<tr>' + row.map(cell => '<td>' + (cell || '') + '</td>').join('') + '</tr>'
            ).join('');
            
            updateStats();
            updatePagination();
            
            document.getElementById('noResults').style.display = 
              currentData.length === 0 ? 'block' : 'none';
            document.querySelector('.table-container table').style.display = 
              currentData.length === 0 ? 'none' : 'table';
          }
          
          function updateStats() {
            const stats = document.getElementById('stats');
            const total = currentData.length;
            const showing = Math.min(rowsPerPage, total - (currentPage - 1) * rowsPerPage);
            const from = total > 0 ? (currentPage - 1) * rowsPerPage + 1 : 0;
            const to = (currentPage - 1) * rowsPerPage + showing;
            
            stats.textContent = 'Mostrando ' + from + ' a ' + to + ' de ' + total + ' registros';
            if (total !== originalData.length) {
              stats.textContent += ' (filtrado de ' + originalData.length + ' registros totales)';
            }
          }
          
          function updatePagination() {
            const pagination = document.getElementById('pagination');
            const totalPages = Math.ceil(currentData.length / rowsPerPage);
            
            if (totalPages <= 1) {
              pagination.innerHTML = '';
              return;
            }
            
            let html = '';
            html += '<button onclick="goToPage(1)" ' + (currentPage === 1 ? 'disabled' : '') + '>« Primera</button>';
            html += '<button onclick="goToPage(' + (currentPage - 1) + ')" ' + (currentPage === 1 ? 'disabled' : '') + '>‹ Anterior</button>';
            
            let startPage = Math.max(1, currentPage - 2);
            let endPage = Math.min(totalPages, currentPage + 2);
            
            if (startPage > 1) {
              html += '<button onclick="goToPage(1)">1</button>';
              if (startPage > 2) html += '<span>...</span>';
            }
            
            for (let i = startPage; i <= endPage; i++) {
              html += '<button onclick="goToPage(' + i + ')" ' + 
                     (i === currentPage ? 'class="active"' : '') + '>' + i + '</button>';
            }
            
            if (endPage < totalPages) {
              if (endPage < totalPages - 1) html += '<span>...</span>';
              html += '<button onclick="goToPage(' + totalPages + ')">' + totalPages + '</button>';
            }
            
            html += '<button onclick="goToPage(' + (currentPage + 1) + ')" ' + (currentPage === totalPages ? 'disabled' : '') + '>Siguiente ›</button>';
            html += '<button onclick="goToPage(' + totalPages + ')" ' + (currentPage === totalPages ? 'disabled' : '') + '>Última »</button>';
            
            pagination.innerHTML = html;
          }
          
          function goToPage(page) {
            const totalPages = Math.ceil(currentData.length / rowsPerPage);
            if (page >= 1 && page <= totalPages) {
              currentPage = page;
              renderTable();
            }
          }
          
          function filterData() {
            const searchTerm = document.getElementById('searchBox').value.toLowerCase();
            currentData = originalData.filter(row => 
              row.some(cell => cell.toLowerCase().includes(searchTerm))
            );
            currentPage = 1;
            renderTable();
          }
          
          function sortTable(columnIndex) {
            if (sortColumn === columnIndex) {
              sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
            } else {
              sortColumn = columnIndex;
              sortDirection = 'asc';
            }
            
            currentData.sort((a, b) => {
              const aVal = a[columnIndex] || '';
              const bVal = b[columnIndex] || '';
              
              const aNum = parseFloat(aVal.replace(/[^0-9.-]/g, ''));
              const bNum = parseFloat(bVal.replace(/[^0-9.-]/g, ''));
              
              let result;
              if (!isNaN(aNum) && !isNaN(bNum)) {
                result = aNum - bNum;
              } else {
                result = aVal.localeCompare(bVal);
              }
              
              return sortDirection === 'asc' ? result : -result;
            });
            
            // Update sort indicators
            document.querySelectorAll('.sort-indicator').forEach(el => el.textContent = '↕️');
            document.getElementById('sort-' + columnIndex).textContent = 
              sortDirection === 'asc' ? '↑' : '↓';
            
            currentPage = 1;
            renderTable();
          }
          
          // Event listeners
          document.getElementById('searchBox').addEventListener('input', filterData);
          
          // Initialize table
          renderTable();
        </script>
      </body>
      </html>
    `;
  }

  onClear(): void {
    this.form.reset();
    this.selectedCompania.set(null);
    this.reportesOptions.set([]);
    
    // Resetear fecha a hoy
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    this.form.patchValue({ fechaProceso: `${yyyy}-${mm}-${dd}` });
  }

  goBack(): void {
    // Implementar navegación atrás
    window.history.back();
  }

  // Helpers para validación
  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field?.invalid && field?.touched);
  }

  getErrorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (field?.hasError('required')) return 'Campo obligatorio';
    if (field?.hasError('notFound')) return 'Compañía no encontrada';
    return '';
  }

  trackByReporte(index: number, reporte: ReporteOption): string {
    return reporte['pcProg-Sel'];
  }
}