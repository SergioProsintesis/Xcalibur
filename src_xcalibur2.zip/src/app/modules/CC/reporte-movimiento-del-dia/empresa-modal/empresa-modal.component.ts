import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, signal, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { debounceTime, distinctUntilChanged, startWith, Subject, takeUntil } from 'rxjs';

import { CCService } from '../../../../core/services/cc.service';

interface EmpresaRecord {
  empresa: number;
  'nombre-emp': string;
  nit: string;
  cia: number;
}

@Component({
  selector: 'app-empresa-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  template: `
    <div class="modal-backdrop" *ngIf="show" (click)="onClose()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2 class="modal-title">Buscar Empresa</h2>
          <button type="button" class="close-btn" (click)="onClose()">&times;</button>
        </div>

        <div class="modal-body">
          <form [formGroup]="searchForm" class="search-form">
            <div class="search-field">
              <label class="field-label">Buscar por código o nombre</label>
              <input type="text" formControlName="search" class="search-input" placeholder="Escriba para buscar...">
            </div>
          </form>

          <div class="empresas-grid" *ngIf="filteredEmpresas().length > 0; else noResults">
            <div class="grid-header">
              <div class="header-cell">Código</div>
              <div class="header-cell">NIT</div>
              <div class="header-cell">Nombre</div>
              <div class="header-cell">Acción</div>
            </div>
            <div class="grid-body">
              <div class="grid-row" *ngFor="let empresa of filteredEmpresas(); trackBy: trackByEmpresa">
                <div class="grid-cell">{{ empresa.empresa }}</div>
                <div class="grid-cell">{{ empresa.nit }}</div>
                <div class="grid-cell">{{ empresa['nombre-emp'] }}</div>
                <div class="grid-cell">
                  <button type="button" class="select-btn" (click)="onSelectEmpresa(empresa)">
                    Seleccionar
                  </button>
                </div>
              </div>
            </div>
          </div>

          <ng-template #noResults>
            <div class="no-results" *ngIf="!isLoading()">
              <p>No se encontraron empresas</p>
            </div>
          </ng-template>

          <div class="loading-indicator" *ngIf="isLoading()">
            <div class="spinner"></div>
            <span>Cargando empresas...</span>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn-secondary" (click)="onClose()">Cancelar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .modal-content {
      background: white;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 800px;
      max-height: 80vh;
      display: flex;
      flex-direction: column;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .modal-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: #003087;
      margin: 0;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #6b7280;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .close-btn:hover {
      color: #374151;
    }

    .modal-body {
      padding: 1.5rem;
      overflow-y: auto;
      flex: 1;
    }

    .search-form {
      margin-bottom: 1.5rem;
    }

    .search-field {
      display: flex;
      flex-direction: column;
    }

    .field-label {
      font-weight: 500;
      color: #374151;
      margin-bottom: 0.5rem;
    }

    .search-input {
      border: 1px solid #d1d5db;
      border-radius: 8px;
      padding: 0.75rem 1rem;
      font-size: 1rem;
      font-family: inherit;
    }

    .search-input:focus {
      outline: none;
      border-color: #003087;
      box-shadow: 0 0 0 3px rgba(0, 48, 135, 0.1);
    }

    .empresas-grid {
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      overflow: hidden;
    }

    .grid-header {
      display: grid;
      grid-template-columns: 100px 120px 1fr 100px;
      gap: 0;
      padding: 1rem;
      background: #f9fafb;
      border-bottom: 1px solid #e5e7eb;
      font-weight: 600;
      color: #374151;
    }

    .header-cell {
      text-align: left;
      font-size: 0.875rem;
      padding: 0.5rem 0.75rem;
      border-right: 1px solid #e5e7eb;
    }

    .header-cell:last-child {
      border-right: none;
    }

    .grid-body {
      max-height: 400px;
      overflow-y: auto;
    }

    .grid-row {
      display: grid;
      grid-template-columns: 100px 120px 1fr 100px;
      gap: 0;
      padding: 0;
      border-bottom: 1px solid #f3f4f6;
      align-items: center;
    }

    .grid-row:hover {
      background: #f9fafb;
    }

    .grid-cell {
      padding: 0.75rem;
      font-size: 0.875rem;
      color: #374151;
      border-right: 1px solid #f3f4f6;
      display: flex;
      align-items: center;
    }

    .grid-cell:last-child {
      border-right: none;
    }

    .select-btn {
      background-color: #003087;
      color: white;
      border: none;
      padding: 0.4rem 1rem;
      border-radius: 6px;
      font-size: 0.8rem;
      cursor: pointer;
      transition: background-color 0.2s;
      white-space: nowrap;
      min-width: 95px;
    }

    .select-btn:hover {
      background-color: #002066;
    }

    .no-results {
      padding: 2rem;
      text-align: center;
      color: #6b7280;
    }

    .loading-indicator {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      gap: 1rem;
    }

    .spinner {
      width: 40px;
      height: 40px;
      border: 4px solid #e5e7eb;
      border-top-color: #003087;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .modal-footer {
      display: flex;
      justify-content: flex-end;
      padding: 1.5rem;
      border-top: 1px solid #e5e7eb;
      gap: 1rem;
    }

    .btn-secondary {
      background: #f3f4f6;
      color: #374151;
      border: 1px solid #d1d5db;
      border-radius: 6px;
      padding: 0.75rem 1.5rem;
      font-size: 1rem;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
    }

    .btn-secondary:hover {
      background: #e5e7eb;
    }
  `]
})
export class EmpresaModalComponent implements OnInit, OnDestroy, OnChanges {
  @Input() show = false;
  @Input() compania: number | null = null;
  @Output() closeModal = new EventEmitter<void>();
  @Output() empresaSelected = new EventEmitter<EmpresaRecord>();

  searchForm: FormGroup;
  empresas = signal<EmpresaRecord[]>([]);
  filteredEmpresas = signal<EmpresaRecord[]>([]);
  isLoading = signal(false);

  private destroy$ = new Subject<void>();

  constructor(
    private fb: FormBuilder,
    private ccService: CCService
  ) {
    this.searchForm = this.fb.group({
      search: ['']
    });
  }

  ngOnInit(): void {
    this.setupSearchListener();
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log('[EmpresaModal] ngOnChanges detected:', changes);
    if (changes['show']) {
      console.log('[EmpresaModal] show changed - previous:', changes['show'].previousValue, 'current:', changes['show'].currentValue);
    }
    if (changes['compania']) {
      console.log('[EmpresaModal] compania changed - previous:', changes['compania'].previousValue, 'current:', changes['compania'].currentValue);
    }
    if (changes['show'] && changes['show'].currentValue && this.compania) {
      console.log('[EmpresaModal] Loading empresas...');
      this.loadEmpresas();
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private loadEmpresas(): void {
    if (!this.compania) return;

    this.isLoading.set(true);
    this.ccService.getEmpresasCargaCobranza(this.compania.toString())
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (empresas) => {
          this.empresas.set(empresas);
          this.filteredEmpresas.set(empresas);
          this.isLoading.set(false);
        },
        error: (err) => {
          console.error('Error loading empresas:', err);
          this.isLoading.set(false);
        }
      });
  }

  private setupSearchListener(): void {
    this.searchForm.get('search')?.valueChanges
      .pipe(
        startWith(''),
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe((searchTerm) => {
        this.filterEmpresas(searchTerm);
      });
  }

  private filterEmpresas(term: string): void {
    const filtered = this.empresas().filter(empresa =>
      empresa.empresa.toString().includes(term) ||
      empresa['nombre-emp']?.toLowerCase().includes(term?.toLowerCase()) ||
      empresa.nit?.includes(term)
    );
    this.filteredEmpresas.set(filtered);
  }

  onSelectEmpresa(empresa: EmpresaRecord): void {
    this.empresaSelected.emit(empresa);
    this.onClose();
  }

  onClose(): void {
    this.closeModal.emit();
  }

  trackByEmpresa(index: number, empresa: EmpresaRecord): number {
    return empresa.empresa;
  }
}
