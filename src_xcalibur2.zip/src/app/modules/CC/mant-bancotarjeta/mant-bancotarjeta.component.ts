import { Component, inject, signal, OnInit, computed, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CCService } from '../../../core/services/cc.service';
import { BancoTarjetaRecord, CompaniaRecord } from '../../../core/interfaces/cc.interface';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { BancoTarjetaModalComponent } from './banco-tarjeta-modal/banco-tarjeta-modal.component';

@Component({
  selector: 'app-mant-bancotarjeta',
  standalone: true,
  imports: [
    CommonModule, 
    ReactiveFormsModule, 
    FormsModule, 
    CompaniaModalComponent,
    BancoTarjetaModalComponent
  ],
  templateUrl: './mant-bancotarjeta.component.html',
  styleUrls: ['./mant-bancotarjeta.component.css']
})
export class MantBancoTarjetaComponent implements OnInit {
  // Force file reload timestamp: 2026-02-02T00:00:00Z
  private fb = inject(FormBuilder);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private ccService = inject(CCService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  bancoTarjetaForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Banco/Tarjeta`);
  
  // Signals para estado reactivo
  loadingState = signal<boolean>(false);
  hasUnsavedChanges = signal<boolean>(false);
  showCompaniaModal = signal<boolean>(false);
  showBancoTarjetaModal = signal<boolean>(false);
  showCreateModal = signal<boolean>(false);
  showReportModal = signal<boolean>(false);
  createBancoTarjetaForm!: FormGroup;
  
  // Datos seleccionados
  selectedCompania = signal<CompaniaRecord | null>(null);
  selectedBancoTarjeta = signal<BancoTarjetaRecord | null>(null);
  bancosTarjetasDisponibles = signal<BancoTarjetaRecord[]>([]);
  reportResponse: any = null;

  ngOnInit(): void {
    this.initializeForm();
    this.initializeCreateForm();
    this.resetForm();
  }

  private initializeForm(): void {
    this.bancoTarjetaForm = this.fb.group({
      // Campos del formulario
      cia: [null, [Validators.required]],
      'nombre-cia': [{ value: '', disabled: true }],
      bantar: [null, [Validators.required]],
      'nombre-bant': ['', [Validators.required]],
      'text-bant': ['', [Validators.maxLength(500)]] // Comentario
    });

    // Detectar cambios en el formulario
    this.bancoTarjetaForm.valueChanges.subscribe(() => {
      this.hasUnsavedChanges.set(true);
    });
  }

  private initializeCreateForm(): void {
    this.createBancoTarjetaForm = this.fb.group({
      bantar: ['', [Validators.required, Validators.min(1)]],
      'nombre-bant': ['', [Validators.required, Validators.minLength(1)]],
      'text-bant': ['', [Validators.maxLength(500)]]
    });
  }


  /** Resetear formulario a estado inicial */
  resetForm(): void {
    this.bancoTarjetaForm.reset({
      cia: null,
      'nombre-cia': '',
      bantar: null,
      'nombre-bant': '',
      'text-bant': '',
      'Agrega-Bant': '',
      'date-ctrl': '',
      'login-ctrl': '',
      'agrega-banswift': '',
      tparent: ''
    });
    
    this.selectedCompania.set(null);
    this.selectedBancoTarjeta.set(null);
    this.hasUnsavedChanges.set(false);
  }

  /** Abrir modal de compañías */
  openCompaniaModal(): void {
    this.showCompaniaModal.set(true);
  }

  /** Cerrar modal de compañías */
  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  /** Manejar selección de compañía */
  onCompaniaSelected(compania: CompaniaRecord): void {
    this.selectedCompania.set(compania);
    this.bancoTarjetaForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.hasUnsavedChanges.set(true);
  }

  /** Validar compañía al perder el foco */
  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.bancoTarjetaForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.selectedCompania.set(compania);
        this.bancoTarjetaForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
    }
  }

  /** Limpiar datos de compañía */
  private limpiarCompania(): void {
    this.selectedCompania.set(null);
    this.bancoTarjetaForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
  }

  /** Abrir modal de banco/tarjeta */
  async openBancoTarjetaModal(): Promise<void> {
    const companiaId = this.bancoTarjetaForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Seleccione primero una compañía');
      return;
    }

    try {
      this.loadingState.set(true);
      
      // Cargar DATOS PRIMERO
      const bancos = await this.ccService.getBancosTarjetas(companiaId.toString()).toPromise();
      
      if (!bancos || bancos.length === 0) {
        this.toastService.showWarning('No hay bancos/tarjetas disponibles para esta compañía');
        this.loadingState.set(false);
        return;
      }

      // Guardar datos en signal antes de abrir modal
      this.bancosTarjetasDisponibles.set(bancos);

      // AHORA abrir el modal CON DATOS
      this.showBancoTarjetaModal.set(true);
    } catch (error) {
      console.error('Error loading bancos/tarjetas:', error);
      this.toastService.showError('Error al cargar los bancos/tarjetas');
    } finally {
      this.loadingState.set(false);
    }
  }

  /** Cerrar modal de banco/tarjeta */
  closeBancoTarjetaModal(): void {
    this.showBancoTarjetaModal.set(false);
  }

  /** Método alias para compatibilidad */
  closeShowModal(): void {
    this.showBancoTarjetaModal.set(false);
  }

  /** Cargar bancos/tarjetas disponibles */
  private async loadBancoTarjetas(): Promise<void> {
    const companiaId = this.bancoTarjetaForm.get('cia')?.value;
    if (companiaId) {
      try {
        const bancos = await this.ccService.getBancosTarjetas(companiaId.toString()).toPromise();
        if (bancos) {
          this.bancosTarjetasDisponibles.set(bancos);
        }
      } catch (error) {
        console.error('Error al recargar bancos/tarjetas:', error);
      }
    }
  }

  /** Manejar selección de banco/tarjeta */
  async onBancoTarjetaSelected(bancoTarjeta: BancoTarjetaRecord): Promise<void> {
    const companiaId = this.bancoTarjetaForm.get('cia')?.value;
    if (!companiaId) return;

    this.loadingState.set(true);
    try {
      // Load fresh data from server
      const bancos = await this.ccService.getBancosTarjetas(companiaId.toString()).toPromise();
      const bancoActualizado = bancos?.find(b => b.bantar === bancoTarjeta.bantar);

      if (bancoActualizado) {
        this.selectedBancoTarjeta.set(bancoActualizado);
        this.bancoTarjetaForm.patchValue({
          bantar: bancoActualizado.bantar,
          'nombre-bant': bancoActualizado['nombre-bant'],
          'text-bant': bancoActualizado['text-bant'],
          'Agrega-Bant': bancoActualizado['Agrega-Bant'],
          'date-ctrl': bancoActualizado['date-ctrl'],
          'login-ctrl': bancoActualizado['login-ctrl'],
          'agrega-banswift': bancoActualizado['agrega-banswift'],
          tparent: bancoActualizado.tparent
        });
        this.toastService.showSuccess(`Banco/Tarjeta "${bancoActualizado['nombre-bant']}" cargado`);
      }
    } catch (error) {
      console.error('Error al recargar banco/tarjeta:', error);
      // Fallback to local data
      this.selectedBancoTarjeta.set(bancoTarjeta);
      this.bancoTarjetaForm.patchValue({
        bantar: bancoTarjeta.bantar,
        'nombre-bant': bancoTarjeta['nombre-bant'],
        'text-bant': bancoTarjeta['text-bant'],
        'Agrega-Bant': bancoTarjeta['Agrega-Bant'],
        'date-ctrl': bancoTarjeta['date-ctrl'],
        'login-ctrl': bancoTarjeta['login-ctrl'],
        'agrega-banswift': bancoTarjeta['agrega-banswift'],
        tparent: bancoTarjeta.tparent
      });
    } finally {
      this.loadingState.set(false);
      this.closeBancoTarjetaModal();
      this.hasUnsavedChanges.set(false); // Al cargar datos existentes, no hay cambios sin guardar
    }
  }

  /** Validar banco/tarjeta al cambiar manualmente el campo */
  onBancoTarjetaChange(): void {
    const companiaId = this.bancoTarjetaForm.get('cia')?.value;
    const bancoTarjetaId = this.bancoTarjetaForm.get('bantar')?.value;
    
    if (companiaId && bancoTarjetaId) {
      this.loadingState.set(true);
      this.ccService.validateBancoTarjeta(companiaId.toString(), bancoTarjetaId.toString()).subscribe({
        next: (bancoTarjeta) => {
          this.loadingState.set(false);
          if (bancoTarjeta) {
            this.selectedBancoTarjeta.set(bancoTarjeta);
            this.bancoTarjetaForm.patchValue({
              'nombre-bant': bancoTarjeta['nombre-bant'],
              'text-bant': bancoTarjeta['text-bant'],
              'Agrega-Bant': bancoTarjeta['Agrega-Bant'],
              'date-ctrl': bancoTarjeta['date-ctrl'],
              'login-ctrl': bancoTarjeta['login-ctrl'],
              'agrega-banswift': bancoTarjeta['agrega-banswift'],
              tparent: bancoTarjeta.tparent
            });
            this.hasUnsavedChanges.set(false); // Al cargar datos existentes, no hay cambios sin guardar
          } else {
            this.toastService.showWarning('Banco/Tarjeta no encontrado');
            this.bancoTarjetaForm.patchValue({
              'nombre-bant': '',
              'text-bant': '',
              'Agrega-Bant': '',
              'date-ctrl': '',
              'login-ctrl': '',
              'agrega-banswift': '',
              tparent: ''
            });
            this.selectedBancoTarjeta.set(null);
          }
        },
        error: () => {
          this.loadingState.set(false);
          this.toastService.showError('Error al validar banco/tarjeta');
        }
      });
    }
  }

  /** Ejecutado cuando se sale del campo bantar (blur event) */
  onBancoTarjetaLeave(): void {
    const companiaId = this.bancoTarjetaForm.get('cia')?.value;
    const bancoTarjetaId = this.bancoTarjetaForm.get('bantar')?.value;

    if (!companiaId || !bancoTarjetaId) {
      return;
    }

    console.log('🔍 onBancoTarjetaLeave - Validando:', { companiaId, bancoTarjetaId });

    this.loadingState.set(true);
    this.ccService.validateBancoTarjeta(companiaId.toString(), bancoTarjetaId.toString()).subscribe({
      next: (bancoTarjeta) => {
        this.loadingState.set(false);
        if (bancoTarjeta) {
          console.log('✅ Banco/Tarjeta encontrado:', bancoTarjeta['nombre-bant']);
          this.selectedBancoTarjeta.set(bancoTarjeta);
          this.bancoTarjetaForm.patchValue({
            'nombre-bant': bancoTarjeta['nombre-bant'],
            'text-bant': bancoTarjeta['text-bant'],
            'Agrega-Bant': bancoTarjeta['Agrega-Bant'],
            'date-ctrl': bancoTarjeta['date-ctrl'],
            'login-ctrl': bancoTarjeta['login-ctrl'],
            'agrega-banswift': bancoTarjeta['agrega-banswift'],
            tparent: bancoTarjeta.tparent
          });
          this.hasUnsavedChanges.set(false);
        } else {
          console.warn('⚠️ Banco/Tarjeta no encontrado');
          this.toastService.showWarning('Banco/Tarjeta no encontrado');
          this.bancoTarjetaForm.patchValue({
            'nombre-bant': '',
            'text-bant': '',
            'Agrega-Bant': '',
            'date-ctrl': '',
            'login-ctrl': '',
            'agrega-banswift': '',
            tparent: ''
          });
          this.selectedBancoTarjeta.set(null);
        }
      },
      error: (error) => {
        this.loadingState.set(false);
        console.error('❌ Error en onBancoTarjetaLeave:', error);
        this.toastService.showError('Error al validar banco/tarjeta');
      }
    });
  }

  /** Nuevo registro - Abre modal de crear */
  openCreateModal(): void {
    const companiaId = this.bancoTarjetaForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Seleccione una compañía primero');
      return;
    }
    this.createBancoTarjetaForm.reset();
    this.showCreateModal.set(true);
  }

  /** Cerrar modal de crear */
  closeCreateModal(): void {
    this.showCreateModal.set(false);
    this.createBancoTarjetaForm.reset();
  }

  /** Guardar nuevo banco/tarjeta desde modal */
  async onSaveNew(): Promise<void> {
    if (this.createBancoTarjetaForm.invalid) {
      this.toastService.showWarning('Complete los campos requeridos');
      this.createBancoTarjetaForm.markAllAsTouched();
      return;
    }

    const companiaId = this.bancoTarjetaForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Seleccione una compañía');
      return;
    }

    const formValue = this.createBancoTarjetaForm.value;
    const bancoTarjeta: BancoTarjetaRecord = {
      bantar: formValue.bantar,
      cia: companiaId,
      'nombre-bant': formValue['nombre-bant'],
      'text-bant': formValue['text-bant'] || '',
      'agrega-banswift': '',
      'Agrega-Bant': '',
      'date-ctrl': new Date().toISOString().split('T')[0],
      'login-ctrl': '',
      tparent: ''
    };

    this.loadingState.set(true);
    this.ccService.updateBancoTarjeta(bancoTarjeta).subscribe({
      next: (result) => {
        this.loadingState.set(false);
        if (result) {
          const mensaje = result.terrores && result.terrores.length > 0 
            ? result.terrores[0].descripcion 
            : 'Banco/Tarjeta creado exitosamente';
          this.toastService.showSuccess(mensaje);
          this.resetForm();
          this.showBancoTarjetaModal.set(false);
          this.loadBancoTarjetas();
          this.closeCreateModal();
        } else {
          this.toastService.showError('No se pudo crear el banco/tarjeta');
        }
      },
      error: () => {
        this.loadingState.set(false);
        this.toastService.showError('Error al crear banco/tarjeta');
      }
    });
  }

  /** Limpiar formulario */
  limpiarPantalla(): void {
    this.resetForm();
    this.toastService.showInfo('Formulario limpio');
  }

  /** Guardar banco/tarjeta */
  onSubmit(): void {
    if (this.bancoTarjetaForm.invalid) {
      this.toastService.showWarning('Complete los campos requeridos');
      this.bancoTarjetaForm.markAllAsTouched();
      return;
    }

    const formValue = this.bancoTarjetaForm.value;
    const bancoTarjeta: BancoTarjetaRecord = {
      'Agrega-Bant': formValue['Agrega-Bant'] || '',
      bantar: formValue.bantar,
      cia: formValue.cia,
      'date-ctrl': formValue['date-ctrl'] || new Date().toISOString().split('T')[0],
      'login-ctrl': formValue['login-ctrl'] || '',
      'nombre-bant': formValue['nombre-bant'],
      'text-bant': formValue['text-bant'] || '',
      'agrega-banswift': formValue['agrega-banswift'] || '',
      tparent: formValue.tparent || ''
    };

    this.loadingState.set(true);
    this.ccService.updateBancoTarjeta(bancoTarjeta).subscribe({
      next: (result) => {
        this.loadingState.set(false);
        if (result) {
          const mensaje = result.terrores && result.terrores.length > 0 
            ? result.terrores[0].descripcion 
            : 'Banco/Tarjeta guardado exitosamente';
          this.toastService.showSuccess(mensaje);
          this.resetForm();
          this.showBancoTarjetaModal.set(false);
          this.loadBancoTarjetas();
          this.hasUnsavedChanges.set(false);
          
          // Actualizar el formulario con los datos devueltos
          this.selectedBancoTarjeta.set(result);
        } else {
          this.toastService.showError('No se pudo guardar el banco/tarjeta');
        }
      },
      error: () => {
        this.loadingState.set(false);
        this.toastService.showError('Error al guardar banco/tarjeta');
      }
    });
  }

  /** Eliminar banco/tarjeta */
  onDelete(): void {
    const companiaId = this.bancoTarjetaForm.get('cia')?.value;
    const bancoTarjetaId = this.bancoTarjetaForm.get('bantar')?.value;
    
    if (!companiaId || !bancoTarjetaId) {
      this.toastService.showWarning('Seleccione una compañía y banco/tarjeta');
      return;
    }

    if (confirm('¿Está seguro de eliminar este banco/tarjeta?')) {
      this.loadingState.set(true);
      this.ccService.deleteBancoTarjeta(companiaId.toString(), bancoTarjetaId.toString()).subscribe({
        next: (result) => {
          this.loadingState.set(false);
          if (result) {
            const mensaje = result.terrores && result.terrores.length > 0 
              ? result.terrores[0].descripcion 
              : 'Banco/Tarjeta eliminado exitosamente';
            this.toastService.showSuccess(mensaje);
            this.resetForm();
            this.openBancoTarjetaModal();
          } else {
            this.toastService.showError('No se pudo eliminar el banco/tarjeta');
          }
        },
        error: () => {
          this.loadingState.set(false);
          this.toastService.showError('Error al eliminar banco/tarjeta');
        }
      });
    }
  }

  /** Generar reporte */
  async onGenerateReport(): Promise<void> {
    const companiaId = this.bancoTarjetaForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Seleccione una compañía');
      return;
    }

    try {
      this.loadingState.set(true);
      const fechaActual = new Date().toISOString().split('T')[0];
      
      const response = await this.ccService.generarReporteBancoTarjeta(
        companiaId.toString(), 
        fechaActual
      ).toPromise();
      
      const reportData = response?.response || response;
      
      if (reportData?.pcArchPDF || reportData?.pcArchCSV) {
        this.reportResponse = reportData;
        this.showReportModal.set(true);
        this.toastService.showSuccess('Reporte generado exitosamente');
      } else {
        this.toastService.showWarning('No se pudo generar el reporte');
      }
    } catch (error) {
      console.error('Error generando reporte:', error);
      this.toastService.showError('Error al generar el reporte');
    } finally {
      this.loadingState.set(false);
    }
  }

  downloadReportPDF(): void {
    if (this.reportResponse?.pcArchPDF) {
      this.downloadFile(this.reportResponse.pcArchPDF, 'BancoTarjeta_Reporte.pdf', 'application/pdf');
    }
  }

  downloadReportCSV(): void {
    if (this.reportResponse?.pcArchCSV) {
      this.downloadFile(this.reportResponse.pcArchCSV, 'BancoTarjeta_Reporte.csv', 'text/csv');
    }
  }

  closeReportModal(): void {
    this.showReportModal.set(false);
    this.reportResponse = null;
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    const blob = this.base64ToBlob(base64Data, mimeType);
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    window.URL.revokeObjectURL(url);
  }

  /** Convertir base64 a Blob */
  private base64ToBlob(base64: string, mimeType: string): Blob {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: mimeType });
  }

  /** Navegar hacia atrás */
  goBack(): void {
    if (this.hasUnsavedChanges()) {
      if (confirm('Tiene cambios sin guardar. ¿Desea salir sin guardar?')) {
        this.hasUnsavedChanges.set(false);
        this.router.navigate(['/dashboard']);
      }
    } else {
      this.router.navigate(['/dashboard']);
    }
  }

  /** Verificar si el campo es inválido */
  isFieldInvalid(fieldName: string): boolean {
    const field = this.bancoTarjetaForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  /** Obtener mensaje de error para un campo */
  getFieldError(fieldName: string): string {
    const field = this.bancoTarjetaForm.get(fieldName);
    if (field?.errors) {
      if (field.errors['required']) return 'Este campo es requerido';
      if (field.errors['maxlength']) return `Máximo ${field.errors['maxlength'].requiredLength} caracteres`;
    }
    return '';
  }
}