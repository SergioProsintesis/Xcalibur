import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CCService } from '../../../../core/services/cc.service';
import { BancoTarjetaRecord } from '../../../../core/interfaces/cc.interface';

@Component({
  selector: 'app-banco-tarjeta-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="modal-backdrop" *ngIf="show" (click)="onClose()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2 class="modal-title">Buscar Banco/Tarjeta</h2>
          <button type="button" class="close-btn" (click)="onClose()">&times;</button>
        </div>

        <div class="modal-body">
          <form class="search-form">
            <div class="search-field">
              <label class="field-label">Buscar por código o nombre</label>
              <input 
                type="text" 
                [(ngModel)]="searchTerm"
                [ngModelOptions]="{standalone: true}"
                (input)="filterBancosTarjetas()" 
                class="search-input" 
                placeholder="Escriba para buscar...">
            </div>
          </form>

          <div class="bancos-grid" *ngIf="filteredBancosTarjetas.length > 0; else noResults">
            <div class="grid-header">
              <div class="header-cell">Código</div>
              <div class="header-cell">Nombre</div>
              <div class="header-cell">Comentario</div>
              <div class="header-cell">Acción</div>
            </div>
            <div class="grid-body">
              <div class="grid-row" *ngFor="let banco of filteredBancosTarjetas; trackBy: trackByBanco">
                <div class="grid-cell">{{ banco.bantar }}</div>
                <div class="grid-cell">{{ banco['nombre-bant'] }}</div>
                <div class="grid-cell">{{ (banco['text-bant'] || '') | slice:0:40 }}{{ (banco['text-bant'] && banco['text-bant'].length > 40) ? '...' : '' }}</div>
                <div class="grid-cell">
                  <button type="button" class="select-btn" (click)="onSelectBanco(banco)">
                    Seleccionar
                  </button>
                </div>
              </div>
            </div>
          </div>

          <ng-template #noResults>
            <div class="no-results" *ngIf="!isLoading">
              <p>No se encontraron bancos/tarjetas</p>
            </div>
          </ng-template>

          <div class="loading-indicator" *ngIf="isLoading">
            <div class="spinner"></div>
            <span>Cargando bancos/tarjetas...</span>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn-secondary" (click)="onClose()">Cancelar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .modal-content {
      background: white;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 800px;
      max-height: 80vh;
      display: flex;
      flex-direction: column;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .modal-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: #003087;
      margin: 0;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #6b7280;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .close-btn:hover {
      color: #374151;
    }

    .modal-body {
      padding: 1.5rem;
      overflow-y: auto;
      flex: 1;
    }

    .search-form {
      margin-bottom: 1.5rem;
    }

    .search-field {
      display: flex;
      flex-direction: column;
    }

    .field-label {
      font-weight: 500;
      color: #374151;
      margin-bottom: 0.5rem;
    }

    .search-input {
      border: 1px solid #d1d5db;
      border-radius: 8px;
      padding: 0.75rem;
      font-size: 0.95rem;
      transition: all 0.2s;
    }

    .search-input:focus {
      outline: none;
      border-color: #003087;
      box-shadow: 0 0 0 2px rgba(0, 48, 135, 0.15);
    }

    .bancos-grid {
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      overflow: hidden;
    }

    .grid-header {
      display: grid;
      grid-template-columns: 80px 150px 1fr 120px;
      background: #f9fafb;
      border-bottom: 1px solid #e5e7eb;
    }

    .header-cell {
      padding: 0.75rem;
      font-weight: 600;
      font-size: 0.875rem;
      color: #374151;
      border-right: 1px solid #e5e7eb;
    }

    .header-cell:last-child {
      border-right: none;
    }

    .grid-body {
      max-height: 300px;
      overflow-y: auto;
    }

    .grid-row {
      display: grid;
      grid-template-columns: 80px 150px 1fr 120px;
      border-bottom: 1px solid #f3f4f6;
    }

    .grid-row:hover {
      background: #f9fafb;
    }

    .grid-cell {
      padding: 0.75rem;
      font-size: 0.875rem;
      color: #374151;
      border-right: 1px solid #f3f4f6;
      display: flex;
      align-items: center;
    }

    .grid-cell:last-child {
      border-right: none;
    }

    .select-btn {
      background-color: #003087;
      color: white;
      border: none;
      padding: 0.4rem 0.8rem;
      border-radius: 6px;
      font-size: 0.8rem;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .select-btn:hover {
      background-color: #002066;
    }

    .no-results {
      text-align: center;
      padding: 2rem;
      color: #6b7280;
    }

    .loading-indicator {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      color: #6b7280;
    }

    .spinner {
      width: 20px;
      height: 20px;
      border: 2px solid #f3f4f6;
      border-top-color: #003087;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin-right: 0.5rem;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 0.75rem;
      padding: 1.5rem;
      border-top: 1px solid #e5e7eb;
    }

    .btn-secondary {
      background-color: #f3f4f6;
      color: #374151;
      border: 1px solid #d1d5db;
      padding: 0.6rem 1.5rem;
      border-radius: 8px;
      font-weight: 500;
      cursor: pointer;
    }

    .btn-secondary:hover {
      background-color: #e5e7eb;
    }
  `]
})
export class BancoTarjetaModalComponent implements OnChanges {
  @Input() show = false;
  @Input() companiaId: number | null = null;
  @Input() bancosTarjetas: BancoTarjetaRecord[] = [];
  @Output() close = new EventEmitter<void>();
  @Output() select = new EventEmitter<BancoTarjetaRecord>();

  filteredBancosTarjetas: BancoTarjetaRecord[] = [];
  searchTerm = '';
  isLoading = false;

  constructor(private ccService: CCService) {}

  ngOnChanges(changes: SimpleChanges): void {
    // Si recibimos datos ya cargados, los usamos directamente
    if (changes['bancosTarjetas'] && this.bancosTarjetas && this.bancosTarjetas.length > 0) {
      this.filteredBancosTarjetas = [...this.bancosTarjetas];
    }
    
    // Si no recibimos datos pero el modal se abre, intentamos cargar (fallback)
    if (changes['show'] && this.show && this.companiaId && this.bancosTarjetas.length === 0) {
      this.loadBancosTarjetas();
    }
  }

  private loadBancosTarjetas(): void {
    if (!this.companiaId) return;
    
    this.isLoading = true;
    this.ccService.getBancosTarjetas(this.companiaId.toString()).subscribe({
      next: (data) => {
        this.bancosTarjetas = data || [];
        this.filteredBancosTarjetas = [...this.bancosTarjetas];
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading bancos/tarjetas:', error);
        this.bancosTarjetas = [];
        this.filteredBancosTarjetas = [];
        this.isLoading = false;
      }
    });
  }

  filterBancosTarjetas(): void {
    const term = this.searchTerm.toLowerCase().trim();
    
    if (!term) {
      this.filteredBancosTarjetas = [...this.bancosTarjetas];
      return;
    }

    this.filteredBancosTarjetas = this.bancosTarjetas.filter(banco =>
      banco.bantar.toString().includes(term) ||
      banco['nombre-bant'].toLowerCase().includes(term) ||
      (banco['text-bant'] && banco['text-bant'].toLowerCase().includes(term))
    );
  }

  onSelectBanco(banco: BancoTarjetaRecord): void {
    this.select.emit(banco);
    this.onClose();
  }

  onClose(): void {
    this.close.emit();
    this.searchTerm = '';
    this.filteredBancosTarjetas = [...this.bancosTarjetas];
  }

  trackByBanco(index: number, banco: BancoTarjetaRecord): number {
    return banco.bantar;
  }
}