import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { CompanyResponse, DiscountObservation, DiscountResponse } from './mant-descuentos-facturacion.interface';

@Injectable({
  providedIn: 'root'
})
export class MantDescuentosFacturacionService {
  private apiUrl = 'http://184.168.30.44:8810/XcaliburWeb/rest/ServiciosXcaliburWeb';
  loadingState = signal(false);

  constructor(private http: HttpClient) {}

  async getCompanies(pcLogin: string, pcSuper: string, pcToken: string): Promise<CompanyResponse> {
    this.loadingState.set(true);
    try {
      const params = new HttpParams()
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      return await this.http.get<CompanyResponse>(`${this.apiUrl}/GetCECompanias`, { params }).toPromise() as CompanyResponse;
    } finally {
      this.loadingState.set(false);
    }
  }

  async getLeaveData(pcCompania: string, pcLogin: string, pcSuper: string, pcToken: string): Promise<DiscountResponse> {
    this.loadingState.set(true);
    try {
      const params = new HttpParams()
        .set('pcCompania', pcCompania)
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      return await this.http.get<DiscountResponse>(`${this.apiUrl}/GetLeaveCia_fa5003`, { params }).toPromise() as DiscountResponse;
    } finally {
      this.loadingState.set(false);
    }
  }

  async updateData(data: DiscountObservation, pcLogin: string, pcSuper: string, pcToken: string): Promise<DiscountResponse> {
    this.loadingState.set(true);
    try {
      const payload = {
        tfaobsgen: [data]
      };
      return await this.http.put<DiscountResponse>(`${this.apiUrl}/Updatefaobsgen_fa5003`, payload).toPromise() as DiscountResponse;
    } finally {
      this.loadingState.set(false);
    }
  }
}
