import { Component, OnInit, signal } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MantDescuentosFacturacionService } from './mant-descuentos-facturacion.service';
import { AuthService } from '../../../core/services/auth.service';
import { Company } from './mant-descuentos-facturacion.interface';

@Component({
  selector: 'app-mant-descuentos-facturacion',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './mant-descuentos-facturacion.component.html',
  styleUrl: './mant-descuentos-facturacion.component.css'
})
export class MantDescuentosFacturacionComponent implements OnInit {
  form!: FormGroup;
  companies = signal<Company[]>([]);
  isLoading = signal(false);

  constructor(
    private fb: FormBuilder,
    private service: MantDescuentosFacturacionService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.loadCompanies();
  }

  private initForm(): void {
    this.form = this.fb.group({
      cia: ['', Validators.required],
      obser1_obs: ['', Validators.required],
      obser2_obs: ['', Validators.required],
      obser3_obs: [''],
      obser4_obs: [''],
      obser5_obs: [''],
      obser6_obs: [''],
      obser7_obs: [''],
      teobser7_obs: ['']
    });
  }

  private async loadCompanies(): Promise<void> {
    try {
      const user = this.authService.user();
      if (user && user.pcLogin && user.pcSuper && user.pcToken) {
        const response = await this.service.getCompanies(user.pcLogin, user.pcSuper, user.pcToken);
        this.companies.set(response.dsRespuesta.tgecias);
      }
    } catch (error) {
      console.error('Error loading companies:', error);
    }
  }

  async onCompanyChange(): Promise<void> {
    try {
      const ciaValue = this.form.get('cia')?.value;
      const user = this.authService.user();
      if (ciaValue && user && user.pcLogin && user.pcSuper && user.pcToken) {
        this.isLoading.set(true);
        const response = await this.service.getLeaveData(ciaValue, user.pcLogin, user.pcSuper, user.pcToken);
        if (response.dsRespuesta.tfaobsgen.length > 0) {
          const data = response.dsRespuesta.tfaobsgen[0];
          this.form.patchValue({
            obser1_obs: data.obser1_obs || '',
            obser2_obs: data.obser2_obs || '',
            obser3_obs: data.obser3_obs || '',
            obser4_obs: data.obser4_obs || '',
            obser5_obs: data.obser5_obs || '',
            obser6_obs: data.obser6_obs || '',
            obser7_obs: data.obser7_obs || '',
            teobser7_obs: data.teobser7_obs || ''
          });
        }
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      this.isLoading.set(false);
    }
  }

  async onSave(): Promise<void> {
    if (this.form.invalid) return;
    try {
      this.isLoading.set(true);
      const user = this.authService.user();
      if (user && user.pcLogin && user.pcSuper && user.pcToken) {
        const formValue = this.form.value;
        const data = {
          cia: parseInt(formValue.cia),
          nombre_cia: this.companies().find(c => c.cia === parseInt(formValue.cia))?.nombre_cia || '',
          obser1_obs: formValue.obser1_obs,
          obser2_obs: formValue.obser2_obs,
          obser3_obs: formValue.obser3_obs,
          obser4_obs: formValue.obser4_obs,
          obser5_obs: formValue.obser5_obs,
          obser6_obs: formValue.obser6_obs,
          obser7_obs: formValue.obser7_obs,
          teobser7_obs: formValue.teobser7_obs
        };
        await this.service.updateData(data, user.pcLogin, user.pcSuper, user.pcToken);
        alert('Datos guardados exitosamente');
      }
    } catch (error) {
      console.error('Error saving data:', error);
      alert('Error al guardar');
    } finally {
      this.isLoading.set(false);
    }
  }

  onCancel(): void {
    this.form.reset();
  }
}
