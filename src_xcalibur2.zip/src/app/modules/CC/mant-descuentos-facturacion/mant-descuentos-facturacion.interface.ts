export interface CompanyResponse {
  dsRespuesta: {
    tgecias: Company[];
  };
}

export interface Company {
  cia: number;
  nombre_cia: string;
}

export interface DiscountObservation {
  cia: number;
  nombre_cia: string;
  obser1_obs: string;
  obser2_obs: string;
  obser3_obs: string;
  obser4_obs: string;
  obser5_obs: string;
  obser6_obs: string;
  obser7_obs: string;
  teobser7_obs: string;
}

export interface DiscountResponse {
  dsRespuesta: {
    tfaobsgen: DiscountObservation[];
  };
}
