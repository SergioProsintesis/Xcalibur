import { Component, OnDestroy, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { debounceTime, distinctUntilChanged, filter, Subject, takeUntil } from 'rxjs';

import { AuthService } from '../../../../core/services/auth.service';
import { ToastService } from '../../../../core/services/toast.service';
import { LoadingService } from '../../../../core/services/loading.service';
import { ProgramContextService } from '../../../../core/services/program-context.service';
import { CCService } from '../../../../core/services/cc.service';
import { CompaniaRecord } from '../../../../core/interfaces/cc.interface';
import { CompaniaModalComponent } from '../../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { HelpIconComponent } from '../../../../shared/components/help-icon/help-icon.component';

@Component({
  selector: 'app-reporte-ps2000',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, CompaniaModalComponent],
  templateUrl: './reporte-ps2000.component.html',
  styleUrl: './reporte-ps2000.component.css'
})
export class ReportePS2000Component implements OnInit, OnDestroy {
  form: FormGroup;
  isLoading = signal(false);
  showCompaniaModal = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  isGeneratingReport = signal(false);
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Rep.Fact y Recaudo por Ciudad y PG`);
  
  private destroy$ = new Subject<void>();
  private programContext = inject(ProgramContextService);

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
    private loading: LoadingService,
    private ccService: CCService
  ) {
    this.form = this.fb.group({
      compania: ['', Validators.required],
      fecha: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    // Fecha por defecto: hoy
    const today = new Date();
    
    const formatDate = (date: Date) => {
      const yyyy = date.getFullYear();
      const mm = String(date.getMonth() + 1).padStart(2, '0');
      const dd = String(date.getDate()).padStart(2, '0');
      return `${yyyy}-${mm}-${dd}`;
    };
    
    this.form.patchValue({
      fecha: formatDate(today)
    });

    // Validación de compañía con backend
    this.form.get('compania')!.valueChanges.pipe(
      takeUntil(this.destroy$),
      debounceTime(400),
      distinctUntilChanged(),
      filter(v => !!v && v.length > 0)
    ).subscribe(value => this.validateCompania(value));
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private validateCompania(codigo: string) {
    this.ccService.validateCompania(codigo).subscribe(compania => {
      if (compania) {
        this.selectedCompania.set(compania);
        const ctrl = this.form.get('compania');
        if (ctrl?.hasError('notFound')) {
          const errors = { ...(ctrl.errors || {}) };
          delete errors['notFound'];
          ctrl.setErrors(Object.keys(errors).length ? errors : null);
        }
      } else {
        this.selectedCompania.set(null);
        this.form.get('compania')?.setErrors({ notFound: true });
      }
    });
  }

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.selectedCompania.set(compania);
    this.form.patchValue({ compania: compania.cia.toString() });
    this.showCompaniaModal.set(false);
    this.validateCompania(compania.cia.toString());
  }

  onCloseModal(): void {
    this.showCompaniaModal.set(false);
  }

  onGenerarReporte(formato: 'excel' | 'pdf' | 'pantalla'): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.toast.showWarning('Complete todos los campos obligatorios');
      return;
    }

    const { compania, fecha } = this.form.value;
    
    this.isGeneratingReport.set(true);
    this.loading.show('Generando reporte...');
    
    // Convertir fecha a formato DD/MM/YYYY
    const formatDateToAPI = (dateStr: string) => {
      const [yyyy, mm, dd] = dateStr.split('-');
      return `${dd}/${mm}/${yyyy}`;
    };

    const params = {
      pcCompania: compania,
      pcFecha: formatDateToAPI(fecha)
    };

    this.ccService.getPS2000Report(params).subscribe({
      next: (response) => {
        this.isGeneratingReport.set(false);
        this.loading.hide();
        
        if (response?.response) {
          this.handleReporteGenerated(response.response, formato);
        } else {
          this.toast.showError('No se pudo generar el reporte');
        }
      },
      error: (err) => {
        this.isGeneratingReport.set(false);
        this.loading.hide();
        console.error('Error generando reporte:', err);
        this.toast.showError('Error al generar el reporte');
      }
    });
  }

  private handleReporteGenerated(response: any, formato: 'excel' | 'pdf' | 'pantalla'): void {
    switch (formato) {
      case 'excel':
        if (response.pcArchXLS) {
          this.downloadExcelFile(response.pcArchXLS);
          this.toast.showSuccess('Archivo Excel descargado');
        } else {
          this.toast.showError('No hay datos disponibles para Excel');
        }
        break;

      case 'pdf':
        if (response.pcArchCSV) {
          this.downloadPdfFile(response.pcArchCSV);
          this.toast.showSuccess('Archivo PDF descargado');
        } else {
          this.toast.showError('No hay datos disponibles para PDF');
        }
        break;

      case 'pantalla':
        if (response.pcArchXLS) {
          this.downloadExcelFile(response.pcArchXLS);
          this.toast.showSuccess('Reporte generado');
        } else {
          this.toast.showError('No hay datos disponibles');
        }
        break;
    }
  }

  private downloadExcelFile(base64: string): void {
    try {
      const binaryString = atob(base64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      this.triggerDownload(blob, `PS2000_${new Date().getTime()}.xlsx`);
    } catch (error) {
      console.error('Error downloading Excel file:', error);
      this.toast.showError('Error al descargar el archivo');
    }
  }

  private downloadPdfFile(base64: string): void {
    try {
      const binaryString = atob(base64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'application/pdf' });
      this.triggerDownload(blob, `PS2000_${new Date().getTime()}.pdf`);
    } catch (error) {
      console.error('Error downloading PDF file:', error);
      this.toast.showError('Error al descargar el archivo');
    }
  }

  private triggerDownload(blob: Blob, filename: string): void {
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  }

  onLimpiar(): void {
    this.form.reset({});
    
    const today = new Date();
    const formatDate = (date: Date) => {
      const yyyy = date.getFullYear();
      const mm = String(date.getMonth() + 1).padStart(2, '0');
      const dd = String(date.getDate()).padStart(2, '0');
      return `${yyyy}-${mm}-${dd}`;
    };
    
    this.form.patchValue({
      fecha: formatDate(today)
    });
    
    this.selectedCompania.set(null);
  }

  goBack(): void {
    window.history.back();
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field?.invalid && field?.touched);
  }

  getErrorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (field?.hasError('required')) return 'Campo obligatorio';
    if (field?.hasError('notFound')) return 'Compañía no encontrada';
    return '';
  }
}
