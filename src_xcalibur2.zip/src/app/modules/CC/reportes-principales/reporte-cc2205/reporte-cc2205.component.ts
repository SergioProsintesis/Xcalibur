import { Component, OnDestroy, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { debounceTime, distinctUntilChanged, filter, Subject, takeUntil } from 'rxjs';

import { AuthService } from '../../../../core/services/auth.service';
import { ToastService } from '../../../../core/services/toast.service';
import { LoadingService } from '../../../../core/services/loading.service';
import { ProgramContextService } from '../../../../core/services/program-context.service';
import { CCService } from '../../../../core/services/cc.service';
import { CompaniaRecord } from '../../../../core/interfaces/cc.interface';
import { CompaniaModalComponent } from '../../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { EmpresaModalComponent } from '../../reporte-movimiento-del-dia/empresa-modal/empresa-modal.component';
import { HelpIconComponent } from '../../../../shared/components/help-icon/help-icon.component';

interface EmpresaRecord {
  empresa: number;
  'nombre-emp': string;
  nit: string;
  cia: number;
}

@Component({
  selector: 'app-reporte-cc2205',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, CompaniaModalComponent, EmpresaModalComponent],
  templateUrl: './reporte-cc2205.component.html',
  styleUrl: './reporte-cc2205.component.css'
})
export class ReporteCC2205Component implements OnInit, OnDestroy {
  form: FormGroup;
  isLoading = signal(false);
  showCompaniaModal = signal(false);
  showEmpresaDesdeModal = signal(false);
  showEmpresaHastaModal = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  selectedEmpresaDesde = signal<EmpresaRecord | null>(null);
  selectedEmpresaHasta = signal<EmpresaRecord | null>(null);
  isGeneratingReport = signal(false);
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Reporte Estado de Cuenta Histórico`);
  
  private destroy$ = new Subject<void>();
  private programContext = inject(ProgramContextService);

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
    private loading: LoadingService,
    private ccService: CCService
  ) {
    this.form = this.fb.group({
      compania: ['', Validators.required],
      nombreCompania: [{value: '', disabled: true}],
      empresaDesde: ['', Validators.required],
      nombreEmpresaDesde: [{value: '', disabled: true}],
      empresaHasta: ['', Validators.required],
      nombreEmpresaHasta: [{value: '', disabled: true}],
      fechaDesde: ['', Validators.required],
      fechaHasta: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    console.log('[ReporteCC2205] Component initialized');
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private validateCompania(codigo: string) {
    console.log('[ReporteCC2205] validateCompania called with:', codigo);
    this.ccService.validateCompania(codigo).subscribe(compania => {
      console.log('[ReporteCC2205] validateCompania response:', compania);
      if (compania) {
        this.selectedCompania.set(compania);
        this.form.patchValue({ 
          nombreCompania: compania['nombre-cia'] || ''
        });
        const ctrl = this.form.get('compania');
        if (ctrl?.hasError('notFound')) {
          const errors = { ...(ctrl.errors || {}) };
          delete errors['notFound'];
          ctrl.setErrors(Object.keys(errors).length ? errors : null);
        }
      } else {
        this.selectedCompania.set(null);
        this.form.patchValue({ nombreCompania: '' });
        this.form.get('compania')?.setErrors({ notFound: true });
      }
    });
  }

  private validateEmpresaDesde(codigo: string) {
    const compania = this.form.get('compania')?.value;
    console.log('[ReporteCC2205] validateEmpresaDesde called with codigo:', codigo, 'compania:', compania);
    if (!compania) return;

    this.ccService.validateEmpresa(compania, codigo).subscribe(empresa => {
      console.log('[ReporteCC2205] validateEmpresaDesde response:', empresa);
      if (empresa) {
        this.selectedEmpresaDesde.set(empresa);
        this.form.patchValue({ 
          nombreEmpresaDesde: empresa['nombre-emp'] || ''
        });
        const ctrl = this.form.get('empresaDesde');
        if (ctrl?.hasError('notFound')) {
          const errors = { ...(ctrl.errors || {}) };
          delete errors['notFound'];
          ctrl.setErrors(Object.keys(errors).length ? errors : null);
        }
      } else {
        this.selectedEmpresaDesde.set(null);
        this.form.patchValue({ nombreEmpresaDesde: '' });
        this.form.get('empresaDesde')?.setErrors({ notFound: true });
      }
    });
  }

  private validateEmpresaHasta(codigo: string) {
    const compania = this.form.get('compania')?.value;
    console.log('[ReporteCC2205] validateEmpresaHasta called with codigo:', codigo, 'compania:', compania);
    if (!compania) return;

    this.ccService.validateEmpresa(compania, codigo).subscribe(empresa => {
      console.log('[ReporteCC2205] validateEmpresaHasta response:', empresa);
      if (empresa) {
        this.selectedEmpresaHasta.set(empresa);
        this.form.patchValue({ 
          nombreEmpresaHasta: empresa['nombre-emp'] || ''
        });
        const ctrl = this.form.get('empresaHasta');
        if (ctrl?.hasError('notFound')) {
          const errors = { ...(ctrl.errors || {}) };
          delete errors['notFound'];
          ctrl.setErrors(Object.keys(errors).length ? errors : null);
        }
      } else {
        this.selectedEmpresaHasta.set(null);
        this.form.patchValue({ nombreEmpresaHasta: '' });
        this.form.get('empresaHasta')?.setErrors({ notFound: true });
      }
    });
  }

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    console.log('[ReporteCC2205] Compania selected:', compania);
    this.selectedCompania.set(compania);
    this.form.patchValue({ 
      compania: compania.cia.toString(),
      nombreCompania: compania['nombre-cia'] || ''
    });
    this.showCompaniaModal.set(false);
    this.validateCompania(compania.cia.toString());
    // Reset empresas when compania changes
    this.selectedEmpresaDesde.set(null);
    this.selectedEmpresaHasta.set(null);
    this.form.patchValue({ 
      empresaDesde: '', 
      nombreEmpresaDesde: '',
      empresaHasta: '', 
      nombreEmpresaHasta: ''
    });
  }

  onCloseModal(): void {
    this.showCompaniaModal.set(false);
    this.showEmpresaDesdeModal.set(false);
    this.showEmpresaHastaModal.set(false);
  }

  onCompaniaBlur(): void {
    const value = this.form.get('compania')?.value;
    console.log('[ReporteCC2205] onCompaniaBlur called, value:', value);
    if (value && value.toString().length > 0) {
      console.log('[ReporteCC2205] Calling validateCompania with:', value);
      this.validateCompania(value);
    }
  }

  onEmpresaDesdeBlur(): void {
    const value = this.form.get('empresaDesde')?.value;
    console.log('[ReporteCC2205] onEmpresaDesdeBlur called, value:', value);
    if (value && value.toString().length > 0) {
      console.log('[ReporteCC2205] Calling validateEmpresaDesde with:', value);
      this.validateEmpresaDesde(value);
    }
  }

  onEmpresaHastaBlur(): void {
    const value = this.form.get('empresaHasta')?.value;
    console.log('[ReporteCC2205] onEmpresaHastaBlur called, value:', value);
    if (value && value.toString().length > 0) {
      console.log('[ReporteCC2205] Calling validateEmpresaHasta with:', value);
      this.validateEmpresaHasta(value);
    }
  }

  onOpenEmpresaDesdeModal(): void {
    console.log('[ReporteCC2205] onOpenEmpresaDesdeModal called');
    const compania = this.form.get('compania')?.value;
    console.log('[ReporteCC2205] Compania value:', compania);
    if (!compania) {
      console.warn('[ReporteCC2205] No compania selected');
      this.toast.showWarning('Seleccione una compañía primero');
      return;
    }
    console.log('[ReporteCC2205] Setting showEmpresaDesdeModal to true');
    this.showEmpresaDesdeModal.set(true);
    console.log('[ReporteCC2205] showEmpresaDesdeModal is now:', this.showEmpresaDesdeModal());
  }

  onOpenEmpresaHastaModal(): void {
    console.log('[ReporteCC2205] onOpenEmpresaHastaModal called');
    const compania = this.form.get('compania')?.value;
    console.log('[ReporteCC2205] Compania value:', compania);
    if (!compania) {
      console.warn('[ReporteCC2205] No compania selected');
      this.toast.showWarning('Seleccione una compañía primero');
      return;
    }
    console.log('[ReporteCC2205] Setting showEmpresaHastaModal to true');
    this.showEmpresaHastaModal.set(true);
    console.log('[ReporteCC2205] showEmpresaHastaModal is now:', this.showEmpresaHastaModal());
  }

  onEmpresaDesdeSelected(empresa: EmpresaRecord): void {
    console.log('[ReporteCC2205] Empresa Desde selected:', empresa);
    console.log('[ReporteCC2205] Nombre empresa:', empresa['nombre-emp']);
    this.selectedEmpresaDesde.set(empresa);
    console.log('[ReporteCC2205] selectedEmpresaDesde signal value:', this.selectedEmpresaDesde());
    this.form.patchValue({ 
      empresaDesde: empresa.empresa.toString(),
      nombreEmpresaDesde: empresa['nombre-emp'] || ''
    });
    this.showEmpresaDesdeModal.set(false);
    this.validateEmpresaDesde(empresa.empresa.toString());
  }

  onEmpresaHastaSelected(empresa: EmpresaRecord): void {
    console.log('[ReporteCC2205] Empresa Hasta selected:', empresa);
    console.log('[ReporteCC2205] Nombre empresa:', empresa['nombre-emp']);
    this.selectedEmpresaHasta.set(empresa);
    console.log('[ReporteCC2205] selectedEmpresaHasta signal value:', this.selectedEmpresaHasta());
    this.form.patchValue({ 
      empresaHasta: empresa.empresa.toString(),
      nombreEmpresaHasta: empresa['nombre-emp'] || ''
    });
    this.showEmpresaHastaModal.set(false);
    this.validateEmpresaHasta(empresa.empresa.toString());
  }

  onGenerarReporte(formato: 'excel' | 'pdf' | 'pantalla'): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.toast.showWarning('Complete todos los campos obligatorios');
      return;
    }

    const { compania, empresaDesde, empresaHasta, fechaDesde, fechaHasta } = this.form.value;
    
    this.isGeneratingReport.set(true);
    this.loading.show('Generando reporte...');

    // Convertir fechas a formato DD/MM/YYYY si es necesario
    const formatDateToAPI = (dateStr: string) => {
      const [yyyy, mm, dd] = dateStr.split('-');
      return `${dd}/${mm}/${yyyy}`;
    };

    const params = {
      pcCompania: compania,
      pcEmpresaDesde: empresaDesde,
      pcEmpresaHasta: empresaHasta,
      pcFechaDesde: formatDateToAPI(fechaDesde),
      pcFechaHasta: formatDateToAPI(fechaHasta)
    };

    this.ccService.getCC2205Report(params).subscribe({
      next: (response) => {
        this.isGeneratingReport.set(false);
        this.loading.hide();
        
        if (response?.response) {
          this.handleReporteGenerated(response.response, formato);
        } else {
          this.toast.showError('No se pudo generar el reporte');
        }
      },
      error: (err) => {
        this.isGeneratingReport.set(false);
        this.loading.hide();
        console.error('Error generando reporte:', err);
        this.toast.showError('Error al generar el reporte');
      }
    });
  }

  private handleReporteGenerated(response: any, formato: 'excel' | 'pdf' | 'pantalla'): void {
    switch (formato) {
      case 'excel':
        // Intentar con CSV primero, luego XLS
        if (response.pcArchCSV) {
          this.downloadCsvFile(response.pcArchCSV);
          this.toast.showSuccess('Archivo CSV descargado');
        } else if (response.pcArchXLS) {
          this.downloadExcelFile(response.pcArchXLS);
          this.toast.showSuccess('Archivo Excel descargado');
        } else {
          this.toast.showError('No hay datos disponibles para Excel');
        }
        break;

      case 'pdf':
        if (response.pcArchPDF) {
          this.downloadPdfFile(response.pcArchPDF);
          this.toast.showSuccess('Archivo PDF descargado');
        } else {
          this.toast.showError('No hay datos disponibles para PDF');
        }
        break;

      case 'pantalla':
        // Para pantalla, intentar CSV primero, luego XLS
        if (response.pcArchCSV) {
          this.downloadCsvFile(response.pcArchCSV);
          this.toast.showSuccess('Reporte generado');
        } else if (response.pcArchXLS) {
          this.downloadExcelFile(response.pcArchXLS);
          this.toast.showSuccess('Reporte generado');
        } else {
          this.toast.showError('No hay datos disponibles');
        }
        break;
    }
  }

  private downloadExcelFile(base64: string): void {
    try {
      const binaryString = atob(base64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      this.triggerDownload(blob, `CC2205_${new Date().getTime()}.xlsx`);
    } catch (error) {
      console.error('Error downloading Excel file:', error);
      this.toast.showError('Error al descargar el archivo');
    }
  }

  private downloadCsvFile(base64: string): void {
    try {
      const binaryString = atob(base64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'text/csv;charset=utf-8;' });
      this.triggerDownload(blob, `CC2205_${new Date().getTime()}.csv`);
    } catch (error) {
      console.error('Error downloading CSV file:', error);
      this.toast.showError('Error al descargar el archivo');
    }
  }

  private downloadPdfFile(base64: string): void {
    try {
      const binaryString = atob(base64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'application/pdf' });
      this.triggerDownload(blob, `CC2205_${new Date().getTime()}.pdf`);
    } catch (error) {
      console.error('Error downloading PDF file:', error);
      this.toast.showError('Error al descargar el archivo');
    }
  }

  private triggerDownload(blob: Blob, filename: string): void {
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  }

  onLimpiar(): void {
    this.form.reset({
      compania: '',
      nombreCompania: '',
      empresaDesde: '',
      nombreEmpresaDesde: '',
      empresaHasta: '',
      nombreEmpresaHasta: '',
      fechaDesde: '',
      fechaHasta: ''
    });
    this.selectedCompania.set(null);
    this.selectedEmpresaDesde.set(null);
    this.selectedEmpresaHasta.set(null);
  }

  goBack(): void {
    window.history.back();
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field?.invalid && field?.touched);
  }

  getErrorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (field?.hasError('required')) return 'Campo obligatorio';
    if (field?.hasError('notFound')) return 'No encontrado';
    return '';
  }
}
