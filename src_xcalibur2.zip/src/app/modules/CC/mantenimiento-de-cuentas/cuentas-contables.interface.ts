// CG5002 - MANTENIMIENTO DE CUENTAS CONTABLES Interfaces

export interface CgcontabRecord {
  'cia': number;
  'cuenta': string;
  'nombre-cta': string;
  'clase-cta': string;
  'tipo-cta': string;
  'moneda': number;
  'nombre-mon'?: string;
  'fiscal': number;
  'nombre-cfi'?: string;
  'gruaju': number;
  'nombre-aju'?: string;
  'codfis': number;
  'nombre-codfis'?: string;
  'consol-cta': boolean;
  'gravable': boolean;
  'auxili-cta': boolean;
  'columna-cta': number;
  'secuen-cta': number;
  'ctapre-cta': string;
  'nombre-ctap'?: string;
  'ctarep-cta': string;
  'nombre-ctar'?: string;
  'text-cta': string;
  'date-ctrl': string;
  'login-ctrl': string;
  'tparent'?: string;
}

export interface CompaniaRecord {
  'cia': number;
  'nombre-cia': string;
  'nit': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CuentaRecord {
  'cuenta': string;
  'nombre-cta': string;
  'cia': number;
  'moneda'?: number;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface GemomedaRecord {
  'moneda': number;
  'nombre-mon': string;
  'simbol-mon': string;
  'cambio-mon': number;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CgfiscalRecord {
  'cia': number;
  'codfis': number;
  'nombre-cfi': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CggruajuRecord {
  'cia': number;
  'gruaju': number;
  'nombre-gaj': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CG5002Response {
  'dsRespuesta': {
    'tcgcontab'?: CgcontabRecord[];
    'tgecias'?: CompaniaRecord[];
    'tcgcontab2'?: CuentaRecord[];
    'tgemoneda'?: GemomedaRecord[];
    'tcgfiscal'?: CgfiscalRecord[];
    'tcggruaju'?: CggruajuRecord[];
  };
}
