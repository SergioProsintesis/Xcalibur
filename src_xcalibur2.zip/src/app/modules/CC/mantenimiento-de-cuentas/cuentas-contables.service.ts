import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../core/services/auth.service';
import { CG5002Response, CgcontabRecord } from './cuentas-contables.interface';

@Injectable({
  providedIn: 'root'
})
export class CuentasContablesService {
  private http = inject(HttpClient);
  private auth = inject(AuthService);

  // ==================== CONSULTAS EMERGENTES ====================

  /**
   * Obtiene lista de compañías
   */
  getCECompanias(): Observable<CG5002Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECompanias?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CG5002Response>(url);
  }

  /**
   * Obtiene compañía en evento Leave
   */
  getLeaveCompania(pcCompania: number): Observable<CG5002Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveGEciasCxC?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CG5002Response>(url);
  }

  /**
   * Obtiene cuentas contables
   */
  getCECuenta(pcCompania: number): Observable<CG5002Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECuentaCCxC?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CG5002Response>(url);
  }

  /**
   * Obtiene cuenta en evento Leave
   */
  getLeaveCuenta(pcCompania: number, pcCuenta: string): Observable<CG5002Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCuenta-cc0046?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcCuenta=${encodeURIComponent(pcCuenta)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CG5002Response>(url);
  }

  /**
   * Obtiene monedas
   */
  getCEMoneda(): Observable<CG5002Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEgemoneda?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CG5002Response>(url);
  }

  /**
   * Obtiene moneda en evento Leave
   */
  getLeaveMoneda(pcMoneda: number): Observable<CG5002Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveMoneda?pcMoneda=${encodeURIComponent(pcMoneda.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CG5002Response>(url);
  }

  /**
   * Obtiene códigos fiscales
   */
  getCECodfis(pcCompania: number): Observable<CG5002Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECodfis_cg5002?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CG5002Response>(url);
  }

  /**
   * Obtiene código fiscal en evento Leave
   */
  getLeaveCodfis(pcCompania: number, pcCodfis: number): Observable<CG5002Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCodfis_cg5002?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcCodfis=${encodeURIComponent(pcCodfis.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CG5002Response>(url);
  }

  /**
   * Obtiene grupos de ajuste
   */
  getCEGruaju(pcCompania: number): Observable<CG5002Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEGruaju_cg5002?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CG5002Response>(url);
  }

  /**
   * Obtiene grupo de ajuste en evento Leave
   */
  getLeaveGruaju(pcCompania: number, pcGruaju: number): Observable<CG5002Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveGruaju_cg5002?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcGruaju=${encodeURIComponent(pcGruaju.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CG5002Response>(url);
  }

  // ==================== CRUD OPERATIONS ====================

  /**
   * Crea o actualiza una cuenta contable
   */
  updateCuentaContable(cuenta: CgcontabRecord): Observable<CG5002Response> {
    const url = `${environment.apiUrl}/Updatecgcontab_cg5002`;
    return this.http.put<CG5002Response>(url, { tcgcontab: [cuenta] });
  }

  /**
   * Elimina una cuenta contable
   */
  deleteCuentaContable(pcCompania: number, pcCuenta: string): Observable<CG5002Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Delcgcontab_cg5002?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcCuentaC=${encodeURIComponent(pcCuenta)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.delete<CG5002Response>(url);
  }
}
