import { Component, inject, signal, OnInit, computed, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { CuentasContablesService } from './cuentas-contables.service';
import {
  CgcontabRecord,
  CompaniaRecord,
  CuentaRecord,
  GemomedaRecord,
  CgfiscalRecord,
  CggruajuRecord
} from './cuentas-contables.interface';

@Component({
  selector: 'app-mantenimiento-de-cuentas',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent],
  templateUrl: './mant-cuentas-contables.component.html',
  styleUrls: ['./mant-cuentas-contables.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MantenimientoDeCuentasComponent implements OnInit {
  private fb = inject(FormBuilder);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private programContext = inject(ProgramContextService);
  private cuentasService = inject(CuentasContablesService);
  private router = inject(Router);

  // Estado y control
  loadingState = signal(false);
  isEditMode = signal(false);

  // Compañía seleccionada
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  cuentaSeleccionada = signal<CgcontabRecord | null>(null);

  // Listas disponibles
  cuentasList = signal<CuentaRecord[]>([]);
  monedaList = signal<GemomedaRecord[]>([]);
  codfiscalList = signal<CgfiscalRecord[]>([]);
  gruajuList = signal<CggruajuRecord[]>([]);

  // Control de modales
  showCompaniaModal = signal(false);
  showCuentaModal = signal(false);
  showMonedaModal = signal(false);
  showCodfiscalModal = signal(false);
  showGruajuModal = signal(false);
  showCreateModal = signal(false);

  // Búsqueda en modales
  cuentaSearch = signal('');
  monedaSearch = signal('');
  codfiscalSearch = signal('');
  gruajuSearch = signal('');

  // Listas filtradas
  filteredCuentaList = computed(() => {
    const query = this.cuentaSearch().toLowerCase();
    return this.cuentasList().filter(item =>
      item.cuenta.toLowerCase().includes(query) ||
      item['nombre-cta'].toLowerCase().includes(query)
    );
  });

  filteredMonedaList = computed(() => {
    const query = this.monedaSearch().toLowerCase();
    return this.monedaList().filter(item =>
      item.moneda.toString().includes(query) ||
      item['nombre-mon'].toLowerCase().includes(query)
    );
  });

  filteredCodfiscalList = computed(() => {
    const query = this.codfiscalSearch().toLowerCase();
    return this.codfiscalList().filter(item =>
      item.codfis.toString().includes(query) ||
      item['nombre-cfi'].toLowerCase().includes(query)
    );
  });

  filteredGruajuList = computed(() => {
    const query = this.gruajuSearch().toLowerCase();
    return this.gruajuList().filter(item =>
      item.gruaju.toString().includes(query) ||
      item['nombre-gaj'].toLowerCase().includes(query)
    );
  });

  // Formularios
  cuentaForm!: FormGroup;
  createForm!: FormGroup;

  ngOnInit(): void {
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
  }

  private initializeForm(): void {
    this.cuentaForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      cuenta: ['', [Validators.required]],
      'nombre-cta': [{ value: '', disabled: true }],
      'clase-cta': [''],
      'tipo-cta': [''],
      moneda: ['', [Validators.required, Validators.min(1)]],
      'nombre-mon': [{ value: '', disabled: true }],
      fiscal: [''],
      'nombre-cfi': [{ value: '', disabled: true }],
      gruaju: [''],
      'nombre-gaj': [{ value: '', disabled: true }],
      codfis: [''],
      'nombre-codfis': [{ value: '', disabled: true }],
      'consol-cta': [true],
      gravable: [false],
      'auxili-cta': [false],
      columna: [''],
      secuen: [''],
      'ctapre-cta': [''],
      'ctarep-cta': [''],
      'text-cta': ['']
    });

    this.createForm = this.fb.group({
      cuenta: ['', [Validators.required]],
      'nombre-cta': ['', [Validators.required]],
      'clase-cta': [''],
      'tipo-cta': [''],
      moneda: ['', [Validators.required]],
      fiscal: [''],
      gruaju: [''],
      codfis: [''],
      'consol-cta': [true],
      gravable: [false],
      'auxili-cta': [false],
      columna: [''],
      secuen: [''],
      'ctapre-cta': [''],
      'ctarep-cta': [''],
      'text-cta': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string, form: string = 'main'): boolean {
    const formGroup = form === 'main' ? this.cuentaForm : this.createForm;
    const field = formGroup.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string, form: string = 'main'): string {
    const formGroup = form === 'main' ? this.cuentaForm : this.createForm;
    const field = formGroup.get(fieldName);
    if (!field?.errors) return '';

    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;

    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.cuentaForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.cuentaForm.get('cia')?.value;

    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.cuentasService.getLeaveCompania(ciaValue).toPromise();

      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.cuentaForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarCompania(): void {
    this.cuentaForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
    this.companiaSeleccionada.set(null);
  }

  // ==================== MODAL DE CUENTAS ====================
  async buscarCuenta(): Promise<void> {
    const cia = this.cuentaForm.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      if (this.cuentasList().length === 0) {
        await this.loadCuentasListAsync();
      }
    } catch (error) {
      console.error('Error in buscarCuenta:', error);
      this.toastService.showError('Error al buscar cuentas');
    } finally {
      this.loadingState.set(false);
      this.showCuentaModal.set(true);
    }
  }

  private loadCuentasListAsync(): Promise<void> {
    return new Promise((resolve) => {
      const cia = this.cuentaForm.get('cia')?.value;
      if (!cia) {
        resolve();
        return;
      }

      try {
        this.cuentasService.getCECuenta(cia).subscribe({
          next: (response) => {
            if (response?.dsRespuesta?.tcgcontab2) {
              this.cuentasList.set(response.dsRespuesta.tcgcontab2);
            }
            resolve();
          },
          error: (err) => {
            console.error('Error cargando cuentas:', err);
            resolve();
          }
        });
      } catch (error) {
        console.error('Error:', error);
        resolve();
      }
    });
  }

  closeCuentaModal(): void {
    this.showCuentaModal.set(false);
    this.cuentaSearch.set('');
  }

  onCuentaSelected(cuenta: CuentaRecord): void {
    this.cuentaForm.patchValue({
      cuenta: cuenta.cuenta,
      'nombre-cta': cuenta['nombre-cta']
    });
    this.closeCuentaModal();
  }

  // ==================== MODAL DE MONEDAS ====================
  async buscarMoneda(): Promise<void> {
    try {
      this.loadingState.set(true);
      if (this.monedaList().length === 0) {
        await this.loadMonedasListAsync();
      }
    } catch (error) {
      console.error('Error in buscarMoneda:', error);
      this.toastService.showError('Error al buscar monedas');
    } finally {
      this.loadingState.set(false);
      this.showMonedaModal.set(true);
    }
  }

  private loadMonedasListAsync(): Promise<void> {
    return new Promise((resolve) => {
      try {
        this.cuentasService.getCEMoneda().subscribe({
          next: (response) => {
            if (response?.dsRespuesta?.tgemoneda) {
              this.monedaList.set(response.dsRespuesta.tgemoneda);
            }
            resolve();
          },
          error: (err) => {
            console.error('Error cargando monedas:', err);
            resolve();
          }
        });
      } catch (error) {
        console.error('Error:', error);
        resolve();
      }
    });
  }

  closeMonedaModal(): void {
    this.showMonedaModal.set(false);
    this.monedaSearch.set('');
  }

  onMonedaSelected(moneda: GemomedaRecord): void {
    this.cuentaForm.patchValue({
      moneda: moneda.moneda,
      'nombre-mon': moneda['nombre-mon']
    });
    this.closeMonedaModal();
  }

  // ==================== MODAL DE FISCALES ====================
  async buscarCodfiscal(): Promise<void> {
    const cia = this.cuentaForm.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      if (this.codfiscalList().length === 0) {
        await this.loadCodfiscaListAsync();
      }
    } catch (error) {
      console.error('Error in buscarCodfiscal:', error);
      this.toastService.showError('Error al buscar códigos fiscales');
    } finally {
      this.loadingState.set(false);
      this.showCodfiscalModal.set(true);
    }
  }

  private loadCodfiscaListAsync(): Promise<void> {
    return new Promise((resolve) => {
      const cia = this.cuentaForm.get('cia')?.value;
      if (!cia) {
        resolve();
        return;
      }

      try {
        this.cuentasService.getCECodfis(cia).subscribe({
          next: (response) => {
            if (response?.dsRespuesta?.tcgfiscal) {
              this.codfiscalList.set(response.dsRespuesta.tcgfiscal);
            }
            resolve();
          },
          error: (err) => {
            console.error('Error cargando códigos fiscales:', err);
            resolve();
          }
        });
      } catch (error) {
        console.error('Error:', error);
        resolve();
      }
    });
  }

  closeCodfiscalModal(): void {
    this.showCodfiscalModal.set(false);
    this.codfiscalSearch.set('');
  }

  onCodfiscalSelected(codfiscal: CgfiscalRecord): void {
    this.cuentaForm.patchValue({
      codfis: codfiscal.codfis,
      'nombre-codfis': codfiscal['nombre-cfi']
    });
    this.closeCodfiscalModal();
  }

  // ==================== MODAL DE GRUPOS AJUSTE ====================
  async buscarGruaju(): Promise<void> {
    const cia = this.cuentaForm.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      if (this.gruajuList().length === 0) {
        await this.loadGruajuListAsync();
      }
    } catch (error) {
      console.error('Error in buscarGruaju:', error);
      this.toastService.showError('Error al buscar grupos de ajuste');
    } finally {
      this.loadingState.set(false);
      this.showGruajuModal.set(true);
    }
  }

  private loadGruajuListAsync(): Promise<void> {
    return new Promise((resolve) => {
      const cia = this.cuentaForm.get('cia')?.value;
      if (!cia) {
        resolve();
        return;
      }

      try {
        this.cuentasService.getCEGruaju(cia).subscribe({
          next: (response) => {
            if (response?.dsRespuesta?.tcggruaju) {
              this.gruajuList.set(response.dsRespuesta.tcggruaju);
            }
            resolve();
          },
          error: (err) => {
            console.error('Error cargando grupos ajuste:', err);
            resolve();
          }
        });
      } catch (error) {
        console.error('Error:', error);
        resolve();
      }
    });
  }

  closeGruajuModal(): void {
    this.showGruajuModal.set(false);
    this.gruajuSearch.set('');
  }

  onGruajuSelected(gruaju: CggruajuRecord): void {
    this.cuentaForm.patchValue({
      gruaju: gruaju.gruaju,
      'nombre-gaj': gruaju['nombre-gaj']
    });
    this.closeGruajuModal();
  }

  // ==================== CREAR/EDITAR ====================
  openCreateModal(): void {
    this.isEditMode.set(false);
    this.createForm.reset();
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
  }

  async onCreateSubmit(): Promise<void> {
    if (this.createForm.invalid) return;

    try {
      this.loadingState.set(true);
      const cia = this.cuentaForm.get('cia')?.value;
      const cuentaData: CgcontabRecord = {
        ...this.createForm.value,
        cia
      };

      await this.cuentasService.updateCuentaContable(cuentaData).toPromise();
      this.toastService.showSuccess('Cuenta contable creada exitosamente');
      this.closeCreateModal();
      this.cuentaForm.reset();
    } catch (error) {
      console.error('Error al crear cuenta:', error);
      this.toastService.showError('Error al crear la cuenta contable');
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== ACCIONES ====================
  limpiar(): void {
    this.cuentaForm.reset();
    this.isEditMode.set(false);
    this.cuentaSeleccionada.set(null);
  }

  guardar(): void {
    if (this.cuentaForm.invalid) {
      this.toastService.showError('Verifique los campos requeridos');
      return;
    }
    // Implementar guardado
  }

  eliminar(): void {
    if (!this.cuentaSeleccionada()) {
      this.toastService.showError('Debe seleccionar una cuenta para eliminar');
      return;
    }
    // Implementar eliminación
  }

  volver(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }
}
