import { Component, EventEmitter, Input, Output, computed, signal, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

export interface CondicionPagoOption {
  condpago: number;
  cia?: number;
  'nombre-cpag': string;
  'diapla-cpag': number;
  'cancuo-cpag': number;
  'porini-cpag': number;
  'porfin-cpag': number;
  'diacuo-cpag'?: number;
  'text-cpag'?: string;
  'Agrega-Conp'?: string;
  'agrega-ccpreg'?: string;
}

@Component({
  selector: 'app-condicion-pago-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './condicion-pago-modal.component.html',
  styleUrls: ['./condicion-pago-modal.component.css']
})
export class CondicionPagoModalComponent implements OnChanges {
  // 🔴 CONVERTIR condiciones A SIGNAL PARA QUE SEA REACTIVO
  private condicionesSignal = signal<CondicionPagoOption[]>([]);
  
  @Input() set condiciones(value: CondicionPagoOption[]) {
    console.log('🔗 [MODAL] @Input condiciones actualizado:', value?.length || 0);
    this.condicionesSignal.set(value || []);
  }
  
  get condiciones(): CondicionPagoOption[] {
    return this.condicionesSignal();
  }
  
  @Input() visible = false;
  @Output() condicionSelected = new EventEmitter<CondicionPagoOption>();
  @Output() closed = new EventEmitter<void>();

  searchTerm = signal('');
  private isVisible = signal(false);
  private previousCondicionesLength = 0;
  private previousCondicionesRef: CondicionPagoOption[] | null = null;

  ngOnChanges(changes: SimpleChanges): void {
    console.log('🔔 [MODAL ngOnChanges] cambios detectados:', Object.keys(changes));
    console.log('🔔 [MODAL] condiciones actual:', this.condiciones?.length || 0);
    
    // ===== DETECTAR CAMBIOS EN EL ARRAY DE CONDICIONES =====
    if (changes['condiciones']) {
      console.log('📝 [MODAL] Change en condiciones:', {
        firstChange: changes['condiciones'].firstChange,
        previousValue: changes['condiciones'].previousValue?.length,
        currentValue: changes['condiciones'].currentValue?.length
      });
      
      if (!changes['condiciones'].firstChange) {
        const newCondiciones = this.condiciones;
        const condicionesActualmenteCambiadas = 
          this.previousCondicionesRef !== newCondiciones || 
          newCondiciones.length !== this.previousCondicionesLength;

        if (condicionesActualmenteCambiadas) {
          console.log('🔄 [MODAL] Nuevo array de condiciones detectado. Limpiando búsqueda');
          this.searchTerm.set('');
          this.previousCondicionesLength = newCondiciones.length;
          this.previousCondicionesRef = newCondiciones;
        }
      }
    }

    // ===== CONTROLAR VISIBILIDAD DEL MODAL =====
    if (changes['visible']) {
      this.isVisible.set(this.visible);
      console.log(`[MODAL VISIBLE] visible=${this.visible}`);
      if (!this.visible) {
        // Limpiar búsqueda cuando se cierre el modal
        console.log('❌ [MODAL] Modal cerrado. Limpiando búsqueda');
        this.searchTerm.set('');
      } else {
        // Al abrir el modal, asegurarse que la búsqueda esté limpia
        console.log('✅ [MODAL] Modal abierto. Búsqueda limpia');
        this.searchTerm.set('');
      }
    }

    // Inicializar el contador y referencia en el primer cambio
    if (changes['condiciones']?.firstChange) {
      this.previousCondicionesLength = this.condiciones.length;
      this.previousCondicionesRef = this.condiciones;
    }
  }

  condicionesFiltradas = computed(() => {
    const condicionesActuales = this.condicionesSignal();
    const term = this.searchTerm().toLowerCase();
    const filtered = !term ? condicionesActuales : 
      condicionesActuales.filter(cond => 
        cond.condpago?.toString().includes(term) ||
        cond['nombre-cpag']?.toLowerCase().includes(term)
      );
    
    console.log(`🔍 [MODAL] Filtrando: "${term}" → ${filtered.length}/${condicionesActuales.length} resultados`);
    return filtered;
  });

  onSearch(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.searchTerm.set(value);
  }

  selectCondicion(condicion: CondicionPagoOption): void {
    console.log('✅ [MODAL SELECT] Condición seleccionada:', condicion.condpago, condicion['nombre-cpag']);
    this.condicionSelected.emit(condicion);
    this.close();
  }

  close(): void {
    this.searchTerm.set('');
    this.closed.emit();
  }
}
