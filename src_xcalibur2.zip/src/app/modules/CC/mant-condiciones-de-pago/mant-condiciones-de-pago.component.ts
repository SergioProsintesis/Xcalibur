import { Component, inject, signal, OnInit, computed, effect, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { AuthService } from '../../../core/services/auth.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { CondicionPagoModalComponent, CondicionPagoOption } from './condicion-pago-modal/condicion-pago-modal.component';
import { CompaniaRecord } from '../../../core/interfaces/cc.interface';
import { CCService } from '../../../core/services/cc.service';

/**
 * CC0005: Mantenimiento de Condiciones de Pago
 * 
 * Componente para gestionar condiciones de pago por compañía
 * 
 * ENDPOINTS UTILIZADOS:
 * - GetCECompanias: Obtener lista de compañías
 * - GetLeaveGEcias: Validar compañía seleccionada
 * - GetCECondPago: Obtener condiciones de pago disponibles
 * - GetLeaveCondpago-cc0005: Validar y obtener detalles de condición
 * - UpdateCcconpag-CC0005: Crear/Actualizar condición de pago
 * - Delccconpag-cc0005: Eliminar condición de pago
 * - Getcc2005: Generar reporte de condiciones de pago (PDF/CSV)
 */

export interface CondicionPagoRecord {
  condpago: number;
  cia: number;
  'nombre-cia'?: string;
  'nombre-cpag': string;
  'diapla-cpag': number;
  'cancuo-cpag': number;
  'diacuo-cpag': number;
  'porini-cpag': number;
  'porfin-cpag': number;
  'text-cpag': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'Agrega-Conp'?: string;
  'agrega-ccpreg'?: string;
  tparent?: string;
}

@Component({
  selector: 'app-mant-condiciones-de-pago',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent, CondicionPagoModalComponent],
  templateUrl: './mant-condiciones-de-pago.component.html',
  styleUrls: ['./mant-condiciones-de-pago.component.css']
})
export class MantCondicionesDePagoComponent implements OnInit {
  private fb = inject(FormBuilder);
  private modalService = inject(ModalService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private ccService = inject(CCService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private auth = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);

  condicionPagoForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Condiciones de Pago`);
  loadingState = signal<boolean>(false);
  saveButtonState = signal<'saving' | 'success' | 'normal'>('normal');

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  condicionSeleccionada = signal<any>(null);

  // Control de modales
  showCompaniaModal = signal(false);
  showCondicionModal = signal(false);
  showCreateModal = signal(false);
  showReportModal = signal(false);
  isEditMode = signal(false);
  condicionesDisponibles = signal<CondicionPagoOption[]>([]);
  createCondicionForm!: FormGroup;
  reportResponse: any = null;

  // Effect reactivo para recargar condiciones cuando cambia la compañía
  private loadCompaniaEffect = effect(() => {
    const compania = this.companiaSeleccionada();
    if (compania && compania.cia) {
      console.log('🔔 EFECTO REACTIVO: Compañía cambió a:', compania.cia, compania['nombre-cia']);
      // 🔴 CIERRA EL MODAL DE CONDICIONES AL CAMBIAR COMPAÑÍA
      this.showCondicionModal.set(false);
      this.limpiarCondicion();
      this.loadCondiciones().catch(err => {
        console.error('❌ Error al recargar condiciones en efecto reactivo:', err);
      });
    }
  });

  ngOnInit() {
    console.log('🔄 MantCondicionesDePagoComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    
    // Mostrar checkmark al cargar y luego cambiar a "Guardar"
    this.saveButtonState.set('success');
    setTimeout(() => {
      this.saveButtonState.set('normal');
    }, 1500);
    
    console.log('✅ MantCondicionesDePagoComponent inicializado correctamente');
  }

  private initializeForm(): void {
    this.condicionPagoForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      condpago: ['', [Validators.required]],
      'Agrega-Conp': [''],
      'nombre-cpag': [''],
      'diapla-cpag': [0],
      'cancuo-cpag': [0],
      'diacuo-cpag': [0],
      'porini-cpag': [0],
      'porfin-cpag': [0],
      'text-cpag': ['']
    });

    this.createCondicionForm = this.fb.group({
      condpago: ['', [Validators.required, Validators.min(1)]],
      'nombre-cpag': ['', Validators.required],
      'diapla-cpag': [0],
      'cancuo-cpag': [0],
      'diacuo-cpag': [0],
      'porini-cpag': [0],
      'porfin-cpag': [0],
      'text-cpag': ['']
    });
  }

  // ==================== COMPAÑIA MODAL ====================

  openCompaniaModal(): void {
    console.log('🔍 Abriendo modal de compañías');
    this.showCompaniaModal.set(true);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    console.log('✅ Compañía seleccionada:', compania);
    this.companiaSeleccionada.set(compania);
    this.condicionPagoForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.showCompaniaModal.set(false);
    // 🔴 CIERRA EL MODAL DE CONDICIONES SI ESTABA ABIERTO
    this.showCondicionModal.set(false);
    this.limpiarCondicion();
    this.loadCondiciones().catch(err => console.error('Error loading condiciones:', err));
  }

  onCloseCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  // ==================== CONDICION MODAL ====================

  openCondicionModal(): void {
    const companiaId = this.condicionPagoForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }
    
    // 🔄 REFRESCA LOS DATOS DEL SERVIDOR ANTES DE ABRIR EL MODAL
    console.log('🔄 [MODAL] Limpiando y refrescando datos...');
    this.condicionesDisponibles.set([]);
    
    this.loadCondiciones()
      .then(() => {
        console.log('✅ [MODAL] Datos refrescados. Abriendo modal');
        console.log('📊 [MODAL] Condiciones disponibles:', this.condicionesDisponibles().length);
        setTimeout(() => {
          this.showCondicionModal.set(true);
        }, 100);
      })
      .catch(err => {
        console.error('❌ [MODAL] Error refrescando datos:', err);
        this.toastService.showError('Error al cargar las condiciones');
      });
  }

  onCondicionSelected(condicion: CondicionPagoOption): void {
    console.log('✅ [MODAL SELECT] Condición seleccionada:', condicion);
    console.log('📋 [MODAL SELECT] Datos disponibles:', JSON.stringify(condicion, null, 2));

    // Cerrar modal PRIMERO
    this.showCondicionModal.set(false);
    console.log('🔌 [MODAL SELECT] Modal cerrado');

    // Llenar el formulario INMEDIATAMENTE con TODOS los datos disponibles
    const formData = {
      cia: this.condicionPagoForm.get('cia')?.value,
      'nombre-cia': this.condicionPagoForm.get('nombre-cia')?.value,
      condpago: condicion.condpago,
      'Agrega-Conp': condicion['Agrega-Conp'] || '',
      'nombre-cpag': condicion['nombre-cpag'] || '',
      'diapla-cpag': condicion['diapla-cpag'] || 0,
      'cancuo-cpag': condicion['cancuo-cpag'] || 0,
      'diacuo-cpag': condicion['diacuo-cpag'] || 0,
      'porini-cpag': condicion['porini-cpag'] || 0,
      'porfin-cpag': condicion['porfin-cpag'] || 0,
      'text-cpag': condicion['text-cpag'] || ''
    };

    console.log('📝 [MODAL SELECT] Form data a asignar:', JSON.stringify(formData, null, 2));

    // Usar setValue con los datos completos
    this.condicionPagoForm.setValue(formData);
    
    console.log('✅ [MODAL SELECT] setValue completado');
    console.log('📊 [MODAL SELECT] Estado actual del form:', JSON.stringify(this.condicionPagoForm.value, null, 2));

    // Marcar modo edición
    this.isEditMode.set(true);
    this.condicionSeleccionada.set(condicion);
    console.log('✅ [MODAL SELECT] isEditMode establecido a true');

    // Cargar detalles COMPLETOS del servidor EN BACKGROUND (sin bloquear)
    this.cargarDetallesCompletos(condicion);
  }

  /**
   * Carga detalles completos del servidor en background
   */
  private async cargarDetallesCompletos(condicion: CondicionPagoOption): Promise<void> {
    const companiaId = this.condicionPagoForm.get('cia')?.value;
    
    if (!companiaId || !condicion.condpago) {
      console.warn('⚠️ No se puede cargar detalles: falta compañía o condición');
      return;
    }

    try {
      this.loadingState.set(true);
      console.log('🔄 Cargando detalles completos en background:', condicion.condpago);
      
      const response = await this.ccService.getLeaveCondPago(companiaId.toString(), condicion.condpago);
      
      if (response?.dsRespuesta?.tccconpag && response.dsRespuesta.tccconpag.length > 0) {
        const condicionCompleta = response.dsRespuesta.tccconpag[0];
        console.log('✅ Detalles completos del servidor:', condicionCompleta);
        
        // Actualizar formulario con detalles completos del servidor
        this.condicionPagoForm.patchValue({
          condpago: condicionCompleta.condpago,
          'nombre-cpag': condicionCompleta['nombre-cpag'] || '',
          'diapla-cpag': condicionCompleta['diapla-cpag'] || 0,
          'cancuo-cpag': condicionCompleta['cancuo-cpag'] || 0,
          'diacuo-cpag': condicionCompleta['diacuo-cpag'] || 0,
          'porini-cpag': condicionCompleta['porini-cpag'] || 0,
          'porfin-cpag': condicionCompleta['porfin-cpag'] || 0,
          'text-cpag': condicionCompleta['text-cpag'] || '',
          'Agrega-Conp': condicionCompleta['Agrega-Conp'] || ''
        });
        
        this.condicionSeleccionada.set(condicionCompleta);
        console.log('✅ Formulario actualizado con detalles del servidor');
      } else {
        console.warn('⚠️ El servidor no devolvió detalles');
      }
    } catch (error) {
      console.error('❌ Error al cargar detalles:', error);
      // No mostramos error porque ya el formulario tiene datos del modal
    } finally {
      this.loadingState.set(false);
    }
  }

  onCloseCondicionModal(): void {
    this.showCondicionModal.set(false);
  }

  closeCondicionModal(): void {
    this.showCondicionModal.set(false);
  }

  // ==================== CARGA DE DATOS ====================

  private async loadCondiciones(): Promise<void> {
    const companiaId = this.condicionPagoForm.get('cia')?.value;
    if (!companiaId) {
      console.warn('⚠️ No hay compañía seleccionada');
      return;
    }

    try {
      this.loadingState.set(true);
      console.log('🧹 Limpiando condiciones anteriores');
      
      const response = await this.ccService.getCECondPago(companiaId.toString());
      
      if (response?.dsRespuesta?.tccconpag && response.dsRespuesta.tccconpag.length > 0) {
        console.log('📡 Servidor retornó', response.dsRespuesta.tccconpag.length, 'condiciones');
        // Mapear con TODOS los campos disponibles
        const condiciones: CondicionPagoOption[] = response.dsRespuesta.tccconpag.map((c: any) => ({
          condpago: c.condpago,
          'nombre-cpag': c['nombre-cpag'] || '',
          'diapla-cpag': c['diapla-cpag'] || 0,
          'cancuo-cpag': c['cancuo-cpag'] || 0,
          'porini-cpag': c['porini-cpag'] || 0,
          'porfin-cpag': c['porfin-cpag'] || 0,
          'diacuo-cpag': c['diacuo-cpag'] || 0,
          'text-cpag': c['text-cpag'] || '',
          'Agrega-Conp': c['Agrega-Conp'] || '',
          'agrega-ccpreg': c['agrega-ccpreg'] || '',
          cia: c.cia || companiaId
        }));
        this.condicionesDisponibles.set(condiciones);
        console.log('✅ Signal actualizado con', condiciones.length, 'condiciones');
      } else {
        console.log('⚠️ Esta empresa NO tiene condiciones de pago');
        this.condicionesDisponibles.set([]);
      }
    } catch (error) {
      console.error('❌ Error al cargar condiciones:', error);
      this.condicionesDisponibles.set([]);
      this.toastService.showError('Error al cargar las condiciones de pago');
    } finally {
      this.loadingState.set(false);
      console.log('🏁 loadCondiciones completado');
    }
  }

  /**
   * Se ejecuta cuando el usuario sale del campo de condición de pago
   * (blur event - cuando edita manualmente el ID)
   */
  async onCondicionLeave(): Promise<void> {
    const companiaId = this.condicionPagoForm.get('cia')?.value;
    const condicionId = this.condicionPagoForm.get('condpago')?.value;

    console.log('🔍 onCondicionLeave - Validando edición manual:', { companiaId, condicionId });

    if (!companiaId || !condicionId) {
      console.log('⚠️ onCondicionLeave - Falta compañía o condición');
      return;
    }

    try {
      console.log('📡 Validando condición editada manualmente...');
      const response = await this.ccService.getLeaveCondPago(companiaId.toString(), Number(condicionId));
      
      console.log('📦 Respuesta del servidor:', response);
      
      if (response?.dsRespuesta?.tccconpag && response.dsRespuesta.tccconpag.length > 0) {
        const condicion = response.dsRespuesta.tccconpag[0];
        console.log('✅ Validación exitosa, detalles recibidos:', {
          nombre: condicion['nombre-cpag'],
          dias: condicion['diapla-cpag']
        });
        
        // Actualizar con todos los campos
        this.condicionSeleccionada.set(condicion);
        this.condicionPagoForm.patchValue({
          condpago: condicion.condpago,
          'nombre-cpag': condicion['nombre-cpag'] || '',
          'diapla-cpag': condicion['diapla-cpag'] || 0,
          'cancuo-cpag': condicion['cancuo-cpag'] || 0,
          'diacuo-cpag': condicion['diacuo-cpag'] || 0,
          'porini-cpag': condicion['porini-cpag'] || 0,
          'porfin-cpag': condicion['porfin-cpag'] || 0,
          'text-cpag': condicion['text-cpag'] || '',
          'Agrega-Conp': condicion['Agrega-Conp'] || ''
        });
        
        this.isEditMode.set(true);
      } else {
        console.warn('⚠️ Condición no encontrada');
        this.toastService.showError('La condición de pago seleccionada no existe');
        this.limpiarCondicion();
      }
    } catch (error) {
      console.error('❌ Error en validación:', error);
      this.toastService.showError('Error al validar la condición de pago');
      this.limpiarCondicion();
    }
  }

  private limpiarCondicion(): void {
    this.condicionPagoForm.patchValue({
      condpago: '',
      'nombre-cpag': '',
      'diapla-cpag': 0,
      'cancuo-cpag': 0,
      'diacuo-cpag': 0,
      'porini-cpag': 0,
      'porfin-cpag': 0,
      'text-cpag': ''
    });
    this.condicionSeleccionada.set(null);
    this.isEditMode.set(false);
  }

  // ==================== ACCIONES CRUD ====================

  openCreateModal(): void {
    const companiaId = this.condicionPagoForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }
    this.createCondicionForm.reset();
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
  }

  async onCreateSubmit(): Promise<void> {
    if (!this.createCondicionForm.valid) {
      this.toastService.showError('Por favor complete todos los campos obligatorios');
      return;
    }

    const companiaId = this.condicionPagoForm.get('cia')?.value;
    const today = new Date();
    const dateCtrl = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    const user = this.auth.user();
    
    try {
      this.loadingState.set(true);
      
      const payload = {
        tccconpag: [{
          cia: companiaId,
          condpago: this.createCondicionForm.get('condpago')?.value,  // Incluir código
          'nombre-cpag': this.createCondicionForm.get('nombre-cpag')?.value || '',
          'diapla-cpag': this.createCondicionForm.get('diapla-cpag')?.value || 0,
          'cancuo-cpag': this.createCondicionForm.get('cancuo-cpag')?.value || 0,
          'diacuo-cpag': this.createCondicionForm.get('diacuo-cpag')?.value || 0,
          'porini-cpag': this.createCondicionForm.get('porini-cpag')?.value || 0,
          'porfin-cpag': this.createCondicionForm.get('porfin-cpag')?.value || 0,
          'text-cpag': this.createCondicionForm.get('text-cpag')?.value || '',
          'Agrega-Conp': '            ',
          'agrega-ccpreg': '            ',
          'date-ctrl': dateCtrl,
          'login-ctrl': user?.pcLogin || '',
          tparent: user?.pcLogin || ''
        }]
      };
      
      console.log('📝 Payload CREATE:', JSON.stringify(payload, null, 2));
      
      const response = await this.ccService.updateCondicionPago(payload);
      
      console.log('📥 Respuesta CREATE:', response);
      
      if (response?.dsRespuesta?.tccconpag?.[0]?.terrores?.[0]) {
        const error = response.dsRespuesta.tccconpag[0].terrores[0];
        this.toastService.showSuccess(error.descripcion || 'Condición de pago creada correctamente');
        this.onClear();
        this.closeCondicionModal();
        await this.loadCondiciones();
        this.cdr.detectChanges();
        this.closeCreateModal();
        this.limpiarCondicion();
      } else {
        this.toastService.showError('No se pudo procesar la respuesta del servidor');
      }
    } catch (error) {
      console.error('Error al guardar:', error);
      this.toastService.showError('Error al guardar la condición de pago');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onSubmit(): Promise<void> {
    if (!this.condicionPagoForm.valid) {
      this.toastService.showError('Por favor complete todos los campos obligatorios');
      return;
    }

    const companiaId = this.condicionPagoForm.get('cia')?.value;
    const condicionId = this.condicionPagoForm.get('condpago')?.value;

    if (!condicionId) {
      this.toastService.showError('Debe seleccionar una condición de pago para actualizar');
      return;
    }

    const today = new Date();
    const dateCtrl = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    const user = this.auth.user();

    try {
      this.loadingState.set(true);
      
      const payload = {
        tccconpag: [{
          cia: companiaId,
          condpago: condicionId,  // ID existente = actualizar
          'nombre-cpag': this.condicionPagoForm.get('nombre-cpag')?.value || '',
          'diapla-cpag': this.condicionPagoForm.get('diapla-cpag')?.value || 0,
          'cancuo-cpag': this.condicionPagoForm.get('cancuo-cpag')?.value || 0,
          'diacuo-cpag': this.condicionPagoForm.get('diacuo-cpag')?.value || 0,
          'porini-cpag': this.condicionPagoForm.get('porini-cpag')?.value || 0,
          'porfin-cpag': this.condicionPagoForm.get('porfin-cpag')?.value || 0,
          'text-cpag': this.condicionPagoForm.get('text-cpag')?.value || '',
          'Agrega-Conp': '            ',
          'agrega-ccpreg': '            ',
          'date-ctrl': dateCtrl,
          'login-ctrl': user?.pcLogin || '',
          tparent: user?.pcLogin || ''
        }]
      };
      
      console.log('📝 Payload UPDATE:', JSON.stringify(payload, null, 2));
      
      const response = await this.ccService.updateCondicionPago(payload);
      
      console.log('📥 Respuesta UPDATE:', response);
      
      if (response?.dsRespuesta?.tccconpag?.[0]?.terrores?.[0]) {
        const error = response.dsRespuesta.tccconpag[0].terrores[0];
        this.toastService.showSuccess(error.descripcion || 'Condición de pago actualizada correctamente');
        this.onClear();
        this.closeCondicionModal();
        await this.loadCondiciones();
        this.cdr.detectChanges();
        
        // Mostrar checkmark en el botón
        this.saveButtonState.set('success');
        setTimeout(() => {
          this.saveButtonState.set('normal');
        }, 1500);
      } else {
        this.toastService.showError('No se pudo procesar la respuesta del servidor');
      }
    } catch (error) {
      console.error('Error al guardar:', error);
      this.toastService.showError('Error al guardar la condición de pago');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onDelete(): Promise<void> {
    const companiaId = this.condicionPagoForm.get('cia')?.value;
    const condpago = this.condicionPagoForm.get('condpago')?.value;

    if (!companiaId || !condpago) {
      this.toastService.showError('Debe seleccionar una compañía y una condición de pago para eliminar');
      return;
    }

    const confirmed = confirm('¿Está seguro de eliminar esta condición de pago?\nEsta acción no se puede deshacer');

    if (!confirmed) return;

    try {
      this.loadingState.set(true);
      const response = await this.ccService.deleteCondicionPago(companiaId, condpago);
      
      if (response?.dsRespuesta?.tccconpag?.[0]?.terrores?.[0]) {
        const error = response.dsRespuesta.tccconpag[0].terrores[0];
        this.toastService.showSuccess(error.descripcion || 'Condición de pago eliminada');
        this.closeCondicionModal();
        this.onClear();
        await this.loadCondiciones();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al eliminar:', error);
      this.toastService.showError('Error al eliminar la condición de pago');
    } finally {
      this.loadingState.set(false);
    }
  }

  onClear(): void {
    this.condicionPagoForm.reset({
      cia: this.companiaSeleccionada()?.cia,
      'nombre-cia': this.companiaSeleccionada()?.['nombre-cia'],
      condpago: '',
      'nombre-cpag': '',
      'diapla-cpag': 0,
      'cancuo-cpag': 0,
      'diacuo-cpag': 0,
      'porini-cpag': 0,
      'porfin-cpag': 0,
      'text-cpag': ''
    });
    this.condicionSeleccionada.set(null);
    this.isEditMode.set(false);
  }

  async onGenerateReport(): Promise<void> {
    const companiaId = this.condicionPagoForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía para generar reporte');
      return;
    }

    try {
      this.loadingState.set(true);
      const today = new Date();
      const pcFecha = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      
      const response = await this.ccService.getReporteCondicionesPago(
        companiaId.toString(),
        pcFecha
      );
      
      if (!response) {
        this.toastService.showError('No se pudo generar el reporte');
        return;
      }

      // Guardar la respuesta y abrir el modal
      this.reportResponse = response;
      this.showReportModal.set(true);
    } catch (error) {
      console.error('Error generando reporte:', error);
      this.toastService.showError('Error al generar el reporte');
    } finally {
      this.loadingState.set(false);
    }
  }

  downloadReportPDF(): void {
    if (!this.reportResponse?.pcArchPDF) {
      this.toastService.showError('No se pudo generar el reporte PDF');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchPDF, 'reporte-condiciones-pago.pdf', 'application/pdf');
    this.toastService.showSuccess('Reporte PDF descargado exitosamente');
    this.showReportModal.set(false);
  }

  downloadReportCSV(): void {
    if (!this.reportResponse?.pcArchCSV) {
      this.toastService.showError('No se pudo generar el reporte CSV');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchCSV, 'reporte-condiciones-pago.csv', 'text/csv');
    this.toastService.showSuccess('Reporte CSV descargado exitosamente');
    this.showReportModal.set(false);
  }

  closeReportModal(): void {
    this.showReportModal.set(false);
    this.reportResponse = null;
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error al descargar el archivo:', error);
      this.toastService.showError('Error al descargar el archivo');
    }
  }

  goBack(): void {
    this.router.navigate(['/']);
  }

  // ==================== MÉTODOS AUXILIARES ====================

  isInvalid(fieldName: string): boolean {
    const field = this.condicionPagoForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.condicionPagoForm.get(fieldName);
    if (!field) return '';
    
    if (field.hasError('required')) return 'Este campo es obligatorio';
    if (field.hasError('min')) return 'El valor debe ser mayor a 0';
    
    return 'Campo inválido';
  }

  onCompaniaLeave(): void {
    const ciaValue = this.condicionPagoForm.get('cia')?.value;
    
    if (!ciaValue) {
      return;
    }

    this.loadingState.set(true);
    this.ccService.validateCompania(ciaValue.toString()).subscribe({
      next: (compania) => {
        this.loadingState.set(false);
        if (compania) {
          this.companiaSeleccionada.set(compania);
          // Habilitar temporalmente el campo para actualizar su valor
          const nombreCiaControl = this.condicionPagoForm.get('nombre-cia');
          if (nombreCiaControl?.disabled) {
            nombreCiaControl.enable();
            nombreCiaControl.patchValue(compania['nombre-cia']);
            nombreCiaControl.disable();
          } else {
            nombreCiaControl?.patchValue(compania['nombre-cia']);
          }
        } else {
          this.toastService.showWarning('Compañía no encontrada');
          const nombreCiaControl = this.condicionPagoForm.get('nombre-cia');
          if (nombreCiaControl?.disabled) {
            nombreCiaControl.enable();
            nombreCiaControl.patchValue('');
            nombreCiaControl.disable();
          } else {
            nombreCiaControl?.patchValue('');
          }
          this.condicionPagoForm.patchValue({
            'condpago': '',
            'nombre-cpag': '',
            'text-cpag': ''
          });
          this.companiaSeleccionada.set(null);
        }
      },
      error: (err) => {
        this.loadingState.set(false);
        console.error('❌ Error validando compañía:', err);
        this.toastService.showError('Error al validar compañía');
      }
    });
  }

  buscarCompania(): void {
    // Método para abrir modal de búsqueda de compañías
    this.openCompaniaModal();
  }

  buscarCondicionPago(): void {
    // Método para abrir modal de búsqueda de condiciones de pago
    this.openCondicionModal();
  }
}
