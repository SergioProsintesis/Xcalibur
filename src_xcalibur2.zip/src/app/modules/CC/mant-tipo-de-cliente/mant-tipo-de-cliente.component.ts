import { Component, inject, signal, OnInit, computed, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { AuthService } from '../../../core/services/auth.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { TipoClienteModalComponent } from '../../../shared/components/tipo-cliente-modal/tipo-cliente-modal.component';
import { CompaniaRecord, TipoClienteRecord } from '../../../core/interfaces/cc.interface';
import { CCService } from '../../../core/services/cc.service';

@Component({
  selector: 'app-mant-tipo-de-cliente',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent, TipoClienteModalComponent],
  templateUrl: './mant-tipo-de-cliente.component.html',
  styleUrls: ['./mant-tipo-de-cliente.component.css']
})
export class MantTipoDeClienteComponent implements OnInit {
  private fb = inject(FormBuilder);
  private modalService = inject(ModalService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private ccService = inject(CCService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private auth = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);

  tipoClienteForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Tipo de Cliente`);
  createTipoClienteForm!: FormGroup;
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  tipoClienteSeleccionado = signal<TipoClienteRecord | null>(null);

  // Control de modales
  showCompaniaModal = signal(false);
  showTipoClienteModal = signal(false);
  showCreateModal = signal(false);
  showReportModal = signal(false);
  isEditMode = signal(false);
  tiposClienteDisponibles = signal<TipoClienteRecord[]>([]);
  
  // Datos de reporte
  reportResponse: any = null;

  ngOnInit() {
    console.log('🔄 MantTipoDeClienteComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    console.log('✅ MantTipoDeClienteComponent inicializado correctamente');
  }

  private initializeForm(): void {
    this.tipoClienteForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      tipocli: ['', [Validators.required]],
      'nombre-tipc': [''],
      'text-tipc': ['']
    });

    this.createTipoClienteForm = this.fb.group({
      tipocli: ['', [Validators.required, Validators.min(1)]],
      'nombre-tipc': ['', [Validators.required]],
      'text-tipc': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.tipoClienteForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.tipoClienteForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.tipoClienteForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.limpiarTipoCliente();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.tipoClienteForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.tipoClienteForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.tipoClienteForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
    this.limpiarTipoCliente();
  }

  // ==================== MODAL DE TIPO DE CLIENTE ====================
  async buscarTipoCliente(): Promise<void> {
    const companiaId = this.tipoClienteForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getCETipoCliente(companiaId);
      
      if (response?.dsRespuesta?.tcctipcli && response.dsRespuesta.tcctipcli.length > 0) {
        this.tiposClienteDisponibles.set(response.dsRespuesta.tcctipcli);
        this.showTipoClienteModal.set(true);
      } else {
        this.toastService.showWarning('No se encontraron tipos de cliente');
      }
    } catch (error) {
      console.error('Error al buscar tipos de cliente:', error);
      this.toastService.showError('Error al buscar tipos de cliente');
    } finally {
      this.loadingState.set(false);
    }
  }

  closeTipoClienteModal(): void {
    this.showTipoClienteModal.set(false);
  }

  async onTipoClienteSelected(tipoCliente: TipoClienteRecord): Promise<void> {
    const companiaId = this.tipoClienteForm.get('cia')?.value;
    if (!companiaId) return;

    this.loadingState.set(true);
    try {
      // Load fresh data from server
      const response = await this.ccService.getCETipoCliente(companiaId);
      const tiposActualizados = response?.dsRespuesta?.tcctipcli || [];
      const tipoActualizado = tiposActualizados.find((t: TipoClienteRecord) => t.tipocli === tipoCliente.tipocli);

      if (tipoActualizado) {
        this.tipoClienteSeleccionado.set(tipoActualizado);
        this.tipoClienteForm.patchValue({
          tipocli: tipoActualizado.tipocli,
          'nombre-tipc': tipoActualizado['nombre-tipc'],
          'text-tipc': tipoActualizado['text-tipc']
        });
        this.toastService.showSuccess(`Tipo de cliente "${tipoActualizado['nombre-tipc']}" cargado`);
      }
    } catch (error) {
      console.error('Error al recargar tipo de cliente:', error);
      // Fallback to local data
      this.tipoClienteSeleccionado.set(tipoCliente);
      this.tipoClienteForm.patchValue({
        tipocli: tipoCliente.tipocli,
        'nombre-tipc': tipoCliente['nombre-tipc'],
        'text-tipc': tipoCliente['text-tipc']
      });
    } finally {
      this.loadingState.set(false);
      this.closeTipoClienteModal();
    }
  }

  async onTipoClienteLeave(): Promise<void> {
    const companiaId = this.tipoClienteForm.get('cia')?.value;
    const tipoCliId = this.tipoClienteForm.get('tipocli')?.value;
    
    if (!companiaId || !tipoCliId) {
      this.limpiarTipoCliente();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveTipoCliente(companiaId, tipoCliId);
      
      if (response?.dsRespuesta?.tcctipcli && response.dsRespuesta.tcctipcli.length > 0) {
        const tipoCliente = response.dsRespuesta.tcctipcli[0];
        this.tipoClienteSeleccionado.set(tipoCliente);
        this.tipoClienteForm.patchValue({
          'nombre-tipc': tipoCliente['nombre-tipc'],
          'text-tipc': tipoCliente['text-tipc']
        });
      } else {
        this.toastService.showError('Tipo de cliente no encontrado');
        this.limpiarTipoCliente();
      }
    } catch (error) {
      console.error('Error al buscar tipo de cliente:', error);
      this.toastService.showError('Error al buscar el tipo de cliente');
      this.limpiarTipoCliente();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarTipoCliente(): void {
    this.tipoClienteSeleccionado.set(null);
    this.tipoClienteForm.patchValue({
      tipocli: '',
      'nombre-tipc': '',
      'text-tipc': ''
    });
  }

  trackByTipoId(index: number, tipo: TipoClienteRecord): number | string {
    return tipo.tipocli;
  }

  // ==================== ACCIONES CRUD ====================
  async onSubmit(): Promise<void> {
    const cia = this.tipoClienteForm.get('cia')?.value;
    const tipocli = this.tipoClienteForm.get('tipocli')?.value;
    const nombreTipc = this.tipoClienteForm.get('nombre-tipc')?.value;

    if (!cia || !tipocli || !nombreTipc) {
      this.toastService.showError('Debe seleccionar una compañía, tipo de cliente y proporcionar una descripción');
      return;
    }

    try {
      this.loadingState.set(true);
      const formData = this.tipoClienteForm.getRawValue();
      
      const payload = {
        cia: formData.cia,
        tipocli: formData.tipocli,
        'nombre-tipc': formData['nombre-tipc'],
        'text-tipc': formData['text-tipc'] || ''
      };
      
      console.log('🔄 Enviando actualización:', payload);
      const response = await this.ccService.updateTipoClienteAsync(payload);
      console.log('✅ Respuesta del servidor:', response);
      
      if (response?.dsRespuesta?.tcctipcli && response.dsRespuesta.tcctipcli.length > 0) {
        const result = response.dsRespuesta.tcctipcli[0];
        
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          const mensaje = error.descripcion || 'Operación exitosa';
          console.log('✅ Error object:', error);
          this.toastService.showSuccess(mensaje);
        } else {
          console.warn('⚠️ Respuesta sin array terrores');
          this.toastService.showSuccess('Tipo de cliente guardado exitosamente');
        }
        await this.loadTiposClientes();
        this.cdr.detectChanges();
      } else {
        console.error('❌ Respuesta inválida:', response);
        this.toastService.showError('Respuesta inválida del servidor');
      }
    } catch (error) {
      console.error('❌ Error al guardar:', error);
      const errorMsg = (error as any)?.error?.mensaje || (error as any)?.message || 'Error desconocido';
      this.toastService.showError('Error al guardar: ' + errorMsg);
    } finally {
      this.loadingState.set(false);
    }
  }

  async onDelete(): Promise<void> {
    const companiaId = this.tipoClienteForm.get('cia')?.value;
    const tipoCliId = this.tipoClienteForm.get('tipocli')?.value;

    if (!companiaId || !tipoCliId) {
      this.toastService.showError('Debe seleccionar una compañía y un tipo de cliente para eliminar');
      return;
    }

    const confirmed = confirm('¿Está seguro de eliminar este tipo de cliente?\nEsta acción no se puede deshacer');

    if (!confirmed) return;

    try {
      this.loadingState.set(true);
      const response = await this.ccService.deleteTipoClienteAsync(companiaId, tipoCliId);
      
      if (response?.dsRespuesta?.tcctipcli && response.dsRespuesta.tcctipcli.length > 0) {
        const result = response.dsRespuesta.tcctipcli[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Registro eliminado');
        } else {
          this.toastService.showSuccess('Tipo de cliente eliminado exitosamente');
        }
        this.onClear();
        this.closeTipoClienteModal();
        await this.loadTiposClientes();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al eliminar:', error);
      this.toastService.showError('Error al eliminar el tipo de cliente');
    } finally {
      this.loadingState.set(false);
    }
  }

  private async loadTiposClientes(): Promise<void> {
    const companiaId = this.tipoClienteForm.get('cia')?.value;
    
    if (!companiaId) {
      return;
    }

    try {
      const response = await this.ccService.getCETipoCliente(companiaId);
      
      if (response?.dsRespuesta?.tcctipcli && response.dsRespuesta.tcctipcli.length > 0) {
        const allTiposCliente = response.dsRespuesta.tcctipcli;
        const filteredTiposCliente = allTiposCliente.filter((tipc: any) => 
          !tipc.cia || tipc.cia === companiaId || tipc.cia.toString() === companiaId.toString()
        );
        
        const tiposClienteToShow = filteredTiposCliente.length > 0 ? filteredTiposCliente : allTiposCliente;
        this.tiposClienteDisponibles.set(tiposClienteToShow);
        console.log('✅ Tipos de cliente recargados');
      }
    } catch (error) {
      console.error('Error al cargar tipos de cliente:', error);
    }
  }

  // ==================== CREAR NUEVO ====================
  openCreateModal(): void {
    const cia = this.tipoClienteForm.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }
    this.createTipoClienteForm.reset();
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
    this.createTipoClienteForm.reset();
  }

  async onSaveNew(): Promise<void> {
    if (this.createTipoClienteForm.invalid) {
      this.toastService.showError('Por favor complete los campos requeridos');
      return;
    }

    const companiaId = this.tipoClienteForm.get('cia')?.value;
    const companiaName = this.tipoClienteForm.get('nombre-cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      
      const formData = this.createTipoClienteForm.value;
      const userLogin = this.auth.user()?.pcLogin || '';
      const today = new Date().toISOString().split('T')[0];
      
      const payload = {
        tcctipcli: [{
          'Agrega-Tipc': '',
          cia: parseInt(companiaId, 10),
          'nombre-cia': companiaName || '',
          'date-ctrl': today,
          'login-ctrl': userLogin,
          tipocli: parseInt(formData.tipocli, 10),
          'nombre-tipc': formData['nombre-tipc'],
          'text-tipc': formData['text-tipc'] || '',
          tparent: userLogin
        }]
      };
      
      console.log('🔄 Creando tipo de cliente:', JSON.stringify(payload, null, 2));
      const response = await this.ccService.updateTipoClienteAsync(payload);
      console.log('✅ Respuesta del servidor (Crear):', response);
      
      if (response?.dsRespuesta?.tcctipcli && response.dsRespuesta.tcctipcli.length > 0) {
        const result = response.dsRespuesta.tcctipcli[0];
        
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          const mensaje = error.descripcion || 'Tipo de cliente creado exitosamente';
          console.log('✅ Error object:', error);
          this.toastService.showSuccess(mensaje);
        } else {
          console.warn('⚠️ Respuesta sin array terrores');
          this.toastService.showSuccess('Tipo de cliente creado exitosamente');
        }
        this.onClear();
        this.closeTipoClienteModal();
        // Recargar la lista de tipos de cliente sin abrir el modal
        const companiaId = this.tipoClienteForm.get('cia')?.value;
        try {
          const response = await this.ccService.getCETipoCliente(companiaId);
          if (response?.dsRespuesta?.tcctipcli && response.dsRespuesta.tcctipcli.length > 0) {
            this.tiposClienteDisponibles.set(response.dsRespuesta.tcctipcli);
            this.cdr.detectChanges();
            // Seleccionar automáticamente el que acaba de crearse
            const nuevoTipoCliente = response.dsRespuesta.tcctipcli.find((tc: TipoClienteRecord) => tc.tipocli === parseInt(formData.tipocli, 10));
            if (nuevoTipoCliente) {
              this.onTipoClienteSelected(nuevoTipoCliente);
            }
          }
        } catch (error) {
          console.error('Error al recargar tipos de cliente:', error);
        }
        this.closeCreateModal();
      } else {
        console.error('❌ Respuesta inválida del servidor:', response);
        this.toastService.showError('Respuesta inválida del servidor');
      }
    } catch (error) {
      console.error('❌ Error al crear tipo de cliente:', error);
      const errorMessage = (error as any)?.error?.mensaje || (error as any)?.message || 'Error desconocido';
      this.toastService.showError('Error al crear: ' + errorMessage);
    } finally {
      this.loadingState.set(false);
    }
  }

  onClear(): void {
    this.tipoClienteForm.reset();
    this.companiaSeleccionada.set(null);
    this.tipoClienteSeleccionado.set(null);
  }

  async onGenerateReport(): Promise<void> {
    const companiaId = this.tipoClienteForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía para generar reporte');
      return;
    }

    try {
      this.loadingState.set(true);
      const today = new Date();
      const pcFecha = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      
      const response = await this.ccService.generarReporteTipoCliente(companiaId, pcFecha).toPromise();
      
      if (response && (response.pcArchPDF || response.pcArchCSV)) {
        this.reportResponse = response;
        this.showReportModal.set(true);
      } else {
        this.toastService.showWarning('No se generó el reporte');
      }
    } catch (error) {
      console.error('Error al generar reporte:', error);
      this.toastService.showError('Error al generar el reporte');
    } finally {
      this.loadingState.set(false);
    }
  }

  downloadReportPDF(): void {
    if (!this.reportResponse?.pcArchPDF) {
      this.toastService.showError('No se pudo generar el reporte PDF');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchPDF, 'reporte-tipo-cliente.pdf', 'application/pdf');
    this.toastService.showSuccess('Reporte PDF descargado exitosamente');
    this.showReportModal.set(false);
  }

  downloadReportCSV(): void {
    if (!this.reportResponse?.pcArchCSV) {
      this.toastService.showError('No se pudo generar el reporte CSV');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchCSV, 'reporte-tipo-cliente.csv', 'text/csv');
    this.toastService.showSuccess('Reporte CSV descargado exitosamente');
    this.showReportModal.set(false);
  }

  closeReportModal(): void {
    this.showReportModal.set(false);
    this.reportResponse = null;
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error al descargar el archivo:', error);
      this.toastService.showError('Error al descargar el archivo');
    }
  }

  goBack(): void {
    this.router.navigate(['/']);
  }
}
