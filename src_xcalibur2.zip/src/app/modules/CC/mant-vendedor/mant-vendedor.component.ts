import { Component, inject, signal, OnInit, computed, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { VendedorModalComponent } from '../../../shared/components/vendedor-modal/vendedor-modal.component';
import { CompaniaRecord } from '../../../core/interfaces/cc.interface';
import { CCService } from '../../../core/services/cc.service';

export interface VendedorRecord {
  vendedor: number;
  cia: number;
  'nombre-cia': string;
  'nombre-vend': string;
  'text-vend': string;
  codsuper: number;
  'nombre-sup': string;
  ubicacion: number;
  'nombre-ubic': string;
  centro: number;
  'nombre-cen': string;
  zona: number;
  'nombre-zon': string;
  comisi1_vend?: number;
  comisi2_vend?: number;
  comis1_vend?: number;
  comis2_vend?: number;
  comisi_vend?: number;
  comcob_vend?: number;
  tipvend?: number;
  'auxiliarcp'?: number;
  'auxiliargc'?: number;
  'auxiliargv'?: number;
  'centrocp'?: number;
  'centrogc'?: number;
  'centrogv'?: number;
  'cuentacp'?: string;
  'cuentagc'?: string;
  'cuentagv'?: string;
  'ubicacioncp'?: number;
  'ubicaciongc'?: number;
  'ubicaciongv'?: number;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'Agrega-Vend'?: string;
  'agrega-palm'?: string;
  'agrega-cosreg'?: string;
  tparent?: string;
}

@Component({
  selector: 'app-mant-vendedor',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, FormsModule, CompaniaModalComponent, VendedorModalComponent],
  templateUrl: './mant-vendedor.component.html',
  styleUrls: ['./mant-vendedor.component.css']
})
export class MantVendedorComponent implements OnInit {
  private fb = inject(FormBuilder);
  private modalService = inject(ModalService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private ccService = inject(CCService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  vendedorForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Vendedor`);
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  vendedorSeleccionado = signal<VendedorRecord | null>(null);
  vendedoresList = signal<VendedorRecord[]>([]);
  createModalCompaniaId = signal<number | null>(null);
  createModalCompaniaNombre = signal<string>('');

  // Control de modales
  showCompaniaModal = signal(false);
  showVendedorModal = signal(false);
  showCreateModal = signal(false);
  showReportModal = signal(false);
  isEditMode = signal(false);
  vendedoresDisponibles = signal<VendedorRecord[]>([]);

  // Control para modales de búsqueda emergente
  showSearchPopup = signal<boolean>(false);
  currentSearchType = signal<'supervisor' | 'zona' | 'ubicacion' | 'centro' | ''>('');
  searchResults = signal<any[]>([]);
  searchTerm = signal<string>('');
  
  // Para almacenar la resolución de promesas
  private searchPromiseResolver: ((value: any) => void) | null = null;
  
  // Datos de reporte
  reportResponse: any = null;
  
  // Formulario de creación
  createVendedorForm!: FormGroup;

  ngOnInit() {
    console.log('🔄 MantVendedorComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    console.log('✅ MantVendedorComponent inicializado correctamente');
  }

  private initializeForm(): void {
    this.vendedorForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      vendedor: ['', [Validators.required]],
      'nombre-vend': [''],
      'text-vend': [''],
      codsuper: [''],
      'nombre-sup': [''],
      ubicacion: [''],
      'nombre-ubic': [''],
      centro: [''],
      'nombre-cen': [''],
      zona: [''],
      'nombre-zon': [''],
      comisi_vend: [''],
      comis1_vend: [''],
      comis2_vend: [''],
      comcob_vend: [''],
      tipvend: ['']
    });

    this.createVendedorForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      vendedor: ['', [Validators.required, Validators.min(1)]],
      'nombre-vend': ['', [Validators.required]],
      'text-vend': [''],
      codsuper: [''],
      'nombre-sup': [''],
      ubicacion: [''],
      'nombre-ubic': [''],
      centro: [''],
      'nombre-cen': [''],
      zona: [''],
      'nombre-zon': [''],
      comisi_vend: [''],
      tipvend: ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.vendedorForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.vendedorForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.vendedorForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.limpiarVendedor();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.vendedorForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.vendedorForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.vendedorForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
    this.limpiarVendedor();
  }

  // ==================== CAMPO VENDEDOR ====================
  async buscarVendedor(): Promise<void> {
    const companiaId = this.vendedorForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getVendedores(companiaId.toString()).toPromise();
      
      if (response?.dsRespuesta?.tccvended && response.dsRespuesta.tccvended.length > 0) {
        this.vendedoresList.set(response.dsRespuesta.tccvended);
        this.showVendedorModal.set(true);
      } else {
        this.toastService.showError('No hay vendedores disponibles para esta compañía');
      }
    } catch (error) {
      console.error('Error al buscar vendedores:', error);
      this.toastService.showError('Error al buscar vendedores');
    } finally {
      this.loadingState.set(false);
    }
  }

  closeVendedorModal(): void {
    this.showVendedorModal.set(false);
  }

  /** Cargar vendedores disponibles */
  async onVendedorSelected(vendedor: VendedorRecord): Promise<void> {
    const companiaId = this.vendedorForm.get('cia')?.value;
    if (!companiaId) return;

    this.loadingState.set(true);
    try {
      // Load fresh data from server
      const response = await this.ccService.getCEVendedor(companiaId);
      const vendedoresActualizados = response?.dsRespuesta?.tccvended || [];
      const vendedorActualizado = vendedoresActualizados.find((v: VendedorRecord) => v.vendedor === vendedor.vendedor);

      if (vendedorActualizado) {
        this.vendedorSeleccionado.set(vendedorActualizado);
        this.vendedorForm.patchValue({
          vendedor: vendedorActualizado.vendedor
        });
        this.cargarDatosVendedor(vendedorActualizado);
        this.isEditMode.set(true);
        this.toastService.showSuccess(`Vendedor "${vendedorActualizado['nombre-vend']}" cargado`);
      }
    } catch (error) {
      console.error('Error al recargar vendedor:', error);
      // Fallback to local data
      this.vendedorSeleccionado.set(vendedor);
      this.vendedorForm.patchValue({
        vendedor: vendedor.vendedor
      });
      this.cargarDatosVendedor(vendedor);
      this.isEditMode.set(true);
    } finally {
      this.loadingState.set(false);
      this.closeVendedorModal();
    }
  }

  async onVendedorLeave(): Promise<void> {
    const companiaId = this.vendedorForm.get('cia')?.value;
    const vendedorId = this.vendedorForm.get('vendedor')?.value;
    
    if (!companiaId || !vendedorId) {
      this.limpiarVendedor();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveVendedor(companiaId, vendedorId);
      
      if (response?.dsRespuesta?.tccvended && response.dsRespuesta.tccvended.length > 0) {
        const vendedor = response.dsRespuesta.tccvended[0];
        this.vendedorSeleccionado.set(vendedor);
        this.cargarDatosVendedor(vendedor);
        this.isEditMode.set(true);
      } else {
        this.toastService.showError('Vendedor no encontrado');
        this.limpiarVendedor();
      }
    } catch (error) {
      console.error('Error al buscar vendedor:', error);
      this.toastService.showError('Error al buscar el vendedor');
      this.limpiarVendedor();
    } finally {
      this.loadingState.set(false);
    }
  }

  private cargarDatosVendedor(vendedor: VendedorRecord): void {
    this.vendedorForm.patchValue({
      vendedor: vendedor.vendedor,
      'nombre-vend': vendedor['nombre-vend'],
      'text-vend': vendedor['text-vend'],
      codsuper: vendedor.codsuper,
      'nombre-sup': vendedor['nombre-sup'],
      ubicacion: vendedor.ubicacion,
      'nombre-ubic': vendedor['nombre-ubic'],
      centro: vendedor.centro,
      'nombre-cen': vendedor['nombre-cen'],
      zona: vendedor.zona,
      'nombre-zon': vendedor['nombre-zon'],
      comisi_vend: (vendedor as any)['comisi-vend'] || vendedor.comisi_vend || vendedor['comisi_vend'],
      comis1_vend: (vendedor as any)['comis1-vend'] || vendedor.comis1_vend || vendedor['comis1_vend'],
      comis2_vend: (vendedor as any)['comis2-vend'] || vendedor.comis2_vend || vendedor['comis2_vend'],
      comcob_vend: (vendedor as any)['comcob-vend'] || vendedor.comcob_vend || vendedor['comcob_vend'],
      tipvend: vendedor.tipvend
    });
  }

  private limpiarVendedor(): void {
    this.vendedorSeleccionado.set(null);
    this.isEditMode.set(false);
    this.vendedorForm.patchValue({
      vendedor: '',
      'nombre-vend': '',
      'text-vend': '',
      codsuper: '',
      'nombre-sup': '',
      ubicacion: '',
      'nombre-ubic': '',
      centro: '',
      'nombre-cen': '',
      zona: '',
      'nombre-zon': '',
      comisi_vend: '',
      comis1_vend: '',
      comis2_vend: '',
      comcob_vend: '',
      tipvend: ''
    });
  }

  // ==================== ACCIONES CRUD ====================
  openCreateModal(): void {
    const companiaId = this.vendedorForm.get('cia')?.value;
    const nombreCompania = this.vendedorForm.get('nombre-cia')?.value;
    
    console.log('🔍 [openCreateModal] companiaId:', companiaId, 'tipo:', typeof companiaId, 'nombreCompania:', nombreCompania);
    
    if (companiaId === null || companiaId === undefined || companiaId === 0 || companiaId === '') {
      console.error('❌ [openCreateModal] CompañiaId inválida');
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    // Guardar los datos de la compañía para usarlos en el submit
    this.createModalCompaniaId.set(companiaId);
    this.createModalCompaniaNombre.set(nombreCompania);
    
    console.log('✅ [openCreateModal] Datos guardados - companiaId:', this.createModalCompaniaId(), 'nombreCompania:', this.createModalCompaniaNombre());
    
    // Resetear el formulario y luego establecer la compañía
    this.createVendedorForm.reset();
    this.createVendedorForm.patchValue({
      cia: companiaId,
      'nombre-cia': nombreCompania
    });
    
    this.isEditMode.set(false);
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
    this.createVendedorForm.reset();
    this.createModalCompaniaId.set(null);
    this.createModalCompaniaNombre.set('');
  }

  async onCreateSubmit(): Promise<void> {
    if (this.createVendedorForm.invalid) {
      this.toastService.showError('Por favor complete los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const companiaId = this.createVendedorForm.get('cia')?.value;
      const nombreCompania = this.createVendedorForm.get('nombre-cia')?.value;
      
      console.log('🔍 [onCreateSubmit] companiaId:', companiaId, 'tipo:', typeof companiaId, 'nombreCompania:', nombreCompania);
      
      if (companiaId === null || companiaId === undefined || companiaId === 0) {
        console.error('❌ [onCreateSubmit] CompañiaId inválida');
        this.toastService.showError('Debe seleccionar una compañía primero');
        this.loadingState.set(false);
        return;
      }
      
      const formData = this.createVendedorForm.value;
      const auth = this.ccService.getAuthParams();

      const payload = {
        tccvended: [{
          'Agrega-Vend': '',
          cia: companiaId,
          vendedor: formData.vendedor,
          'nombre-cia': nombreCompania,
          'date-ctrl': new Date().toISOString().split('T')[0],
          'login-ctrl': auth.pcLogin || 'user',
          'nombre-vend': formData['nombre-vend'],
          'text-vend': formData['text-vend'] || '',
          codsuper: formData.codsuper || 0,
          ubicacion: formData.ubicacion || 0,
          centro: formData.centro || 0,
          zona: formData.zona || 0,
          comisi_vend: formData.comisi_vend || 0,
          tipvend: formData.tipvend || 0,
          'nombre-sup': '',
          'nombre-ubic': '',
          'nombre-cen': '',
          'nombre-zon': '',
          auxiliarcp: 0,
          auxiliargc: 0,
          auxiliargv: 0,
          centrocp: 0,
          centrogc: 0,
          centrogv: 0,
          cuentacp: '',
          cuentagc: '',
          cuentagv: '',
          ubicacioncp: 0,
          ubicaciongc: 0,
          ubicaciongv: 0,
          comis1_vend: 0,
          comis2_vend: 0,
          comcob_vend: 0,
          'agrega-palm': 'SI',
          'agrega-cosreg': formData.vendedor.toString().padEnd(20),
          tparent: auth.pcLogin || 'user'
        }]
      };

      console.log('🔄 Enviando creación de vendedor:', payload);

      const response = await this.ccService.updateVendedor(payload);

      if (response?.dsRespuesta?.tccvended && response.dsRespuesta.tccvended.length > 0) {
        const result = response.dsRespuesta.tccvended[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Vendedor creado exitosamente');
        } else {
          this.toastService.showSuccess('Vendedor creado exitosamente');
        }
        this.onClear();
        this.closeVendedorModal();
        await this.loadVendedores();
        this.cdr.detectChanges();
        this.closeCreateModal();
      }
    } catch (error) {
      console.error('Error al crear vendedor:', error);
      this.toastService.showError('Error al crear el vendedor');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onSubmit(): Promise<void> {
    if (!this.vendedorForm.get('cia')?.value || !this.vendedorForm.get('vendedor')?.value) {
      this.toastService.showError('Por favor complete todos los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const formData = this.vendedorForm.getRawValue();
      const auth = this.ccService.getAuthParams();
      
      const payload = {
        tccvended: [{
          'Agrega-Vend': '',
          vendedor: formData.vendedor,
          cia: formData.cia,
          'nombre-cia': formData['nombre-cia'],
          'date-ctrl': new Date().toISOString().split('T')[0],
          'login-ctrl': auth.pcLogin || 'user',
          'nombre-vend': formData['nombre-vend'] || '',
          'text-vend': formData['text-vend'] || '',
          codsuper: formData.codsuper || 0,
          'nombre-sup': formData['nombre-sup'] || '',
          ubicacion: formData.ubicacion || 0,
          'nombre-ubic': formData['nombre-ubic'] || '',
          centro: formData.centro || 0,
          'nombre-cen': formData['nombre-cen'] || '',
          zona: formData.zona || 0,
          'nombre-zon': formData['nombre-zon'] || '',
          comisi_vend: formData.comisi_vend || 0,
          comis1_vend: formData.comis1_vend || 0,
          comis2_vend: formData.comis2_vend || 0,
          comcob_vend: formData.comcob_vend || 0,
          tipvend: formData.tipvend || 0,
          auxiliarcp: 0,
          auxiliargc: 0,
          auxiliargv: 0,
          centrocp: 0,
          centrogc: 0,
          centrogv: 0,
          cuentacp: '',
          cuentagc: '',
          cuentagv: '',
          ubicacioncp: 0,
          ubicaciongc: 0,
          ubicaciongv: 0,
          'agrega-palm': 'SI',
          'agrega-cosreg': formData.vendedor.toString().padEnd(20),
          tparent: auth.pcLogin || 'user'
        }]
      };

      console.log('🔄 Enviando actualización de vendedor:', payload);

      const response = await this.ccService.updateVendedor(payload);
      
      if (response?.dsRespuesta?.tccvended && response.dsRespuesta.tccvended.length > 0) {
        const result = response.dsRespuesta.tccvended[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Vendedor actualizado exitosamente');
        } else {
          this.toastService.showSuccess('Vendedor actualizado exitosamente');
        }
        this.onClear();
        this.closeVendedorModal();
        await this.loadVendedores();
        this.cdr.detectChanges();
        this.isEditMode.set(true);
      }
    } catch (error) {
      console.error('Error al guardar vendedor:', error);
      this.toastService.showError('Error al guardar el vendedor');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onDelete(): Promise<void> {
    const companiaId = this.vendedorForm.get('cia')?.value;
    const vendedorId = this.vendedorForm.get('vendedor')?.value;

    if (!companiaId || !vendedorId) {
      this.toastService.showError('Debe seleccionar un vendedor para eliminar');
      return;
    }

    const confirmed = confirm('¿Está seguro de eliminar este vendedor?\nEsta acción no se puede deshacer');

    if (!confirmed) return;

    try {
      this.loadingState.set(true);
      const response = await this.ccService.deleteVendedor(companiaId, vendedorId);
      
      if (response?.dsRespuesta?.tccvended && response.dsRespuesta.tccvended.length > 0) {
        const result = response.dsRespuesta.tccvended[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Vendedor eliminado');
        } else {
          this.toastService.showSuccess('Vendedor eliminado exitosamente');
        }
        this.onClear();
        this.closeVendedorModal();
        await this.loadVendedores();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al eliminar vendedor:', error);
      this.toastService.showError('Error al eliminar el vendedor');
    } finally {
      this.loadingState.set(false);
    }
  }

  private async loadVendedores(): Promise<void> {
    const companiaId = this.vendedorForm.get('cia')?.value;
    
    if (!companiaId) {
      return;
    }

    try {
      const response = await this.ccService.getCEVendedor(companiaId.toString());
      
      if (response?.dsRespuesta?.tccvended && response.dsRespuesta.tccvended.length > 0) {
        const allVendedores = response.dsRespuesta.tccvended;
        const filteredVendedores = allVendedores.filter((vend: any) => 
          !vend.cia || vend.cia === companiaId || vend.cia.toString() === companiaId.toString()
        );
        
        const vendedoresToShow = filteredVendedores.length > 0 ? filteredVendedores : allVendedores;
        this.vendedoresDisponibles.set(vendedoresToShow);
        console.log('✅ Vendedores recargados');
      }
    } catch (error) {
      console.error('Error al cargar vendedores:', error);
    }
  }

  onClear(): void {
    this.vendedorForm.reset();
    this.companiaSeleccionada.set(null);
    this.vendedorSeleccionado.set(null);
    this.isEditMode.set(false);
  }

  async onGenerateReport(): Promise<void> {
    const companiaId = this.vendedorForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía para generar reporte');
      return;
    }

    try {
      this.loadingState.set(true);
      const today = new Date();
      const pcFecha = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      
      // Usar endpoint específico GetCC2016 para Vendedor
      const response = await this.ccService.generarReporteVendedor(
        companiaId.toString(),
        pcFecha
      ).toPromise();
      
      if (response?.pcArchXLS) {
        this.reportResponse = response;
        this.showReportModal.set(true);
      } else {
        this.toastService.showError('No se pudo generar el reporte');
      }
    } catch (error) {
      console.error('Error generando reporte:', error);
      this.toastService.showError('Error al generar el reporte');
    } finally {
      this.loadingState.set(false);
    }
  }

  downloadReportExcel(): void {
    if (!this.reportResponse?.pcArchXLS) {
      this.toastService.showError('No se pudo generar el reporte Excel');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchXLS, 'reporte-vendedor.xls', 'application/vnd.ms-excel');
    this.toastService.showSuccess('Reporte Excel descargado exitosamente');
    this.showReportModal.set(false);
  }

  closeReportModal(): void {
    this.showReportModal.set(false);
    this.reportResponse = null;
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error al descargar el archivo:', error);
      this.toastService.showError('Error al descargar el archivo');
    }
  }

  // ==================== BÚSQUEDAS EMERGENTES PARA CREAR ====================
  async buscarSupervisor(): Promise<void> {
    const companiaId = this.createVendedorForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getCESupervisores(companiaId.toString()).toPromise();
      
      if (response?.dsRespuesta?.tccvendedSup && response.dsRespuesta.tccvendedSup.length > 0) {
        this.searchResults.set(response.dsRespuesta.tccvendedSup);
        this.currentSearchType.set('supervisor');
        this.showSearchPopup.set(true);
        this.modalService.openModal();
        
        // Esperar a que el usuario seleccione un item
        const selected = await new Promise<any>((resolve) => {
          this.searchPromiseResolver = resolve;
        });
        
        if (selected) {
          this.createVendedorForm.patchValue({
            codsuper: selected.codsuper,
            'nombre-sup': selected['nombre-sup']
          });
        }
      } else {
        this.toastService.showError('No hay supervisores disponibles');
      }
    } catch (error) {
      console.error('Error al buscar supervisores:', error);
      this.toastService.showError('Error al buscar supervisores');
    } finally {
      this.loadingState.set(false);
    }
  }

  async buscarZona(): Promise<void> {
    const companiaId = this.createVendedorForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getCEZonasCreate(companiaId.toString()).toPromise();
      
      if (response?.dsRespuesta?.tcczona && response.dsRespuesta.tcczona.length > 0) {
        this.searchResults.set(response.dsRespuesta.tcczona);
        this.currentSearchType.set('zona');
        this.showSearchPopup.set(true);
        this.modalService.openModal();
        
        const selected = await new Promise<any>((resolve) => {
          this.searchPromiseResolver = resolve;
        });
        
        if (selected) {
          this.createVendedorForm.patchValue({
            zona: selected.zona,
            'nombre-zon': selected['nombre-zon']
          });
        }
      } else {
        this.toastService.showError('No hay zonas disponibles');
      }
    } catch (error) {
      console.error('Error al buscar zonas:', error);
      this.toastService.showError('Error al buscar zonas');
    } finally {
      this.loadingState.set(false);
    }
  }

  async buscarUbicacion(): Promise<void> {
    const companiaId = this.createVendedorForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getCEUbicacionesCreate(companiaId.toString()).toPromise();
      
      if (response?.dsRespuesta?.tcgubicac && response.dsRespuesta.tcgubicac.length > 0) {
        this.searchResults.set(response.dsRespuesta.tcgubicac);
        this.currentSearchType.set('ubicacion');
        this.showSearchPopup.set(true);
        this.modalService.openModal();
        
        const selected = await new Promise<any>((resolve) => {
          this.searchPromiseResolver = resolve;
        });
        
        if (selected) {
          this.createVendedorForm.patchValue({
            ubicacion: selected.ubicacion,
            'nombre-ubic': selected['nombre-ubic']
          });
        }
      } else {
        this.toastService.showError('No hay ubicaciones disponibles');
      }
    } catch (error) {
      console.error('Error al buscar ubicaciones:', error);
      this.toastService.showError('Error al buscar ubicaciones');
    } finally {
      this.loadingState.set(false);
    }
  }

  async buscarCentro(): Promise<void> {
    const companiaId = this.createVendedorForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getCECentrosCreate(companiaId.toString()).toPromise();
      
      if (response?.dsRespuesta?.tgecencos && response.dsRespuesta.tgecencos.length > 0) {
        this.searchResults.set(response.dsRespuesta.tgecencos);
        this.currentSearchType.set('centro');
        this.showSearchPopup.set(true);
        this.modalService.openModal();
        
        const selected = await new Promise<any>((resolve) => {
          this.searchPromiseResolver = resolve;
        });
        
        if (selected) {
          this.createVendedorForm.patchValue({
            centro: selected.centro,
            'nombre-cen': selected['nombre-cen']
          });
        }
      } else {
        this.toastService.showError('No hay centros disponibles');
      }
    } catch (error) {
      console.error('Error al buscar centros:', error);
      this.toastService.showError('Error al buscar centros');
    } finally {
      this.loadingState.set(false);
    }
  }

  // Cuando el usuario selecciona un item del popup
  selectFromSearchPopup(item: any): void {
    if (this.searchPromiseResolver) {
      this.searchPromiseResolver(item);
      this.searchPromiseResolver = null;
    }
    this.closeSearchPopup();
  }

  // Cerrar el popup de búsqueda
  closeSearchPopup(): void {
    this.showSearchPopup.set(false);
    this.currentSearchType.set('');
    this.searchResults.set([]);
    this.searchTerm.set('');
    this.modalService.closeModal();
  }

  // Obtener resultados filtrados por término de búsqueda
  getFilteredResults(): any[] {
    const term = this.searchTerm().toLowerCase();
    if (!term) return this.searchResults();

    const searchType = this.currentSearchType();
    return this.searchResults().filter((item: any) => {
      if (searchType === 'supervisor') {
        return (
          item.codsuper?.toString().includes(term) ||
          item['nombre-sup']?.toLowerCase().includes(term)
        );
      } else if (searchType === 'zona') {
        return (
          item.zona?.toString().includes(term) ||
          item['nombre-zon']?.toLowerCase().includes(term)
        );
      } else if (searchType === 'ubicacion') {
        return (
          item.ubicacion?.toString().includes(term) ||
          item['nombre-ubic']?.toLowerCase().includes(term)
        );
      } else if (searchType === 'centro') {
        return (
          item.centro?.toString().includes(term) ||
          item['nombre-cen']?.toLowerCase().includes(term)
        );
      }
      return false;
    });
  }

  // ==================== BÚSQUEDAS EN PANTALLA PRINCIPAL ====================
  async buscarMainSupervisor(): Promise<void> {
    const companiaId = this.vendedorForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getCESupervisores(companiaId.toString()).toPromise();
      
      if (response?.dsRespuesta?.tccvendedSup && response.dsRespuesta.tccvendedSup.length > 0) {
        this.searchResults.set(response.dsRespuesta.tccvendedSup);
        this.currentSearchType.set('supervisor');
        this.showSearchPopup.set(true);
        this.modalService.openModal();
        
        const selected = await new Promise<any>((resolve) => {
          this.searchPromiseResolver = resolve;
        });
        
        if (selected) {
          this.vendedorForm.patchValue({
            codsuper: selected.codsuper,
            'nombre-sup': selected['nombre-sup']
          });
        }
      } else {
        this.toastService.showError('No hay supervisores disponibles');
      }
    } catch (error) {
      console.error('Error al buscar supervisores:', error);
      this.toastService.showError('Error al buscar supervisores');
    } finally {
      this.loadingState.set(false);
    }
  }

  async buscarMainZona(): Promise<void> {
    const companiaId = this.vendedorForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getCEZonasCreate(companiaId.toString()).toPromise();
      
      if (response?.dsRespuesta?.tcczona && response.dsRespuesta.tcczona.length > 0) {
        this.searchResults.set(response.dsRespuesta.tcczona);
        this.currentSearchType.set('zona');
        this.showSearchPopup.set(true);
        this.modalService.openModal();
        
        const selected = await new Promise<any>((resolve) => {
          this.searchPromiseResolver = resolve;
        });
        
        if (selected) {
          this.vendedorForm.patchValue({
            zona: selected.zona,
            'nombre-zon': selected['nombre-zon']
          });
        }
      } else {
        this.toastService.showError('No hay zonas disponibles');
      }
    } catch (error) {
      console.error('Error al buscar zonas:', error);
      this.toastService.showError('Error al buscar zonas');
    } finally {
      this.loadingState.set(false);
    }
  }

  async buscarMainUbicacion(): Promise<void> {
    const companiaId = this.vendedorForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getCEUbicacionesCreate(companiaId.toString()).toPromise();
      
      if (response?.dsRespuesta?.tcgubicac && response.dsRespuesta.tcgubicac.length > 0) {
        this.searchResults.set(response.dsRespuesta.tcgubicac);
        this.currentSearchType.set('ubicacion');
        this.showSearchPopup.set(true);
        this.modalService.openModal();
        
        const selected = await new Promise<any>((resolve) => {
          this.searchPromiseResolver = resolve;
        });
        
        if (selected) {
          this.vendedorForm.patchValue({
            ubicacion: selected.ubicacion,
            'nombre-ubic': selected['nombre-ubic']
          });
        }
      } else {
        this.toastService.showError('No hay ubicaciones disponibles');
      }
    } catch (error) {
      console.error('Error al buscar ubicaciones:', error);
      this.toastService.showError('Error al buscar ubicaciones');
    } finally {
      this.loadingState.set(false);
    }
  }

  async buscarMainCentro(): Promise<void> {
    const companiaId = this.vendedorForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getCECentrosCreate(companiaId.toString()).toPromise();
      
      if (response?.dsRespuesta?.tgecencos && response.dsRespuesta.tgecencos.length > 0) {
        this.searchResults.set(response.dsRespuesta.tgecencos);
        this.currentSearchType.set('centro');
        this.showSearchPopup.set(true);
        this.modalService.openModal();
        
        const selected = await new Promise<any>((resolve) => {
          this.searchPromiseResolver = resolve;
        });
        
        if (selected) {
          this.vendedorForm.patchValue({
            centro: selected.centro,
            'nombre-cen': selected['nombre-cen']
          });
        }
      } else {
        this.toastService.showError('No hay centros disponibles');
      }
    } catch (error) {
      console.error('Error al buscar centros:', error);
      this.toastService.showError('Error al buscar centros');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onMainSupervisorLeave(): Promise<void> {
    const codsuper = this.vendedorForm.get('codsuper')?.value;
    const companiaId = this.vendedorForm.get('cia')?.value;
    
    if (codsuper && companiaId) {
      try {
        this.loadingState.set(true);
        const response = await this.ccService.getLeaveSupervisor(companiaId.toString(), codsuper.toString()).toPromise();
        
        if (response?.dsRespuesta?.tccvendedSup && response.dsRespuesta.tccvendedSup.length > 0) {
          const sup = response.dsRespuesta.tccvendedSup[0];
          this.vendedorForm.patchValue({
            'nombre-sup': sup['nombre-sup']
          });
        }
      } catch (error) {
        console.error('Error en Leave Supervisor:', error);
      } finally {
        this.loadingState.set(false);
      }
    }
  }

  async onMainZonaLeave(): Promise<void> {
    const zona = this.vendedorForm.get('zona')?.value;
    const companiaId = this.vendedorForm.get('cia')?.value;
    
    if (zona && companiaId) {
      try {
        this.loadingState.set(true);
        const response = await this.ccService.getLeaveZonaCreate(companiaId.toString(), zona.toString()).toPromise();
        
        if (response?.dsRespuesta?.tcczona && response.dsRespuesta.tcczona.length > 0) {
          const z = response.dsRespuesta.tcczona[0];
          this.vendedorForm.patchValue({
            'nombre-zon': z['nombre-zon']
          });
        }
      } catch (error) {
        console.error('Error en Leave Zona:', error);
      } finally {
        this.loadingState.set(false);
      }
    }
  }

  async onMainUbicacionLeave(): Promise<void> {
    const ubicacion = this.vendedorForm.get('ubicacion')?.value;
    const companiaId = this.vendedorForm.get('cia')?.value;
    
    if (ubicacion && companiaId) {
      try {
        this.loadingState.set(true);
        const response = await this.ccService.getLeaveUbicacionCreate(companiaId.toString(), ubicacion.toString()).toPromise();
        
        if (response?.dsRespuesta?.tcgubicac && response.dsRespuesta.tcgubicac.length > 0) {
          const ubic = response.dsRespuesta.tcgubicac[0];
          this.vendedorForm.patchValue({
            'nombre-ubic': ubic['nombre-ubic']
          });
        }
      } catch (error) {
        console.error('Error en Leave Ubicación:', error);
      } finally {
        this.loadingState.set(false);
      }
    }
  }

  async onMainCentroLeave(): Promise<void> {
    const centro = this.vendedorForm.get('centro')?.value;
    const companiaId = this.vendedorForm.get('cia')?.value;
    
    if (centro && companiaId) {
      try {
        this.loadingState.set(true);
        const response = await this.ccService.getLeaveCentroCreate(companiaId.toString(), centro.toString()).toPromise();
        
        if (response?.dsRespuesta?.tgecencos && response.dsRespuesta.tgecencos.length > 0) {
          const cen = response.dsRespuesta.tgecencos[0];
          this.vendedorForm.patchValue({
            'nombre-cen': cen['nombre-cen']
          });
        }
      } catch (error) {
        console.error('Error en Leave Centro:', error);
      } finally {
        this.loadingState.set(false);
      }
    }
  }

  async onSupervisorLeave(): Promise<void> {
    const codsuper = this.createVendedorForm.get('codsuper')?.value;
    const companiaId = this.createVendedorForm.get('cia')?.value;
    
    if (codsuper && companiaId) {
      try {
        this.loadingState.set(true);
        const response = await this.ccService.getLeaveSupervisor(companiaId.toString(), codsuper.toString()).toPromise();
        
        if (response?.dsRespuesta?.tccvendedSup && response.dsRespuesta.tccvendedSup.length > 0) {
          const sup = response.dsRespuesta.tccvendedSup[0];
          this.createVendedorForm.patchValue({
            'nombre-sup': sup['nombre-sup']
          });
        }
      } catch (error) {
        console.error('Error en Leave Supervisor:', error);
      } finally {
        this.loadingState.set(false);
      }
    }
  }

  async onZonaLeave(): Promise<void> {
    const zona = this.createVendedorForm.get('zona')?.value;
    const companiaId = this.createVendedorForm.get('cia')?.value;
    
    if (zona && companiaId) {
      try {
        this.loadingState.set(true);
        const response = await this.ccService.getLeaveZonaCreate(companiaId.toString(), zona.toString()).toPromise();
        
        if (response?.dsRespuesta?.tcczona && response.dsRespuesta.tcczona.length > 0) {
          const z = response.dsRespuesta.tcczona[0];
          this.createVendedorForm.patchValue({
            'nombre-zon': z['nombre-zon']
          });
        }
      } catch (error) {
        console.error('Error en Leave Zona:', error);
      } finally {
        this.loadingState.set(false);
      }
    }
  }

  async onUbicacionLeave(): Promise<void> {
    const ubicacion = this.createVendedorForm.get('ubicacion')?.value;
    const companiaId = this.createVendedorForm.get('cia')?.value;
    
    if (ubicacion && companiaId) {
      try {
        this.loadingState.set(true);
        const response = await this.ccService.getLeaveUbicacionCreate(companiaId.toString(), ubicacion.toString()).toPromise();
        
        if (response?.dsRespuesta?.tcgubicac && response.dsRespuesta.tcgubicac.length > 0) {
          const ubic = response.dsRespuesta.tcgubicac[0];
          this.createVendedorForm.patchValue({
            'nombre-ubic': ubic['nombre-ubic']
          });
        }
      } catch (error) {
        console.error('Error en Leave Ubicación:', error);
      } finally {
        this.loadingState.set(false);
      }
    }
  }

  async onCentroLeave(): Promise<void> {
    const centro = this.createVendedorForm.get('centro')?.value;
    const companiaId = this.createVendedorForm.get('cia')?.value;
    
    if (centro && companiaId) {
      try {
        this.loadingState.set(true);
        const response = await this.ccService.getLeaveCentroCreate(companiaId.toString(), centro.toString()).toPromise();
        
        if (response?.dsRespuesta?.tgecencos && response.dsRespuesta.tgecencos.length > 0) {
          const cen = response.dsRespuesta.tgecencos[0];
          this.createVendedorForm.patchValue({
            'nombre-cen': cen['nombre-cen']
          });
        }
      } catch (error) {
        console.error('Error en Leave Centro:', error);
      } finally {
        this.loadingState.set(false);
      }
    }
  }

  goBack(): void {
    this.router.navigate(['/']);
  }
}
