import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { 
  OtroConceptoResponse, 
  NaturalezaResponse, 
  TipoCantidadResponse 
} from './fa5156.interface';

@Injectable({
  providedIn: 'root'
})
export class Fa5156Service {
  private apiUrl = 'http://184.168.30.44:8810/XcaliburWeb/rest/ServiciosXcaliburWeb';

  // Auth parameters (should be injected from auth service)
  private pcLogin = 'CEB';
  private pcSuper = '0';
  private pcToken = '';

  constructor(private http: HttpClient) {}

  // Set auth parameters
  setAuthParams(login: string, token: string, super_?: string): void {
    this.pcLogin = login;
    this.pcToken = token;
    if (super_) this.pcSuper = super_;
  }

  // ==================== GET (Buscar/Consulta Emergente) ====================

  getCEFaotros(pcCompania: number): Observable<OtroConceptoResponse> {
    const url = `${this.apiUrl}/GetCEFaotros_fa5156`;
    return this.http.get<OtroConceptoResponse>(url, {
      params: {
        pcCompania: pcCompania.toString(),
        pcLogin: this.pcLogin,
        pcSuper: this.pcSuper,
        pcToken: this.pcToken
      }
    });
  }

  // ==================== LEAVE EVENTS ====================

  getLeaveOtrocon(pcCompania: number, pcOtrocon: string): Observable<OtroConceptoResponse> {
    const url = `${this.apiUrl}/GetLeaveOtrocon_fa5156`;
    return this.http.get<OtroConceptoResponse>(url, {
      params: {
        pcCompania: pcCompania.toString(),
        pcOtrocon: pcOtrocon,
        pcLogin: this.pcLogin,
        pcSuper: this.pcSuper,
        pcToken: this.pcToken
      }
    });
  }

  getLeavenaturaleza(pcCompania: number, pcNaturaleza: string): Observable<NaturalezaResponse> {
    const url = `${this.apiUrl}/GetLeaveNaturaleza_fa5156`;
    return this.http.get<NaturalezaResponse>(url, {
      params: {
        pcCompania: pcCompania.toString(),
        pcNaturaleza: pcNaturaleza,
        pcLogin: this.pcLogin,
        pcSuper: this.pcSuper,
        pcToken: this.pcToken
      }
    });
  }

  getLeavetipcanfaot(pcCompania: number, pcTipcanfaot: string): Observable<TipoCantidadResponse> {
    const url = `${this.apiUrl}/GetLeavetipcanfaot_fa5156`;
    return this.http.get<TipoCantidadResponse>(url, {
      params: {
        pcCompania: pcCompania.toString(),
        pcTipcanfaot: pcTipcanfaot,
        pcLogin: this.pcLogin,
        pcSuper: this.pcSuper,
        pcToken: this.pcToken
      }
    });
  }

  // ==================== CREATE/UPDATE ====================

  updateFaotros(payload: any): Observable<OtroConceptoResponse> {
    const url = `${this.apiUrl}/Updatefaotros_fa5156`;
    return this.http.put<OtroConceptoResponse>(url, payload);
  }

  // ==================== DELETE ====================

  deleteFaotros(pcCompania: number, pcOtrocon: string): Observable<OtroConceptoResponse> {
    const url = `${this.apiUrl}/DelFaotros_fa5156`;
    return this.http.delete<OtroConceptoResponse>(url, {
      params: {
        pcCompania: pcCompania.toString(),
        pcOtrocon: pcOtrocon,
        pcLogin: this.pcLogin,
        pcSuper: this.pcSuper,
        pcToken: this.pcToken
      }
    });
  }
}
