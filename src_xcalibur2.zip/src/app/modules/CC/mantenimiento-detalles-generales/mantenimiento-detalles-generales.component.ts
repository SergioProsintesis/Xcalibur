import { Component, inject, signal, OnInit, computed, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { AuthService } from '../../../core/services/auth.service';
import { CCService } from '../../../core/services/cc.service';
import { Fa5156Service } from './fa5156.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { 
  OtroConceptoRecord, 
  CompaniaRecord, 
  NaturalezaRecord,
  TipoCantidadRecord
} from './fa5156.interface';

@Component({
  selector: 'app-mantenimiento-detalles-generales',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent],
  templateUrl: './mantenimiento-detalles-generales.component.html',
  styleUrls: ['./mantenimiento-detalles-generales.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MantenimientoDetallesGeneralesComponent implements OnInit {
  private fb = inject(FormBuilder);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private ccService = inject(CCService);
  private fa5156Service = inject(Fa5156Service);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private authService = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);

  detallesForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Detalles Generales`);
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  otroConceptoSeleccionado = signal<OtroConceptoRecord | null>(null);
  naturalezaSeleccionada = signal<NaturalezaRecord | null>(null);
  tipoCantidadSeleccionado = signal<TipoCantidadRecord | null>(null);

  // Control de modales
  showCompaniaModal = signal(false);
  showOtroConceptoModal = signal(false);
  showCreateModal = signal(false);
  showReportModal = signal(false);
  isEditMode = signal(false);
  otrosConceptos = signal<OtroConceptoRecord[]>([]);
  
  // Datos de reporte
  reportResponse: any = null;
  
  // Formulario de creación
  createDetallesForm!: FormGroup;

  // Field visibility controls based on Naturaleza
  mostrarAuxiliar = signal(false);
  mostrarCentroCosto = signal(false);
  mostrarUbicacion = signal(false);
  mostrarImpuesto = signal(false);
  mostrarPorcentDesc = signal(false);

  // Field visibility for Tipo Cantidad
  mostrarPrecio = signal(false);

  ngOnInit() {
    console.log('🔄 MantenimientoDetallesGeneralesComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    this.initializeAuthParams();
    console.log('✅ MantenimientoDetallesGeneralesComponent inicializado correctamente');
  }

  private initializeAuthParams(): void {
    const auth = this.ccService.getAuthParams();
    this.fa5156Service.setAuthParams(auth.pcLogin, auth.pcToken, auth.pcSuper);
  }

  private initializeForm(): void {
    this.detallesForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      'Otrocon': ['', [Validators.required]],
      'Nombre-Faot': [''],
      'Text-Faot': [''],
      'Naturaleza': [''],
      'Tipcan-Faot': [''],
      'Impuesto': [{ value: '', disabled: true }],
      'nombre-impu': [{ value: '', disabled: true }],
      'Cuenta-Conce': [{ value: '', disabled: true }],
      'nombre-cta': [{ value: '', disabled: true }],
      'Ubicacion-Conce': [{ value: '', disabled: true }],
      'nombre-ubic': [{ value: '', disabled: true }],
      'Centro-Conce': [{ value: '', disabled: true }],
      'nombre-cen': [{ value: '', disabled: true }],
      'Auxiliar-Conce': [{ value: '', disabled: true }],
      'nombre-aux': [{ value: '', disabled: true }],
      'Precio-Faot': [{ value: '', disabled: true }],
      'Tipconcep-Faot': [''],
      'agrega-codcon': ['']
    });

    this.createDetallesForm = this.fb.group({
      'Otrocon': ['', [Validators.required]],
      'Nombre-Faot': ['', [Validators.required]],
      'Text-Faot': [''],
      'Naturaleza': ['', [Validators.required]],
      'Tipcan-Faot': [''],
      'Impuesto': [''],
      'nombre-impu': [''],
      'Cuenta-Conce': [''],
      'nombre-cta': [''],
      'Ubicacion-Conce': [''],
      'nombre-ubic': [''],
      'Centro-Conce': [''],
      'nombre-cen': [''],
      'Auxiliar-Conce': [''],
      'nombre-aux': [''],
      'Precio-Faot': [''],
      'Tipconcep-Faot': [''],
      'agrega-codcon': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.detallesForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.detallesForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.detallesForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.limpiarOtroConcecto();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.detallesForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.detallesForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.detallesForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
    this.limpiarOtroConcecto();
  }

  // ==================== MODAL DE OTROS CONCEPTOS ====================
  async buscarOtroConceso(): Promise<void> {
    const companiaId = this.detallesForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.fa5156Service.getCEFaotros(companiaId).toPromise();
      
      if (response?.dsRespuesta?.tfaotros && response.dsRespuesta.tfaotros.length > 0) {
        this.otrosConceptos.set(response.dsRespuesta.tfaotros);
        this.showOtroConceptoModal.set(true);
      } else {
        this.toastService.showWarning('No se encontraron otros conceptos para esta compañía');
      }
    } catch (error) {
      console.error('Error al buscar otros conceptos:', error);
      this.toastService.showError('Error al buscar otros conceptos');
    } finally {
      this.loadingState.set(false);
    }
  }

  closeOtroConceptoModal(): void {
    this.showOtroConceptoModal.set(false);
  }

  async onOtroConceptoSelected(concepto: OtroConceptoRecord): Promise<void> {
    const companiaId = this.detallesForm.get('cia')?.value;
    if (!companiaId) return;

    this.loadingState.set(true);
    try {
      const response = await this.fa5156Service.getCEFaotros(companiaId).toPromise();
      const conceptosActualizados = response?.dsRespuesta?.tfaotros || [];
      const conceptoActualizado = conceptosActualizados.find((c: OtroConceptoRecord) => c.Otrocon === concepto.Otrocon);

      if (conceptoActualizado) {
        this.otroConceptoSeleccionado.set(conceptoActualizado);
        this.cargarDatosOtroConceso(conceptoActualizado);
        this.isEditMode.set(true);
        this.toastService.showSuccess(`Concepto "${conceptoActualizado['Nombre-Faot']}" cargado`);
      }
    } catch (error) {
      console.error('Error al recargar otro concepto:', error);
      this.otroConceptoSeleccionado.set(concepto);
      this.cargarDatosOtroConceso(concepto);
      this.isEditMode.set(true);
    } finally {
      this.loadingState.set(false);
      this.closeOtroConceptoModal();
    }
  }

  async onOtroConceptoLeave(): Promise<void> {
    const companiaId = this.detallesForm.get('cia')?.value;
    const otroconValue = this.detallesForm.get('Otrocon')?.value;
    
    if (!companiaId || !otroconValue) {
      this.limpiarOtroConcecto();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.fa5156Service.getLeaveOtrocon(companiaId, otroconValue).toPromise();
      
      if (response?.dsRespuesta?.tfaotros && response.dsRespuesta.tfaotros.length > 0) {
        const concepto = response.dsRespuesta.tfaotros[0];
        this.otroConceptoSeleccionado.set(concepto);
        this.cargarDatosOtroConceso(concepto);
      } else {
        this.toastService.showError('Otro concepto no encontrado');
        this.limpiarOtroConcecto();
      }
    } catch (error) {
      console.error('Error al buscar otro concepto:', error);
      this.toastService.showError('Error al buscar el otro concepto');
      this.limpiarOtroConcecto();
    } finally {
      this.loadingState.set(false);
    }
  }

  private cargarDatosOtroConceso(concepto: OtroConceptoRecord): void {
    this.detallesForm.patchValue({
      'Otrocon': concepto.Otrocon,
      'Nombre-Faot': concepto['Nombre-Faot'],
      'Text-Faot': concepto['Text-Faot'],
      'Naturaleza': concepto.Naturaleza,
      'Tipcan-Faot': concepto['Tipcan-Faot'],
      'Impuesto': concepto.Impuesto,
      'nombre-impu': concepto['nombre-impu'],
      'Cuenta-Conce': concepto['Cuenta-Conce'],
      'nombre-cta': concepto['nombre-cta'],
      'Ubicacion-Conce': concepto['Ubicacion-Conce'],
      'nombre-ubic': concepto['nombre-ubic'],
      'Centro-Conce': concepto['Centro-Conce'],
      'nombre-cen': concepto['nombre-cen'],
      'Auxiliar-Conce': concepto['Auxiliar-Conce'],
      'nombre-aux': concepto['nombre-aux'],
      'Precio-Faot': concepto['Precio-Faot'],
      'Tipconcep-Faot': concepto['Tipconcep-Faot'],
      'agrega-codcon': concepto['agrega-codcon']
    });
  }

  private limpiarOtroConcecto(): void {
    this.otroConceptoSeleccionado.set(null);
    this.isEditMode.set(false);
    this.detallesForm.patchValue({
      'Otrocon': '',
      'Nombre-Faot': '',
      'Text-Faot': '',
      'Naturaleza': '',
      'Tipcan-Faot': '',
      'Impuesto': '',
      'nombre-impu': '',
      'Cuenta-Conce': '',
      'nombre-cta': '',
      'Ubicacion-Conce': '',
      'nombre-ubic': '',
      'Centro-Conce': '',
      'nombre-cen': '',
      'Auxiliar-Conce': '',
      'nombre-aux': '',
      'Precio-Faot': '',
      'Tipconcep-Faot': '',
      'agrega-codcon': ''
    });
    this.resetFieldVisibilities();
  }

  // ==================== LEAVE EVENTS PARA NATURALEZA ====================
  async onNaturalezaLeave(): Promise<void> {
    const companiaId = this.detallesForm.get('cia')?.value;
    const naturalezaValue = this.detallesForm.get('Naturaleza')?.value;
    
    if (!companiaId || !naturalezaValue) {
      this.resetFieldVisibilities();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.fa5156Service.getLeavenaturaleza(companiaId, naturalezaValue).toPromise();
      
      if (response?.dsRespuesta?.tnaturalezaFO && response.dsRespuesta.tnaturalezaFO.length > 0) {
        const naturaleza = response.dsRespuesta.tnaturalezaFO[0];
        this.naturalezaSeleccionada.set(naturaleza);
        
        // Controlar visibilidad de campos basado en True/False
        this.mostrarAuxiliar.set(naturaleza['Bool-Auxneg'] === true || naturaleza['Bool-Auxneg'] == 'true' || naturaleza['Bool-Auxneg'] == '1');
        this.mostrarCentroCosto.set(naturaleza['Bool-Centrales'] === true || naturaleza['Bool-Centrales'] == 'true' || naturaleza['Bool-Centrales'] == '1');
        this.mostrarUbicacion.set(naturaleza['Bool-Fact'] === true || naturaleza['Bool-Fact'] == 'true' || naturaleza['Bool-Fact'] == '1');
        this.mostrarImpuesto.set(naturaleza['Bool-Impuesto'] === true || naturaleza['Bool-Impuesto'] == 'true' || naturaleza['Bool-Impuesto'] == '1');
        this.mostrarPorcentDesc.set(naturaleza['Bool-PorcentDesc'] === true || naturaleza['Bool-PorcentDesc'] == 'true' || naturaleza['Bool-PorcentDesc'] == '1');
      }
    } catch (error) {
      console.error('Error al validar naturaleza:', error);
      this.resetFieldVisibilities();
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== LEAVE EVENTS PARA TIPO CANTIDAD ====================
  async onTipoCantidadLeave(): Promise<void> {
    const companiaId = this.detallesForm.get('cia')?.value;
    const tipcanValue = this.detallesForm.get('Tipcan-Faot')?.value;
    
    if (!companiaId || !tipcanValue) {
      this.mostrarPrecio.set(false);
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.fa5156Service.getLeavetipcanfaot(companiaId, tipcanValue).toPromise();
      
      if (response?.dsRespuesta?.ttipocantidadFO && response.dsRespuesta.ttipocantidadFO.length > 0) {
        const tipoCantidad = response.dsRespuesta.ttipocantidadFO[0];
        this.tipoCantidadSeleccionado.set(tipoCantidad);
        
        // Controlar visibilidad de campo Precio basado en Bool-Precio
        this.mostrarPrecio.set(tipoCantidad['Bool-Precio'] === true || tipoCantidad['Bool-Precio'] == 'true' || tipoCantidad['Bool-Precio'] == '1');
      }
    } catch (error) {
      console.error('Error al validar tipo cantidad:', error);
      this.mostrarPrecio.set(false);
    } finally {
      this.loadingState.set(false);
    }
  }

  private resetFieldVisibilities(): void {
    this.mostrarAuxiliar.set(false);
    this.mostrarCentroCosto.set(false);
    this.mostrarUbicacion.set(false);
    this.mostrarImpuesto.set(false);
    this.mostrarPorcentDesc.set(false);
    this.mostrarPrecio.set(false);
  }

  // ==================== ACCIONES CRUD ====================
  openCreateModal(): void {
    const companiaId = this.detallesForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    this.createDetallesForm.reset();
    this.isEditMode.set(false);
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
    this.createDetallesForm.reset();
  }

  async onCreateSubmit(): Promise<void> {
    if (this.createDetallesForm.invalid) {
      this.toastService.showError('Por favor complete los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const companiaId = this.detallesForm.get('cia')?.value;
      const nombreCompania = this.detallesForm.get('nombre-cia')?.value;
      const formData = this.createDetallesForm.value;
      const auth = this.ccService.getAuthParams();

      const payload = {
        tfaotros: [{
          'Agrega-Faot': '',
          Cia: companiaId,
          'nombre-cia': nombreCompania,
          Otrocon: formData['Otrocon'],
          'Nombre-Faot': formData['Nombre-Faot'],
          'Text-Faot': formData['Text-Faot'] || '',
          Naturaleza: formData['Naturaleza'],
          'Tipcan-Faot': formData['Tipcan-Faot'] || '',
          Impuesto: formData['Impuesto'] || 0,
          'nombre-impu': formData['nombre-impu'] || '',
          'Cuenta-Conce': formData['Cuenta-Conce'] || '',
          'nombre-cta': formData['nombre-cta'] || '',
          'Ubicacion-Conce': formData['Ubicacion-Conce'] || 0,
          'nombre-ubic': formData['nombre-ubic'] || '',
          'Centro-Conce': formData['Centro-Conce'] || 0,
          'nombre-cen': formData['nombre-cen'] || '',
          'Auxiliar-Conce': formData['Auxiliar-Conce'] || 0,
          'nombre-aux': formData['nombre-aux'] || '',
          'Precio-Faot': formData['Precio-Faot'] || 0,
          'Tipconcep-Faot': formData['Tipconcep-Faot'] || 0,
          'agrega-codcon': formData['agrega-codcon'] || 0,
          'nombre-conce': '',
          'Date-Ctrl': new Date().toISOString().split('T')[0],
          'Login-Ctrl': auth.pcLogin || 'user',
          tparent: auth.pcLogin || 'user'
        }]
      };

      console.log('🔄 Enviando creación:', payload);

      const response = await this.fa5156Service.updateFaotros(payload).toPromise();

      if (response?.dsRespuesta?.tfaotros && response.dsRespuesta.tfaotros.length > 0) {
        this.toastService.showSuccess('Otro concepto creado exitosamente');
        this.onClear();
        await this.cargarOtrosConceptos();
        this.cdr.detectChanges();
        this.closeCreateModal();
      }
    } catch (error) {
      console.error('Error al crear:', error);
      this.toastService.showError('Error al crear el otro concepto');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onSubmit(): Promise<void> {
    if (!this.detallesForm.get('cia')?.value || !this.detallesForm.get('Otrocon')?.value) {
      this.toastService.showError('Por favor complete todos los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const formData = this.detallesForm.getRawValue();
      const auth = this.ccService.getAuthParams();
      
      const payload = {
        tfaotros: [{
          'Agrega-Faot': '',
          Cia: formData.cia,
          'nombre-cia': formData['nombre-cia'],
          Otrocon: formData['Otrocon'],
          'Nombre-Faot': formData['Nombre-Faot'],
          'Text-Faot': formData['Text-Faot'] || '',
          Naturaleza: formData['Naturaleza'],
          'Tipcan-Faot': formData['Tipcan-Faot'] || '',
          Impuesto: formData['Impuesto'] || 0,
          'nombre-impu': formData['nombre-impu'] || '',
          'Cuenta-Conce': formData['Cuenta-Conce'] || '',
          'nombre-cta': formData['nombre-cta'] || '',
          'Ubicacion-Conce': formData['Ubicacion-Conce'] || 0,
          'nombre-ubic': formData['nombre-ubic'] || '',
          'Centro-Conce': formData['Centro-Conce'] || 0,
          'nombre-cen': formData['nombre-cen'] || '',
          'Auxiliar-Conce': formData['Auxiliar-Conce'] || 0,
          'nombre-aux': formData['nombre-aux'] || '',
          'Precio-Faot': formData['Precio-Faot'] || 0,
          'Tipconcep-Faot': formData['Tipconcep-Faot'] || 0,
          'agrega-codcon': formData['agrega-codcon'] || 0,
          'nombre-conce': '',
          'Date-Ctrl': new Date().toISOString().split('T')[0],
          'Login-Ctrl': auth.pcLogin || 'user',
          tparent: auth.pcLogin || 'user'
        }]
      };

      console.log('🔄 Enviando actualización:', payload);

      const response = await this.fa5156Service.updateFaotros(payload).toPromise();
      
      if (response?.dsRespuesta?.tfaotros && response.dsRespuesta.tfaotros.length > 0) {
        this.toastService.showSuccess('Concepto actualizado exitosamente');
        this.onClear();
        await this.cargarOtrosConceptos();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al guardar:', error);
      this.toastService.showError('Error al guardar el concepto');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onDelete(): Promise<void> {
    const companiaId = this.detallesForm.get('cia')?.value;
    const otroconId = this.detallesForm.get('Otrocon')?.value;

    if (!companiaId || !otroconId) {
      this.toastService.showError('Debe seleccionar una compañía y un concepto para eliminar');
      return;
    }

    const confirmed = confirm('¿Está seguro de eliminar este concepto?\nEsta acción no se puede deshacer');

    if (!confirmed) return;

    try {
      this.loadingState.set(true);
      const response = await this.fa5156Service.deleteFaotros(companiaId, otroconId).toPromise();
      
      if (response?.dsRespuesta?.tfaotros && response.dsRespuesta.tfaotros.length > 0) {
        this.toastService.showSuccess('Concepto eliminado exitosamente');
        this.onClear();
        await this.cargarOtrosConceptos();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al eliminar:', error);
      this.toastService.showError('Error al eliminar el concepto');
    } finally {
      this.loadingState.set(false);
    }
  }

  private async cargarOtrosConceptos(): Promise<void> {
    const companiaId = this.detallesForm.get('cia')?.value;
    
    if (!companiaId) {
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.fa5156Service.getCEFaotros(companiaId).toPromise();
      
      if (response?.dsRespuesta?.tfaotros && response.dsRespuesta.tfaotros.length > 0) {
        this.otrosConceptos.set(response.dsRespuesta.tfaotros);
        console.log('✅ Otros conceptos recargados');
      }
    } catch (error) {
      console.error('Error al recargar otros conceptos:', error);
    } finally {
      this.loadingState.set(false);
    }
  }

  onClear(): void {
    this.limpiarOtroConcecto();
    this.detallesForm.get('cia')?.markAsUntouched();
    this.detallesForm.get('Otrocon')?.markAsUntouched();
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }
}
