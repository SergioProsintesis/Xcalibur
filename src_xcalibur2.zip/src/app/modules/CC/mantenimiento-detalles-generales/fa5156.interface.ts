// Interface for FA5156 - Mantenimiento de Detalles Generales (Otros Conceptos)

export interface OtroConceptoRecord {
  'Agrega-Faot'?: string;
  'Auxiliar-Conce': number;
  'nombre-aux'?: string;
  'Centro-Conce': number;
  'nombre-cen'?: string;
  'Cia': number;
  'nombre-cia': string;
  'Cuenta-Conce': string;
  'nombre-cta': string;
  'Date-Ctrl'?: string;
  'Impuesto': number;
  'nombre-impu': string;
  'Login-Ctrl'?: string;
  'Naturaleza': string;
  'Nombre-Faot': string;
  'Otrocon': string;
  'Precio-Faot': number;
  'Text-Faot': string;
  'Tipcan-Faot': string;
  'Tipconcep-Faot': number;
  'agrega-codcon': number;
  'nombre-conce': string;
  'Ubicacion-Conce': number;
  'nombre-ubic'?: string;
  'tparent'?: string;
}

export interface CompaniaRecord {
  cia: number;
  'nombre-cia': string;
  nit?: string;
  [key: string]: any;
}

export interface NaturalezaRecord {
  'Cod-Naturaleza': string;
  'Descripcion': string;
  'Activa-Nat'?: boolean | string;
  'Bool-Fact'?: boolean | string;
  'Bool-Nota'?: boolean | string;
  'Bool-Auxneg'?: boolean | string;
  'Bool-Centrales'?: boolean | string;
  'Bool-Impuesto'?: boolean | string;
  'Bool-PorcentDesc'?: boolean | string;
  [key: string]: any;
}

export interface TipoCantidadRecord {
  'Cod-TipoCan': string;
  'Descripcion': string;
  'Activa-Tipcan'?: boolean | string;
  'Bool-Precio'?: boolean | string;
  [key: string]: any;
}

export interface ImuestoRecord {
  Impuesto: number;
  'nombre-impu': string;
  [key: string]: any;
}

export interface CuentaRecord {
  'Cuenta': string;
  'nombre-cta': string;
  [key: string]: any;
}

export interface UbicacionRecord {
  'ubicacion': number;
  'nombre-ubic'?: string;
  [key: string]: any;
}

export interface CentroRecord {
  'Centro': number;
  'nombre-cen'?: string;
  [key: string]: any;
}

export interface AuxiliarRecord {
  'auxiliar': number;
  'nombre-aux'?: string;
  [key: string]: any;
}

export interface ConceptoRecord {
  'agrega-codcon': number;
  'nombre-conce': string;
  [key: string]: any;
}

// Response interfaces
export interface OtroConceptoResponse {
  dsRespuesta: {
    tfaotros: OtroConceptoRecord[];
  };
}

export interface NaturalezaResponse {
  dsRespuesta: {
    tnaturalezaFO: NaturalezaRecord[];
  };
}

export interface TipoCantidadResponse {
  dsRespuesta: {
    ttipocantidadFO: TipoCantidadRecord[];
  };
}
