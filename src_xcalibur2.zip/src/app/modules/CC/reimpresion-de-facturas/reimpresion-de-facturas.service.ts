import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../core/services/auth.service';
import { CompaniasResponse, FacturasReimpresionResponse, CompaniaRecord, FacturaReimpresionRecord } from './reimpresion-de-facturas.interface';

@Injectable({
  providedIn: 'root'
})
export class ReimpresionDeFacturasService {
  constructor(private http: HttpClient, private auth: AuthService) {}

  /** Obtener parámetros de autenticación */
  private getAuthParams(): { pcLogin: string; pcSuper: string; pcToken: string } {
    const user = this.auth.user();
    return {
      pcLogin: user?.pcLogin || '',
      pcSuper: user?.pcSuper || '',
      pcToken: user?.pcToken || ''
    };
  }

  /** Obtener todas las compañías */
  getCompanias(): Observable<CompaniaRecord[]> {
    const { pcLogin, pcSuper, pcToken } = this.getAuthParams();
    const url = `${environment.apiUrl}/GetCECompanias?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<CompaniasResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tgecias || []),
      catchError(err => {
        console.error('Error getCompanias', err);
        return of([]);
      })
    );
  }

  /** Validar compañía específica (evento Leave) */
  getLeaveCompania(cia: number): Promise<CompaniasResponse> {
    const { pcLogin, pcSuper, pcToken } = this.getAuthParams();
    const url = `${environment.apiUrl}/GetLeaveGEcias?pcCompania=${cia}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return new Promise((resolve, reject) => {
      this.http.get<CompaniasResponse>(url)
        .pipe(
          catchError(err => {
            console.error('Error getLeaveCompania', err);
            reject(err);
            return of({} as CompaniasResponse);
          })
        )
        .subscribe(res => resolve(res));
    });
  }

  /** Obtener facturas disponibles para reimpresión */
  getFacturasDisponibles(cia: number): Promise<FacturaReimpresionRecord[]> {
    const { pcLogin, pcSuper, pcToken } = this.getAuthParams();
    const url = `${environment.apiUrl}/GetLeaveGEcias?pcCompania=${cia}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return new Promise((resolve, reject) => {
      this.http.get<FacturasReimpresionResponse>(url)
        .pipe(
          map(res => res?.dsRespuesta?.tfafact || []),
          catchError(err => {
            console.error('Error getFacturasDisponibles', err);
            reject(err);
            return of([]);
          })
        )
        .subscribe(res => resolve(res));
    });
  }

  /** Procesar reimpresión de facturas */
  procesarReimpresion(cia: number, facturas: string[], cantidadCopias: number): Promise<any> {
    const { pcLogin, pcSuper, pcToken } = this.getAuthParams();
    const url = `${environment.apiUrl}/ProcesarReimpresionFacturas`;

    const payload = {
      cia,
      facturas,
      cantidadCopias,
      pcLogin,
      pcSuper,
      pcToken
    };

    return new Promise((resolve, reject) => {
      this.http.post(url, payload)
        .pipe(
          catchError(err => {
            console.error('Error procesarReimpresion', err);
            reject(err);
            return of(null);
          })
        )
        .subscribe(res => resolve(res));
    });
  }
}
