export interface CompaniaRecord {
  cia: number;
  'nombre-cia': string;
}

export interface FacturaReimpresionRecord {
  'numero-fact': string;
  cia: number;
  'nombre-cia': string;
  'numero-cliente': string;
  'nombre-cliente': string;
  'fecha-fact': string;
  'valor-fact': number;
  'estado-fact': string;
  'cantidad-copias': number;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
}

export interface CompaniasResponse {
  dsRespuesta?: {
    tgecias: CompaniaRecord[];
  };
}

export interface FacturasReimpresionResponse {
  dsRespuesta?: {
    tfafact: FacturaReimpresionRecord[];
  };
}
