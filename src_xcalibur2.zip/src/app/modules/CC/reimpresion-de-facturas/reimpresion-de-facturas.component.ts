import { Component, inject, signal, OnInit, computed, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { ReimpresionDeFacturasService } from './reimpresion-de-facturas.service';
import { CompaniaRecord, FacturaReimpresionRecord } from './reimpresion-de-facturas.interface';

@Component({
  selector: 'app-reimpresion-de-facturas',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent],
  templateUrl: './reimpresion-de-facturas.component.html',
  styleUrls: ['./reimpresion-de-facturas.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ReimpresionDeFacturasComponent implements OnInit {
  private fb = inject(FormBuilder);
  private modalService = inject(ModalService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private service = inject(ReimpresionDeFacturasService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  reimpresionForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}FA5212 - Reimpresión de Facturas`);
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  facturasDisponibles = signal<FacturaReimpresionRecord[]>([]);
  facturasSeleccionadas = signal<string[]>([]);

  // Control de modales
  showCompaniaModal = signal(false);

  ngOnInit() {
    console.log('🔄 ReimpresionDeFacturasComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    console.log('✅ ReimpresionDeFacturasComponent inicializado correctamente');
  }

  private initializeForm(): void {
    this.reimpresionForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      'cantidad-copias': [1, [Validators.required, Validators.min(1), Validators.max(99)]]
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.reimpresionForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.reimpresionForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    if (errors['max']) return `Valor máximo: ${errors['max'].max}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.reimpresionForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.loadFacturasDisponibles();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.reimpresionForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.service.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.reimpresionForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
        this.loadFacturasDisponibles();
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.facturasDisponibles.set([]);
    this.facturasSeleccionadas.set([]);
    this.reimpresionForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
  }

  // ==================== CARGAR DATOS ====================
  private async loadFacturasDisponibles(): Promise<void> {
    const ciaValue = this.reimpresionForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.facturasDisponibles.set([]);
      return;
    }

    try {
      this.loadingState.set(true);
      const facturas = await this.service.getFacturasDisponibles(ciaValue);
      this.facturasDisponibles.set(facturas);
      this.facturasSeleccionadas.set([]);
    } catch (error) {
      console.error('Error al cargar facturas:', error);
      this.toastService.showError('Error al cargar las facturas disponibles');
      this.facturasDisponibles.set([]);
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  // ==================== SELECCIÓN DE FACTURAS ====================
  toggleFactura(numeroFactura: string): void {
    const seleccionadas = [...this.facturasSeleccionadas()];
    const index = seleccionadas.indexOf(numeroFactura);
    
    if (index > -1) {
      seleccionadas.splice(index, 1);
    } else {
      seleccionadas.push(numeroFactura);
    }
    
    this.facturasSeleccionadas.set(seleccionadas);
    this.cdr.markForCheck();
  }

  isFacturaSeleccionada(numeroFactura: string): boolean {
    return this.facturasSeleccionadas().includes(numeroFactura);
  }

  toggleTodas(): void {
    if (this.facturasSeleccionadas().length === this.facturasDisponibles().length) {
      this.facturasSeleccionadas.set([]);
    } else {
      this.facturasSeleccionadas.set(this.facturasDisponibles().map(f => f['numero-fact']));
    }
    this.cdr.markForCheck();
  }

  // ==================== ACCIONES ====================
  onLimpiar(): void {
    this.reimpresionForm.reset({ 'cantidad-copias': 1 });
    this.limpiarCompania();
    this.cdr.markForCheck();
  }

  onGenerarReimpresion(): void {
    if (this.reimpresionForm.invalid) {
      this.toastService.showError('Por favor, complete los campos requeridos');
      return;
    }

    if (this.facturasSeleccionadas().length === 0) {
      this.toastService.showError('Seleccione al menos una factura');
      return;
    }

    const ciaValue = this.reimpresionForm.get('cia')?.value;
    const cantidadCopias = this.reimpresionForm.get('cantidad-copias')?.value;

    this.procesarReimpresion(ciaValue, this.facturasSeleccionadas(), cantidadCopias);
  }

  private async procesarReimpresion(cia: number, facturas: string[], cantidadCopias: number): Promise<void> {
    try {
      this.loadingState.set(true);
      await this.service.procesarReimpresion(cia, facturas, cantidadCopias);
      this.toastService.showSuccess(`Reimpresión de ${facturas.length} factura(s) procesada correctamente`);
      this.onLimpiar();
    } catch (error) {
      console.error('Error al procesar reimpresión:', error);
      this.toastService.showError('Error al procesar la reimpresión');
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  onVolver(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }
}
