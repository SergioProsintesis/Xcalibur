export interface CargaCobranzaRecord {
  cia: number;
  'nombre-cia'?: string;
  'fec-periodo': string;
  'lote-his': string;
  't-debe'?: number;
  't-haber'?: number;
  empresa: string;
  'nombre-emp'?: string;
  numdoc: string;
  'nombre-doc'?: string;
  tipodoc: string;
  'desc-tdoc'?: string;
  'fec-pago': string;
  cobrador: string;
  'nombre-cobr'?: string;
  referencia: string;
  monto: number;
  'moneda': number;
  'monext': number;
  'd': string;
  'h': string;
  'c': string;
  recar: number;
  dcto: number;
  retencion: number;
  'agencia'?: number;
  'estado-his'?: string;
  'fecha-ing'?: string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CargaCobranzaGridRow {
  cliente: string;
  documento: string;
  'tipoDoc': string;
  monto: number;
  cDscto: string;
  descuento: number;
  montoExtranjero: number;
  cRecar: string;
  recargo: number;
  cReten: string;
  retencion: number;
  fechaPago: string;
  cobrado: boolean;
  recibo: string;
}

export interface CargaCobranzaResponse {
  dsRespuesta?: {
    tcchistorCob?: CargaCobranzaRecord[];
    tgecias?: any[];
    tccempres2?: any[];
    tccdocume?: any[];
    tcctipdoc?: any[];
    tcccobrad?: any[];
    terrores?: Array<{ descripcion: string }>;
  };
}
