import { Component, Input, Output, EventEmitter, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CCService } from '../../../../../core/services/cc.service';

@Component({
  selector: 'app-tipo-doc-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="modal-backdrop" *ngIf="show" (click)="onClose()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2 class="modal-title">Seleccionar Tipo de Documento</h2>
          <button type="button" class="close-btn" (click)="onClose()">&times;</button>
        </div>

        <div class="modal-body">
          <form class="search-form">
            <div class="search-field">
              <label class="field-label">Buscar por código o descripción</label>
              <input 
                type="text" 
                [(ngModel)]="searchTerm" 
                name="searchTerm"
                (input)="filterTiposDoc()" 
                class="search-input" 
                placeholder="Escriba para buscar...">
            </div>
          </form>

          <div class="grid-container" *ngIf="filteredTiposDoc.length > 0; else noResults">
            <div class="grid-header">
              <div class="header-cell">Código</div>
              <div class="header-cell">Descripción</div>
              <div class="header-cell">Acción</div>
            </div>
            <div class="grid-body">
              <div class="grid-row" *ngFor="let tipo of filteredTiposDoc; trackBy: trackByTipo">
                <div class="grid-cell">{{ tipo['cod-tipdo'] }}</div>
                <div class="grid-cell">{{ tipo['desc-tipdo'] }}</div>
                <div class="grid-cell">
                  <button type="button" class="select-btn" (click)="onSelectTipo(tipo)">
                    Seleccionar
                  </button>
                </div>
              </div>
            </div>
          </div>

          <ng-template #noResults>
            <div class="no-results" *ngIf="!isLoading">
              <p>No se encontraron tipos de documento</p>
            </div>
          </ng-template>

          <div class="loading-indicator" *ngIf="isLoading">
            <div class="spinner"></div>
            <span>Cargando tipos de documento...</span>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn-secondary" (click)="onClose()">Cancelar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .modal-content {
      background: white;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 700px;
      max-height: 80vh;
      display: flex;
      flex-direction: column;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .modal-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: #003087;
      margin: 0;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #6b7280;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .close-btn:hover {
      color: #374151;
    }

    .modal-body {
      padding: 1.5rem;
      overflow-y: auto;
      flex: 1;
    }

    .search-form {
      margin-bottom: 1.5rem;
    }

    .search-field {
      display: flex;
      flex-direction: column;
    }

    .field-label {
      font-weight: 500;
      color: #374151;
      margin-bottom: 0.5rem;
    }

    .search-input {
      border: 1px solid #d1d5db;
      border-radius: 6px;
      padding: 0.75rem;
      font-size: 1rem;
      transition: all 0.3s ease;
    }

    .search-input:focus {
      outline: none;
      border-color: #003087;
      box-shadow: 0 0 0 3px rgba(0, 48, 135, 0.1);
    }

    .grid-container {
      border: 1px solid #e5e7eb;
      border-radius: 6px;
      overflow: hidden;
    }

    .grid-header {
      display: grid;
      grid-template-columns: 1fr 2fr 1fr;
      background: #f3f4f6;
      border-bottom: 1px solid #d1d5db;
      font-weight: 600;
      color: #374151;
      position: sticky;
      top: 0;
      z-index: 1;
    }

    .header-cell {
      padding: 0.75rem;
      border-right: 1px solid #d1d5db;
    }

    .header-cell:last-child {
      border-right: none;
    }

    .grid-body {
      max-height: 400px;
      overflow-y: auto;
    }

    .grid-row {
      display: grid;
      grid-template-columns: 1fr 2fr 1fr;
      border-bottom: 1px solid #e5e7eb;
      align-items: center;
      transition: background-color 0.2s;
    }

    .grid-row:hover {
      background-color: #f9fafb;
    }

    .grid-cell {
      padding: 0.75rem;
      border-right: 1px solid #e5e7eb;
      font-size: 0.9rem;
      color: #374151;
    }

    .grid-cell:last-child {
      border-right: none;
    }

    .select-btn {
      background: #3b82f6;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 0.5rem 1rem;
      font-size: 0.85rem;
      cursor: pointer;
      transition: all 0.3s;
    }

    .select-btn:hover {
      background: #2563eb;
      transform: translateY(-1px);
    }

    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      padding: 1.5rem;
      border-top: 1px solid #e5e7eb;
      background: #f9fafb;
    }

    .btn-secondary {
      background: #6b7280;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 0.75rem 1.5rem;
      cursor: pointer;
      font-size: 1rem;
      transition: all 0.3s;
    }

    .btn-secondary:hover {
      background: #4b5563;
    }

    .no-results {
      text-align: center;
      padding: 2rem;
      color: #9ca3af;
    }

    .loading-indicator {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 1rem;
      padding: 2rem;
      color: #6b7280;
    }

    .spinner {
      width: 20px;
      height: 20px;
      border: 3px solid #e5e7eb;
      border-top-color: #3b82f6;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }
  `]
})
export class TipoDocModalComponent implements OnInit, OnChanges {
  @Input() show = false;
  @Input() companiaId: string = '';
  @Output() close = new EventEmitter<void>();
  @Output() tipoDocSelected = new EventEmitter<any>();

  tiposDoc: any[] = [];
  filteredTiposDoc: any[] = [];
  searchTerm = '';
  isLoading = false;

  constructor(private ccService: CCService) {}

  ngOnInit(): void {
    this.loadTiposDoc();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['show'] && changes['show'].currentValue && !changes['show'].previousValue) {
      this.loadTiposDoc();
    }
  }

  loadTiposDoc(): void {
    if (!this.companiaId) return;
    this.isLoading = true;
    this.ccService.getTiposDocCargaCobranza(this.companiaId).subscribe({
      next: (data: any[]) => {
        this.tiposDoc = data || [];
        this.filterTiposDoc();
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
        this.tiposDoc = [];
      }
    });
  }

  filterTiposDoc(): void {
    const term = this.searchTerm.toLowerCase();
    this.filteredTiposDoc = this.tiposDoc.filter(tipo =>
      (tipo['cod-tipdo']?.toString().toLowerCase().includes(term) ||
       tipo['desc-tipdo']?.toLowerCase().includes(term))
    );
  }

  onSelectTipo(tipo: any): void {
    this.tipoDocSelected.emit(tipo);
    this.onClose();
  }

  onClose(): void {
    this.close.emit();
  }

  trackByTipo(_index: number, tipo: any): any {
    return tipo['cod-tipdo'];
  }
}
