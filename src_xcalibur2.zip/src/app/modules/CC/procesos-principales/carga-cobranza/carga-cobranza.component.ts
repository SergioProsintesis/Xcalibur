import { Component, OnInit, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastService } from '../../../../core/services/toast.service';
import { LoadingService } from '../../../../core/services/loading.service';
import { CCService } from '../../../../core/services/cc.service';
import { AuthService } from '../../../../core/services/auth.service';
import { ProgramContextService } from '../../../../core/services/program-context.service';
import { CargaCobranzaRecord, CargaCobranzaResponse, CargaCobranzaGridRow } from './carga-cobranza.interface';
import { CompaniaModalComponent } from '../../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { EmpresaModalComponent } from './empresa-modal/empresa-modal.component';
import { TipoDocModalComponent } from './tipo-doc-modal/tipo-doc-modal.component';
import { DocumentoModalComponent } from './documento-modal/documento-modal.component';
import { CobradorModalComponent } from './cobrador-modal/cobrador-modal.component';

@Component({
  selector: 'app-carga-cobranza',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    CompaniaModalComponent,
    EmpresaModalComponent,
    TipoDocModalComponent,
    DocumentoModalComponent,
    CobradorModalComponent
  ],
  templateUrl: './carga-cobranza.component.html',
  styleUrls: ['./carga-cobranza.component.css']
})
export class CargaCobranzaComponent implements OnInit {
  private programContext = inject(ProgramContextService);
  
  cargaCobranzaForm: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Carga de Cobranza`);
  gridData: CargaCobranzaGridRow[] = [];
  
  private hasUnsavedChanges = false;

  // Estado para modales
  showCompaniaModal = false;
  showEmpresaModal = false;
  showDocumentoModal = false;
  showTipoDocModal = false;
  showCobradorModal = false;
  showRecarModal = false;
  showDctoModal = false;
  showRetencionModal = false;

  // Datos seleccionados
  selectedCompania: any = null;
  selectedEmpresa: any = null;
  selectedDocumento: any = null;
  selectedTipoDoc: any = null;
  selectedCobrador: any = null;

  public get loadingState() { 
    return this.loading.getLoadingState(); 
  }

  constructor(
    private fb: FormBuilder,
    private toastService: ToastService,
    private loading: LoadingService,
    private ccService: CCService,
    private router: Router
  ) {
    this.cargaCobranzaForm = this.fb.group({
      cia: [null, [Validators.required]],
      'nombre-cia': [{ value: '', disabled: true }],
      'fec-periodo': ['', [Validators.required]],
      'lote-his': ['', [Validators.required]],
      't-debe': [{ value: 0, disabled: true }],
      't-haber': [{ value: 0, disabled: true }],
      
      empresa: [null, [Validators.required]],
      'nombre-emp': [{ value: '', disabled: true }],
      numdoc: [null, [Validators.required]],
      'nombre-doc': [{ value: '', disabled: true }],
      tipodoc: [null, [Validators.required]],
      'desc-tdoc': [{ value: '', disabled: true }],
      
      'fec-pago': ['', [Validators.required]],
      cobrador: [null, [Validators.required]],
      'nombre-cobr': [{ value: '', disabled: true }],
      referencia: ['', [Validators.required]],
      
      monto: [0, [Validators.required, Validators.min(0)]],
      'moneda': [0],
      'monext': [{ value: 0, disabled: true }],
      
      'd': [''],
      'h': [''],
      'c': [''],
      
      recar: [0],
      dcto: [0],
      retencion: [0]
    });

    this.cargaCobranzaForm.valueChanges.subscribe(() => {
      this.hasUnsavedChanges = true;
    });
  }

  ngOnInit(): void {
    this.resetForm();
    this.setupLeaveValidation();
  }

  private setupLeaveValidation(): void {
    window.addEventListener('beforeunload', (event) => {
      if (this.hasUnsavedChanges) {
        event.preventDefault();
        event.returnValue = '';
      }
    });
  }

  resetForm(): void {
    this.cargaCobranzaForm.reset({
      cia: null,
      'nombre-cia': '',
      'fec-periodo': '',
      'lote-his': '',
      't-debe': 0,
      't-haber': 0,
      empresa: null,
      'nombre-emp': '',
      numdoc: null,
      'nombre-doc': '',
      tipodoc: null,
      'desc-tdoc': '',
      'fec-pago': '',
      cobrador: null,
      'nombre-cobr': '',
      referencia: '',
      monto: 0,
      'moneda': 0,
      'monext': 0,
      'd': '',
      'h': '',
      'c': '',
      recar: 0,
      dcto: 0,
      retencion: 0
    });
    
    this.selectedCompania = null;
    this.selectedEmpresa = null;
    this.selectedDocumento = null;
    this.selectedTipoDoc = null;
    this.selectedCobrador = null;
    this.gridData = [];
    this.hasUnsavedChanges = false;
  }

  // Modal handlers
  openCompaniaModal(): void {
    this.showCompaniaModal = true;
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal = false;
  }

  onCompaniaSelected(compania: any): void {
    this.selectedCompania = compania;
    this.cargaCobranzaForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.hasUnsavedChanges = true;
  }

  openEmpresaModal(): void {
    const companiaId = this.cargaCobranzaForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Seleccione primero una compañía');
      return;
    }
    this.showEmpresaModal = true;
  }

  closeEmpresaModal(): void {
    this.showEmpresaModal = false;
  }

  onEmpresaSelected(empresa: any): void {
    this.selectedEmpresa = empresa;
    this.cargaCobranzaForm.patchValue({
      empresa: empresa.empresa,
      'nombre-emp': empresa['nombre-emp']
    });
    this.closeEmpresaModal();
    this.hasUnsavedChanges = true;
  }

  openDocumentoModal(): void {
    const companiaId = this.cargaCobranzaForm.get('cia')?.value;
    const empresaId = this.cargaCobranzaForm.get('empresa')?.value;
    
    if (!companiaId || !empresaId) {
      this.toastService.showWarning('Seleccione primero compañía y empresa');
      return;
    }
    this.showDocumentoModal = true;
  }

  closeDocumentoModal(): void {
    this.showDocumentoModal = false;
  }

  onDocumentoSelected(documento: any): void {
    this.selectedDocumento = documento;
    this.cargaCobranzaForm.patchValue({
      numdoc: documento.numdoc,
      'nombre-doc': documento['nombre-doc']
    });
    this.closeDocumentoModal();
    this.hasUnsavedChanges = true;
  }

  openTipoDocModal(): void {
    const companiaId = this.cargaCobranzaForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Seleccione primero una compañía');
      return;
    }
    this.showTipoDocModal = true;
  }

  closeTipoDocModal(): void {
    this.showTipoDocModal = false;
  }

  onTipoDocSelected(tipoDoc: any): void {
    this.selectedTipoDoc = tipoDoc;
    this.cargaCobranzaForm.patchValue({
      tipodoc: tipoDoc.tipodoc,
      'desc-tdoc': tipoDoc['desc-tdoc']
    });
    this.closeTipoDocModal();
    this.hasUnsavedChanges = true;
  }

  openCobradorModal(): void {
    const companiaId = this.cargaCobranzaForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Seleccione primero una compañía');
      return;
    }
    this.showCobradorModal = true;
  }

  closeCobradorModal(): void {
    this.showCobradorModal = false;
  }

  onCobradorSelected(cobrador: any): void {
    this.selectedCobrador = cobrador;
    this.cargaCobranzaForm.patchValue({
      cobrador: cobrador.cobrador,
      'nombre-cobr': cobrador['nombre-cobr']
    });
    this.closeCobradorModal();
    this.hasUnsavedChanges = true;
  }

  // Modal handlers for recargo, descuento, retención
  openRecarModal(): void {
    this.showRecarModal = true;
  }

  closeRecarModal(): void {
    this.showRecarModal = false;
  }

  openDctoModal(): void {
    this.showDctoModal = true;
  }

  closeDctoModal(): void {
    this.showDctoModal = false;
  }

  openRetencionModal(): void {
    this.showRetencionModal = true;
  }

  closeRetencionModal(): void {
    this.showRetencionModal = false;
  }

  // Cargar lote
  onLoteChange(): void {
    const companiaId = this.cargaCobranzaForm.get('cia')?.value;
    const fechaPeriodo = this.cargaCobranzaForm.get('fec-periodo')?.value;
    const lote = this.cargaCobranzaForm.get('lote-his')?.value;
    
    if (companiaId && fechaPeriodo && lote) {
      this.loading.show('Cargando lote...');
      this.ccService.getLoteCargaCobranza(companiaId.toString(), fechaPeriodo, lote).subscribe({
        next: (result: any) => {
          this.loading.hide();
          if (result && result.dsRespuesta?.tcchistorCob) {
            this.loadLoteData(result.dsRespuesta.tcchistorCob);
          }
        },
        error: () => {
          this.loading.hide();
          this.toastService.showError('Error al cargar el lote');
        }
      });
    }
  }

  private loadLoteData(records: CargaCobranzaRecord[]): void {
    if (records.length > 0) {
      const firstRecord = records[0];
      this.cargaCobranzaForm.patchValue({
        't-debe': this.calculateTotalDebe(records),
        't-haber': this.calculateTotalHaber(records)
      });
      
      this.gridData = records.map(r => ({
        cliente: r['nombre-emp'] || '',
        documento: r.numdoc.toString(),
        tipoDoc: r['desc-tdoc'] || '',
        monto: r.monto,
        cDscto: r.dcto.toString(),
        descuento: r.dcto,
        montoExtranjero: r.monext,
        cRecar: r.recar.toString(),
        recargo: r.recar,
        cReten: r.retencion.toString(),
        retencion: r.retencion,
        fechaPago: r['fec-pago'],
        cobrado: r['estado-his'] === 'C',
        recibo: r.referencia
      }));
    }
  }

  private calculateTotalDebe(records: CargaCobranzaRecord[]): number {
    return records.reduce((sum, r) => sum + (r.monto || 0), 0);
  }

  private calculateTotalHaber(records: CargaCobranzaRecord[]): number {
    return records.reduce((sum, r) => sum + (r.monext || 0), 0);
  }

  // CRUD operations
  nuevo(): void {
    this.resetForm();
    this.toastService.showInfo('Formulario limpio para nuevo registro');
  }

  guardar(): void {
    if (this.cargaCobranzaForm.invalid) {
      this.toastService.showWarning('Complete los campos requeridos');
      this.cargaCobranzaForm.markAllAsTouched();
      return;
    }

    const formValue = this.cargaCobranzaForm.value;
    const data: CargaCobranzaRecord = {
      cia: formValue.cia,
      'nombre-cia': formValue['nombre-cia'],
      'fec-periodo': formValue['fec-periodo'],
      'lote-his': formValue['lote-his'],
      empresa: formValue.empresa,
      'nombre-emp': formValue['nombre-emp'],
      numdoc: formValue.numdoc,
      'nombre-doc': formValue['nombre-doc'],
      tipodoc: formValue.tipodoc,
      'desc-tdoc': formValue['desc-tdoc'],
      'fec-pago': formValue['fec-pago'],
      cobrador: formValue.cobrador,
      'nombre-cobr': formValue['nombre-cobr'],
      referencia: formValue.referencia,
      monto: formValue.monto,
      moneda: formValue.moneda,
      monext: formValue.monext,
      'd': formValue.d,
      'h': formValue.h,
      'c': formValue.c,
      recar: formValue.recar,
      dcto: formValue.dcto,
      retencion: formValue.retencion
    };

    this.loading.show('Guardando carga de cobranza...');
    this.ccService.saveCargaCobranza(data).subscribe({
      next: (result: any) => {
        this.loading.hide();
        const mensaje = result?.dsRespuesta?.terrores?.[0]?.descripcion || 
                       'Carga de cobranza guardada exitosamente';
        this.toastService.showSuccess(mensaje);
        this.hasUnsavedChanges = false;
      },
      error: () => {
        this.loading.hide();
        this.toastService.showError('Error al guardar carga de cobranza');
      }
    });
  }

  eliminar(): void {
    const companiaId = this.cargaCobranzaForm.get('cia')?.value;
    const lote = this.cargaCobranzaForm.get('lote-his')?.value;
    
    if (!companiaId || !lote) {
      this.toastService.showWarning('Seleccione compañía y lote');
      return;
    }

    if (confirm('¿Está seguro de eliminar este lote?')) {
      this.loading.show('Eliminando lote...');
      this.ccService.deleteLoteCargaCobranza(companiaId.toString(), lote).subscribe({
        next: () => {
          this.loading.hide();
          this.toastService.showSuccess('Lote eliminado exitosamente');
          this.resetForm();
        },
        error: () => {
          this.loading.hide();
          this.toastService.showError('Error al eliminar el lote');
        }
      });
    }
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.cargaCobranzaForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getFieldError(fieldName: string): string {
    const field = this.cargaCobranzaForm.get(fieldName);
    if (field?.errors) {
      if (field.errors['required']) return 'Este campo es requerido';
      if (field.errors['min']) return `Valor mínimo es 0`;
    }
    return '';
  }

  goBack(): void {
    if (this.hasUnsavedChanges) {
      if (confirm('Tiene cambios sin guardar. ¿Desea salir sin guardar?')) {
        this.hasUnsavedChanges = false;
        this.router.navigate(['/dashboard']);
      }
    } else {
      this.router.navigate(['/dashboard']);
    }
  }

  trackByGrid(index: number, item: CargaCobranzaGridRow): string {
    return item.documento + item.cliente;
  }
}
