import { Component, OnInit, OnDestroy, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators, FormsModule } from '@angular/forms';
import { Subject, debounceTime, distinctUntilChanged } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CCService } from '../../../../core/services/cc.service';
import { LoadingService } from '../../../../core/services/loading.service';
import { ToastService } from '../../../../core/services/toast.service';
import { ProgramContextService } from '../../../../core/services/program-context.service';
import { AuditoriaCorreoRecord, CC5062Response, CC5062ReportResponse } from './auditoria-correos-facturacion.interface';
import { CompaniaModalComponent } from '../../../CC/reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { CompaniaRecord } from '../../../../core/interfaces/cc.interface';

@Component({
  selector: 'app-auditoria-correos-facturacion',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, CompaniaModalComponent],
  templateUrl: './auditoria-correos-facturacion.component.html',
  styleUrls: ['./auditoria-correos-facturacion.component.css']
})
export class AuditoriaCorreosFacturacionComponent implements OnInit, OnDestroy {
  private programContext = inject(ProgramContextService);
  
  form!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}AUDITORÍA CORREOS FACTURACIÓN ELECTRÓNICA`);
  private destroy$ = new Subject<void>();
  
  // Signals
  showCompaniaModal = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  isGeneratingReport = signal(false);
  registros = signal<AuditoriaCorreoRecord[]>([]);

  constructor(
    private fb: FormBuilder,
    private ccService: CCService,
    private loadingService: LoadingService,
    private toastService: ToastService
  ) {
    this.initForm();
  }

  ngOnInit(): void {
    // Fecha por defecto: hoy
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    this.form.patchValue({ 'fecha-desde': `${yyyy}-${mm}-${dd}` });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private initForm(): void {
    this.form = this.fb.group({
      'cia-codigo': ['', Validators.required],
      'cia-nombre': ['', Validators.required],
      'fecha-desde': ['', Validators.required],
      'email': ['']
    });
  }

  private validateCompania(codigo: string) {
    this.ccService.validateCompania(codigo).subscribe(compania => {
      if (compania) {
        this.selectedCompania.set(compania);
        const ctrl = this.form.get('cia-codigo');
        if (ctrl?.hasError('notFound')) {
          const errors = { ...(ctrl.errors || {}) };
          delete errors['notFound'];
          ctrl.setErrors(Object.keys(errors).length ? errors : null);
        }
      } else {
        this.selectedCompania.set(null);
        this.form.get('cia-codigo')?.setErrors({ notFound: true });
      }
    });
  }

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.selectedCompania.set(compania);
    this.form.patchValue({ 
      'cia-codigo': compania.cia.toString(),
      'cia-nombre': compania['nombre-cia'],
      'email': compania['telex-cia'] || ''
    });
    this.showCompaniaModal.set(false);
    this.validateCompania(compania.cia.toString());
  }

  onCloseModal(): void {
    this.showCompaniaModal.set(false);
  }

  onGenerarReporte(formato: 'csv' | 'pantalla'): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.toastService.showWarning('Complete todos los campos obligatorios');
      return;
    }

    const compania = this.form.get('cia-codigo')?.value;
    const fechaDesde = this.form.get('fecha-desde')?.value;
    const email = this.form.get('email')?.value;
    
    this.isGeneratingReport.set(true);
    this.loadingService.show('Generando reporte...');
    
    this.ccService.getCC5062Report(compania, fechaDesde, email)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: CC5062ReportResponse) => {
          this.isGeneratingReport.set(false);
          this.loadingService.hide();
          
          if (response && response.response) {
            this.handleReporteGenerated(response.response, formato);
          } else {
            this.toastService.showError('No se pudo generar el reporte');
          }
        },
        error: (err) => {
          this.isGeneratingReport.set(false);
          this.loadingService.hide();
          console.error('Error generando reporte:', err);
          this.toastService.showError('Error al generar el reporte');
        }
      });
  }

  private handleReporteGenerated(response: CC5062ReportResponse['response'], formato: 'csv' | 'pantalla'): void {
    console.log('🎯 Respuesta completa recibida:', {
      csvExists: !!response.pcArchCSV,
      csvLength: response.pcArchCSV?.length || 0,
      csvStart: response.pcArchCSV?.substring(0, 50) || 'N/A'
    });
    
    if (!response.pcArchCSV) {
      this.toastService.showError('No se pudo obtener los datos del reporte');
      return;
    }

    switch (formato) {
      case 'csv':
        console.log('📊 Descargando CSV');
        this.downloadCSVFile(response.pcArchCSV);
        break;
      case 'pantalla':
        console.log('🖥️ Mostrando en pantalla');
        this.showReportInScreen(response.pcArchCSV);
        break;
    }
    
    this.toastService.showSuccess(`Reporte ${formato === 'pantalla' ? 'mostrado' : 'descargado'} exitosamente`);
  }

  private downloadCSVFile(content: string): void {
    try {
      const csvContent = this.isBase64(content) ? atob(content) : content;
      const bom = '\uFEFF';
      const blob = new Blob([bom + csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      
      link.setAttribute('href', url);
      link.setAttribute('download', `auditoria-correos-${new Date().getTime()}.csv`);
      link.style.visibility = 'hidden';
      
      document.body.appendChild(link);
      setTimeout(() => {
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }, 100);
    } catch (error) {
      console.error('Error al descargar CSV:', error);
      this.toastService.showError('Error al descargar el archivo');
    }
  }

  private showReportInScreen(content: string): void {
    try {
      // Procesar contenido
      let csvData: string;
      if (this.isBase64(content)) {
        csvData = atob(content);
      } else {
        csvData = content;
      }

      // Convertir a formato estructurado
      const processedData = this.convertToCsvWithSemicolons(csvData);
      const lines = processedData.split('\n').filter(line => line.trim());
      
      if (lines.length === 0) {
        this.toastService.showWarning('No hay datos para mostrar');
        return;
      }

      const headers = lines[0].split(';').map(h => h.trim());
      const rows = lines.slice(1).map(line => line.split(';').map(cell => cell.trim()));

      // Abrir ventana nueva con tabla interactiva
      const newWindow = window.open('', '_blank', 'width=1200,height=800');
      if (newWindow) {
        newWindow.document.write(this.generateInteractiveTableHTML(headers, rows));
        newWindow.document.close();
      }
    } catch (error) {
      console.error('Error mostrando reporte en pantalla:', error);
      this.toastService.showError('Error al procesar los datos para visualización');
    }
  }

  private generateInteractiveTableHTML(headers: string[], rows: string[][]): string {
    const compania = this.selectedCompania()?.["nombre-cia"] || this.form.get('cia-codigo')?.value || '';
    const fecha = this.form.get('fecha-desde')?.value || '';
    
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Auditoría Correos Facturación</title>
        <style>
          * { box-sizing: border-box; }
          body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            margin: 0; 
            padding: 20px; 
            background-color: #f5f5f5;
          }
          
          .container { 
            background: white; 
            border-radius: 8px; 
            padding: 20px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
          }
          
          .header { 
            text-align: center; 
            margin-bottom: 20px; 
            padding-bottom: 15px;
            border-bottom: 2px solid #003087;
          }
          
          .header h1 { 
            color: #003087; 
            margin: 0; 
            font-size: 1.8rem;
          }
          
          .report-info { 
            display: flex; 
            justify-content: space-between; 
            margin: 15px 0; 
            font-size: 0.9rem; 
            color: #666;
          }
          
          .controls { 
            margin: 20px 0; 
            display: flex; 
            gap: 15px; 
            align-items: center; 
            flex-wrap: wrap;
          }
          
          .search-box { 
            flex: 1; 
            min-width: 200px; 
            padding: 8px 12px; 
            border: 1px solid #ddd; 
            border-radius: 4px; 
            font-size: 14px;
          }
          
          .pagination { 
            display: flex; 
            gap: 5px; 
            align-items: center;
          }
          
          .pagination button { 
            padding: 6px 12px; 
            border: 1px solid #ddd; 
            background: white; 
            cursor: pointer; 
            border-radius: 4px;
          }
          
          .pagination button:hover { background: #f0f0f0; }
          .pagination button:disabled { opacity: 0.5; cursor: not-allowed; }
          .pagination button.active { background: #003087; color: white; }
          
          .table-container { 
            overflow-x: auto; 
            border: 1px solid #ddd; 
            border-radius: 4px;
          }
          
          table { 
            width: 100%; 
            border-collapse: collapse; 
            font-size: 13px;
          }
          
          th { 
            background: #003087; 
            color: white; 
            padding: 12px 8px; 
            text-align: left; 
            font-weight: 600; 
            position: sticky; 
            top: 0; 
            z-index: 10;
            cursor: pointer;
            user-select: none;
          }
          
          th:hover { background: #002066; }
          
          td { 
            padding: 8px; 
            border-bottom: 1px solid #eee;
          }
          
          tbody tr:hover { background: #f8f9fa; }
          tbody tr:nth-child(even) { background: #fafbfc; }
          tbody tr:nth-child(even):hover { background: #f0f1f2; }
          
          .stats { 
            margin: 15px 0; 
            padding: 10px; 
            background: #f8f9fa; 
            border-radius: 4px; 
            font-size: 14px;
          }
          
          .no-results { 
            text-align: center; 
            padding: 40px; 
            color: #666; 
            font-style: italic;
          }
          
          .sort-indicator { 
            margin-left: 5px; 
            opacity: 0.6;
          }
          
          @media (max-width: 768px) {
            .controls { flex-direction: column; align-items: stretch; }
            .search-box { min-width: auto; }
            th, td { padding: 6px 4px; font-size: 12px; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Auditoría Correos Facturación Electrónica</h1>
            <div class="report-info">
              <span><strong>Compañía:</strong> ${compania}</span>
              <span><strong>Fecha:</strong> ${fecha}</span>
              <span><strong>Generado:</strong> ${new Date().toLocaleString()}</span>
            </div>
          </div>
          
          <div class="controls">
            <input type="text" id="searchBox" class="search-box" placeholder="Buscar en todos los campos...">
            <div class="pagination" id="pagination"></div>
          </div>
          
          <div class="stats" id="stats"></div>
          
          <div class="table-container">
            <table id="dataTable">
              <thead>
                <tr>
                  ${headers.map((header, index) => 
                    `<th onclick="sortTable(${index})" title="Hacer clic para ordenar">
                      ${header}
                      <span class="sort-indicator" id="sort-${index}">↕️</span>
                     </th>`
                  ).join('')}
                </tr>
              </thead>
              <tbody id="tableBody">
              </tbody>
            </table>
            <div class="no-results" id="noResults" style="display: none;">
              No se encontraron resultados para la búsqueda actual
            </div>
          </div>
        </div>
        
        <script>
          const originalData = ${JSON.stringify(rows)};
          let currentData = [...originalData];
          let currentPage = 1;
          const rowsPerPage = 50;
          let sortColumn = -1;
          let sortDirection = 'asc';
          
          function renderTable() {
            const tbody = document.getElementById('tableBody');
            const start = (currentPage - 1) * rowsPerPage;
            const end = start + rowsPerPage;
            const pageData = currentData.slice(start, end);
            
            if (pageData.length === 0 && currentData.length > 0) {
              currentPage = 1;
              renderTable();
              return;
            }
            
            tbody.innerHTML = pageData.map(row => 
              '<tr>' + row.map(cell => '<td>' + (cell || '') + '</td>').join('') + '</tr>'
            ).join('');
            
            updateStats();
            updatePagination();
            
            document.getElementById('noResults').style.display = 
              currentData.length === 0 ? 'block' : 'none';
            document.querySelector('.table-container table').style.display = 
              currentData.length === 0 ? 'none' : 'table';
          }
          
          function updateStats() {
            const stats = document.getElementById('stats');
            const total = currentData.length;
            const showing = Math.min(rowsPerPage, total - (currentPage - 1) * rowsPerPage);
            const from = total > 0 ? (currentPage - 1) * rowsPerPage + 1 : 0;
            const to = (currentPage - 1) * rowsPerPage + showing;
            
            stats.textContent = 'Mostrando ' + from + ' a ' + to + ' de ' + total + ' registros';
            if (total !== originalData.length) {
              stats.textContent += ' (filtrado de ' + originalData.length + ' registros totales)';
            }
          }
          
          function updatePagination() {
            const pagination = document.getElementById('pagination');
            const totalPages = Math.ceil(currentData.length / rowsPerPage);
            
            if (totalPages <= 1) {
              pagination.innerHTML = '';
              return;
            }
            
            let html = '';
            html += '<button onclick="goToPage(1)" ' + (currentPage === 1 ? 'disabled' : '') + '>« Primera</button>';
            html += '<button onclick="goToPage(' + (currentPage - 1) + ')" ' + (currentPage === 1 ? 'disabled' : '') + '>‹ Anterior</button>';
            
            let startPage = Math.max(1, currentPage - 2);
            let endPage = Math.min(totalPages, currentPage + 2);
            
            if (startPage > 1) {
              html += '<button onclick="goToPage(1)">1</button>';
              if (startPage > 2) html += '<span>...</span>';
            }
            
            for (let i = startPage; i <= endPage; i++) {
              html += '<button onclick="goToPage(' + i + ')" ' + 
                     (i === currentPage ? 'class="active"' : '') + '>' + i + '</button>';
            }
            
            if (endPage < totalPages) {
              if (endPage < totalPages - 1) html += '<span>...</span>';
              html += '<button onclick="goToPage(' + totalPages + ')">' + totalPages + '</button>';
            }
            
            html += '<button onclick="goToPage(' + (currentPage + 1) + ')" ' + (currentPage === totalPages ? 'disabled' : '') + '>Siguiente ›</button>';
            html += '<button onclick="goToPage(' + totalPages + ')" ' + (currentPage === totalPages ? 'disabled' : '') + '>Última »</button>';
            
            pagination.innerHTML = html;
          }
          
          function goToPage(page) {
            const totalPages = Math.ceil(currentData.length / rowsPerPage);
            if (page >= 1 && page <= totalPages) {
              currentPage = page;
              renderTable();
            }
          }
          
          function filterData() {
            const searchTerm = document.getElementById('searchBox').value.toLowerCase();
            currentData = originalData.filter(row => 
              row.some(cell => cell.toLowerCase().includes(searchTerm))
            );
            currentPage = 1;
            renderTable();
          }
          
          function sortTable(columnIndex) {
            if (sortColumn === columnIndex) {
              sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
            } else {
              sortColumn = columnIndex;
              sortDirection = 'asc';
            }
            
            currentData.sort((a, b) => {
              const aVal = a[columnIndex] || '';
              const bVal = b[columnIndex] || '';
              
              const aNum = parseFloat(aVal.replace(/[^0-9.-]/g, ''));
              const bNum = parseFloat(bVal.replace(/[^0-9.-]/g, ''));
              
              let result;
              if (!isNaN(aNum) && !isNaN(bNum)) {
                result = aNum - bNum;
              } else {
                result = aVal.localeCompare(bVal);
              }
              
              return sortDirection === 'asc' ? result : -result;
            });
            
            // Update sort indicators
            document.querySelectorAll('.sort-indicator').forEach(el => el.textContent = '↕️');
            document.getElementById('sort-' + columnIndex).textContent = 
              sortDirection === 'asc' ? '↑' : '↓';
            
            currentPage = 1;
            renderTable();
          }
          
          // Event listeners
          document.getElementById('searchBox').addEventListener('input', filterData);
          
          // Initialize table
          renderTable();
        </script>
      </body>
      </html>
    `;
  }

  private isBase64(str: string): boolean {
    try {
      return /^[A-Za-z0-9+/=]+$/.test(str) && str.length % 4 === 0;
    } catch {
      return false;
    }
  }

  private convertToCsvWithSemicolons(content: string): string {
    // Si ya tiene punto y coma, retornar como está
    if (content.includes(';')) {
      return content;
    }
    
    // Convertir comas a punto y coma (si es necesario)
    // Detectar delimitador: si tiene muchas comas probablemente sea CSV
    const lines = content.split('\n');
    if (lines.length === 0) return content;
    
    const firstLine = lines[0];
    const commaCount = (firstLine.match(/,/g) || []).length;
    const semicolonCount = (firstLine.match(/;/g) || []).length;
    
    // Si hay más comas que puntos y coma, convertir comas a punto y coma
    if (commaCount > semicolonCount && commaCount > 0) {
      return lines.map(line => {
        // Evitar convertir comas dentro de comillas
        let inQuotes = false;
        let result = '';
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          if (char === '"') {
            inQuotes = !inQuotes;
          }
          if (char === ',' && !inQuotes) {
            result += ';';
          } else {
            result += char;
          }
        }
        return result;
      }).join('\n');
    }
    
    return content;
  }

  onClear(): void {
    this.form.reset();
    this.selectedCompania.set(null);
    this.registros.set([]);
  }

  goBack(): void {
    window.history.back();
  }

  isInvalid(field: string): boolean {
    const control = this.form.get(field);
    return !!(control && control.invalid && (control.dirty || control.touched));
  }

  getErrorMessage(field: string): string {
    const control = this.form.get(field);
    if (control?.hasError('required')) {
      return `${field} es obligatorio`;
    }
    if (control?.hasError('notFound')) {
      return 'Compañía no encontrada';
    }
    return 'Campo inválido';
  }
}

