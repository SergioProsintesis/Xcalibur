export interface EmpresaData {
  Agrega_Cias: string;
  cia: number;
  ClaveResolucion: string;
  date_ctrl: string;
  direc_cia: string;
  DS_BRANCH_ID: string;
  DS_ClaveResolucion: number;
  DS_FechaFinResolucion: string;
  DS_FechaIniResolucion: string;
  DS_MatMercantil: string;
  DS_NroResolucionDian: string;
  DS_Prefijo: string;
  DS_RangoFinResolucion: number;
  DS_RangoIniResolucion: number;
  fax_cia: string;
  FechaFinResolucion: string;
  FechaIniResolucion: string;
  login_ctrl: string;
  MatMercantil: string;
  nit: string;
  nombre_cia: string;
  nomrep_cia: string;
  NroResolucionDian: string;
  ObserParametros: string;
  Prefijo01: string;
  Prefijo02: string;
  Prefijo03: string;
  RangoFinResolucion: number;
  RangoIniResolucion: number;
  Resolucion01: string;
  Resolucion03: string;
  Resolucion04: string;
  Resolucion05: string;
  rif_cia: string;
  RutaFormatos: string;
  telefo_cia: string;
  telex_cia: string;
  text_cia: string;
  zonpos_cia: string;
  fecperi_his: string | null;
  fecmov_his: string | null;
  cuadre: boolean;
  tparent: string;
}

export interface AuditoriaCorreoRecord {
  cia: number;
  nombreCompania: string;
  nitCompania: string;
  email: string;
  fechaUltima: string;
}

export interface CC5062Response {
  dsRespuesta: {
    tgecias: EmpresaData[];
  };
}

export interface CC5062ReportResponse {
  response: {
    pcArchCSV: string;
    pcArchPDF?: string;
  };
}
