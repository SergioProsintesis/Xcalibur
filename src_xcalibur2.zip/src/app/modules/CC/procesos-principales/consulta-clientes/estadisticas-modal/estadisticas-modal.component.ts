import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-estadisticas-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="modal-overlay" *ngIf="show" (click)="closeModal()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2 class="modal-title">Estadísticas del Cliente</h2>
          <button type="button" class="close-button" (click)="closeModal()">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
          </button>
        </div>

        <div class="modal-body">
          <div *ngIf="estadisticasData; else noData" class="estadisticas-container">
            
            <!-- Información General -->
            <div class="info-section">
              <h3 class="section-title">Información General</h3>
              <div class="info-grid">
                <div class="info-item">
                  <span class="label">Cliente:</span>
                  <span class="value">{{ estadisticasData['nombre-emp'] }}</span>
                </div>
                <div class="info-item">
                  <span class="label">Año Ejercicio:</span>
                  <span class="value">{{ estadisticasData['ejerci-est'] }}</span>
                </div>
                <div class="info-item">
                  <span class="label">Última Compra:</span>
                  <span class="value">{{ estadisticasData['fecultcom-est'] | date: 'yyyy-MM-dd' }}</span>
                </div>
                <div class="info-item">
                  <span class="label">Última Pago:</span>
                  <span class="value">{{ estadisticasData['fecultpag-est'] | date: 'yyyy-MM-dd' }}</span>
                </div>
                <div class="info-item">
                  <span class="label">Límite Crédito:</span>
                  <span class="value">{{ estadisticasData['Limite-Est'] | number: '1.2-2' }}</span>
                </div>
                <div class="info-item">
                  <span class="label">Días Mora:</span>
                  <span class="value">{{ estadisticasData['diamor-est'] }}</span>
                </div>
              </div>
            </div>

            <!-- Resumen de Ventas -->
            <div class="info-section">
              <h3 class="section-title">Resumen de Ventas</h3>
              <div class="info-grid">
                <div class="info-item">
                  <span class="label">Total Ventas Mes:</span>
                  <span class="value">{{ estadisticasData['total-ventas'] | number: '1.2-2' }}</span>
                </div>
                <div class="info-item">
                  <span class="label">Cantidad Ventas:</span>
                  <span class="value">{{ estadisticasData['total-cantventas'] }}</span>
                </div>
                <div class="info-item">
                  <span class="label">Total Ventas Anteriores:</span>
                  <span class="value">{{ estadisticasData['total-ventasAnt'] | number: '1.2-2' }}</span>
                </div>
                <div class="info-item">
                  <span class="label">Cantidad Ventas Anteriores:</span>
                  <span class="value">{{ estadisticasData['total-cantventasAnt'] }}</span>
                </div>
              </div>
            </div>

            <!-- Resumen de Cobros -->
            <div class="info-section">
              <h3 class="section-title">Resumen de Cobros</h3>
              <div class="info-grid">
                <div class="info-item">
                  <span class="label">Total Cobros Mes:</span>
                  <span class="value">{{ estadisticasData['total-cobros'] | number: '1.2-2' }}</span>
                </div>
                <div class="info-item">
                  <span class="label">Cantidad Cobros:</span>
                  <span class="value">{{ estadisticasData['total-cantcobros'] }}</span>
                </div>
                <div class="info-item">
                  <span class="label">Total Cobros Anteriores:</span>
                  <span class="value">{{ estadisticasData['total-cobrosAnt'] | number: '1.2-2' }}</span>
                </div>
                <div class="info-item">
                  <span class="label">Cantidad Cobros Anteriores:</span>
                  <span class="value">{{ estadisticasData['total-cantcobrosAnt'] }}</span>
                </div>
              </div>
            </div>

            <!-- Tabla de Meses -->
            <div class="info-section" *ngIf="estadisticasData['nombre-mes'] && estadisticasData['nombre-mes'].length > 0">
              <h3 class="section-title">Detalle Mensual</h3>
              <div class="table-wrapper">
                <table class="data-table">
                  <thead>
                    <tr>
                      <th>Mes</th>
                      <th>Ventas</th>
                      <th>Cobros</th>
                      <th>Comisión</th>
                      <th>Costo</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr *ngFor="let i of getMonthRange()">
                      <td>{{ estadisticasData['nombre-mes'][i] }}</td>
                      <td class="text-right">{{ getMonthValue('canfacmes-est', i) | number: '1.2-2' }}</td>
                      <td class="text-right">{{ getMonthValue('canpagmes-est', i) | number: '1.2-2' }}</td>
                      <td class="text-right">{{ getMonthValue('commes-est', i) | number: '1.2-2' }}</td>
                      <td class="text-right">{{ getMonthValue('cosmes-est', i) | number: '1.2-2' }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <ng-template #noData>
            <div class="no-data">
              <p>No hay datos de estadísticas disponibles</p>
            </div>
          </ng-template>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" (click)="closeModal()">Cerrar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }

    .modal-content {
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      max-width: 1000px;
      width: 90%;
      max-height: 80vh;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
    }

    .modal-header {
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-shrink: 0;
    }

    .modal-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0;
    }

    .close-button {
      background: none;
      border: none;
      color: #6b7280;
      cursor: pointer;
      padding: 0.5rem;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: color 0.2s;
    }

    .close-button:hover {
      color: #1f2937;
    }

    .modal-body {
      padding: 1.5rem;
      flex: 1;
      overflow-y: auto;
    }

    .estadisticas-container {
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
    }

    .info-section {
      background-color: #f9fafb;
      padding: 1rem;
      border-radius: 6px;
      border: 1px solid #e5e7eb;
    }

    .section-title {
      font-size: 1rem;
      font-weight: 600;
      color: #1e40af;
      margin: 0 0 1rem 0;
      padding-bottom: 0.5rem;
      border-bottom: 2px solid #1e40af;
    }

    .info-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1rem;
    }

    .info-item {
      display: flex;
      flex-direction: column;
      gap: 0.25rem;
    }

    .label {
      font-size: 0.85rem;
      color: #6b7280;
      font-weight: 500;
    }

    .value {
      font-size: 1rem;
      color: #1f2937;
      font-weight: 500;
    }

    .table-wrapper {
      width: 100%;
      overflow-x: auto;
    }

    .data-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.9rem;
    }

    .data-table thead {
      background-color: #e0e7ff;
    }

    .data-table th {
      padding: 0.75rem;
      text-align: left;
      font-weight: 600;
      color: #1e40af;
      border-bottom: 2px solid #1e40af;
    }

    .data-table td {
      padding: 0.75rem;
      border-bottom: 1px solid #e5e7eb;
      color: #374151;
    }

    .data-table tbody tr:hover {
      background-color: #f3f4f6;
    }

    .text-right {
      text-align: right;
    }

    .no-data {
      padding: 2rem;
      text-align: center;
      color: #9ca3af;
    }

    .modal-footer {
      padding: 1.5rem;
      border-top: 1px solid #e5e7eb;
      display: flex;
      justify-content: flex-end;
      gap: 0.75rem;
      flex-shrink: 0;
    }

    .btn {
      padding: 0.5rem 1rem;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 500;
      transition: all 0.2s;
    }

    .btn-secondary {
      background-color: #e5e7eb;
      color: #374151;
    }

    .btn-secondary:hover {
      background-color: #d1d5db;
    }

    .w-6 {
      width: 1.5rem;
      height: 1.5rem;
    }
  `]
})
export class EstadisticasModalComponent {
  @Input() show = false;
  @Input() estadisticasData: any = null;
  @Output() closeModalEvent = new EventEmitter<void>();

  closeModal(): void {
    this.closeModalEvent.emit();
  }

  getMonthRange(): number[] {
    if (!this.estadisticasData?.['nombre-mes']) return [];
    return Array.from({ length: this.estadisticasData['nombre-mes'].length }, (_, i) => i);
  }

  getMonthValue(field: string, index: number): number {
    return this.estadisticasData?.[field]?.[index] || 0;
  }
}
