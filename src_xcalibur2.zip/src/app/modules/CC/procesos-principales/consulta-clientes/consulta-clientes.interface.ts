export interface ConsultaClientesRecord {
  cia: number;
  empresa: number;
  'nombre-emp': string;
  nit: string;
  'rif-emp': string;
  'saldo-total': number;
  'por-vencer': number;
  'de-1a30': number;
  'de-31a60': number;
  'de-61a90': number;
  'de-91a120': number;
  'mayora120': number;
  'cheque-devuelto': number;
  'cheque-adelantado': number;
  'com-mes': number;
  'com-pr': number;
  'pago-mes': number;
  'pago-anual': number;
  'fecultcom-est': string;
  'fecultpag-est': string;
  'telefo-emp': string;
  'fax-emp': string;
  vendedor: number;
  'nombre-vend': string;
  condpago: number;
  'nombre-cpag': string;
  'situc': string;
  'email-emp': string;
  'nomcon-emp': string;
  'direc-emp': string;
  'fecing-emp': string;
  'prom-hora-canc': number;
  periodo?: number;
  ano?: number;
}

export interface EmpresaEstadisticas {
  tccestadiCC: ConsultaClientesRecord[];
}

export interface DocumentoBalance {
  tccdocume: any[];
}

export interface ChequeDevuelto {
  tcchistor: any[];
}

export interface VendedorData {
  tccvended: any[];
}

export interface CondicionPagoData {
  tccconpag: any[];
}
