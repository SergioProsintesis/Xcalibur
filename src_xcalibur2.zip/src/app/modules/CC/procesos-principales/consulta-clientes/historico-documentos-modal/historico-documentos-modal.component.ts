import { Component, Input, Output, EventEmitter, OnInit, SimpleChanges, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-historico-documentos-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  template: `
    <div class="modal-overlay" *ngIf="show" (click)="closeModal()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <div class="header-title">
            <h2 class="modal-title">Histórico de Documentos</h2>
            <p class="modal-subtitle">Cliente: {{ empresaNombre }} | Período: {{ periodoDisplay }}</p>
          </div>
          <button type="button" class="close-button" (click)="closeModal()">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
          </button>
        </div>

        <!-- Filter Section -->
        <div class="filter-section">
          <form [formGroup]="filterForm" class="filter-form">
            <div class="filter-group">
              <label class="filter-label">Fecha Desde:</label>
              <input 
                type="date" 
                formControlName="fechaDesde" 
                class="filter-input"
                (change)="onFilterChange()">
            </div>
            <div class="filter-group">
              <label class="filter-label">Fecha Hasta:</label>
              <input 
                type="date" 
                formControlName="fechaHasta" 
                class="filter-input"
                (change)="onFilterChange()">
            </div>
            <button type="button" class="btn btn-filter" (click)="applyFilter()">
              Aplicar Filtro
            </button>
            <button type="button" class="btn btn-reset" (click)="resetFilter()">
              Resetear
            </button>
          </form>
        </div>

        <div class="modal-body">
          <div *ngIf="historicoData && historicoData.length > 0; else noData" class="table-wrapper">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Num. Doc</th>
                  <th>Tipo</th>
                  <th>Fecha Movimiento</th>
                  <th>Fecha Vencimiento</th>
                  <th>Fecha Período</th>
                  <th>Monto</th>
                  <th>Saldo</th>
                  <th>Vendedor</th>
                  <th>Mora (días)</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let item of historicoData">
                  <td class="text-center"><strong>{{ item['numdoc-his'] }}</strong></td>
                  <td class="text-center">{{ item['siglas-tdoc'] }}</td>
                  <td>{{ item['fecmov-his'] | date: 'dd/MM/yyyy' }}</td>
                  <td>{{ item['fecven-his'] | date: 'dd/MM/yyyy' }}</td>
                  <td>{{ item['fecperi-his'] | date: 'dd/MM/yyyy' }}</td>
                  <td class="text-right"><strong>{{ item['monto-his'] | number: '1.2-2' }}</strong></td>
                  <td class="text-right"><strong>{{ item['saldo-doc'] | number: '1.2-2' }}</strong></td>
                  <td>{{ item['nombre-ven'] }}</td>
                  <td class="text-center">{{ item['mora'] }}</td>
                  <td class="text-center">
                    <span class="status-badge" [ngClass]="item['estado-his'] ? 'active' : 'inactive'">
                      {{ item['estado-his'] ? 'Activo' : 'Inactivo' }}
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <ng-template #noData>
            <div class="no-data">
              <p>No hay registros de histórico disponibles</p>
              <small>Intente ajustando el rango de fechas</small>
            </div>
          </ng-template>
        </div>

        <div class="modal-footer">
          <div class="footer-info">
            <span *ngIf="historicoData && historicoData.length > 0">
              Total de registros: <strong>{{ historicoData.length }}</strong>
            </span>
          </div>
          <button type="button" class="btn btn-secondary" (click)="closeModal()">Cerrar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }

    .modal-content {
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      max-width: 1200px;
      width: 95%;
      max-height: 85vh;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
    }

    .modal-header {
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      flex-shrink: 0;
      background: linear-gradient(135deg, #f3f4f6 0%, #ffffff 100%);
    }

    .header-title {
      flex: 1;
    }

    .modal-title {
      font-size: 1.5rem;
      font-weight: 700;
      color: #1f2937;
      margin: 0 0 0.25rem 0;
    }

    .modal-subtitle {
      font-size: 0.875rem;
      color: #6b7280;
      margin: 0;
      font-weight: 500;
    }

    .close-button {
      background: none;
      border: none;
      color: #6b7280;
      cursor: pointer;
      padding: 0.5rem;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: color 0.2s;
      flex-shrink: 0;
      margin-left: 1rem;
    }

    .close-button:hover {
      color: #ef4444;
    }

    .filter-section {
      padding: 1rem 1.5rem;
      background-color: #f9fafb;
      border-bottom: 1px solid #e5e7eb;
      flex-shrink: 0;
    }

    .filter-form {
      display: flex;
      gap: 1rem;
      align-items: flex-end;
      flex-wrap: wrap;
    }

    .filter-group {
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }

    .filter-label {
      font-size: 0.875rem;
      font-weight: 600;
      color: #374151;
    }

    .filter-input {
      padding: 0.5rem 0.75rem;
      border: 1px solid #d1d5db;
      border-radius: 4px;
      font-size: 0.875rem;
      min-width: 150px;
      transition: border-color 0.2s;
    }

    .filter-input:focus {
      outline: none;
      border-color: #3b82f6;
      box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    }

    .btn {
      padding: 0.5rem 1rem;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 500;
      transition: all 0.2s;
      font-size: 0.875rem;
    }

    .btn-filter {
      background-color: #3b82f6;
      color: white;
    }

    .btn-filter:hover {
      background-color: #2563eb;
      box-shadow: 0 2px 4px rgba(59, 130, 246, 0.2);
    }

    .btn-reset {
      background-color: #e5e7eb;
      color: #374151;
    }

    .btn-reset:hover {
      background-color: #d1d5db;
    }

    .modal-body {
      padding: 1.5rem;
      flex: 1;
      overflow-y: auto;
    }

    .table-wrapper {
      width: 100%;
      overflow-x: auto;
      border-radius: 6px;
      border: 1px solid #e5e7eb;
    }

    .data-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.875rem;
    }

    .data-table thead {
      background-color: #f3f4f6;
      position: sticky;
      top: 0;
      z-index: 10;
    }

    .data-table th {
      padding: 0.75rem;
      text-align: left;
      font-weight: 600;
      color: #374151;
      border-bottom: 2px solid #d1d5db;
      white-space: nowrap;
    }

    .data-table td {
      padding: 0.75rem;
      border-bottom: 1px solid #e5e7eb;
      color: #374151;
    }

    .data-table tbody tr:hover {
      background-color: #f9fafb;
    }

    .data-table tbody tr:nth-child(even) {
      background-color: #fafbfc;
    }

    .text-right {
      text-align: right;
    }

    .text-center {
      text-align: center;
    }

    .status-badge {
      display: inline-block;
      padding: 0.25rem 0.75rem;
      border-radius: 9999px;
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
    }

    .status-badge.active {
      background-color: #dcfce7;
      color: #166534;
    }

    .status-badge.inactive {
      background-color: #fee2e2;
      color: #991b1b;
    }

    .no-data {
      padding: 3rem 2rem;
      text-align: center;
      color: #9ca3af;
    }

    .no-data p {
      margin: 0 0 0.5rem 0;
      font-size: 1rem;
    }

    .no-data small {
      color: #d1d5db;
    }

    .modal-footer {
      padding: 1.5rem;
      border-top: 1px solid #e5e7eb;
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 0.75rem;
      flex-shrink: 0;
      background-color: #f9fafb;
    }

    .footer-info {
      flex: 1;
      font-size: 0.875rem;
      color: #6b7280;
    }

    .btn-secondary {
      background-color: #e5e7eb;
      color: #374151;
    }

    .btn-secondary:hover {
      background-color: #d1d5db;
    }

    .w-6 {
      width: 1.5rem;
      height: 1.5rem;
    }

    @media (max-width: 768px) {
      .modal-content {
        width: 98%;
        max-height: 90vh;
      }

      .filter-form {
        flex-direction: column;
      }

      .filter-group {
        width: 100%;
      }

      .filter-input {
        min-width: unset;
        width: 100%;
      }

      .data-table {
        font-size: 0.75rem;
      }

      .data-table th,
      .data-table td {
        padding: 0.5rem;
      }

      .modal-footer {
        flex-direction: column;
        align-items: flex-start;
      }
    }
  `]
})
export class HistoricoDocumentosModalComponent implements OnInit, OnChanges {
  @Input() show = false;
  @Input() historicoData: any[] = [];
  @Input() empresaNombre = '';
  @Input() periodoDisplay = '';
  @Input() fechaDesdeInicial = '';
  @Input() fechaHastaInicial = '';
  @Output() closeModalEvent = new EventEmitter<void>();
  @Output() filtroAplicado = new EventEmitter<{ fechaDesde: string; fechaHasta: string }>();

  filterForm: FormGroup;
  private originalData: any[] = [];

  constructor(private fb: FormBuilder) {
    this.filterForm = this.fb.group({
      fechaDesde: ['', Validators.required],
      fechaHasta: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.initializeFilters();
  }

  ngOnChanges(): void {
    if (this.show) {
      this.originalData = [...this.historicoData];
      this.initializeFilters();
    }
  }

  private initializeFilters(): void {
    if (this.fechaDesdeInicial && this.fechaHastaInicial) {
      this.filterForm.patchValue({
        fechaDesde: this.fechaDesdeInicial,
        fechaHasta: this.fechaHastaInicial
      });
    }
  }

  onFilterChange(): void {
    // On change, just update the form - user applies with button
  }

  applyFilter(): void {
    const fechaDesde = this.filterForm.get('fechaDesde')?.value;
    const fechaHasta = this.filterForm.get('fechaHasta')?.value;

    if (!fechaDesde || !fechaHasta) {
      return;
    }

    // Emit event to parent component to reload data with new dates
    this.filtroAplicado.emit({ fechaDesde, fechaHasta });
  }

  resetFilter(): void {
    this.initializeFilters();
    this.historicoData = [...this.originalData];
  }

  closeModal(): void {
    this.closeModalEvent.emit();
  }
}
