import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-cheques-devueltos-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="modal-overlay" *ngIf="isOpen" (click)="closeModal()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2>Cheques Devueltos</h2>
          <button class="close-btn" (click)="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div *ngIf="!cheques || cheques.length === 0" class="empty-state">
            <p>No hay cheques devueltos</p>
          </div>
          <table class="data-table" *ngIf="cheques && cheques.length > 0">
            <thead>
              <tr>
                <th>Documento</th>
                <th>Fecha Movimiento</th>
                <th>Tipo Documento</th>
                <th>Monto</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let chq of cheques">
                <td>{{ chq['numdoc-his'] }}</td>
                <td>{{ chq['fecmov-his'] | date:'dd/MM/yyyy' }}</td>
                <td>{{ chq['tipodoc'] }}</td>
                <td>{{ chq['monto-his'] | currency }}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="modal-footer">
          <button class="btn-close" (click)="closeModal()">Cerrar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }

    .modal-content {
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      max-width: 700px;
      width: 90%;
      max-height: 600px;
      overflow-y: auto;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px 20px;
      border-bottom: 1px solid #e5e7eb;
      background-color: #f3f4f6;
    }

    .modal-header h2 {
      margin: 0;
      font-size: 18px;
      font-weight: 600;
      color: #1f2937;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 24px;
      cursor: pointer;
      color: #6b7280;
      padding: 0;
    }

    .close-btn:hover {
      color: #1f2937;
    }

    .modal-body {
      padding: 20px;
    }

    .empty-state {
      text-align: center;
      padding: 40px 20px;
      color: #6b7280;
    }

    .data-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 14px;
    }

    .data-table thead {
      background-color: #f3f4f6;
      border-bottom: 2px solid #e5e7eb;
    }

    .data-table th {
      padding: 10px;
      text-align: left;
      font-weight: 600;
      color: #374151;
    }

    .data-table td {
      padding: 10px;
      border-bottom: 1px solid #e5e7eb;
      color: #1f2937;
    }

    .data-table tbody tr:hover {
      background-color: #f9fafb;
    }

    .modal-footer {
      padding: 16px 20px;
      border-top: 1px solid #e5e7eb;
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }

    .btn-close {
      padding: 8px 16px;
      background-color: #6b7280;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-weight: 500;
    }

    .btn-close:hover {
      background-color: #4b5563;
    }
  `]
})
export class ChequesDevueltosModalComponent {
  @Input() isOpen = false;
  @Input() cheques: any[] = [];
  @Output() closeEvent = new EventEmitter<void>();

  closeModal() {
    this.closeEvent.emit();
  }
}
