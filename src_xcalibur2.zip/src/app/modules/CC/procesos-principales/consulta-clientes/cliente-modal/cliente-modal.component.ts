import { Component, EventEmitter, Input, Output, signal, inject, OnInit, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { debounceTime, distinctUntilChanged, Subject, takeUntil } from 'rxjs';
import { CCService } from '../../../../../core/services/cc.service';
import { ToastService } from '../../../../../core/services/toast.service';

export interface ClienteRecord {
  // Campos de Empresa/Cliente (son lo mismo en este contexto)
  empresa: number;        // ID de la empresa/cliente
  cliente?: number;       // Alias para empresa
  'nombre-emp': string;   // Nombre de la empresa/cliente
  'nombre-cli'?: string;  // Alias para nombre-emp
  nit?: string;
  'rif-emp'?: string;
  'email-emp'?: string;
  'telefo-emp'?: string;
  'direc-emp'?: string;
  'fax-emp'?: string;
  'condpago'?: number;
  'vendedor'?: number;
  cia: number;            // Company ID
  'nombre-cia': string;   // Company name
  [key: string]: any;
}

@Component({
  selector: 'app-cliente-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="modal-backdrop" *ngIf="show" (click)="onClose()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2 class="modal-title">Buscar Cliente</h2>
          <button type="button" class="close-btn" (click)="onClose()">&times;</button>
        </div>

        <div class="modal-body">
          <form [formGroup]="searchForm" class="search-form">
            <div class="search-field">
              <label class="field-label">Buscar por código o nombre</label>
              <input type="text" formControlName="search" class="search-input" placeholder="Escriba para buscar...">
            </div>
          </form>

          <div class="clientes-grid" *ngIf="filteredClientes().length > 0; else noResults">
            <div class="grid-header">
              <div class="header-cell">Código</div>
              <div class="header-cell">NIT</div>
              <div class="header-cell">Nombre</div>
              <div class="header-cell">Acción</div>
            </div>
            <div class="grid-body">
              <div class="grid-row" *ngFor="let cliente of filteredClientes(); trackBy: trackByCliente">
                <div class="grid-cell">{{ cliente.empresa }}</div>
                <div class="grid-cell">{{ cliente.nit || '-' }}</div>
                <div class="grid-cell">{{ cliente['nombre-emp'] }}</div>
                <div class="grid-cell">
                  <button type="button" class="select-btn" (click)="onSelectCliente(cliente)">
                    Seleccionar
                  </button>
                </div>
              </div>
            </div>
          </div>

          <ng-template #noResults>
            <div class="no-results" *ngIf="!isLoading()">
              <p>No se encontraron clientes</p>
            </div>
          </ng-template>

          <div class="loading-indicator" *ngIf="isLoading()">
            <div class="spinner"></div>
            <span>Cargando clientes...</span>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn-secondary" (click)="onClose()">Cancelar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .modal-content {
      background: white;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 800px;
      max-height: 80vh;
      display: flex;
      flex-direction: column;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .modal-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: #003087;
      margin: 0;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #6b7280;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .close-btn:hover {
      color: #374151;
    }

    .modal-body {
      padding: 1.5rem;
      overflow-y: auto;
      flex: 1;
    }

    .search-form {
      margin-bottom: 1.5rem;
    }

    .search-field {
      display: flex;
      flex-direction: column;
    }

    .field-label {
      font-weight: 500;
      color: #374151;
      margin-bottom: 0.5rem;
    }

    .search-input {
      border: 1px solid #d1d5db;
      border-radius: 8px;
      padding: 0.75rem;
      font-size: 0.95rem;
      transition: all 0.2s;
    }

    .search-input:focus {
      outline: none;
      border-color: #003087;
      box-shadow: 0 0 0 2px rgba(0, 48, 135, 0.15);
    }

    .clientes-grid {
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      overflow: hidden;
    }

    .grid-header {
      display: grid;
      grid-template-columns: 80px 120px 1fr 120px;
      background: #f9fafb;
      border-bottom: 1px solid #e5e7eb;
    }

    .header-cell {
      padding: 0.75rem;
      font-weight: 600;
      font-size: 0.875rem;
      color: #374151;
      border-right: 1px solid #e5e7eb;
    }

    .header-cell:last-child {
      border-right: none;
    }

    .grid-body {
      max-height: 300px;
      overflow-y: auto;
    }

    .grid-row {
      display: grid;
      grid-template-columns: 80px 120px 1fr 120px;
      border-bottom: 1px solid #f3f4f6;
    }

    .grid-row:hover {
      background: #f9fafb;
    }

    .grid-cell {
      padding: 0.75rem;
      font-size: 0.875rem;
      color: #374151;
      border-right: 1px solid #f3f4f6;
      display: flex;
      align-items: center;
    }

    .grid-cell:last-child {
      border-right: none;
    }

    .select-btn {
      background-color: #003087;
      color: white;
      border: none;
      padding: 0.4rem 0.8rem;
      border-radius: 6px;
      font-size: 0.8rem;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .select-btn:hover {
      background-color: #002066;
    }

    .no-results {
      text-align: center;
      padding: 2rem;
      color: #6b7280;
    }

    .loading-indicator {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      color: #6b7280;
    }

    .spinner {
      width: 20px;
      height: 20px;
      border: 2px solid #f3f4f6;
      border-top-color: #003087;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin-right: 0.5rem;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 0.75rem;
      padding: 1.5rem;
      border-top: 1px solid #e5e7eb;
    }

    .btn-secondary {
      background-color: #f3f4f6;
      color: #374151;
      border: 1px solid #d1d5db;
      padding: 0.6rem 1.5rem;
      border-radius: 8px;
      font-weight: 500;
      cursor: pointer;
    }

    .btn-secondary:hover {
      background-color: #e5e7eb;
    }
  `]
})
export class ClienteModalComponent implements OnInit, OnChanges, OnDestroy {
  @Input() show = false;
  @Input() pcCompania: string = '';
  @Input() companiaNombre: string = '';
  @Output() selectCliente = new EventEmitter<ClienteRecord>();
  @Output() close = new EventEmitter<void>();

  // Form
  searchForm!: FormGroup;

  // State Signals
  clientes = signal<ClienteRecord[]>([]);
  filteredClientes = signal<ClienteRecord[]>([]);
  isLoading = signal(false);

  private destroy$ = new Subject<void>();
  private fb = inject(FormBuilder);
  private ccService = inject(CCService);
  private toastService = inject(ToastService);

  ngOnInit(): void {
    this.initializeForm();
    this.setupSearch();
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Load clientes/empresas when modal opens or compania changes
    if (changes['show'] && changes['show'].currentValue === true && this.pcCompania) {
      console.log('🔄 [ClienteModalComponent] Modal opened, loading clientes/empresas para compania:', this.pcCompania);
      this.loadClientes();
    }
    
    if (changes['pcCompania'] && !changes['pcCompania'].firstChange && this.show && this.pcCompania) {
      console.log('🔄 [ClienteModalComponent] Compania changed to:', this.pcCompania, ', reloading clientes/empresas');
      this.loadClientes();
    }

    if (changes['show'] && changes['show'].currentValue === true && !this.pcCompania) {
      console.warn('⚠️ [ClienteModalComponent] Modal opened pero pcCompania está vacío!');
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  // ==================== INITIALIZATION ====================
  private initializeForm(): void {
    this.searchForm = this.fb.group({
      search: ['']
    });
  }

  // ==================== LOAD DATA ====================
  private loadClientes(): void {
    if (!this.pcCompania) {
      console.warn('🚫 [ClienteModalComponent] No pcCompania provided - cannot load clientes/empresas');
      return;
    }

    console.log('🔄 [ClienteModalComponent] Loading clientes/empresas from GetCEEmpresa for compania:', this.pcCompania);
    this.isLoading.set(true);
    this.searchForm.get('search')?.reset();

    this.ccService.getClientes(this.pcCompania)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (data) => {
          console.log('✅ [ClienteModalComponent] Clientes/Empresas loaded successfully:', {
            totalCount: data.length,
            firstItem: data[0],
            timestamp: new Date().toISOString()
          });
          this.clientes.set(data);
          this.filteredClientes.set(data);
          this.isLoading.set(false);
        },
        error: (error) => {
          console.error('❌ [ClienteModalComponent] Error loading clientes/empresas from GetCEEmpresa:', error, {
            errorMessage: error?.message,
            errorStatus: error?.status,
            timestamp: new Date().toISOString()
          });
          this.toastService.showError('Error al cargar los clientes');
          this.clientes.set([]);
          this.filteredClientes.set([]);
          this.isLoading.set(false);
        }
      });
  }

  // ==================== SEARCH ====================
  private setupSearch(): void {
    this.searchForm.get('search')?.valueChanges
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe((searchTerm) => {
        this.filterClientes(searchTerm);
      });
  }

  private filterClientes(searchTerm: string): void {
    if (!searchTerm || !searchTerm.trim()) {
      this.filteredClientes.set(this.clientes());
      return;
    }

    const term = searchTerm.toLowerCase();
    const filtered = this.clientes().filter(cliente =>
      cliente.empresa?.toString().includes(term) ||
      cliente['nombre-emp']?.toLowerCase().includes(term) ||
      cliente.nit?.toLowerCase().includes(term)
    );
    this.filteredClientes.set(filtered);
  }

  // ==================== SELECTION ====================
  onSelectCliente(cliente: ClienteRecord): void {
    console.log('🎯 ClienteModalComponent: Cliente selected:', cliente);
    this.selectCliente.emit(cliente);
    this.onClose();
  }

  // ==================== CLOSE ====================
  onClose(): void {
    console.log('🔙 ClienteModalComponent: Closing modal');
    this.searchForm.reset();
    this.filteredClientes.set([]);
    this.close.emit();
  }

  // ==================== TRACKING ====================
  trackByCliente(index: number, cliente: ClienteRecord): number {
    return cliente.empresa;
  }
}
