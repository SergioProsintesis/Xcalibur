import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-saldo-total-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="modal-overlay" *ngIf="isOpen" (click)="closeModal()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2>Saldo Total y Antigüedad</h2>
          <button class="close-btn" (click)="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div class="data-grid">
            <div class="data-row">
              <label>Saldo Total</label>
              <span class="data-value">{{ data?.saldoTotal | currency }}</span>
            </div>
            <div class="data-row">
              <label>Por Vencer</label>
              <span class="data-value">{{ data?.porVencer | currency }}</span>
            </div>
            <div class="data-row">
              <label>1-30 días</label>
              <span class="data-value">{{ data?.dias1_30 | currency }}</span>
            </div>
            <div class="data-row">
              <label>31-60 días</label>
              <span class="data-value">{{ data?.dias31_60 | currency }}</span>
            </div>
            <div class="data-row">
              <label>61-90 días</label>
              <span class="data-value">{{ data?.dias61_90 | currency }}</span>
            </div>
            <div class="data-row">
              <label>91-120 días</label>
              <span class="data-value">{{ data?.dias91_120 | currency }}</span>
            </div>
            <div class="data-row">
              <label>Mayor a 120 días</label>
              <span class="data-value">{{ data?.diasMas120 | currency }}</span>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-close" (click)="closeModal()">Cerrar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }

    .modal-content {
      background: white;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      max-width: 600px;
      width: 90%;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .modal-header h2 {
      margin: 0;
      font-size: 1.25rem;
      font-weight: 600;
      color: #003087;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #6b7280;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .close-btn:hover {
      color: #374151;
    }

    .modal-body {
      padding: 1.5rem;
    }

    .data-grid {
      display: grid;
      gap: 1rem;
    }

    .data-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0.75rem;
      background-color: #f9fafb;
      border-radius: 6px;
      border-left: 3px solid #003087;
    }

    .data-row label {
      font-weight: 500;
      color: #374151;
    }

    .data-value {
      color: #1f2937;
      font-weight: 600;
    }

    .modal-footer {
      padding: 1.5rem;
      border-top: 1px solid #e5e7eb;
      display: flex;
      justify-content: flex-end;
      gap: 0.75rem;
    }

    .btn-close {
      padding: 0.6rem 1.5rem;
      background-color: #f3f4f6;
      color: #374151;
      border: 1px solid #d1d5db;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 500;
    }

    .btn-close:hover {
      background-color: #e5e7eb;
    }
  `]
})
export class SaldoTotalModalComponent {
  @Input() isOpen = false;
  @Input() data: any = null;
  @Output() closeEvent = new EventEmitter<void>();

  closeModal() {
    this.closeEvent.emit();
  }
}
