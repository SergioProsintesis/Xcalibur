import { Component, EventEmitter, Input, Output, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-condicion-pago-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="modal-overlay" *ngIf="isOpen" (click)="closeModal()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2 class="modal-title">Seleccionar Condición de Pago</h2>
          <button type="button" class="close-btn" (click)="closeModal()">&times;</button>
        </div>

        <div class="modal-body">
          <form class="search-form">
            <div class="search-field">
              <label class="field-label">Buscar por nombre o plazo</label>
              <input 
                type="text" 
                [(ngModel)]="searchTerm" 
                name="searchTerm"
                (input)="filterCondiciones()" 
                class="search-input" 
                placeholder="Escriba para buscar...">
            </div>
          </form>

          <div class="grid-container" *ngIf="filteredCondiciones.length > 0; else noResults">
            <div class="grid-header">
              <div class="header-cell col-codigo">Código</div>
              <div class="header-cell col-nombre">Nombre</div>
              <div class="header-cell col-plazo">Plazo (días)</div>
              <div class="header-cell col-accion">Acción</div>
            </div>
            <div class="grid-body">
              <div class="grid-row" *ngFor="let cond of filteredCondiciones; trackBy: trackByCondicion">
                <div class="grid-cell col-codigo">{{ cond.condpago }}</div>
                <div class="grid-cell col-nombre" [title]="cond['nombre-cpag']">{{ cond['nombre-cpag'] }}</div>
                <div class="grid-cell col-plazo text-center">{{ cond['diapla-cpag'] }}</div>
                <div class="grid-cell col-accion">
                  <button type="button" class="select-btn" (click)="selectCondicion(cond)">
                    Seleccionar
                  </button>
                </div>
              </div>
            </div>
          </div>

          <ng-template #noResults>
            <div class="no-results">
              <p>No se encontraron condiciones de pago</p>
            </div>
          </ng-template>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn-secondary" (click)="closeModal()">Cancelar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .modal-content {
      background: white;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 700px;
      max-height: 80vh;
      display: flex;
      flex-direction: column;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .modal-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: #003087;
      margin: 0;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #6b7280;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .close-btn:hover {
      color: #374151;
    }

    .modal-body {
      padding: 1.5rem;
      overflow-y: auto;
      flex: 1;
    }

    .search-form {
      margin-bottom: 1.5rem;
    }

    .search-field {
      display: flex;
      flex-direction: column;
    }

    .field-label {
      font-weight: 500;
      color: #374151;
      margin-bottom: 0.5rem;
      font-size: 0.9rem;
    }

    .search-input {
      border: 1px solid #d1d5db;
      border-radius: 6px;
      padding: 0.75rem;
      font-size: 1rem;
      transition: all 0.3s ease;
    }

    .search-input:focus {
      outline: none;
      border-color: #003087;
      box-shadow: 0 0 0 3px rgba(0, 48, 135, 0.1);
    }

    .grid-container {
      border: 1px solid #e5e7eb;
      border-radius: 6px;
      overflow: hidden;
    }

    .grid-header {
      display: grid;
      grid-template-columns: 0.7fr 2fr 1fr 1.2fr;
      background: #f3f4f6;
      border-bottom: 1px solid #d1d5db;
      font-weight: 600;
      color: #374151;
      position: sticky;
      top: 0;
      z-index: 1;
    }

    .header-cell {
      padding: 0.75rem;
      border-right: 1px solid #d1d5db;
      font-size: 0.9rem;
    }

    .header-cell:last-child {
      border-right: none;
    }

    .grid-body {
      max-height: 400px;
      overflow-y: auto;
    }

    .grid-row {
      display: grid;
      grid-template-columns: 0.7fr 2fr 1fr 1.2fr;
      border-bottom: 1px solid #e5e7eb;
      align-items: center;
      transition: background-color 0.2s;
    }

    .grid-row:hover {
      background-color: #f9fafb;
    }

    .grid-cell {
      padding: 0.75rem;
      border-right: 1px solid #e5e7eb;
      font-size: 0.85rem;
      color: #374151;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .grid-cell.col-codigo {
      font-weight: 600;
      color: #003087;
    }

    .grid-cell.col-nombre {
      font-weight: 500;
    }

    .grid-cell.col-accion {
      border-right: none;
      text-align: center;
      white-space: normal;
    }

    .text-center {
      text-align: center;
    }

    .select-btn {
      background: #3b82f6;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 0.5rem 1rem;
      font-size: 0.85rem;
      cursor: pointer;
      transition: all 0.3s;
    }

    .select-btn:hover {
      background: #2563eb;
      transform: translateY(-1px);
    }

    .select-btn:active {
      transform: translateY(0);
    }

    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      padding: 1.5rem;
      border-top: 1px solid #e5e7eb;
      background: #f9fafb;
    }

    .btn-secondary {
      background: #6b7280;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 0.75rem 1.5rem;
      cursor: pointer;
      font-size: 1rem;
      transition: all 0.3s;
    }

    .btn-secondary:hover {
      background: #4b5563;
    }

    .no-results {
      text-align: center;
      padding: 2rem;
      color: #9ca3af;
    }
  `]
})
export class CondicionPagoModalComponent implements OnInit, OnChanges {
  @Input() isOpen = false;
  @Input() condiciones: any[] = [];
  @Output() selectEvent = new EventEmitter<any>();
  @Output() closeEvent = new EventEmitter<void>();

  searchTerm = '';
  filteredCondiciones: any[] = [];

  ngOnInit() {
    this.filterCondiciones();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['condiciones']) {
      this.filterCondiciones();
    }
  }

  filterCondiciones(): void {
    const term = this.searchTerm.toLowerCase();
    this.filteredCondiciones = this.condiciones.filter(cond =>
      (cond.condpago?.toString().toLowerCase().includes(term) ||
       cond['nombre-cpag']?.toLowerCase().includes(term) ||
       cond['diapla-cpag']?.toString().includes(term))
    );
  }

  selectCondicion(condicion: any) {
    this.selectEvent.emit(condicion);
    this.closeModal();
  }

  closeModal() {
    this.closeEvent.emit();
  }

  trackByCondicion(_index: number, condicion: any): any {
    return condicion.condpago;
  }
}
