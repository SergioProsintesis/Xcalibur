import { Component, EventEmitter, Input, Output, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-vendedor-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="modal-overlay" *ngIf="isOpen" (click)="closeModal()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2>Seleccionar Vendedor</h2>
          <button class="close-btn" (click)="closeModal()">✕</button>
        </div>
        <div class="modal-body">
          <div class="search-box">
            <input 
              type="text" 
              placeholder="Buscar vendedor..."
              [(ngModel)]="searchTerm"
              (ngModelChange)="filterVendedores()">
          </div>
          <div *ngIf="!filteredVendedores || filteredVendedores.length === 0" class="empty-state">
            <p>No hay vendedores disponibles</p>
          </div>
          <div class="vendedor-list" *ngIf="filteredVendedores && filteredVendedores.length > 0">
            <div class="vendedor-item" *ngFor="let vend of filteredVendedores" (click)="selectVendedor(vend)">
              <strong>{{ vend['nombre-vend'] }}</strong>
              <small>{{ vend['text-vend'] }}</small>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-close" (click)="closeModal()">Cerrar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }

    .modal-content {
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      max-width: 500px;
      width: 90%;
      max-height: 600px;
      overflow-y: auto;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px 20px;
      border-bottom: 1px solid #e5e7eb;
      background-color: #f3f4f6;
    }

    .modal-header h2 {
      margin: 0;
      font-size: 18px;
      font-weight: 600;
      color: #1f2937;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 24px;
      cursor: pointer;
      color: #6b7280;
      padding: 0;
    }

    .close-btn:hover {
      color: #1f2937;
    }

    .modal-body {
      padding: 20px;
    }

    .search-box {
      margin-bottom: 15px;
    }

    .search-box input {
      width: 100%;
      padding: 8px 12px;
      border: 1px solid #d1d5db;
      border-radius: 4px;
      font-size: 14px;
    }

    .search-box input:focus {
      outline: none;
      border-color: #3b82f6;
      box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    }

    .empty-state {
      text-align: center;
      padding: 40px 20px;
      color: #6b7280;
    }

    .vendedor-list {
      display: grid;
      gap: 8px;
    }

    .vendedor-item {
      padding: 12px;
      background-color: #f9fafb;
      border: 1px solid #e5e7eb;
      border-radius: 4px;
      cursor: pointer;
      transition: all 0.2s;
      display: flex;
      flex-direction: column;
    }

    .vendedor-item:hover {
      background-color: #e0e7ff;
      border-color: #3b82f6;
    }

    .vendedor-item strong {
      color: #1f2937;
      font-size: 14px;
    }

    .vendedor-item small {
      color: #6b7280;
      font-size: 12px;
      margin-top: 4px;
    }

    .modal-footer {
      padding: 16px 20px;
      border-top: 1px solid #e5e7eb;
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }

    .btn-close {
      padding: 8px 16px;
      background-color: #6b7280;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-weight: 500;
    }

    .btn-close:hover {
      background-color: #4b5563;
    }
  `]
})
export class VendedorModalComponent implements OnInit, OnChanges {
  @Input() isOpen = false;
  @Input() vendedores: any[] = [];
  @Output() selectEvent = new EventEmitter<any>();
  @Output() closeEvent = new EventEmitter<void>();

  searchTerm = '';
  filteredVendedores: any[] = [];

  ngOnInit() {
    this.filteredVendedores = this.vendedores || [];
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['vendedores']) {
      this.filteredVendedores = this.vendedores || [];
      this.searchTerm = '';
    }
  }

  filterVendedores() {
    if (!this.searchTerm.trim()) {
      this.filteredVendedores = this.vendedores || [];
    } else {
      this.filteredVendedores = (this.vendedores || []).filter(v => 
        v['nombre-vend']?.toLowerCase().includes(this.searchTerm.toLowerCase())
      );
    }
  }

  selectVendedor(vendedor: any) {
    this.selectEvent.emit(vendedor);
    this.closeModal();
  }

  closeModal() {
    this.closeEvent.emit();
  }
}
