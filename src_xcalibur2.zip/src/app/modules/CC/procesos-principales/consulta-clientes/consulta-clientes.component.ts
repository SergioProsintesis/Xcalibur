import { Component, OnInit, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastService } from '../../../../core/services/toast.service';
import { LoadingService } from '../../../../core/services/loading.service';
import { CCService } from '../../../../core/services/cc.service';
import { AuthService } from '../../../../core/services/auth.service';
import { ProgramContextService } from '../../../../core/services/program-context.service';
import { ConsultaClientesRecord } from './consulta-clientes.interface';
import { CompaniaModalComponent } from '../../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { ClienteModalComponent } from './cliente-modal/cliente-modal.component';
import { SaldoTotalModalComponent } from './saldo-total-modal/saldo-total-modal.component';
import { DocumentosModalComponent } from './documentos-modal/documentos-modal.component';
import { ChequesDevueltosModalComponent } from './cheques-devueltos-modal/cheques-devueltos-modal.component';
import { VendedorModalComponent } from './vendedor-modal/vendedor-modal.component';
import { CondicionPagoModalComponent } from './condicion-pago-modal/condicion-pago-modal.component';
import { HistoricoDocumentosModalComponent } from './historico-documentos-modal/historico-documentos-modal.component';
import { EstadisticasModalComponent } from './estadisticas-modal/estadisticas-modal.component';

@Component({
  selector: 'app-consulta-clientes',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    CompaniaModalComponent,
    ClienteModalComponent,
    SaldoTotalModalComponent,
    DocumentosModalComponent,
    ChequesDevueltosModalComponent,
    VendedorModalComponent,
    CondicionPagoModalComponent,
    HistoricoDocumentosModalComponent,
    EstadisticasModalComponent
  ],
  templateUrl: './consulta-clientes.component.html',
  styleUrls: ['./consulta-clientes.component.css']
})
export class ConsultaClientesComponent implements OnInit {
  private programContext = inject(ProgramContextService);
  
  consultaForm: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Consulta de Clientes`);
  clientesData: ConsultaClientesRecord[] = [];
  filteredClientes: ConsultaClientesRecord[] = [];
  
  showCompaniaModal = false;
  showClienteModal = false;
  showSaldoTotalModal = false;
  showPVencerModal = false;
  showCheDevModal = false;
  showComMesModal = false;
  showVendedorModal = false;
  showCondicionPagoModal = false;
  showHistoricoModal = false;
  showEstadisticasModal = false;

  selectedCompania: any = null;
  documentosDisponibles: any[] = [];
  chequeDevuelto: any[] = [];
  vendedoresDisponibles: any[] = [];
  condicionesPago: any[] = [];
  historicoDocumentos: any[] = [];
  historicoFechaDesde = '';
  historicoFechaHasta = '';
  historicoEmpresaNombre = '';
  estadisticasData: any = null;

  searchClienteTerm = '';
  currentYear = new Date().getFullYear();

  public get loadingState() {
    return this.loading.getLoadingState();
  }

  constructor(
    private fb: FormBuilder,
    private toastService: ToastService,
    private loading: LoadingService,
    private ccService: CCService,
    private authService: AuthService,
    private router: Router
  ) {
    this.consultaForm = this.fb.group({
      cia: ['', Validators.required],
      'nombre-cia': [''],
      cliente: [''],
      ano: ['', Validators.required],
      'saldo-total': [''],
      nit: [''],
      rif: [''],
      'p-vencer': [''],
      '1-30': [''],
      '31-60': [''],
      '61-90': [''],
      '91-120': [''],
      '>120': [''],
      'che-dev': [''],
      'com-mes': [''],
      adel: [''],
      limite: [''],
      'com-mes-valor': [''],
      ano2: [''],
      'f-ult-comp': [''],
      'pago-mes': [''],
      'ano-pago': [''],
      'f-ult-pago': [''],
      telefono: [''],
      fax: [''],
      vendedor: [''],
      'c-pago': [''],
      situc: [''],
      email: [''],
      contacto: [''],
      direccion: [''],
      'fecha-ingr': [''],
      'prom-hora-canc': ['']
    });
  }

  ngOnInit(): void {
    // No cargar vendedores y condiciones al iniciar porque aún no hay compañía seleccionada
    // Se cargarán después de que se seleccione una compañía
  }

  openCompaniaModal(): void {
    this.showCompaniaModal = true;
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal = false;
  }

  onCompaniaSelected(compania: any): void {
    this.selectedCompania = compania;
    this.consultaForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    
    // Cargar vendedores y condiciones de pago después de seleccionar compañía
    this.loadVendedores();
    this.loadCondicionesPago();
  }

  openClienteModal(): void {
    if (!this.selectedCompania) {
      this.toastService.showWarning('Seleccione una compañía primero');
      return;
    }
    this.showClienteModal = true;
  }

  closeClienteModal(): void {
    this.showClienteModal = false;
  }

  onClienteSelected(cliente: any): void {
    console.log('✅ Cliente seleccionado:', cliente);
    
    // El cliente objeto retornado tiene empresa como ID
    const empresaId = cliente.empresa;
    const nombreCliente = cliente['nombre-emp'] || '';
    
    this.consultaForm.patchValue({
      cliente: empresaId,
      nit: cliente.nit || '',
      rif: cliente['rif-emp'] || '',
      telefono: cliente['telefo-emp'] || '',
      fax: cliente['fax-emp'] || '',
      direccion: cliente['direc-emp'] || '',
      email: cliente['email-emp'] || ''
    });
    
    this.closeClienteModal();
    
    // Cargar datos automáticamente después de seleccionar
    setTimeout(() => {
      this.onClienteChange();
    }, 300);
  }

  onClienteChange(): void {
    const empresaCode = this.consultaForm.get('cliente')?.value;
    if (!empresaCode || !this.selectedCompania) return;

    this.loading.show('Cargando datos del cliente...');
    const ano = this.consultaForm.get('ano')?.value || new Date().getFullYear();
    const periodo = this.consultaForm.get('periodo')?.value || '';  // Get period if available
    
    // First call GetLeaveEmpresa-cc0022 to load period-specific data
    const companiaId = this.selectedCompania.cia.toString();
    const empresaId = empresaCode.toString();
    const periodValue = periodo || ano.toString();
    
    this.ccService.getLeaveEmpresa(companiaId, empresaId, periodValue).subscribe({
      next: (leaveResult: any) => {
        // Process leave result if needed
        console.log('✅ GetLeaveEmpresa result:', leaveResult);
        
        // Then call getEmpresasEstadisticas
        this.ccService.getEmpresasEstadisticas(companiaId, empresaId, ano.toString()).subscribe({
          next: (result: any) => {
            this.loading.hide();
            if (result?.dsRespuesta?.tccestadiCC?.[0]) {
              this.estadisticasData = result.dsRespuesta.tccestadiCC[0];
              this.populateClienteData(result.dsRespuesta.tccestadiCC[0]);
              this.loadDocumentos(empresaCode);
              this.loadChequeDevuelto(empresaCode);
            }
          },
          error: () => {
            this.loading.hide();
            this.toastService.showError('Error al cargar datos del cliente');
          }
        });
      },
      error: (err) => {
        console.warn('Warning calling getLeaveEmpresa:', err);
        // Continue with statistics even if leave fails
        this.ccService.getEmpresasEstadisticas(companiaId, empresaId, ano.toString()).subscribe({
          next: (result: any) => {
            this.loading.hide();
            if (result?.dsRespuesta?.tccestadiCC?.[0]) {
              this.estadisticasData = result.dsRespuesta.tccestadiCC[0];
              this.populateClienteData(result.dsRespuesta.tccestadiCC[0]);
              this.loadDocumentos(empresaCode);
              this.loadChequeDevuelto(empresaCode);
            }
          },
          error: () => {
            this.loading.hide();
            this.toastService.showError('Error al cargar datos del cliente');
          }
        });
      }
    });
  }

  private populateClienteData(data: any): void {
    this.consultaForm.patchValue({
      'saldo-total': data['Saldo-total'] || 0,
      nit: data.nit || '',
      rif: data['rif-emp'] || '',
      'p-vencer': data['Por-vencer'] || 0,
      '1-30': data['De-1a30'] || 0,
      '31-60': data['De-31a60'] || 0,
      '61-90': data['De-61a90'] || 0,
      '91-120': data['De-91a120'] || 0,
      '>120': data['Mayora120'] || 0,
      'che-dev': data['ChequeDevuelto'] || 0,
      'com-mes': data['ComMes'] || 0,
      adel: data['ChequeAdelantado'] || 0,
      'limite': data['Limite-Est'] || 0,
      'com-mes-valor': data['ComPr'] || 0,
      'f-ult-comp': data['fecultcom-est'] || '',
      'pago-mes': data['PagoMes'] || 0,
      'f-ult-pago': data['fecultpag-est'] || '',
      telefono: data['telefo-emp'] || '',
      fax: data['fax-emp'] || '',
      vendedor: data['Vendedor'] || '',
      'c-pago': data['Condpago'] || '',
      email: data['email-emp'] || '',
      contacto: data['nomcon-emp'] || '',
      direccion: data['direc-emp'] || '',
      'fecha-ingr': data['Fecing-Est'] || '',
      'prom-hora-canc': data['diasPromCanc'] || 0
    });
  }

  private loadDocumentos(empresa: string): void {
    if (!this.selectedCompania) return;
    
    const ano = this.consultaForm.get('ano')?.value;
    const startDate = `${ano}-01-01`;
    const endDate = `${ano}-12-31`;

    this.ccService.getDocumentosBalance(
      this.selectedCompania.cia.toString(),
      empresa.toString(),
      '0',
      startDate,
      endDate
    ).subscribe({
      next: (result: any) => {
        this.documentosDisponibles = result?.dsRespuesta?.tccdocume || [];
      },
      error: () => {
        this.documentosDisponibles = [];
      }
    });
  }

  private loadChequeDevuelto(empresa: string): void {
    if (!this.selectedCompania) return;

    this.ccService.getChequeDevuelto(
      this.selectedCompania.cia.toString(),
      empresa.toString(),
      '3'
    ).subscribe({
      next: (result: any) => {
        this.chequeDevuelto = result?.dsRespuesta?.tcchistor || [];
      },
      error: () => {
        this.chequeDevuelto = [];
      }
    });
  }

  private loadVendedores(): void {
    if (!this.selectedCompania) return;

    this.ccService.getVendedores(this.selectedCompania?.cia?.toString() || '').subscribe({
      next: (result: any) => {
        this.vendedoresDisponibles = result?.dsRespuesta?.tccvended || [];
      },
      error: () => {
        this.vendedoresDisponibles = [];
      }
    });
  }

  private loadCondicionesPago(): void {
    if (!this.selectedCompania) return;

    this.ccService.getCondicionesPago(this.selectedCompania?.cia?.toString() || '').subscribe({
      next: (result: any) => {
        this.condicionesPago = result?.dsRespuesta?.tccconpag || [];
      },
      error: () => {
        this.condicionesPago = [];
      }
    });
  }

  consultarCliente(): void {
    if (this.consultaForm.get('cliente')?.value) {
      this.onClienteChange();
    } else {
      this.toastService.showWarning('Seleccione un cliente');
    }
  }

  onVendedorSelected(vendedor: any): void {
    this.consultaForm.patchValue({
      vendedor: vendedor['nombre-vend']
    });
  }

  onCondicionSelected(condicion: any): void {
    this.consultaForm.patchValue({
      'c-pago': condicion['nombre-cpag']
    });
  }

  limpiar(): void {
    this.consultaForm.reset();
    this.selectedCompania = null;
    this.clientesData = [];
    this.documentosDisponibles = [];
    this.chequeDevuelto = [];
    this.historicoDocumentos = [];
    this.estadisticasData = null;
  }

  loadHistoricoDocumentos(): void {
    const empresaCode = this.consultaForm.get('cliente')?.value;
    if (!empresaCode || !this.selectedCompania) {
      this.toastService.showWarning('Seleccione un cliente primero');
      return;
    }

    const ano = this.consultaForm.get('ano')?.value || new Date().getFullYear();
    this.historicoFechaDesde = `${ano}-01-01`;
    this.historicoFechaHasta = `${ano}-12-31`;
    this.historicoEmpresaNombre = this.consultaForm.get('cliente')?.value?.toString() || '';

    this.cargarHistoricoConFechas(empresaCode, this.historicoFechaDesde, this.historicoFechaHasta);
  }

  private cargarHistoricoConFechas(empresaCode: any, fechaDesde: string, fechaHasta: string): void {
    // Clear previous data to ensure fresh state
    this.historicoDocumentos = [];
    this.showHistoricoModal = false;

    this.loading.show('Cargando histórico de documentos...');
    
    console.log('📋 Cargando histórico con parámetros:', {
      cia: this.selectedCompania.cia.toString(),
      empresa: empresaCode.toString(),
      fechaDesde,
      fechaHasta
    });

    this.ccService.getHistoricoDocumentos(
      this.selectedCompania.cia.toString(),
      empresaCode.toString(),
      fechaDesde,
      fechaHasta
    ).subscribe({
      next: (result: any) => {
        this.loading.hide();
        // Ensure we get fresh data from response
        this.historicoDocumentos = result?.dsRespuesta?.tcchistorCC || [];
        console.log('📊 Histórico cargado:', this.historicoDocumentos.length, 'registros');
        
        if (this.historicoDocumentos.length === 0) {
          this.toastService.showInfo('No hay histórico de documentos disponible para el período seleccionado');
        }
        
        // Show modal - use Promise to ensure state is updated
        Promise.resolve().then(() => {
          this.showHistoricoModal = true;
        });
      },
      error: (err) => {
        this.loading.hide();
        console.error('❌ Error al cargar histórico:', err);
        this.toastService.showError('Error al cargar histórico de documentos');
        this.historicoDocumentos = [];
      }
    });
  }

  onHistoricoFiltroAplicado(filtro: { fechaDesde: string; fechaHasta: string }): void {
    console.log('🔍 Aplicando filtro de histórico:', filtro);
    const empresaCode = this.consultaForm.get('cliente')?.value;
    if (!empresaCode || !this.selectedCompania) return;

    this.historicoFechaDesde = filtro.fechaDesde;
    this.historicoFechaHasta = filtro.fechaHasta;
    
    this.cargarHistoricoConFechas(empresaCode, filtro.fechaDesde, filtro.fechaHasta);
  }

  loadEstadisticas(): void {
    const empresaCode = this.consultaForm.get('cliente')?.value;
    if (!empresaCode || !this.selectedCompania || !this.estadisticasData) {
      this.toastService.showWarning('Seleccione un cliente primero');
      return;
    }

    this.showEstadisticasModal = true;
  }

  exportar(): void {
    this.toastService.showInfo('Función de exportación no implementada aún');
  }

  goBack(): void {
    this.router.navigate(['/']);
  }
}
