import { Component, EventEmitter, Input, OnDestroy, OnInit, OnChanges, Output, signal, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { debounceTime, distinctUntilChanged, Subject, takeUntil } from 'rxjs';

import { CCService } from '../../../../../core/services/cc.service';

@Component({
  selector: 'app-concepto-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  template: `
    <div class="modal-backdrop" *ngIf="show" (click)="onClose()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2 class="modal-title">Seleccionar Concepto</h2>
          <button type="button" class="close-btn" (click)="onClose()">&times;</button>
        </div>

        <div class="modal-body">
          <form [formGroup]="searchForm" class="search-form">
            <div class="search-field">
              <label class="field-label">Buscar por nombre</label>
              <input type="text" formControlName="search" class="search-input" placeholder="Escriba para buscar...">
            </div>
          </form>

          <div class="conceptos-grid" *ngIf="filteredConceptos().length > 0; else noResults">
            <div class="grid-header">
              <div class="header-cell">Código</div>
              <div class="header-cell">Nombre</div>
              <div class="header-cell">Acción</div>
            </div>
            <div class="grid-body">
              <div class="grid-row" *ngFor="let concepto of filteredConceptos(); trackBy: trackByConcepto">
                <div class="grid-cell">{{ concepto.tipoconce }}</div>
                <div class="grid-cell">{{ concepto['nombre-conce'] }}</div>
                <div class="grid-cell">
                  <button type="button" class="select-btn" (click)="onSelectConcepto(concepto)">
                    Seleccionar
                  </button>
                </div>
              </div>
            </div>
          </div>

          <ng-template #noResults>
            <div class="no-results" *ngIf="!isLoading()">
              <p>No se encontraron conceptos</p>
            </div>
          </ng-template>

          <div class="loading-indicator" *ngIf="isLoading()">
            <div class="spinner"></div>
            <span>Cargando conceptos...</span>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn-secondary" (click)="onClose()">Cancelar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .modal-content {
      background: white;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 600px;
      max-height: 80vh;
      display: flex;
      flex-direction: column;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .modal-title {
      margin: 0;
      font-size: 1.25rem;
      font-weight: 600;
      color: #1f2937;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #6b7280;
      transition: color 0.2s;
    }

    .close-btn:hover {
      color: #1f2937;
    }

    .modal-body {
      flex: 1;
      overflow-y: auto;
      padding: 1.5rem;
    }

    .search-form {
      margin-bottom: 1.5rem;
    }

    .search-field {
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }

    .field-label {
      font-size: 0.875rem;
      font-weight: 500;
      color: #374151;
    }

    .search-input {
      padding: 0.75rem;
      border: 1px solid #d1d5db;
      border-radius: 6px;
      font-size: 1rem;
      transition: border-color 0.2s;
    }

    .search-input:focus {
      outline: none;
      border-color: #2563eb;
      box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
    }

    .conceptos-grid {
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      overflow: hidden;
    }

    .grid-header {
      display: grid;
      grid-template-columns: 1fr 2fr 1fr;
      background: #f9fafb;
      border-bottom: 1px solid #e5e7eb;
      font-weight: 600;
      font-size: 0.875rem;
      color: #374151;
    }

    .header-cell {
      padding: 0.75rem 1rem;
    }

    .grid-body {
      max-height: 400px;
      overflow-y: auto;
    }

    .grid-row {
      display: grid;
      grid-template-columns: 1fr 2fr 1fr;
      border-bottom: 1px solid #f3f4f6;
      align-items: center;
      transition: background-color 0.2s;
    }

    .grid-row:hover {
      background-color: #f9fafb;
    }

    .grid-cell {
      padding: 0.75rem 1rem;
      font-size: 0.875rem;
      color: #1f2937;
    }

    .select-btn {
      padding: 0.5rem 1rem;
      background-color: #2563eb;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 0.75rem;
      font-weight: 500;
      transition: background-color 0.2s;
    }

    .select-btn:hover {
      background-color: #1d4ed8;
    }

    .no-results {
      text-align: center;
      padding: 2rem;
      color: #6b7280;
    }

    .loading-indicator {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 1rem;
      padding: 2rem;
    }

    .spinner {
      width: 24px;
      height: 24px;
      border: 3px solid #e5e7eb;
      border-top-color: #2563eb;
      border-radius: 50%;
      animation: spin 0.6s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 1rem;
      padding: 1.5rem;
      border-top: 1px solid #e5e7eb;
    }

    .btn-secondary {
      padding: 0.75rem 1.5rem;
      background-color: #e5e7eb;
      color: #1f2937;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 0.875rem;
      font-weight: 500;
      transition: background-color 0.2s;
    }

    .btn-secondary:hover {
      background-color: #d1d5db;
    }
  `]
})
export class ConceptoModalComponent implements OnInit, OnChanges, OnDestroy {
  @Input() show = false;
  @Input() pcCompania: string = '';
  @Output() selectConcepto = new EventEmitter<any>();
  @Output() close = new EventEmitter<void>();

  searchForm!: FormGroup;
  conceptos = signal<any[]>([]);
  filteredConceptos = signal<any[]>([]);
  isLoading = signal(false);

  private destroy$ = new Subject<void>();
  private searchSubject$ = new Subject<string>();

  constructor(
    private fb: FormBuilder,
    private ccService: CCService
  ) {
    this.initializeForm();
  }

  ngOnInit(): void {
    this.setupSearch();
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Reload data when show changes to true
    if (changes['show'] && changes['show'].currentValue === true) {
      console.log('🔔 Modal show changed to true, loading data');
      this.loadConceptos();
    }
    
    // Also reload if pcCompania changed while modal is open
    if (changes['pcCompania'] && !changes['pcCompania'].firstChange && this.show) {
      console.log('🔔 pcCompania changed, reloading data');
      this.loadConceptos();
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private initializeForm(): void {
    this.searchForm = this.fb.group({
      search: ['']
    });
  }

  private loadConceptos(): void {
    if (!this.pcCompania || this.pcCompania === '') {
      console.warn('🚫 No pcCompania provided, cannot load conceptos', this.pcCompania);
      this.isLoading.set(false);
      return;
    }

    console.log('🔍 Loading conceptos for pcCompania:', this.pcCompania);
    this.isLoading.set(true);
    
    this.ccService.getCEConceptos(this.pcCompania)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (data) => {
          console.log('✅ Conceptos loaded successfully:', data);
          this.conceptos.set(data);
          this.filteredConceptos.set(data);
          this.isLoading.set(false);
        },
        error: (error) => {
          console.error('❌ Error loading conceptos:', error);
          this.conceptos.set([]);
          this.filteredConceptos.set([]);
          this.isLoading.set(false);
        }
      });
  }

  private setupSearch(): void {
    this.searchForm.get('search')?.valueChanges
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe((searchTerm) => {
        this.filterConceptos(searchTerm);
      });
  }

  private filterConceptos(searchTerm: string): void {
    const term = searchTerm.toLowerCase();
    const filtered = this.conceptos().filter(conc =>
      conc.tipoconce?.toString().toLowerCase().includes(term) ||
      conc['nombre-conce']?.toLowerCase().includes(term)
    );
    this.filteredConceptos.set(filtered);
  }

  onSelectConcepto(concepto: any): void {
    this.selectConcepto.emit(concepto);
    this.onClose();
  }

  onClose(): void {
    this.close.emit();
  }

  trackByConcepto(index: number, concepto: any): any {
    return concepto.tipoconce; // endpoint retorna 'tipoconce', no 'ccconcon'
  }
}
