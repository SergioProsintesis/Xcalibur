import { Component, OnInit, OnDestroy, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Observable, Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';

import { AuthService } from '../../../../core/services/auth.service';
import { ToastService } from '../../../../core/services/toast.service';
import { LoadingService } from '../../../../core/services/loading.service';
import { ProgramContextService } from '../../../../core/services/program-context.service';
import { CCService } from '../../../../core/services/cc.service';
import { CompaniaRecord, GenerarReporteResponse } from '../../../../core/interfaces/cc.interface';
import { CompaniaModalComponent } from '../../reporte-movimiento-del-dia/compania-modal/compania-modal.component';

interface ContactoRecord {
  cia: number;
  'nombre-cia': string;
  empresa: number;
  'nombre-emp': string;
  gerente: number;
  nombreGerente: string;
  nomcon: string;
  carcon: string;
  socio: number;
  nombreSocio: string;
  tipoconce: number;
  'nombre-conce': string;
  'date-ctrl': string;
  'login-ctrl': string;
  'tparent': string;
}

@Component({
  selector: 'app-mantenimiento-contactos',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, CompaniaModalComponent],
  templateUrl: './mantenimiento-contactos.component.html',
  styleUrl: './mantenimiento-contactos.component.css'
})
export class MantenimientoContactosComponent implements OnInit, OnDestroy {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private programContext = inject(ProgramContextService);
  private ccService = inject(CCService);
  private router = inject(Router);

  form!: FormGroup;
  contactosData = signal<ContactoRecord[]>([]);
  selectedContacto = signal<ContactoRecord | null>(null);
  
  // Popup signals
  showPopup = signal(false);
  popupTitle = signal('');
  popupType = signal('');
  searchTerm = signal('');
  popupData = signal<any[]>([]);
  filteredPopupData = signal<any[]>([]);

  isLoading = signal(false);
  isEditing = signal(false);
  isSaving = signal(false);

  pageTitle = computed(() => 'Mantenimiento de Contactos - WCCEMPCON');
  pcPrograma: string = 'WCCEMPCON';
  pcLogin: string = '';
  pcSuper: string = '';
  pcToken: string = '';

  private destroy$ = new Subject<void>();

  ngOnInit(): void {
    this.initializeForm();
    this.loadAuthData();
    this.loadContactos();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private initializeForm(): void {
    this.form = this.fb.group({
      cia: ['', Validators.required],
      'nombre-cia': [''],
      empresa: ['', Validators.required],
      'nombre-emp': [''],
      gerente: ['', Validators.required],
      nombreGerente: [''],
      nomcon: ['', Validators.required],
      carcon: ['', Validators.required],
      socio: ['', Validators.required],
      nombreSocio: [''],
      tipoconce: ['', Validators.required],
      'nombre-conce': ['']
    });
  }

  private loadAuthData(): void {
    const user = this.authService.user();
    
    if (!user) {
      this.toastService.showError('Sesión expirada. Por favor, inicie sesión nuevamente.');
      this.router.navigate(['/login']);
      return;
    }
    
    this.pcLogin = user.pcLogin || '';
    this.pcSuper = user.pcSuper || '';
    this.pcToken = user.pcToken || '';
  }

  private loadContactos(): void {
    this.isLoading.set(true);
    const cia = this.form.get('cia')?.value || '';
    const empresa = this.form.get('empresa')?.value || '';
    
    this.ccService.getContactos(cia, empresa)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (data) => {
          this.contactosData.set(data);
          this.isLoading.set(false);
        },
        error: (error) => {
          this.toastService.showError('Error al cargar contactos: ' + error.message);
          this.isLoading.set(false);
        }
      });
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getErrorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (field?.hasError('required')) {
      return `${fieldName} es requerido`;
    }
    return 'Campo inválido';
  }

  // Popup methods
  openPopup(type: string): void {
    const cia = this.form.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    this.showPopup.set(true);
    this.popupType.set(type);
    this.popupData.set([]);
    this.filteredPopupData.set([]);
    this.searchTerm.set('');
    this.isLoading.set(true);

    // Set popup title and load data
    switch (type) {
      case 'empresa':
        this.popupTitle.set('Seleccionar Empresa');
        this.loadEmpresasPopup();
        break;
      case 'gerente':
        this.popupTitle.set('Seleccionar Gerente');
        this.loadGerentesPopup();
        break;
      case 'concepto':
        this.popupTitle.set('Seleccionar Concepto');
        this.loadConceptosPopup();
        break;
    }
  }

  private loadEmpresasPopup(): void {
    const cia = this.form.get('cia')?.value;
    console.log('[POPUP] Loading empresas for cia:', cia);
    if (!cia) {
      console.error('[POPUP] No cia selected');
      this.isLoading.set(false);
      return;
    }

    this.ccService.getCEEmpresa(String(cia))
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (data) => {
          console.log('[POPUP] Empresas loaded:', data);
          if (!data || data.length === 0) {
            console.warn('[POPUP] No empresas returned');
          }
          this.popupData.set(data);
          this.filteredPopupData.set(data);
          this.isLoading.set(false);
        },
        error: (error) => {
          console.error('[POPUP] Error loading empresas:', error);
          this.popupData.set([]);
          this.filteredPopupData.set([]);
          this.isLoading.set(false);
        }
      });
  }

  private loadGerentesPopup(): void {
    const cia = this.form.get('cia')?.value;
    console.log('[POPUP] Loading gerentes for cia:', cia);
    if (!cia) {
      console.error('[POPUP] No cia selected');
      this.isLoading.set(false);
      return;
    }

    this.ccService.getCEGerentes(String(cia))
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (data) => {
          console.log('[POPUP] Gerentes loaded:', data);
          if (!data || data.length === 0) {
            console.warn('[POPUP] No gerentes returned');
          }
          this.popupData.set(data);
          this.filteredPopupData.set(data);
          this.isLoading.set(false);
        },
        error: (error) => {
          console.error('[POPUP] Error loading gerentes:', error);
          this.popupData.set([]);
          this.filteredPopupData.set([]);
          this.isLoading.set(false);
        }
      });
  }

  private loadConceptosPopup(): void {
    const cia = this.form.get('cia')?.value;
    console.log('[POPUP] Loading conceptos for cia:', cia);
    if (!cia) {
      console.error('[POPUP] No cia selected');
      this.isLoading.set(false);
      return;
    }

    this.ccService.getCEConceptos(String(cia))
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (data) => {
          console.log('[POPUP] Conceptos raw response:', data);
          console.log('[POPUP] Conceptos length:', data?.length);
          if (data && data.length > 0) {
            console.log('[POPUP] First concepto:', data[0]);
            console.log('[POPUP] Fields in first concepto:', Object.keys(data[0]));
          }
          if (!data || data.length === 0) {
            console.warn('[POPUP] No conceptos returned');
          }
          this.popupData.set(data);
          this.filteredPopupData.set(data);
          this.isLoading.set(false);
        },
        error: (error) => {
          console.error('[POPUP] Error loading conceptos:', error);
          this.popupData.set([]);
          this.filteredPopupData.set([]);
          this.isLoading.set(false);
        }
      });
  }

  onSearch(): void {
    const term = this.searchTerm().toLowerCase();
    const filtered = this.popupData().filter(item =>
      this.getItemCodigo(item)?.toString().toLowerCase().includes(term) ||
      this.getItemNombre(item)?.toLowerCase().includes(term)
    );
    this.filteredPopupData.set(filtered);
  }

  onSearchClear(): void {
    this.searchTerm.set('');
    this.filteredPopupData.set(this.popupData());
  }

  getItemCodigo(item: any): any {
    const type = this.popupType();
    if (type === 'empresa') return item.empresa;
    if (type === 'gerente') return item.vendedor;
    if (type === 'concepto') return item.tipoconce; // endpoint retorna 'tipoconce', no 'ccconcon'
    return item.codigo;
  }

  getItemNombre(item: any): string {
    const type = this.popupType();
    if (type === 'empresa') return item['nombre-emp'] || '';
    if (type === 'gerente') return item['nombre-vend'] || '';
    if (type === 'concepto') return item['nombre-conce'] || ''; // corrección: nombre-conce (no nombre-conc)
    return item.nombre || '';
  }

  selectPopupItem(item: any): void {
    const type = this.popupType();
    
    if (type === 'empresa') {
      this.form.patchValue({
        empresa: item.empresa,
        'nombre-emp': item['nombre-emp'] || ''
      });
      this.toastService.showSuccess(`Empresa ${item['nombre-emp']} seleccionada`);
    } else if (type === 'gerente') {
      this.form.patchValue({
        gerente: item.vendedor,
        nombreGerente: item['nombre-vend'],
        socio: item.vendedor,
        nombreSocio: item['nombre-vend']
      });
      this.toastService.showSuccess(`Gerente ${item['nombre-vend']} seleccionado`);
    } else if (type === 'concepto') {
      this.form.patchValue({
        tipoconce: item.tipoconce, // endpoint retorna 'tipoconce'
        'nombre-conce': item['nombre-conce'] || ''
      });
      this.toastService.showSuccess(`Concepto ${item['nombre-conce']} seleccionado`);
    }
    
    this.closePopup();
  }

  closePopup(): void {
    this.showPopup.set(false);
    this.popupType.set('');
    this.popupData.set([]);
    this.filteredPopupData.set([]);
    this.searchTerm.set('');
  }

  // Convenience methods for HTML template
  onOpenEmpresaModal(): void {
    this.openPopup('empresa');
  }

  onOpenGerenteModal(): void {
    this.openPopup('gerente');
  }

  onOpenConceptoModal(): void {
    this.openPopup('concepto');
  }

  onCloseModal(): void {
    this.closePopup();
  }

  onClear(): void {
    this.form.reset();
    this.selectedContacto.set(null);
    this.isEditing.set(false);
  }

  onSaveContacto(): void {
    if (!this.form.valid) {
      this.toastService.showError('Por favor complete todos los campos requeridos');
      return;
    }

    this.isSaving.set(true);
    const contactoData = {
      ...this.form.value,
      'login-ctrl': this.pcLogin
    };

    this.ccService.saveContacto(contactoData, this.pcLogin, this.pcSuper, this.pcToken)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          this.toastService.showSuccess('Contacto guardado correctamente');
          this.loadContactos();
          this.onClear();
          this.isSaving.set(false);
        },
        error: (error) => {
          this.toastService.showError('Error al guardar contacto: ' + error.message);
          this.isSaving.set(false);
        }
      });
  }

  onEditContacto(contacto: ContactoRecord): void {
    this.isEditing.set(true);
    this.selectedContacto.set(contacto);
    this.form.patchValue(contacto);
  }

  onDeleteContacto(contacto: ContactoRecord): void {
    if (!confirm(`¿Desea eliminar el contacto ${contacto.nomcon}?`)) {
      return;
    }

    this.isLoading.set(true);
    this.ccService.deleteContacto(
      String(contacto.cia), 
      String(contacto.empresa), 
      String(contacto.tipoconce), 
      this.pcLogin, 
      this.pcSuper, 
      this.pcToken
    )
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.toastService.showSuccess('Contacto eliminado correctamente');
          this.loadContactos();
          this.isLoading.set(false);
        },
        error: (error) => {
          this.toastService.showError('Error al eliminar contacto: ' + error.message);
          this.isLoading.set(false);
        }
      });
  }

  // Compañía Modal Methods
  showCompaniaModal = signal(false);

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
  }

  onSelectCompania(compania: CompaniaRecord): void {
    console.log('Compañía seleccionada:', compania);
    if (compania && compania.cia) {
      this.form.patchValue({
        cia: compania.cia,
        'nombre-cia': compania['nombre-cia']
      });
      this.showCompaniaModal.set(false);
      this.toastService.showSuccess(`Compañía ${compania['nombre-cia']} seleccionada`);
      console.log('[SUCCESS] Compañía asignada al formulario:', this.form.get('cia')?.value);
    } else {
      this.toastService.showError('No se seleccionó una compañía válida');
      console.log('[ERROR] Compañía no válida', compania);
    }
  }
}
