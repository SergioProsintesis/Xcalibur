import { Component, inject, signal, computed, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';

import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaRecord } from '../../../core/interfaces/cc.interface';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { GenArchivosFactnotasYCartService } from './gen-archivos-factnotas-y-cart.service';

@Component({
  selector: 'app-gen-archivos-factnotas-y-cart',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, CompaniaModalComponent],
  templateUrl: './gen-archivos-factnotas-y-cart.component.html',
  styleUrls: ['./gen-archivos-factnotas-y-cart.component.css']
})
export class GenArchivosFactnotasYCartComponent implements OnInit, OnDestroy {
  private fb = inject(FormBuilder);
  private toast = inject(ToastService);
  private loading = inject(LoadingService);
  private service = inject(GenArchivosFactnotasYCartService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private destroy$ = new Subject<void>();

  form!: FormGroup;
  isLoading = signal(false);
  showCompaniaModal = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  isGenerating = signal(false);
  
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}PS5010 - Gen.Archivos Fact.Notas y Cart.x Lect.Archivo`);

  ngOnInit(): void {
    this.loading.hide();
    this.initializeForm();
  }

  private initializeForm(): void {
    this.form = this.fb.group({
      cia: ['', Validators.required],
      fecha: ['', Validators.required],
      opcion: ['', Validators.required],
      archivo: ['', Validators.required]
    });
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getErrorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (!field) return '';

    if (field.hasError('required')) return 'Este campo es requerido';
    if (field.hasError('pattern')) return 'Formato inválido';
    
    return 'Error en el campo';
  }

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
  }

  onCloseCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onSelectCompania(compania: CompaniaRecord): void {
    this.selectedCompania.set(compania);
    this.form.patchValue({
      cia: compania.cia
    });
    this.onCloseCompaniaModal();
  }

  onGenerarArchivos(): void {
    if (!this.form.valid) {
      this.toast.showError('Por favor complete los campos requeridos');
      return;
    }

    this.isGenerating.set(true);
    const cia = this.form.get('cia')?.value;
    const fecha = this.form.get('fecha')?.value;
    const opcion = this.form.get('opcion')?.value;
    const archivo = this.form.get('archivo')?.value;

    const archivoCall = this.service.generarArchivos(cia, fecha, opcion, archivo);

    archivoCall
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isGenerating.set(false);
          if (response) {
            this.toast.showSuccess('Archivos generados correctamente');
            // Aquí puedes agregar lógica para descargar si es necesario
          }
        },
        error: (err) => {
          console.error('Error al generar archivos:', err);
          this.toast.showError('Error al generar los archivos');
          this.isGenerating.set(false);
        }
      });
  }

  onVolver(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
