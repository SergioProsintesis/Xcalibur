import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../core/services/auth.service';
import { CompaniaRecord } from '../../../core/interfaces/cc.interface';

@Injectable({
  providedIn: 'root'
})
export class GenArchivosFactnotasYCartService {
  private http = inject(HttpClient);
  private authService = inject(AuthService);

  /** Obtener parámetros de autenticación */
  private getAuthParams(): { pcLogin: string; pcSuper: string; pcToken: string } {
    const user = this.authService.user();
    return {
      pcLogin: user?.pcLogin || '',
      pcSuper: user?.pcSuper || '',
      pcToken: user?.pcToken || ''
    };
  }

  /**
   * GetCECompanias - Obtiene la lista de compañías disponibles
   */
  getCompanias(): Observable<CompaniaRecord[]> {
    const authParams = this.getAuthParams();
    const url = `${environment.apiUrl}/GetCECompanias?pcLogin=${encodeURIComponent(authParams.pcLogin)}&pcSuper=${encodeURIComponent(authParams.pcSuper)}&pcToken=${encodeURIComponent(authParams.pcToken)}`;

    return this.http.get<any>(url).pipe(
      map(res => res?.dsRespuesta?.tgecias || []),
      catchError(err => {
        console.error('Error getCompanias', err);
        return of([]);
      })
    );
  }

  /**
   * GetLeaveGEciasCxC - Valida el campo Compañía
   */
  validateCompania(pcCompania: string | number): Observable<CompaniaRecord | null> {
    const authParams = this.getAuthParams();
    const url = `${environment.apiUrl}/GetLeaveGEciasCxC?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(authParams.pcLogin)}&pcSuper=${encodeURIComponent(authParams.pcSuper)}&pcToken=${encodeURIComponent(authParams.pcToken)}`;

    return this.http.get<any>(url).pipe(
      map(res => res?.dsRespuesta?.tgecias?.[0] || null),
      catchError(err => {
        console.error('Error validateCompania', err);
        return of(null);
      })
    );
  }

  /**
   * GetPS5010 - Genera los archivos de facturas, notas y cartas por lectura de archivo
   */
  generarArchivos(cia: number, fecha: string, opcion: string, archivo: string): Observable<any> {
    const authParams = this.getAuthParams();
    const url = `${environment.apiUrl}/GetPS5010?pcCompania=${encodeURIComponent(cia.toString())}&pcFecha=${encodeURIComponent(fecha)}&pcOpcion=${encodeURIComponent(opcion)}&lcNomArch=${encodeURIComponent(archivo)}&pcLogin=${encodeURIComponent(authParams.pcLogin)}&pcSuper=${encodeURIComponent(authParams.pcSuper)}&pcToken=${encodeURIComponent(authParams.pcToken)}`;

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error generarArchivos', err);
        return of(null);
      })
    );
  }
}
