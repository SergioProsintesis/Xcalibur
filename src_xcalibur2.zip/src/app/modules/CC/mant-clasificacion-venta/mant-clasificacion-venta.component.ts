import { Component, OnInit, signal, computed, inject, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { ClasificacionVentaModalComponent } from '../../../shared/components/clasificacion-venta-modal/clasificacion-venta-modal.component';
import { CCService } from '../../../core/services/cc.service';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaRecord, ClasificacionVentaRecord } from '../../../core/interfaces/cc.interface';

@Component({
  selector: 'app-mant-clasificacion-venta',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent, ClasificacionVentaModalComponent],
  templateUrl: './mant-clasificacion-venta.component.html',
  styleUrls: ['./mant-clasificacion-venta.component.css']
})
export class MantClasificacionVentaComponent implements OnInit {
  private programContext = inject(ProgramContextService);
  private loadingService = inject(LoadingService);
  private cdr = inject(ChangeDetectorRef);
  
  clasificacionVentaForm!: FormGroup;
  createClasificacionForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Clasificación de Venta`);

  // Signals para el estado del componente
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  clasificacionSeleccionada = signal<ClasificacionVentaRecord | null>(null);
  showCompaniaModal = signal(false);
  showClasificacionModal = signal(false);
  showCreateModal = signal(false);
  showReportModal = signal(false);
  isEditMode = signal(false);
  clasificacionesDisponibles = signal<ClasificacionVentaRecord[]>([]);
  loadingState = computed(() => this.loadingService.getLoadingState()());
  
  // Datos de reporte
  reportResponse: any = null;

  constructor(
    private fb: FormBuilder,
    private ccService: CCService,
    private authService: AuthService,
    private toastService: ToastService,
    private router: Router
  ) {
    this.initializeForm();
  }

  ngOnInit() {
    // Inicializar con datos por defecto si es necesario
  }

  private initializeForm() {
    // Formulario Principal
    this.clasificacionVentaForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{value: '', disabled: true}],
      claven: ['', [Validators.required, Validators.min(1)]],
      'nombre-cven': [{value: '', disabled: true}],
      'ventad-cven': [{value: 0, disabled: true}],
      'ventah-cven': [{value: 0, disabled: true}],
      'text-cven': [{value: '', disabled: true}]
    });

    // Formulario de Crear Clasificación
    this.createClasificacionForm = this.fb.group({
      claven: ['', [Validators.required, Validators.min(1)]],
      'nombre-cven': ['', [Validators.required, Validators.minLength(1)]],
      'ventad-cven': [0, [Validators.min(0)]],
      'ventah-cven': [0, [Validators.min(0)]],
      'text-cven': ['']
    });
  }


  // ================== VALIDACIONES Y UTILIDADES ==================

  isInvalid(fieldName: string): boolean {
    const field = this.clasificacionVentaForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.clasificacionVentaForm.get(fieldName);
    if (!field?.errors) return '';

    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['maxlength']) return `Máximo ${errors['maxlength'].requiredLength} caracteres`;
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ================== MODAL DE COMPAÑÍAS ==================

  buscarCompania() {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal() {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord) {
    this.companiaSeleccionada.set(compania);
    this.clasificacionVentaForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    
    // Limpiar campos dependientes
    this.clearClasificacionData();
  }

  async onCompaniaLeave() {
    const companiaId = this.clasificacionVentaForm.get('cia')?.value;
    if (!companiaId) return;

    this.loadingService.show();
    try {
      const compania = await this.ccService.getLeaveCompania(companiaId.toString());
      if (compania?.dsRespuesta?.tgecias?.[0]) {
        const companiaData = compania.dsRespuesta.tgecias[0] as CompaniaRecord;
        this.clasificacionVentaForm.patchValue({
          'nombre-cia': companiaData['nombre-cia']
        });
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.clasificacionVentaForm.patchValue({ cia: '' });
      }
    } catch (error) {
      this.toastService.showError('Error al validar compañía');
      console.error(error);
    } finally {
      this.loadingService.hide();
    }
  }

  // ================== MODAL DE CLASIFICACIÓN DE VENTA ==================

  buscarClasificacion() {
    const companiaId = this.clasificacionVentaForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }
    this.showClasificacionModal.set(true);
  }

  // Recargar clasificaciones SIN abrir modal
  private async reloadClasificaciones(): Promise<void> {
    const companiaId = this.clasificacionVentaForm.get('cia')?.value;
    if (!companiaId) {
      return;
    }
    console.log('✅ Clasificaciones recargadas');
  }

  closeClasificacionModal() {
    this.showClasificacionModal.set(false);
  }

  async onClasificacionSelected(clasificacion: ClasificacionVentaRecord): Promise<void> {
    const companiaId = this.clasificacionVentaForm.get('cia')?.value;
    if (!companiaId) return;

    this.loadingService.show();
    try {
      // Load fresh data from server
      const dataActualizada = await firstValueFrom(this.ccService.validateClasificacionVenta(
        companiaId.toString(),
        clasificacion.claven
      ));

      if (dataActualizada) {
        this.clasificacionSeleccionada.set(dataActualizada);
        this.loadClasificacionData(dataActualizada);
        this.toastService.showSuccess(`Clasificación cargada`);
      }
    } catch (error) {
      console.error('Error al recargar clasificación:', error);
      // Fallback to local data
      this.clasificacionSeleccionada.set(clasificacion);
      this.loadClasificacionData(clasificacion);
    } finally {
      this.loadingService.hide();
      this.closeClasificacionModal();
    }
  }

  async onClasificacionLeave() {
    const companiaId = this.clasificacionVentaForm.get('cia')?.value;
    const clavenValue = this.clasificacionVentaForm.get('claven')?.value;
    
    if (!companiaId || !clavenValue) return;

    this.loadingService.show();
    try {
      const clasificacion = await firstValueFrom(this.ccService.validateClasificacionVenta(
        companiaId.toString(), 
        clavenValue
      ));
      if (clasificacion) {
        this.loadClasificacionData(clasificacion);
      } else {
        this.toastService.showWarning('Clasificación no encontrada');
        this.clearClasificacionData();
      }
    } catch (error) {
      this.toastService.showError('Error al validar clasificación');
      console.error(error);
    } finally {
      this.loadingService.hide();
    }
  }

  // ================== MANEJO DE DATOS ==================

  private loadClasificacionData(clasificacion: ClasificacionVentaRecord) {
    this.clasificacionVentaForm.patchValue({
      claven: clasificacion.claven,
      'nombre-cven': clasificacion['nombre-cven'],
      'ventad-cven': clasificacion['ventad-cven'],
      'ventah-cven': clasificacion['ventah-cven'],
      'text-cven': clasificacion['text-cven']
    });
    
    this.isEditMode.set(true);
    this.enableEditableFields();
  }

  private clearClasificacionData() {
    this.clasificacionSeleccionada.set(null);
    this.clasificacionVentaForm.patchValue({
      claven: '',
      'nombre-cven': '',
      'ventad-cven': 0,
      'ventah-cven': 0,
      'text-cven': ''
    });
    this.isEditMode.set(false);
    this.disableEditableFields();
  }

  // ================== OPERACIONES CRUD ==================

  openCreateModal() {
    const companiaId = this.clasificacionVentaForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }
    
    this.createClasificacionForm.reset();
    this.showCreateModal.set(true);
  }

  closeCreateModal() {
    this.showCreateModal.set(false);
  }

  async onCreateSubmit() {
    if (this.createClasificacionForm.invalid) {
      this.toastService.showError('Por favor complete todos los campos requeridos');
      return;
    }

    this.loadingService.show();
    try {
      const companiaId = this.clasificacionVentaForm.get('cia')?.value;
      const formValues = this.createClasificacionForm.value;
      const user = this.authService.user();

      const clasificacionData: ClasificacionVentaRecord = {
        'Agrega-Clav': '',
        cia: companiaId,
        claven: formValues.claven,
        'date-ctrl': new Date().toISOString().split('T')[0],
        'login-ctrl': user?.pcLogin || '',
        'nombre-cven': formValues['nombre-cven'],
        'text-cven': formValues['text-cven'] || '',
        'ventad-cven': formValues['ventad-cven'] || 0,
        'ventah-cven': formValues['ventah-cven'] || 0,
        tparent: user?.pcLogin || ''
      };

      const result = await firstValueFrom(this.ccService.updateClasificacionVenta(clasificacionData));
      
      if (result) {
        this.toastService.showSuccess('Clasificación creada exitosamente');
        this.closeCreateModal();
        this.loadClasificacionData(result);
      } else {
        this.toastService.showError('No se pudo crear la clasificación');
      }
    } catch (error: any) {
      console.error('Error creating clasificacion:', error);
      this.toastService.showError('Error al crear la clasificación');
    } finally {
      this.loadingService.hide();
    }
  }

  async onSubmit() {
    if (this.clasificacionVentaForm.invalid) {
      this.toastService.showError('Por favor complete todos los campos requeridos');
      return;
    }

    this.loadingService.show();
    try {
      const formValues = this.clasificacionVentaForm.getRawValue();
      const user = this.authService.user();

      const clasificacionData: ClasificacionVentaRecord = {
        'Agrega-Clav': '',
        cia: formValues.cia,
        claven: formValues.claven,
        'date-ctrl': new Date().toISOString().split('T')[0],
        'login-ctrl': user?.pcLogin || '',
        'nombre-cven': formValues['nombre-cven'],
        'text-cven': formValues['text-cven'],
        'ventad-cven': formValues['ventad-cven'],
        'ventah-cven': formValues['ventah-cven'],
        tparent: user?.pcLogin || ''
      };

      const result = await firstValueFrom(this.ccService.updateClasificacionVenta(clasificacionData));
      
      if (result) {
        this.toastService.showSuccess('Clasificación actualizada exitosamente');
        this.onClear();
        this.closeClasificacionModal();
        await this.reloadClasificaciones();
        this.cdr.detectChanges();
        this.loadClasificacionData(result);
      } else {
        this.toastService.showError('No se pudo actualizar la clasificación');
      }
    } catch (error: any) {
      console.error('Error updating clasificacion:', error);
      this.toastService.showError('Error al actualizar la clasificación');
    } finally {
      this.loadingService.hide();
    }
  }

  async onDelete() {
    const companiaId = this.clasificacionVentaForm.get('cia')?.value;
    const clavenValue = this.clasificacionVentaForm.get('claven')?.value;
    
    if (!companiaId || !clavenValue) {
      this.toastService.showError('Seleccione una clasificación para eliminar');
      return;
    }

    if (!confirm('¿Está seguro de que desea eliminar esta clasificación de venta?')) {
      return;
    }

    this.loadingService.show();
    try {
      const result = await firstValueFrom(this.ccService.deleteClasificacionVenta(
        companiaId.toString(), 
        clavenValue
      ));
      
      if (result) {
        this.toastService.showSuccess('Clasificación eliminada exitosamente');
        this.onClear();
        this.closeClasificacionModal();
        await this.reloadClasificaciones();
        this.cdr.detectChanges();
      } else {
        this.toastService.showError('No se pudo eliminar la clasificación');
      }
    } catch (error: any) {
      console.error('Error deleting clasificacion:', error);
      this.toastService.showError('Error al eliminar la clasificación');
    } finally {
      this.loadingService.hide();
    }
  }

  onClear() {
    this.clasificacionVentaForm.reset();
    this.clasificacionSeleccionada.set(null);
    this.companiaSeleccionada.set(null);
    this.isEditMode.set(false);
    this.disableEditableFields();
  }

  // ================== CONTROL DE CAMPOS ==================

  private enableEditableFields() {
    this.clasificacionVentaForm.get('nombre-cven')?.enable();
    this.clasificacionVentaForm.get('ventad-cven')?.enable();
    this.clasificacionVentaForm.get('ventah-cven')?.enable();
    this.clasificacionVentaForm.get('text-cven')?.enable();
  }

  private disableEditableFields() {
    this.clasificacionVentaForm.get('nombre-cven')?.disable();
    this.clasificacionVentaForm.get('ventad-cven')?.disable();
    this.clasificacionVentaForm.get('ventah-cven')?.disable();
    this.clasificacionVentaForm.get('text-cven')?.disable();
  }

  // ================== REPORTES ==================

  async onGenerateReport(): Promise<void> {
    const companiaId = this.clasificacionVentaForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía para generar reporte');
      return;
    }

    try {
      this.loadingService.show();
      const fecha = new Date().toISOString().split('T')[0];
      const result = await firstValueFrom(this.ccService.generarReporteClasificacionVenta(
        companiaId.toString(), 
        fecha
      ));
      
      if (result?.response && (result.response.pcArchPDF || result.response.pcArchCSV)) {
        this.reportResponse = result.response;
        this.showReportModal.set(true);
      } else {
        this.toastService.showError('No se pudo generar el reporte');
      }
    } catch (error: any) {
      console.error('Error generating report:', error);
      this.toastService.showError('Error al generar el reporte');
    } finally {
      this.loadingService.hide();
    }
  }

  downloadReportPDF(): void {
    if (!this.reportResponse?.pcArchPDF) {
      this.toastService.showError('No se pudo generar el reporte PDF');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchPDF, 'reporte-clasificacion-venta.pdf', 'application/pdf');
    this.toastService.showSuccess('Reporte PDF descargado exitosamente');
    this.showReportModal.set(false);
  }

  downloadReportCSV(): void {
    if (!this.reportResponse?.pcArchCSV) {
      this.toastService.showError('No se pudo generar el reporte CSV');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchCSV, 'reporte-clasificacion-venta.csv', 'text/csv');
    this.toastService.showSuccess('Reporte CSV descargado exitosamente');
    this.showReportModal.set(false);
  }

  closeReportModal(): void {
    this.showReportModal.set(false);
    this.reportResponse = null;
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error al descargar el archivo:', error);
      this.toastService.showError('Error al descargar el archivo');
    }
  }

  goBack(): void {
    this.router.navigate(['/']);
  }
}