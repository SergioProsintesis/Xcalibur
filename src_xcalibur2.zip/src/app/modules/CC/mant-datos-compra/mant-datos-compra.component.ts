import { Component, OnInit, signal } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MantDatosCompraService } from './mant-datos-compra.service';
import { AuthService } from '../../../core/services/auth.service';
import { Company } from './mant-datos-compra.interface';

@Component({
  selector: 'app-mant-datos-compra',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './mant-datos-compra.component.html',
  styleUrl: './mant-datos-compra.component.css'
})
export class MantDatosCompraComponent implements OnInit {
  form!: FormGroup;
  companies = signal<Company[]>([]);
  isLoading = signal(false);

  constructor(
    private fb: FormBuilder,
    private service: MantDatosCompraService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.loadCompanies();
  }

  private initForm(): void {
    this.form = this.fb.group({
      cia: ['', Validators.required],
      nombre_datos: ['', Validators.required],
      razon_social: ['', Validators.required],
      nit: ['', Validators.required],
      direc_cia: [''],
      telefo_cia: [''],
      fax_cia: ['']
    });
  }

  private async loadCompanies(): Promise<void> {
    try {
      const user = this.authService.user();
      if (user && user.pcLogin && user.pcSuper && user.pcToken) {
        const response = await this.service.getCompanies(user.pcLogin, user.pcSuper, user.pcToken);
        this.companies.set(response.dsRespuesta.tgecias);
      }
    } catch (error) {
      console.error('Error loading companies:', error);
    }
  }

  async onCompanyChange(): Promise<void> {
    try {
      const ciaValue = this.form.get('cia')?.value;
      const user = this.authService.user();
      if (ciaValue && user && user.pcLogin && user.pcSuper && user.pcToken) {
        this.isLoading.set(true);
        const response = await this.service.getLeaveData(ciaValue, user.pcLogin, user.pcSuper, user.pcToken);
        if (response.dsRespuesta.tgecias.length > 0) {
          const data = response.dsRespuesta.tgecias[0];
          this.form.patchValue({
            nombre_datos: data.nombre_datos || '',
            razon_social: data.razon_social || '',
            nit: data.nit || '',
            direc_cia: data.direc_cia || '',
            telefo_cia: data.telefo_cia || '',
            fax_cia: data.fax_cia || ''
          });
        }
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      this.isLoading.set(false);
    }
  }

  async onSave(): Promise<void> {
    if (this.form.invalid) return;
    try {
      this.isLoading.set(true);
      const formValue = this.form.value;
      const data = {
        cia: parseInt(formValue.cia),
        nombre_cia: this.companies().find(c => c.cia === parseInt(formValue.cia))?.nombre_cia || '',
        nombre_datos: formValue.nombre_datos,
        razon_social: formValue.razon_social,
        nit: formValue.nit,
        direc_cia: formValue.direc_cia,
        telefo_cia: formValue.telefo_cia,
        fax_cia: formValue.fax_cia
      };
      await this.service.updateData(data);
      alert('Datos guardados exitosamente');
    } catch (error) {
      console.error('Error saving data:', error);
      alert('Error al guardar');
    } finally {
      this.isLoading.set(false);
    }
  }

  onCancel(): void {
    this.form.reset();
  }
}
