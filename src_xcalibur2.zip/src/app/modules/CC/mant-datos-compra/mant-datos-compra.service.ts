import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { CompanyResponse, PurchaseData, PurchaseResponse } from './mant-datos-compra.interface';

@Injectable({
  providedIn: 'root'
})
export class MantDatosCompraService {
  private apiUrl = 'http://184.168.30.44:8810/XcaliburWeb/rest/ServiciosXcaliburWeb';
  loadingState = signal(false);

  constructor(private http: HttpClient) {}

  async getCompanies(pcLogin: string, pcSuper: string, pcToken: string): Promise<CompanyResponse> {
    this.loadingState.set(true);
    try {
      const params = new HttpParams()
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      return await this.http.get<CompanyResponse>(`${this.apiUrl}/GetCECompanias`, { params }).toPromise() as CompanyResponse;
    } finally {
      this.loadingState.set(false);
    }
  }

  async getLeaveData(pcCompania: string, pcLogin: string, pcSuper: string, pcToken: string): Promise<PurchaseResponse> {
    this.loadingState.set(true);
    try {
      const params = new HttpParams()
        .set('pcCompania', pcCompania)
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      return await this.http.get<PurchaseResponse>(`${this.apiUrl}/GetLeaveCia_fa5001`, { params }).toPromise() as PurchaseResponse;
    } finally {
      this.loadingState.set(false);
    }
  }

  async updateData(data: PurchaseData): Promise<PurchaseResponse> {
    this.loadingState.set(true);
    try {
      const payload = {
        tgecias: [data]
      };
      return await this.http.put<PurchaseResponse>(`${this.apiUrl}/Updategecias_fa5001`, payload).toPromise() as PurchaseResponse;
    } finally {
      this.loadingState.set(false);
    }
  }
}
