export interface CompanyResponse {
  dsRespuesta: {
    tgecias: Company[];
  };
}

export interface Company {
  cia: number;
  nombre_cia: string;
}

export interface PurchaseData {
  cia: number;
  nombre_cia: string;
  nombre_datos: string;
  razon_social: string;
  nit: string;
  direc_cia: string;
  telefo_cia: string;
  fax_cia: string;
}

export interface PurchaseResponse {
  dsRespuesta: {
    tgecias: PurchaseData[];
  };
}
