export interface CompaniaRecord {
  'Agrega-Cias': string;
  'cia': number;
  'ClaveResolucion': string;
  'date-ctrl': string;
  'direc-cia': string;
  'fax-cia': string;
  'login-ctrl': string;
  'nombre-cia': string;
  'nit': string;
  'telefo-cia': string;
  'text-cia': string;
  'tparent': string;
}

export interface RetencionRecord {
  'Agrega-Tabr': string;
  'auxiliar': number;
  'nombre-aux': string;
  'centro': number;
  'nombre-cen': string;
  'cia': number;
  'nombre-cia': string;
  'cuenta': string;
  'nombre-cta': string;
  'date-ctrl': string;
  'login-ctrl': string;
  'nombre-tret': string;
  'porcen-tret': number;
  'reten-tret': number;
  'text-tret': string;
  'ubicacion': number;
  'nombre-ubic': string;
  'tparent': string;
}

export interface CuentaRecord {
  'Agrega-Cont': string;
  'cuenta': string;
  'nombre-cta': string;
  'date-ctrl': string;
  'login-ctrl': string;
  'text-conta': string;
  'tparent': string;
}

export interface UbicacionRecord {
  'Agrega-Ubic': string;
  'ubicacion': number;
  'nombre-ubic': string;
  'date-ctrl': string;
  'login-ctrl': string;
  'text-ubic': string;
  'tparent': string;
}

export interface CentroRecord {
  'Agrega-Cenc': string;
  'centro': number;
  'nombre-cen': string;
  'date-ctrl': string;
  'login-ctrl': string;
  'text-cenc': string;
  'tparent': string;
}

export interface AuxiliarRecord {
  'Agrega-Maea': string;
  'auxiliar': number;
  'nombre-aux': string;
  'cuenta': string;
  'date-ctrl': string;
  'login-ctrl': string;
  'text-maea': string;
  'tparent': string;
}

export interface CompaniaResponse {
  dsRespuesta: {
    tgecias: CompaniaRecord[];
  };
}

export interface RetencionResponse {
  dsRespuesta: {
    tcctabret: RetencionRecord[];
  };
}

export interface CuentaResponse {
  dsRespuesta: {
    tcgcontab: CuentaRecord[];
  };
}

export interface UbicacionResponse {
  dsRespuesta: {
    tcgubicac: UbicacionRecord[];
  };
}

export interface CentroResponse {
  dsRespuesta: {
    tgecencos: CentroRecord[];
  };
}

export interface AuxiliarResponse {
  dsRespuesta: {
    tcgmaeaux: AuxiliarRecord[];
  };
}
