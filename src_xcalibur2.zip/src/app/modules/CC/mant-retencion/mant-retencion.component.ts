import { Component, inject, signal, OnInit, computed, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { AuthService } from '../../../core/services/auth.service';
import { CCService } from '../../../core/services/cc.service';
import { CctabretService } from './cctabret.service';
import { CompaniaRecord, RetencionRecord } from './cctabret.interface';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';

export interface RetencionModalRecord {
  'reten-tret': number;
  'nombre-tret': string;
  'porcen-tret': number;
  cuenta: number;
  'nombre-cta': string;
  ubicacion?: number;
  'nombre-ubic'?: string;
  centro?: number;
  'nombre-cen'?: string;
  auxiliar?: number;
  'nombre-aux'?: string;
  'text-tret'?: string;
}

@Component({
  selector: 'app-mant-retencion',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent],
  templateUrl: './mant-retencion.component.html',
  styleUrls: ['./mant-retencion.component.css']
})
export class MantRetencionComponent implements OnInit {
  private fb = inject(FormBuilder);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private ccService = inject(CCService);
  private cctabretService = inject(CctabretService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private authService = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);

  retencionForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Retención`);
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  retencionSeleccionada = signal<RetencionRecord | null>(null);

  // Control de modales
  showCompaniaModal = signal(false);
  showRetencionModal = signal(false);
  showCuentaModal = signal(false);
  showCreateModal = signal(false);
  showReportModal = signal(false);
  isEditMode = signal(false);
  retencionesList = signal<RetencionRecord[]>([]);
  cuentasList = signal<any[]>([]);
  reportResponse: any = null;
  
  // Filtros
  retencionFilter = signal<string>('');
  cuentaFilter = signal<string>('');
  
  // Filtered lists
  filteredRetenciones = computed(() => {
    const filter = this.retencionFilter().toLowerCase();
    if (!filter) return this.retencionesList();
    return this.retencionesList().filter(r => 
      r['nombre-tret'].toLowerCase().includes(filter) || 
      String(r['reten-tret']).includes(filter)
    );
  });

  filteredCuentas = computed(() => {
    const filter = this.cuentaFilter().toLowerCase();
    if (!filter) return this.cuentasList();
    return this.cuentasList().filter(c => 
      c['nombre-cta'].toLowerCase().includes(filter) || 
      String(c.cuenta).includes(filter)
    );
  });
  
  // Formulario de creación
  createRetencionForm!: FormGroup;

  ngOnInit() {
    console.log('🔄 MantRetencionComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    this.loadCompanias();
    console.log('✅ MantRetencionComponent inicializado correctamente');
  }

  private initializeForm(): void {
    this.retencionForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      'reten-tret': ['', [Validators.required]],
      'nombre-tret': [''],
      cuenta: ['', [Validators.required, Validators.min(1)]],
      'nombre-cta': [{ value: '', disabled: true }],
      ubicacion: [''],
      'nombre-ubic': [{ value: '', disabled: true }],
      centro: [''],
      'nombre-cen': [{ value: '', disabled: true }],
      auxiliar: [''],
      'nombre-aux': [{ value: '', disabled: true }],
      'porcen-tret': ['', [Validators.required, Validators.min(0), Validators.max(100)]],
      'text-tret': ['']
    });

    this.createRetencionForm = this.fb.group({
      'reten-tret': ['', [Validators.required, Validators.min(1)]],
      'nombre-tret': ['', [Validators.required]],
      'porcen-tret': ['', [Validators.required, Validators.min(0), Validators.max(100)]],
      'text-tret': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.retencionForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.retencionForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    if (errors['max']) return `Valor máximo: ${errors['max'].max}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  async loadCompanias(): Promise<void> {
    try {
      this.loadingState.set(true);
      const response = await this.cctabretService.getCECompanias().toPromise();
      if (response?.dsRespuesta?.tgecias) {
        // Datos de compañías estarán disponibles en el modal
      }
    } catch (error) {
      console.error('Error loading companies:', error);
      this.toastService.showError('Error al cargar compañías');
    } finally {
      this.loadingState.set(false);
    }
  }

  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.retencionForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.limpiarRetencion();
    this.loadRetenciones(compania.cia);
    console.log('✅ Compañía seleccionada:', compania.cia, '- Retenciones cargadas:', this.retencionesList().length);
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.retencionForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.cctabretService.getLeaveCompania(ciaValue).toPromise();
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.retencionForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
        await this.loadRetenciones(ciaValue);
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.retencionForm.patchValue({ 'nombre-cia': '' });
    this.retencionesList.set([]);
  }

  // ==================== RETENCIONES ====================
  private async loadRetenciones(pcCompania: number): Promise<void> {
    try {
      const response = await this.cctabretService.getCERetenciones(pcCompania).toPromise();
      if (response?.dsRespuesta?.tcctabret) {
        this.retencionesList.set(response.dsRespuesta.tcctabret);
      }
    } catch (error) {
      console.error('Error loading retentions:', error);
    }
  }

  buscarRetencion(): void {
    console.log('🔍 Buscando retención...');
    const ciaValue = this.retencionForm.get('cia')?.value;
    if (!ciaValue) {
      this.toastService.showWarning('Seleccione una compañía primero');
      return;
    }
    console.log('📋 Retenciones disponibles:', this.retencionesList());
    this.showRetencionModal.set(true);
    console.log('✅ Modal de retención abierto');
  }

  closeRetencionModal(): void {
    this.showRetencionModal.set(false);
  }

  onRetencionSelected(retencion: RetencionRecord): void {
    this.retencionSeleccionada.set(retencion);
    this.retencionForm.patchValue({
      'reten-tret': retencion['reten-tret'],
      'nombre-tret': retencion['nombre-tret'],
      cuenta: retencion.cuenta,
      'nombre-cta': retencion['nombre-cta'],
      ubicacion: retencion.ubicacion,
      'nombre-ubic': retencion['nombre-ubic'],
      centro: retencion.centro,
      'nombre-cen': retencion['nombre-cen'],
      auxiliar: retencion.auxiliar,
      'nombre-aux': retencion['nombre-aux'],
      'porcen-tret': retencion['porcen-tret'],
      'text-tret': retencion['text-tret']
    });
    this.closeRetencionModal();
    this.isEditMode.set(true);
    
    // Cargar descripciones de campos relacionados
    this.onCuentaLeave();
    this.onUbicacionLeave();
    this.onCentroLeave();
    this.onAuxiliarLeave();
  }

  async onRetencionLeave(): Promise<void> {
    const ciaValue = this.retencionForm.get('cia')?.value;
    const retenValue = this.retencionForm.get('reten-tret')?.value;

    if (!ciaValue || !retenValue) {
      this.limpiarRetencion();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.cctabretService.getLeaveRetencion(ciaValue, retenValue).toPromise();
      
      if (!response?.dsRespuesta?.tcctabret || response.dsRespuesta.tcctabret.length === 0) {
        this.limpiarRetencion();
        this.toastService.showWarning('Retención no válida');
        return;
      }

      const retencionData = response.dsRespuesta.tcctabret[0];
      this.retencionSeleccionada.set(retencionData);
      this.isEditMode.set(true);

      this.retencionForm.patchValue({
        'nombre-tret': retencionData['nombre-tret'],
        cuenta: retencionData.cuenta,
        ubicacion: retencionData.ubicacion,
        centro: retencionData.centro,
        auxiliar: retencionData.auxiliar,
        'porcen-tret': retencionData['porcen-tret'],
        'text-tret': retencionData['text-tret']
      });

      // Actualizar campos disabled directamente
      const disabledFields = [
        { control: 'nombre-cta', value: retencionData['nombre-cta'] },
        { control: 'nombre-ubic', value: retencionData['nombre-ubic'] },
        { control: 'nombre-cen', value: retencionData['nombre-cen'] },
        { control: 'nombre-aux', value: retencionData['nombre-aux'] }
      ];
      
      disabledFields.forEach(field => {
        const control = this.retencionForm.get(field.control);
        control?.enable();
        control?.setValue(field.value);
        control?.disable();
      });

      // Cargar descripciones de campos relacionados
      await this.onCuentaLeave();
      await this.onUbicacionLeave();
      await this.onCentroLeave();
      await this.onAuxiliarLeave();
    } catch (error) {
      console.error('Error validating retention:', error);
      this.toastService.showError('Error al validar retención');
      this.limpiarRetencion();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarRetencion(): void {
    this.retencionSeleccionada.set(null);
    this.isEditMode.set(false);
    this.retencionForm.patchValue({
      'reten-tret': '',
      'nombre-tret': '',
      cuenta: '',
      ubicacion: '',
      centro: '',
      auxiliar: '',
      'porcen-tret': '',
      'text-tret': ''
    });
    
    // Limpiar campos disabled
    const fieldsToClean = ['nombre-cta', 'nombre-ubic', 'nombre-cen', 'nombre-aux'];
    fieldsToClean.forEach(field => {
      const control = this.retencionForm.get(field);
      control?.enable();
      control?.setValue('');
      control?.disable();
    });
  }

  // ==================== MODAL DE CUENTAS ====================
  buscarCuenta(): void {
    console.log('🔍 Buscando cuenta...');
    const ciaValue = this.retencionForm.get('cia')?.value;
    if (!ciaValue) {
      this.toastService.showWarning('Seleccione una compañía primero');
      return;
    }
    console.log('📋 Cargando cuentas para compañía:', ciaValue);
    this.loadCuentas(ciaValue);
    this.showCuentaModal.set(true);
    console.log('✅ Modal de cuentas abierto');
  }

  closeCuentaModal(): void {
    this.showCuentaModal.set(false);
  }

  onCuentaSelected(cuenta: any): void {
    this.retencionForm.patchValue({
      cuenta: cuenta.cuenta
    });
    // Actualizar directamente el campo disabled
    const nombreCtaControl = this.retencionForm.get('nombre-cta');
    nombreCtaControl?.enable();
    nombreCtaControl?.setValue(cuenta['nombre-cta']);
    nombreCtaControl?.disable();
    this.closeCuentaModal();
    // Cargar descripción adicional vía API
    this.onCuentaLeave();
  }

  private async loadCuentas(pcCompania: number): Promise<void> {
    try {
      const response = await this.cctabretService.getCECuentas(pcCompania).toPromise();
      if (response?.dsRespuesta?.tcgcontab) {
        this.cuentasList.set(response.dsRespuesta.tcgcontab);
      }
    } catch (error) {
      console.error('Error loading accounts:', error);
    }
  }

  async onCuentaLeave(): Promise<void> {
    const ciaValue = this.retencionForm.get('cia')?.value;
    const cuentaValue = this.retencionForm.get('cuenta')?.value;

    if (!ciaValue || !cuentaValue) {
      this.retencionForm.patchValue({ 'nombre-cta': '' });
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.cctabretService.getLeaveCuenta(ciaValue, cuentaValue).toPromise();
      
      if (!response) {
        this.retencionForm.patchValue({ 'nombre-cta': '' });
        return;
      }

      // Buscar el nombre de la cuenta en la estructura de respuesta
      let nombreCta = '';
      
      if (response?.dsRespuesta?.tcgcontab?.[0]) {
        nombreCta = response.dsRespuesta.tcgcontab[0]['nombre-cta'];
      }

      if (!nombreCta && response?.dsRespuesta) {
        // Si aún no encontramos el nombre, buscar en el objeto directamente
        const valores = Object.values(response.dsRespuesta);
        for (const valor of valores) {
          if (Array.isArray(valor) && valor.length > 0 && valor[0]['nombre-cta']) {
            nombreCta = valor[0]['nombre-cta'];
            break;
          }
        }
      }

      const nombreCtaControl = this.retencionForm.get('nombre-cta');
      
      // Habilitar temporalmente para actualizar el valor
      nombreCtaControl?.enable();
      nombreCtaControl?.setValue(nombreCta || '');
      nombreCtaControl?.disable();
    } catch (error) {
      console.error('Error validating account:', error);
      this.retencionForm.patchValue({ 'nombre-cta': '' });
    } finally {
      this.loadingState.set(false);
    }
  }

  async onUbicacionLeave(): Promise<void> {
    const ciaValue = this.retencionForm.get('cia')?.value;
    const cuentaValue = this.retencionForm.get('cuenta')?.value;
    const ubicacionValue = this.retencionForm.get('ubicacion')?.value;

    if (!ciaValue || !cuentaValue || !ubicacionValue) {
      const nombreUbicControl = this.retencionForm.get('nombre-ubic');
      nombreUbicControl?.enable();
      nombreUbicControl?.setValue('');
      nombreUbicControl?.disable();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.cctabretService.getLeaveUbicacion(ciaValue, cuentaValue, ubicacionValue).toPromise();
      
      if (!response?.dsRespuesta?.tcgubicac || response.dsRespuesta.tcgubicac.length === 0) {
        const nombreUbicControl = this.retencionForm.get('nombre-ubic');
        nombreUbicControl?.enable();
        nombreUbicControl?.setValue('');
        nombreUbicControl?.disable();
        return;
      }

      const ubicacionData = response.dsRespuesta.tcgubicac[0];
      const nombreUbicControl = this.retencionForm.get('nombre-ubic');
      nombreUbicControl?.enable();
      nombreUbicControl?.setValue(ubicacionData['nombre-ubic']);
      nombreUbicControl?.disable();
    } catch (error) {
      console.error('Error validating location:', error);
      const nombreUbicControl = this.retencionForm.get('nombre-ubic');
      nombreUbicControl?.enable();
      nombreUbicControl?.setValue('');
      nombreUbicControl?.disable();
    } finally {
      this.loadingState.set(false);
    }
  }

  async onCentroLeave(): Promise<void> {
    const ciaValue = this.retencionForm.get('cia')?.value;
    const cuentaValue = this.retencionForm.get('cuenta')?.value;
    const centroValue = this.retencionForm.get('centro')?.value;

    if (!ciaValue || !cuentaValue || !centroValue) {
      const nombreCenControl = this.retencionForm.get('nombre-cen');
      nombreCenControl?.enable();
      nombreCenControl?.setValue('');
      nombreCenControl?.disable();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.cctabretService.getLeavecentro(ciaValue, cuentaValue, centroValue).toPromise();
      
      if (!response?.dsRespuesta?.tgecencos || response.dsRespuesta.tgecencos.length === 0) {
        const nombreCenControl = this.retencionForm.get('nombre-cen');
        nombreCenControl?.enable();
        nombreCenControl?.setValue('');
        nombreCenControl?.disable();
        return;
      }

      const centroData = response.dsRespuesta.tgecencos[0];
      const nombreCenControl = this.retencionForm.get('nombre-cen');
      nombreCenControl?.enable();
      nombreCenControl?.setValue(centroData['nombre-cen']);
      nombreCenControl?.disable();
    } catch (error) {
      console.error('Error validating cost center:', error);
      const nombreCenControl = this.retencionForm.get('nombre-cen');
      nombreCenControl?.enable();
      nombreCenControl?.setValue('');
      nombreCenControl?.disable();
    } finally {
      this.loadingState.set(false);
    }
  }

  async onAuxiliarLeave(): Promise<void> {
    const ciaValue = this.retencionForm.get('cia')?.value;
    const cuentaValue = this.retencionForm.get('cuenta')?.value;
    const auxiliarValue = this.retencionForm.get('auxiliar')?.value;

    if (!ciaValue || !cuentaValue || !auxiliarValue) {
      const nombreAuxControl = this.retencionForm.get('nombre-aux');
      nombreAuxControl?.enable();
      nombreAuxControl?.setValue('');
      nombreAuxControl?.disable();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.cctabretService.getLeaveAuxiliar(ciaValue, cuentaValue, auxiliarValue).toPromise();
      
      if (!response?.dsRespuesta?.tcgmaeaux || response.dsRespuesta.tcgmaeaux.length === 0) {
        const nombreAuxControl = this.retencionForm.get('nombre-aux');
        nombreAuxControl?.enable();
        nombreAuxControl?.setValue('');
        nombreAuxControl?.disable();
        return;
      }

      const auxiliarData = response.dsRespuesta.tcgmaeaux[0];
      const nombreAuxControl = this.retencionForm.get('nombre-aux');
      nombreAuxControl?.enable();
      nombreAuxControl?.setValue(auxiliarData['nombre-aux']);
      nombreAuxControl?.disable();
    } catch (error) {
      console.error('Error validating auxiliary:', error);
      const nombreAuxControl = this.retencionForm.get('nombre-aux');
      nombreAuxControl?.enable();
      nombreAuxControl?.setValue('');
      nombreAuxControl?.disable();
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== ACCIONES ====================
  openCreateModal(): void {
    const ciaValue = this.retencionForm.get('cia')?.value;
    if (!ciaValue) {
      this.toastService.showWarning('Seleccione una compañía primero');
      return;
    }
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
  }

  onCreateSubmit(): void {
    if (!this.createRetencionForm.valid) {
      this.toastService.showError('Complete los campos requeridos');
      this.createRetencionForm.markAllAsTouched();
      return;
    }

    const companiaId = this.retencionForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Seleccione una compañía');
      return;
    }

    try {
      this.loadingState.set(true);
      const formValue = this.createRetencionForm.value;
      const authUser = this.authService.user();
      
      const retencion: RetencionRecord = {
        cia: companiaId,
        'nombre-cia': this.retencionForm.get('nombre-cia')?.value || '',
        'reten-tret': formValue['reten-tret'],
        'nombre-tret': formValue['nombre-tret'],
        'porcen-tret': formValue['porcen-tret'],
        'text-tret': formValue['text-tret'] || '',
        cuenta: '',
        'nombre-cta': '',
        auxiliar: 0,
        'nombre-aux': '',
        centro: 0,
        'nombre-cen': '',
        ubicacion: 0,
        'nombre-ubic': '',
        'Agrega-Tabr': '',
        'date-ctrl': new Date().toISOString().split('T')[0],
        'login-ctrl': authUser?.pcLogin || '',
        tparent: authUser?.pcSuper || ''
      };

      this.cctabretService.updateRetencion([retencion]).subscribe({
        next: (response) => {
          this.loadingState.set(false);
          if (response?.dsRespuesta?.tcctabret) {
            this.toastService.showSuccess('Retención creada exitosamente');
            this.closeCreateModal();
            this.limpiarRetencion();
            // Recargar lista de retenciones
            this.loadRetenciones(companiaId);
          } else {
            this.toastService.showError('No se pudo crear la retención');
          }
        },
        error: () => {
          this.loadingState.set(false);
          this.toastService.showError('Error al crear la retención');
        }
      });
    } catch (error) {
      this.loadingState.set(false);
      this.toastService.showError('Error al procesar la retención');
    }
  }

  async onSubmit(): Promise<void> {
    if (!this.retencionForm.valid) {
      this.toastService.showError('Formulario inválido');
      return;
    }

    try {
      this.loadingState.set(true);
      const formValue = this.retencionForm.getRawValue();
      const authUser = this.authService.user();
      
      const payload: RetencionRecord[] = [{
        'Agrega-Tabr': '',
        auxiliar: formValue.auxiliar || 0,
        'nombre-aux': formValue['nombre-aux'] || '',
        centro: formValue.centro || 0,
        'nombre-cen': formValue['nombre-cen'] || '',
        cia: formValue.cia,
        'nombre-cia': formValue['nombre-cia'],
        cuenta: formValue.cuenta,
        'nombre-cta': formValue['nombre-cta'],
        'date-ctrl': new Date().toISOString().split('T')[0],
        'login-ctrl': authUser?.pcLogin || '',
        'nombre-tret': formValue['nombre-tret'],
        'porcen-tret': formValue['porcen-tret'],
        'reten-tret': formValue['reten-tret'],
        'text-tret': formValue['text-tret'],
        ubicacion: formValue.ubicacion || 0,
        'nombre-ubic': formValue['nombre-ubic'] || '',
        tparent: authUser?.pcSuper || ''
      }];

      const response = await this.cctabretService.updateRetencion(payload).toPromise();
      
      if (response?.dsRespuesta?.tcctabret) {
        this.toastService.showSuccess('Retención guardada correctamente');
        this.onClear();
        this.closeRetencionModal();
        await this.loadRetenciones(formValue.cia);
        this.cdr.detectChanges();
      } else {
        this.toastService.showError('Error al guardar retención');
      }
    } catch (error) {
      console.error('Error updating retention:', error);
      this.toastService.showError('Error al guardar retención');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onDelete(): Promise<void> {
    const ciaValue = this.retencionForm.get('cia')?.value;
    const retenValue = this.retencionForm.get('reten-tret')?.value;

    if (!ciaValue || !retenValue) {
      this.toastService.showError('Seleccione una retención válida');
      return;
    }

    if (!confirm('¿Está seguro de que desea eliminar esta retención?')) {
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.cctabretService.deleteRetencion(ciaValue, retenValue).toPromise();
      
      if (response?.dsRespuesta) {
        this.toastService.showSuccess('Retención eliminada correctamente');
        this.onClear();
        this.closeRetencionModal();
        await this.loadRetenciones(ciaValue);
        this.cdr.detectChanges();
      } else {
        this.toastService.showError('Error al eliminar retención');
      }
    } catch (error) {
      console.error('Error deleting retention:', error);
      this.toastService.showError('Error al eliminar retención');
    } finally {
      this.loadingState.set(false);
    }
  }

  onClear(): void {
    const ciaValue = this.retencionForm.get('cia')?.value;
    this.retencionForm.reset({ cia: ciaValue });
    this.limpiarRetencion();
    this.toastService.showInfo('Formulario limpiado');
  }

  onGenerateReport(format: string): void {
    const companiaId = this.retencionForm.get('cia')?.value;
    const pcFecha = new Date().toISOString().split('T')[0];

    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía');
      return;
    }

    this.loadingService.show();

    this.ccService.generarReporteRetencion(companiaId.toString(), pcFecha).subscribe({
      next: (response) => {
        this.loadingService.hide();
        if (response?.pcArchPDF || response?.pcArchCSV) {
          this.reportResponse = response;
          this.showReportModal.set(true);
        } else {
          this.toastService.showError('No se pudo generar el reporte');
        }
      },
      error: (err) => {
        this.loadingService.hide();
        this.toastService.showError('Error al generar el reporte');
        console.error('Error generarReporteRetencion:', err);
      }
    });
  }

  downloadReportPDF(): void {
    if (this.reportResponse?.pcArchPDF) {
      this.downloadFile(this.reportResponse.pcArchPDF, 'Retencion_Reporte.pdf', 'application/pdf');
      this.showReportModal.set(false);
    }
  }

  downloadReportCSV(): void {
    if (this.reportResponse?.pcArchCSV) {
      this.downloadFile(this.reportResponse.pcArchCSV, 'Retencion_Reporte.csv', 'text/csv');
      this.showReportModal.set(false);
    }
  }

  closeReportModal(): void {
    this.showReportModal.set(false);
    this.reportResponse = null;
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    // Mock download - in real app would convert base64 to blob
    const link = document.createElement('a');
    link.href = `data:${mimeType};base64,${base64Data}`;
    link.download = filename;
    link.click();
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }

  // Helper methods for template events
  onRetencionFilterChange(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.retencionFilter.set(value);
  }

  onCuentaFilterChange(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.cuentaFilter.set(value);
  }
}
