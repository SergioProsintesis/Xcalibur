import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../core/services/auth.service';
import {
  CompaniaResponse,
  RetencionResponse,
  CuentaResponse,
  UbicacionResponse,
  CentroResponse,
  AuxiliarResponse,
  RetencionRecord
} from './cctabret.interface';

@Injectable({
  providedIn: 'root'
})
export class CctabretService {
  constructor(private http: HttpClient, private authService: AuthService) {}

  private getAuthParams() {
    const user = this.authService.user();
    return {
      pcLogin: user?.pcLogin || '',
      pcSuper: user?.pcSuper || '',
      pcToken: user?.pcToken || ''
    };
  }

  getCECompanias(): Observable<CompaniaResponse | null> {
    const auth = this.getAuthParams();
    const url = `${environment.apiUrl}/GetCECompanias?pcLogin=${encodeURIComponent(auth.pcLogin)}&pcSuper=${encodeURIComponent(auth.pcSuper)}&pcToken=${encodeURIComponent(auth.pcToken)}`;

    return this.http.get<CompaniaResponse>(url).pipe(
      catchError(error => {
        console.error('Error fetching companies:', error);
        return of(null);
      })
    );
  }

  getLeaveCompania(pcCompania: number): Observable<CompaniaResponse | null> {
    const auth = this.getAuthParams();
    const url = `${environment.apiUrl}/GetLeaveGEciasCxC?pcCompania=${pcCompania}&pcLogin=${encodeURIComponent(auth.pcLogin)}&pcSuper=${encodeURIComponent(auth.pcSuper)}&pcToken=${encodeURIComponent(auth.pcToken)}`;

    return this.http.get<CompaniaResponse>(url).pipe(
      catchError(error => {
        console.error('Error validating company:', error);
        return of(null);
      })
    );
  }

  getCERetenciones(pcCompania: number): Observable<RetencionResponse | null> {
    const auth = this.getAuthParams();
    const url = `${environment.apiUrl}/GetCEcctabret_cc0019?pcCompania=${pcCompania}&pcLogin=${encodeURIComponent(auth.pcLogin)}&pcSuper=${encodeURIComponent(auth.pcSuper)}&pcToken=${encodeURIComponent(auth.pcToken)}`;

    return this.http.get<RetencionResponse>(url).pipe(
      catchError(error => {
        console.error('Error fetching retentions:', error);
        return of(null);
      })
    );
  }

  getLeaveRetencion(pcCompania: number, pcRetenTret: number): Observable<RetencionResponse | null> {
    const auth = this.getAuthParams();
    const url = `${environment.apiUrl}/GetLeaveReten-tret_cc0049?pcCompania=${pcCompania}&pcRetenTret=${pcRetenTret}&pcLogin=${encodeURIComponent(auth.pcLogin)}&pcSuper=${encodeURIComponent(auth.pcSuper)}&pcToken=${encodeURIComponent(auth.pcToken)}`;

    return this.http.get<RetencionResponse>(url).pipe(
      catchError(error => {
        console.error('Error validating retention:', error);
        return of(null);
      })
    );
  }

  getCECuentas(pcCompania: number): Observable<CuentaResponse | null> {
    const auth = this.getAuthParams();
    const url = `${environment.apiUrl}/GetCECuentaCCxC?pcCompania=${pcCompania}&pcLogin=${encodeURIComponent(auth.pcLogin)}&pcSuper=${encodeURIComponent(auth.pcSuper)}&pcToken=${encodeURIComponent(auth.pcToken)}`;

    return this.http.get<CuentaResponse>(url).pipe(
      catchError(error => {
        console.error('Error fetching accounts:', error);
        return of(null);
      })
    );
  }

  getLeaveCuenta(pcCompania: number, pcCuentaC: string): Observable<CuentaResponse | null> {
    const auth = this.getAuthParams();
    const url = `${environment.apiUrl}/GetLeaveCuentaCCxC?pcCompania=${pcCompania}&pcCuentaC=${encodeURIComponent(pcCuentaC)}&pcLogin=${encodeURIComponent(auth.pcLogin)}&pcSuper=${encodeURIComponent(auth.pcSuper)}&pcToken=${encodeURIComponent(auth.pcToken)}`;

    return this.http.get<CuentaResponse>(url).pipe(
      catchError(error => {
        console.error('Error validating account:', error);
        return of(null);
      })
    );
  }

  getCEUbicaciones(pcCompania: number): Observable<UbicacionResponse | null> {
    const auth = this.getAuthParams();
    const url = `${environment.apiUrl}/GetCEUbicacionCxC?pcCompania=${pcCompania}&pcLogin=${encodeURIComponent(auth.pcLogin)}&pcSuper=${encodeURIComponent(auth.pcSuper)}&pcToken=${encodeURIComponent(auth.pcToken)}`;

    return this.http.get<UbicacionResponse>(url).pipe(
      catchError(error => {
        console.error('Error fetching locations:', error);
        return of(null);
      })
    );
  }

  getLeaveUbicacion(pcCompania: number, pcCuentaC: string, pcUbicacion: number): Observable<UbicacionResponse | null> {
    const auth = this.getAuthParams();
    const url = `${environment.apiUrl}/GetLeaveUbicacionCxC?pcCompania=${pcCompania}&pcCuentaC=${encodeURIComponent(pcCuentaC)}&pcUbicacion=${pcUbicacion}&pcLogin=${encodeURIComponent(auth.pcLogin)}&pcSuper=${encodeURIComponent(auth.pcSuper)}&pcToken=${encodeURIComponent(auth.pcToken)}`;

    return this.http.get<UbicacionResponse>(url).pipe(
      catchError(error => {
        console.error('Error validating location:', error);
        return of(null);
      })
    );
  }

  getCECentros(pcCompania: number): Observable<CentroResponse | null> {
    const auth = this.getAuthParams();
    const url = `${environment.apiUrl}/GetCECentroCCxC?pcCompania=${pcCompania}&pcLogin=${encodeURIComponent(auth.pcLogin)}&pcSuper=${encodeURIComponent(auth.pcSuper)}&pcToken=${encodeURIComponent(auth.pcToken)}`;

    return this.http.get<CentroResponse>(url).pipe(
      catchError(error => {
        console.error('Error fetching cost centers:', error);
        return of(null);
      })
    );
  }

  getLeavecentro(pcCompania: number, pcCuentaC: string, pcCentro: number): Observable<CentroResponse | null> {
    const auth = this.getAuthParams();
    const url = `${environment.apiUrl}/GetLeaveCentroCCxC?pcCompania=${pcCompania}&pcCuentaC=${encodeURIComponent(pcCuentaC)}&pcCentro=${pcCentro}&pcLogin=${encodeURIComponent(auth.pcLogin)}&pcSuper=${encodeURIComponent(auth.pcSuper)}&pcToken=${encodeURIComponent(auth.pcToken)}`;

    return this.http.get<CentroResponse>(url).pipe(
      catchError(error => {
        console.error('Error validating cost center:', error);
        return of(null);
      })
    );
  }

  getCEAuxiliares(pcCompania: number): Observable<AuxiliarResponse | null> {
    const auth = this.getAuthParams();
    const url = `${environment.apiUrl}/GetCEAuxiliarCxC?pcCompania=${pcCompania}&pcLogin=${encodeURIComponent(auth.pcLogin)}&pcSuper=${encodeURIComponent(auth.pcSuper)}&pcToken=${encodeURIComponent(auth.pcToken)}`;

    return this.http.get<AuxiliarResponse>(url).pipe(
      catchError(error => {
        console.error('Error fetching auxiliaries:', error);
        return of(null);
      })
    );
  }

  getLeaveAuxiliar(pcCompania: number, pcCuentaC: string, pcAuxiliar: number): Observable<AuxiliarResponse | null> {
    const auth = this.getAuthParams();
    const url = `${environment.apiUrl}/GetLeaveAuxiliarCxC?pcCompania=${pcCompania}&pcCuentaC=${encodeURIComponent(pcCuentaC)}&pcAuxiliar=${pcAuxiliar}&pcLogin=${encodeURIComponent(auth.pcLogin)}&pcSuper=${encodeURIComponent(auth.pcSuper)}&pcToken=${encodeURIComponent(auth.pcToken)}`;

    return this.http.get<AuxiliarResponse>(url).pipe(
      catchError(error => {
        console.error('Error validating auxiliary:', error);
        return of(null);
      })
    );
  }

  updateRetencion(payload: RetencionRecord[]): Observable<RetencionResponse | null> {
    const auth = this.getAuthParams();
    const body = { tcctabret: payload };
    const url = `${environment.apiUrl}/Updatecctabret_cc0049?pcLogin=${encodeURIComponent(auth.pcLogin)}&pcSuper=${encodeURIComponent(auth.pcSuper)}&pcToken=${encodeURIComponent(auth.pcToken)}`;

    return this.http.put<RetencionResponse>(url, body).pipe(
      catchError(error => {
        console.error('Error updating retention:', error);
        return of(null);
      })
    );
  }

  deleteRetencion(pcCompania: number, pcRetenTret: number): Observable<RetencionResponse | null> {
    const auth = this.getAuthParams();
    const url = `${environment.apiUrl}/Delcctabret_cc0049?pcCompania=${pcCompania}&pcRetenTret=${pcRetenTret}&pcLogin=${encodeURIComponent(auth.pcLogin)}&pcSuper=${encodeURIComponent(auth.pcSuper)}&pcToken=${encodeURIComponent(auth.pcToken)}`;

    return this.http.delete<RetencionResponse>(url).pipe(
      catchError(error => {
        console.error('Error deleting retention:', error);
        return of(null);
      })
    );
  }
}
