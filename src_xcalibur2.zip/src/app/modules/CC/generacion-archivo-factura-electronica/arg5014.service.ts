import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../core/services/auth.service';
import { ARG5014Response } from './arg5014.interface';

@Injectable({
  providedIn: 'root'
})
export class Arg5014Service {
  private http = inject(HttpClient);
  private auth = inject(AuthService);

  // ==================== CONSULTAS EMERGENTES ====================

  /**
   * Obtiene lista de compañías
   */
  getCECompanias(): Observable<ARG5014Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECompanias?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<ARG5014Response>(url);
  }

  /**
   * Obtiene compañía en evento Leave
   */
  getLeaveGEcias(): Observable<ARG5014Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveGEcias?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<ARG5014Response>(url);
  }

  // ==================== CONSULTAS ESPECIALIZADAS ====================

  /**
   * Obtiene generación de archivo de facturación electrónica
   * @param pcCompania Código de compañía
   * @param pcFechaD Fecha desde (YYYY-MM-DD)
   * @param pcFechaH Fecha hasta (YYYY-MM-DD)
   */
  getARG5014(pcCompania: number, pcFechaD: string, pcFechaH: string): Observable<ARG5014Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetARG5014?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcFechaD=${encodeURIComponent(pcFechaD)}&pcFechaH=${encodeURIComponent(pcFechaH)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<ARG5014Response>(url);
  }
}
