import { Component, OnDestroy, OnInit, signal, computed, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Observable, Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';

import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { ModalService } from '../../../core/services/modal.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { Arg5014Service } from './arg5014.service';
import { CompaniaRecord, ARG5014Response } from './arg5014.interface';

@Component({
  selector: 'app-arg5014',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, CompaniaModalComponent],
  templateUrl: './arg5014.component.html',
  styleUrls: ['./arg5014.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class Arg5014Component implements OnInit, OnDestroy {
  parseInt = parseInt;
  form: FormGroup;
  searchForm: FormGroup;
  isLoading = signal(false);
  isGeneratingReport = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  showCompaniaModal = signal(false);
  
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Generación de Archivo de Facturación Electrónica`);
  
  companiasList = signal<CompaniaRecord[]>([]);
  filteredCompaniasList = signal<CompaniaRecord[]>([]);
  isLoadingCompanias = signal(false);
  
  private destroy$ = new Subject<void>();
  private programContext = inject(ProgramContextService);

  private escapeHtml(text: string): string {
    const map: { [key: string]: string } = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, (char) => map[char]);
  }

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
    private loading: LoadingService,
    private service: Arg5014Service,
    private router: Router,
    private modalService: ModalService
  ) {
    this.form = this.fb.group({
      cia: ['', Validators.required],
      fecha_inicio: ['', Validators.required],
      fecha_final: ['', Validators.required]
    });

    this.searchForm = this.fb.group({
      search: ['']
    });
  }

  ngOnInit(): void {
    this.loadCompanias();
  }

  private loadCompanias(): void {
    this.isLoadingCompanias.set(true);
    
    this.service.getCECompanias()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: ARG5014Response) => {
          const companias = response.dsRespuesta?.tgecias || [];
          this.companiasList.set(companias);
          this.isLoadingCompanias.set(false);
        },
        error: (err) => {
          console.error('Error loading companies:', err);
          this.toast.showError('Error al cargar las compañías');
          this.isLoadingCompanias.set(false);
        }
      });
  }

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
    this.searchForm.reset();
    this.filteredCompaniasList.set(this.companiasList());
  }

  onSelectCompania(compania: CompaniaRecord): void {
    this.form.patchValue({
      cia: compania.cia
    });
    this.selectedCompania.set(compania);
    this.showCompaniaModal.set(false);
  }

  onCloseModal(): void {
    this.showCompaniaModal.set(false);
    this.searchForm.reset();
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getErrorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (!field) return '';

    if (field.hasError('required')) return 'Este campo es requerido';
    if (field.hasError('pattern')) return 'Formato inválido';
    
    return 'Error en el campo';
  }

  trackByCompania(index: number, compania: CompaniaRecord): number {
    return compania.cia;
  }

  onGenerarReporte(formato: 'excel' | 'pdf' | 'pantalla' = 'excel'): void {
    if (!this.form.valid) {
      this.toast.showError('Por favor complete los campos requeridos');
      return;
    }

    this.isGeneratingReport.set(true);
    const pcCompania = this.form.get('cia')?.value;
    const pcFechaD = this.form.get('fecha_inicio')?.value;
    const pcFechaH = this.form.get('fecha_final')?.value;

    this.service.getARG5014(pcCompania, pcFechaD, pcFechaH)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isGeneratingReport.set(false);
          if (response) {
            this.handleReporteResponse(response, formato);
            this.toast.showSuccess(`Reporte generado en formato ${formato}`);
          } else {
            this.toast.showError('No se pudo generar el reporte');
          }
        },
        error: (err: any) => {
          this.isGeneratingReport.set(false);
          console.error('Error generating report:', err);
          this.toast.showError('Error al generar el reporte');
        }
      });
  }

  private handleReporteResponse(response: any, formato: string): void {
    if (typeof response === 'string') {
      if (formato === 'excel') {
        this.downloadBase64File(response, 'application/vnd.ms-excel', 'generacion-facturacion-electronica.xls');
      } else if (formato === 'pantalla') {
        this.viewExcelInBrowser(response);
      }
    } else if (response?.dsRespuesta) {
      if (formato === 'excel') {
        if (response.dsRespuesta.pcArchXLS) {
          this.downloadBase64File(response.dsRespuesta.pcArchXLS, 'application/vnd.ms-excel', 'generacion-facturacion-electronica.xls');
        } else if (response.dsRespuesta.pcArchCSV) {
          this.downloadBase64File(response.dsRespuesta.pcArchCSV, 'text/csv', 'generacion-facturacion-electronica.csv');
        }
      } else if (formato === 'pdf' && response.dsRespuesta.pcArchPDF) {
        this.downloadBase64File(response.dsRespuesta.pcArchPDF, 'application/pdf', 'generacion-facturacion-electronica.pdf');
      } else if (formato === 'pantalla') {
        if (response.dsRespuesta.pcArchXLS) {
          this.viewExcelInBrowser(response.dsRespuesta.pcArchXLS);
        } else if (response.dsRespuesta.pcArchCSV) {
          this.viewCSVInBrowser(response.dsRespuesta.pcArchCSV);
        }
      }
    }
  }

  private downloadBase64File(base64Data: string, mimeType: string, fileName: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error descargando archivo:', error);
      this.toast.showError('Error al descargar el archivo');
    }
  }

  private viewExcelInBrowser(base64Data: string): void {
    try {
      const excelData = 'data:application/vnd.ms-excel;base64,' + base64Data;
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head>
              <title>Reporte Excel</title>
            </head>
            <body>
              <iframe src="${excelData}" width="100%" height="100%"></iframe>
            </body>
          </html>
        `);
        newWindow.document.close();
      }
    } catch (error) {
      console.error('Error mostrando Excel:', error);
      this.toast.showError('Error al mostrar el Excel');
    }
  }

  private viewCSVInBrowser(base64Data: string): void {
    try {
      const csvText = atob(base64Data);
      const escapedText = this.escapeHtml(csvText);
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head>
              <title>Reporte CSV</title>
              <style>
                body { 
                  font-family: 'Courier New', monospace; 
                  padding: 20px; 
                  background: #f5f5f5;
                }
                .content {
                  background: white;
                  padding: 20px;
                  border-radius: 4px;
                  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                  white-space: pre-wrap;
                  word-wrap: break-word;
                  max-width: 1200px;
                  margin: 0 auto;
                }
                .print-btn {
                  margin-bottom: 20px;
                  padding: 10px 20px;
                  background: #003087;
                  color: white;
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
                  font-size: 14px;
                }
                .print-btn:hover {
                  background: #002060;
                }
              </style>
            </head>
            <body>
              <button class="print-btn" onclick="window.print()">Imprimir</button>
              <div class="content">${escapedText}</div>
            </body>
          </html>
        `);
        newWindow.document.close();
      }
    } catch (error) {
      console.error('Error mostrando CSV:', error);
      this.toast.showError('Error al mostrar el CSV');
    }
  }

  buscarCompania(): void {
    if (this.companiasList().length === 0) {
      this.toast.showWarning('No hay compañías disponibles');
      return;
    }
    this.onOpenCompaniaModal();
  }

  closeCompaniaModal(): void {
    this.onCloseModal();
  }

  onCompaniaLeave(): void {
    const ciaValue = this.form.get('cia')?.value;
    if (!ciaValue) {
      this.selectedCompania.set(null);
      return;
    }
    const compania = this.companiasList().find(
      (c: CompaniaRecord) => c.cia.toString() === ciaValue.toString()
    );
    if (compania) {
      this.selectedCompania.set(compania);
    } else {
      this.toast.showError('Compañía no encontrada');
      this.form.patchValue({ cia: '' });
      this.selectedCompania.set(null);
    }
  }

  onClear(): void {
    this.form.reset();
    this.selectedCompania.set(null);
  }

  goBack(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
