// ARG5014 - GENERACION ARCHIVO FACTURACION ELECTRONICA Interfaces

export interface Arg5014Record {
  'cia': number;
  'documento'?: string;
  'numero-doc'?: string;
  'fecha-doc'?: string;
  'estado'?: string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CompaniaRecord {
  'cia': number;
  'nombre-cia': string;
  'nit': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface ARG5014Response {
  'dsRespuesta': {
    'targ5014'?: Arg5014Record[];
    'tgecias'?: CompaniaRecord[];
  };
}
