// PS5113 - REPORTE FACTURAS SIN CUFE UBL2 DIC-19 Interfaces

export interface Ps5113CufeRecord {
  'cia': number;
  'documento'?: string;
  'numero-doc'?: string;
  'fecha-doc'?: string;
  'cliente'?: string;
  'valor-doc'?: number;
  'estado'?: string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CompaniaRecord {
  'cia': number;
  'nombre-cia': string;
  'nit': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface PS5113CufeResponse {
  'dsRespuesta': {
    'tps5113'?: Ps5113CufeRecord[];
    'tgecias'?: CompaniaRecord[];
  };
}
