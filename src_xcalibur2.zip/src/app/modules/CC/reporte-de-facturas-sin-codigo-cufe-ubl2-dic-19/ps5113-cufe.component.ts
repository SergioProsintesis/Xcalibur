import { Component, OnDestroy, OnInit, signal, computed, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Observable, Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';

import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { ModalService } from '../../../core/services/modal.service';
import { Ps5113CufeService } from './ps5113-cufe.service';
import { CompaniaRecord, PS5113CufeResponse } from './ps5113-cufe.interface';

@Component({
  selector: 'app-ps5113-cufe',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './ps5113-cufe.component.html',
  styleUrls: ['./ps5113-cufe.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class Ps5113CufeComponent implements OnInit, OnDestroy {
  parseInt = parseInt;
  form: FormGroup;
  isLoading = signal(false);
  isGeneratingReport = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Reporte de Facturas sin Código CUFE -UBL2`);
  
  companiasList = signal<CompaniaRecord[]>([]);
  isLoadingCompanias = signal(false);
  
  private destroy$ = new Subject<void>();
  private programContext = inject(ProgramContextService);

  private escapeHtml(text: string): string {
    const map: { [key: string]: string } = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, (char) => map[char]);
  }

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
    private loading: LoadingService,
    private service: Ps5113CufeService,
    private router: Router,
    private modalService: ModalService
  ) {
    this.form = this.fb.group({
      cia: ['', Validators.required],
      fecha_inicio: ['', Validators.required],
      fecha_final: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadCompanias();
  }

  private loadCompanias(): void {
    this.isLoadingCompanias.set(true);
    
    this.service.getCECompanias()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: PS5113CufeResponse) => {
          const companias = response.dsRespuesta?.tgecias || [];
          this.companiasList.set(companias);
          this.isLoadingCompanias.set(false);
        },
        error: (err) => {
          console.error('Error loading companies:', err);
          this.toast.showError('Error al cargar las compañías');
          this.isLoadingCompanias.set(false);
        }
      });
  }

  onSelectCompania(compania: CompaniaRecord): void {
    this.form.patchValue({
      cia: compania.cia
    });
    this.selectedCompania.set(compania);
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getErrorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (!field) return '';

    if (field.hasError('required')) return 'Este campo es requerido';
    if (field.hasError('pattern')) return 'Formato inválido';
    
    return 'Error en el campo';
  }

  trackByCompania(index: number, compania: CompaniaRecord): number {
    return compania.cia;
  }

  onGenerarReporte(): void {
    if (!this.form.valid) {
      this.toast.showError('Por favor complete los campos requeridos');
      return;
    }

    this.isGeneratingReport.set(true);
    const pcCompania = this.form.get('cia')?.value;
    const pcFechaD = this.form.get('fecha_inicio')?.value;
    const pcFechaH = this.form.get('fecha_final')?.value;

    this.service.getPS5113(pcCompania, pcFechaD, pcFechaH)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isGeneratingReport.set(false);
          if (response) {
            this.handleReporteResponse(response);
            this.toast.showSuccess('Reporte generado exitosamente');
          } else {
            this.toast.showError('No se pudo generar el reporte');
          }
        },
        error: (err: any) => {
          this.isGeneratingReport.set(false);
          console.error('Error generating report:', err);
          this.toast.showError('Error al generar el reporte');
        }
      });
  }

  private handleReporteResponse(response: any): void {
    if (typeof response === 'string') {
      this.downloadBase64File(response, 'application/vnd.ms-excel', 'reporte-facturas-sin-cufe.xls');
    } else if (response?.dsRespuesta) {
      if (response.dsRespuesta.pcArchXLS) {
        this.downloadBase64File(response.dsRespuesta.pcArchXLS, 'application/vnd.ms-excel', 'reporte-facturas-sin-cufe.xls');
      } else if (response.dsRespuesta.pcArchCSV) {
        this.downloadBase64File(response.dsRespuesta.pcArchCSV, 'text/csv', 'reporte-facturas-sin-cufe.csv');
      }
    }
  }

  private downloadBase64File(base64Data: string, mimeType: string, fileName: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error descargando archivo:', error);
      this.toast.showError('Error al descargar el archivo');
    }
  }

  buscarCompania(): void {
    const ciaValue = this.form.get('cia')?.value;
    if (!ciaValue || this.companiasList().length === 0) {
      this.toast.showWarning('No hay compañías disponibles');
      return;
    }
    const compania = this.companiasList().find(c => c.cia.toString() === ciaValue.toString());
    if (compania) {
      this.selectedCompania.set(compania);
      this.toast.showSuccess('Compañía seleccionada');
    } else {
      this.toast.showError('Compañía no encontrada. Intente de nuevo.');
    }
  }

  onCompaniaLeave(): void {
    const ciaValue = this.form.get('cia')?.value;
    if (!ciaValue) {
      return;
    }
    const compania = this.companiasList().find(
      (c: CompaniaRecord) => c.cia.toString() === ciaValue.toString()
    );
    if (compania) {
      this.selectedCompania.set(compania);
    } else {
      this.toast.showError('Compañía no encontrada');
      this.form.patchValue({ cia: '' });
      this.selectedCompania.set(null);
    }
  }

  onClear(): void {
    this.form.reset();
    this.selectedCompania.set(null);
  }

  goBack(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
