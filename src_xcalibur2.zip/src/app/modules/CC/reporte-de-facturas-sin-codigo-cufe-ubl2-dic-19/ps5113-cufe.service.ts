import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../core/services/auth.service';
import { PS5113CufeResponse } from './ps5113-cufe.interface';

@Injectable({
  providedIn: 'root'
})
export class Ps5113CufeService {
  private http = inject(HttpClient);
  private auth = inject(AuthService);

  // ==================== CONSULTAS EMERGENTES ====================

  /**
   * Obtiene lista de compañías
   */
  getCECompanias(): Observable<PS5113CufeResponse> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECompanias?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<PS5113CufeResponse>(url);
  }

  /**
   * Obtiene compañía en evento Leave
   */
  getLeaveGEcias(): Observable<PS5113CufeResponse> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveGEcias?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<PS5113CufeResponse>(url);
  }

  // ==================== CONSULTAS ESPECIALIZADAS ====================

  /**
   * Obtiene reporte de facturas sin código CUFE -UBL2
   * @param pcCompania Código de compañía
   * @param pcFechaD Fecha desde (YYYY-MM-DD)
   * @param pcFechaH Fecha hasta (YYYY-MM-DD)
   */
  getPS5113(pcCompania: number, pcFechaD: string, pcFechaH: string): Observable<PS5113CufeResponse> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetPS5113?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcFechaD=${encodeURIComponent(pcFechaD)}&pcFechaH=${encodeURIComponent(pcFechaH)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<PS5113CufeResponse>(url);
  }
}
