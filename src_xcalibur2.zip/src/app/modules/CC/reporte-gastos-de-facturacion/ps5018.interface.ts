// PS5018 - REPORTE GASTOS DE FACTURACION Interfaces

export interface Ps5018Record {
  'cia': number;
  'documento'?: string;
  'numero-doc'?: string;
  'fecha-doc'?: string;
  'concepto'?: string;
  'valor-gasto'?: number;
  'estado'?: string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CompaniaRecord {
  'cia': number;
  'nombre-cia': string;
  'nit': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface PS5018Response {
  'dsRespuesta': {
    'tps5018'?: Ps5018Record[];
    'tgecias'?: CompaniaRecord[];
  };
}
