import { Component, OnDestroy, OnInit, signal, computed, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Observable, Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';

import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { Ps5018Service } from './ps5018.service';
import { CompaniaRecord, PS5018Response } from './ps5018.interface';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';

@Component({
  selector: 'app-ps5018',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, CompaniaModalComponent],
  templateUrl: './ps5018.component.html',
  styleUrls: ['./ps5018.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class Ps5018Component implements OnInit, OnDestroy {
  parseInt = parseInt;
  form: FormGroup;
  searchForm: FormGroup;
  isLoading = signal(false);
  isGeneratingReport = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  showCompaniaModal = signal(false);
  
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Reporte de Gastos de Facturación`);
  
  companiasList = signal<CompaniaRecord[]>([]);
  filteredCompaniasList = signal<CompaniaRecord[]>([]);
  isLoadingCompanias = signal(false);
  
  private destroy$ = new Subject<void>();
  private programContext = inject(ProgramContextService);

  private escapeHtml(text: string): string {
    const map: { [key: string]: string } = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, (char) => map[char]);
  }

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
    private loading: LoadingService,
    private service: Ps5018Service,
    private router: Router
  ) {
    this.form = this.fb.group({
      compania: ['', Validators.required],
      fecha_inicio: ['', Validators.required],
      fecha_final: ['', Validators.required]
    });

    this.searchForm = this.fb.group({
      search: ['']
    });
  }

  ngOnInit(): void {
    this.loadCompanias();
  }

  private loadCompanias(): void {
    this.isLoadingCompanias.set(true);
    
    this.service.getCECompanias()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: PS5018Response) => {
          const companias = response.dsRespuesta?.tgecias || [];
          this.companiasList.set(companias);
          this.filteredCompaniasList.set(companias);
          this.isLoadingCompanias.set(false);
        },
        error: (err) => {
          console.error('Error loading companies:', err);
          this.toast.showError('Error al cargar las compañías');
          this.isLoadingCompanias.set(false);
        }
      });
  }

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
    this.searchForm.reset();
    this.filteredCompaniasList.set(this.companiasList());
  }

  onSelectCompania(compania: CompaniaRecord): void {
    this.form.patchValue({
      compania: compania.cia
    });
    this.selectedCompania.set(compania);
    this.showCompaniaModal.set(false);
  }

  onCloseModal(): void {
    this.showCompaniaModal.set(false);
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getErrorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (!field) return '';

    if (field.hasError('required')) return 'Este campo es requerido';
    if (field.hasError('pattern')) return 'Formato inválido';
    
    return 'Error en el campo';
  }

  trackByCompania(index: number, compania: CompaniaRecord): number {
    return compania.cia;
  }

  onGenerarReporte(): void {
    if (!this.form.valid) {
      this.toast.showError('Por favor complete los campos requeridos');
      return;
    }

    this.isGeneratingReport.set(true);
    const pcCompania = this.form.get('compania')?.value;
    const pcFechaD = this.form.get('fecha_inicio')?.value;
    const pcFechaH = this.form.get('fecha_final')?.value;

    this.service.getPS5018(pcCompania, pcFechaD, pcFechaH)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isGeneratingReport.set(false);
          if (response) {
            this.handleReporteResponse(response);
            this.toast.showSuccess('Reporte generado exitosamente');
          } else {
            this.toast.showError('No se pudo generar el reporte');
          }
        },
        error: (err: any) => {
          this.isGeneratingReport.set(false);
          console.error('Error generating report:', err);
          this.toast.showError('Error al generar el reporte');
        }
      });
  }

  private handleReporteResponse(response: any): void {
    if (typeof response === 'string') {
      this.downloadBase64File(response, 'application/vnd.ms-excel', 'reporte-gastos-facturacion.xls');
    } else if (response?.dsRespuesta) {
      if (response.dsRespuesta.pcArchXLS) {
        this.downloadBase64File(response.dsRespuesta.pcArchXLS, 'application/vnd.ms-excel', 'reporte-gastos-facturacion.xls');
      } else if (response.dsRespuesta.pcArchCSV) {
        this.downloadBase64File(response.dsRespuesta.pcArchCSV, 'text/csv', 'reporte-gastos-facturacion.csv');
      }
    }
  }

  private downloadBase64File(base64Data: string, mimeType: string, fileName: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error descargando archivo:', error);
      this.toast.showError('Error al descargar el archivo');
    }
  }

  onClear(): void {
    this.form.reset();
    this.selectedCompania.set(null);
  }

  goBack(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
