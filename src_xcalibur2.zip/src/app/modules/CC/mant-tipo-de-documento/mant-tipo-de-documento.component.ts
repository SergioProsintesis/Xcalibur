import { Component, inject, signal, OnInit, computed, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { TipoDocumentoModalComponent } from '../../../shared/components/tipo-documento-modal/tipo-documento-modal.component';
import { CompaniaRecord, TipoDocumentoRecord } from '../../../core/interfaces/cc.interface';
import { CCService } from '../../../core/services/cc.service';

@Component({
  selector: 'app-mant-tipo-de-documento',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent, TipoDocumentoModalComponent],
  templateUrl: './mant-tipo-de-documento.component.html',
  styleUrls: ['./mant-tipo-de-documento.component.css']
})
export class MantTipoDeDocumentoComponent implements OnInit {
  private fb = inject(FormBuilder);
  private modalService = inject(ModalService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private ccService = inject(CCService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  tipoDocumentoForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Tipo de Documento`);
  createTipoDocumentoForm!: FormGroup;
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  tipoDocumentoSeleccionado = signal<TipoDocumentoRecord | null>(null);

  // Control de modales
  showCompaniaModal = signal(false);
  showTipoDocumentoModal = signal(false);
  showCreateModal = signal(false);
  showReportModal = signal(false);
  tiposDisponibles = signal<TipoDocumentoRecord[]>([]);
  
  // Datos de reporte
  reportResponse: any = null;

  ngOnInit() {
    console.log('🔄 MantTipoDeDocumentoComponent - ngOnInit iniciado');
    console.log('🔍 LoadingService estado inicial:', this.loadingService.isCurrentlyLoading());
    
    // FORZAR reset completo del loading state
    this.loadingState.set(false);
    this.loadingService.hide();
    
    console.log('🔧 Inicializando formulario...');
    this.initializeForm();
    
    console.log('✅ MantTipoDeDocumentoComponent inicializado correctamente');
  }

  private initializeForm() {
    console.log('🔄 Inicializando formulario...');
    this.tipoDocumentoForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]], 
      'nombre-cia': [''], // Se llena automáticamente, solo lectura
      tipodoc: ['', [Validators.required, Validators.min(1)]], 
      'nombre-tdoc': [''], // Se llena automáticamente del modal
      'siglas-tdoc': [''], // Se llena automáticamente del modal
      'clase-tdoc': [''], // Se llena automáticamente del modal
      'numped-tdoc': [0, [Validators.min(0)]], // Número pedido - textbox
      'profac-tdoc': [''], // Programa facturación del modal
      'text-tdoc': [''], // Comentario - texto abierto del modal
      'afecxc-tdoc': [false], // Afecta CXC - checkbox del modal
      'afesta-tdoc': [false], // Afecta ventas - checkbox del modal
      'afeinv-tdoc': [false] // Afecta inventario - checkbox del modal
    });

    this.createTipoDocumentoForm = this.fb.group({
      tipodoc: ['', [Validators.required, Validators.min(1)]],
      'nombre-tdoc': ['', [Validators.required, Validators.minLength(1)]],
      'siglas-tdoc': [''],
      'clase-tdoc': [0],
      'numped-tdoc': [0, [Validators.min(0)]],
      'profac-tdoc': [0],
      'text-tdoc': [''],
      'afecxc-tdoc': [false],
      'afesta-tdoc': [false],
      'afeinv-tdoc': [false]
    });
    console.log('✅ Formulario inicializado correctamente');
  }

  // Validaciones
  isInvalid(fieldName: string): boolean {
    const field = this.tipoDocumentoForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.tipoDocumentoForm.get(fieldName);
    if (field?.errors) {
      if (field.errors['required']) {
        switch(fieldName) {
          case 'cia': return 'La compañía es requerida';
          case 'tipodoc': return 'El tipo de documento es requerido';
          default: return `${fieldName} es requerido`;
        }
      }
      if (field.errors['min']) return `Debe ser mayor a ${field.errors['min'].min}`;
    }
    return '';
  }

  // Métodos para manejar compañía
  buscarCompania() {
    console.log('🔍 Abriendo modal de compañías...');
    console.log('📊 Signal showCompaniaModal antes:', this.showCompaniaModal());
    this.showCompaniaModal.set(true);
    console.log('📊 Signal showCompaniaModal después:', this.showCompaniaModal());
  }

  onCompaniaSelected(compania: CompaniaRecord) {
    console.log('🏢 Compañía seleccionada:', compania);
    this.companiaSeleccionada.set(compania);
    
    this.tipoDocumentoForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    
    this.tiposDisponibles.set([]);
    this.showCompaniaModal.set(false);
    this.toastService.showSuccess('Compañía seleccionada correctamente');
  }

  // Cerrar modal de compañías
  closeCompaniaModal() {
    this.showCompaniaModal.set(false);
  }

  // Evento Leave del campo compañía
  onCompaniaLeave() {
    const ciaValue = this.tipoDocumentoForm.get('cia')?.value;
    if (ciaValue) {
      console.log('🔍 Validando compañía:', ciaValue);
      this.loadingService.show();
      
      this.ccService.validateCompania(ciaValue.toString()).subscribe({
        next: (compania) => {
          this.loadingService.hide();
          if (compania) {
            this.companiaSeleccionada.set(compania);
            this.tipoDocumentoForm.patchValue({
              'nombre-cia': compania['nombre-cia']
            });
            console.log('✅ Compañía válida:', compania['nombre-cia']);
          } else {
            this.toastService.showWarning('Compañía no encontrada');
          }
        },
        error: (error) => {
          this.loadingService.hide();
          console.error('❌ Error al validar compañía:', error);
          this.toastService.showError('Error al validar compañía');
        }
      });
    }
  }

  // Búsqueda de tipos de documento - abre modal de selección
  buscarTipoDocumento() {
    console.log('🔍 Iniciando búsqueda de tipos de documento...');
    
    let cia = this.tipoDocumentoForm.get('cia')?.value;
    
    if (!cia) {
      this.toastService.showWarning('Debe seleccionar una compañía primero');
      return;
    }

    console.log('📡 Consultando API para compañía:', cia);
    this.loadingService.show();
    
    this.ccService.getTiposDocumento(cia.toString()).subscribe({
      next: (tiposDocumento) => {
        this.loadingService.hide();
        console.log('✅ Tipos de documento obtenidos:', tiposDocumento);
        
        if (tiposDocumento.length > 0) {
          this.tiposDisponibles.set(tiposDocumento);
          this.showTipoDocumentoModal.set(true);
          console.log('🎯 Modal abierto con', tiposDocumento.length, 'tipos disponibles');
        } else {
          this.toastService.showWarning('No se encontraron tipos de documento para esta compañía');
          console.log('⚠️ No se encontraron tipos de documento');
        }
      },
      error: (error) => {
        this.loadingService.hide();
        console.error('❌ Error al buscar tipos de documento:', error);
        this.toastService.showError('Error al buscar tipos de documento: ' + (error.message || 'Error desconocido'));
      }
    });
  }

  // Métodos para manejar el modal de tipo documento
  async onTipoDocumentoSelected(tipoDocumento: TipoDocumentoRecord) {
    console.log('📄 Tipo de documento seleccionado:', tipoDocumento);
    
    // Recargar datos actualizados del servidor
    const cia = this.tipoDocumentoForm.get('cia')?.value;
    if (!cia) return;

    this.loadingService.show();
    try {
      // Traer los datos actualizados del servidor
      const tiposActualizados = await this.ccService.getTiposDocumento(cia.toString()).toPromise();
      const tipoActualizado = tiposActualizados?.find(t => t.tipodoc === tipoDocumento.tipodoc);
      
      if (tipoActualizado) {
        this.tipoDocumentoSeleccionado.set(tipoActualizado);
        
        this.tipoDocumentoForm.patchValue({
          tipodoc: tipoActualizado.tipodoc,
          'nombre-tdoc': tipoActualizado['nombre-tdoc'],
          'siglas-tdoc': tipoActualizado['siglas-tdoc'],
          'clase-tdoc': tipoActualizado['clase-tdoc'],
          'profac-tdoc': tipoActualizado['profac-tdoc'],
          'text-tdoc': tipoActualizado['text-tdoc'],
          'afecxc-tdoc': tipoActualizado['afecxc-tdoc'],
          'afesta-tdoc': tipoActualizado['afesta-tdoc'],
          'afeinv-tdoc': tipoActualizado['afeinv-tdoc'],
          'numped-tdoc': tipoActualizado['numped-tdoc']
        });
        
        console.log('✅ Datos del servidor cargados:', tipoActualizado);
        this.toastService.showSuccess(`Tipo de documento "${tipoActualizado['nombre-tdoc']}" cargado`);
      }
    } catch (error) {
      console.error('❌ Error al recargar tipo de documento:', error);
      // Fallback a datos locales si hay error
      this.tipoDocumentoSeleccionado.set(tipoDocumento);
      
      this.tipoDocumentoForm.patchValue({
        tipodoc: tipoDocumento.tipodoc,
        'nombre-tdoc': tipoDocumento['nombre-tdoc'],
        'siglas-tdoc': tipoDocumento['siglas-tdoc'],
        'clase-tdoc': tipoDocumento['clase-tdoc'],
        'profac-tdoc': tipoDocumento['profac-tdoc'],
        'text-tdoc': tipoDocumento['text-tdoc'],
        'afecxc-tdoc': tipoDocumento['afecxc-tdoc'],
        'afesta-tdoc': tipoDocumento['afesta-tdoc'],
        'afeinv-tdoc': tipoDocumento['afeinv-tdoc'],
        'numped-tdoc': tipoDocumento['numped-tdoc']
      });
    } finally {
      this.loadingService.hide();
    }
  }

  closeTipoDocumentoModal() {
    this.showTipoDocumentoModal.set(false);
  }

  /** Cargar tipos de documento disponibles */
  async loadTiposDocumento(): Promise<void> {
    const cia = this.tipoDocumentoForm.get('cia')?.value;
    if (!cia) {
      return;
    }

    this.loadingService.show();
    
    this.ccService.getTiposDocumento(cia.toString()).subscribe({
      next: (tiposDocumento) => {
        this.loadingService.hide();
        if (tiposDocumento.length > 0) {
          this.tiposDisponibles.set(tiposDocumento);
          console.log('✅ Tipos de documento recargados');
        }
      },
      error: () => {
        this.loadingService.hide();
        console.error('❌ Error al recargar tipos de documento');
      }
    });
  }

  // Evento Input del campo tipo documento - NO abre modal automáticamente
  onTipoDocumentoInput() {
    // El modal solo se abre cuando el usuario presiona el botón de búsqueda
    // El evento Leave se encarga de traer los datos sin abrir modal
    console.log('Input en tipo documento detectado');
  }

  // Evento Leave del campo tipo documento - Ejecuta el endpoint sin abrir modal
  onTipoDocumentoLeave() {
    const tipodocValue = this.tipoDocumentoForm.get('tipodoc')?.value;
    const ciaValue = this.tipoDocumentoForm.get('cia')?.value;
    
    // Si hay valor y compañía, ejecutar GetCETipoDoc para traer los datos
    if (tipodocValue && ciaValue) {
      console.log('🔍 Leave event - Ejecutando GetCETipoDoc para:', tipodocValue);
      this.loadingService.show();
      
      this.ccService.getTiposDocumento(ciaValue.toString()).subscribe({
        next: (tiposDocumento) => {
          this.loadingService.hide();
          console.log('✅ Datos obtenidos de GetCETipoDoc:', tiposDocumento);
          
          // Buscar el documento específico que el usuario escribió
          const documentoEncontrado = tiposDocumento.find(
            doc => doc.tipodoc.toString() === tipodocValue.toString()
          );
          
          if (documentoEncontrado) {
            console.log('✅ Documento encontrado:', documentoEncontrado);
            this.onTipoDocumentoSelected(documentoEncontrado);
          } else {
            console.warn('⚠️ Documento no encontrado en la lista');
            this.toastService.showWarning('Tipo de documento no encontrado');
          }
        },
        error: (error) => {
          this.loadingService.hide();
          console.error('❌ Error al ejecutar GetCETipoDoc:', error);
          this.toastService.showError('Error al buscar tipo de documento');
        }
      });
    }
  }

  // Métodos CRUD
  async onSubmit(): Promise<void> {
    if (!this.tipoDocumentoForm.valid) {
      this.toastService.showError('Por favor complete todos los campos obligatorios');
      return;
    }

    const companiaId = this.tipoDocumentoForm.get('cia')?.value;
    const tipodocId = this.tipoDocumentoForm.get('tipodoc')?.value;

    if (!tipodocId) {
      this.toastService.showError('Debe seleccionar un tipo de documento para actualizar');
      return;
    }

    const today = new Date();
    const dateCtrl = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    const user = this.ccService.getAuthParams();

    try {
      this.loadingState.set(true);
      
      const payload = {
        tcctipdoc: [{
          cia: companiaId,
          tipodoc: tipodocId,  // ID existente = actualizar
          'nombre-tdoc': this.tipoDocumentoForm.get('nombre-tdoc')?.value || '',
          'siglas-tdoc': this.tipoDocumentoForm.get('siglas-tdoc')?.value || '',
          'clase-tdoc': this.tipoDocumentoForm.get('clase-tdoc')?.value || 0,
          'numped-tdoc': this.tipoDocumentoForm.get('numped-tdoc')?.value || 0,
          'profac-tdoc': this.tipoDocumentoForm.get('profac-tdoc')?.value || 0,
          'text-tdoc': this.tipoDocumentoForm.get('text-tdoc')?.value || '',
          'afecxc-tdoc': this.tipoDocumentoForm.get('afecxc-tdoc')?.value || false,
          'afesta-tdoc': this.tipoDocumentoForm.get('afesta-tdoc')?.value || false,
          'afeinv-tdoc': this.tipoDocumentoForm.get('afeinv-tdoc')?.value || false,
          'Agrega-Tdoc': '            ',
          'date-ctrl': dateCtrl,
          'login-ctrl': user?.pcLogin || '',
          tparent: user?.pcLogin || ''
        }]
      };
      
      console.log('📝 Payload UPDATE:', JSON.stringify(payload, null, 2));
      
      const response = await this.ccService.updateTipoDocumento(payload);
      
      console.log('📥 Respuesta UPDATE:', response);
      
      if (response?.dsRespuesta?.tcctipdoc?.[0]?.terrores?.[0]) {
        const error = response.dsRespuesta.tcctipdoc[0].terrores[0];
        this.toastService.showSuccess(error.descripcion || 'Tipo de documento actualizado correctamente');
        
        // Limpiar completamente todos los modales y datos
        this.cleanupAllModals();
      } else {
        this.toastService.showError('No se pudo procesar la respuesta del servidor');
      }
    } catch (error) {
      console.error('Error al guardar:', error);
      this.toastService.showError('Error al guardar el tipo de documento');
    } finally {
      this.loadingState.set(false);
    }
  }

  onDelete() {
    const tipoDocumento = this.tipoDocumentoForm.get('tipodoc')?.value;
    const compania = this.tipoDocumentoForm.get('cia')?.value;
    
    if (!tipoDocumento || !compania) {
      this.toastService.showWarning('Debe seleccionar un tipo de documento válido para eliminar');
      return;
    }

    if (!confirm('¿Está seguro que desea eliminar este tipo de documento?')) {
      return;
    }

    console.log('🗑️ Eliminando tipo de documento:', tipoDocumento);
    this.loadingService.show();
    
    this.ccService.deleteTipoDocumento(compania.toString(), tipoDocumento.toString()).subscribe({
      next: (response) => {
        this.loadingService.hide();
        console.log('Tipo de documento eliminado:', response);
        this.toastService.showSuccess('Tipo de documento eliminado exitosamente');
        // Limpiar completamente todos los modales y datos
        this.cleanupAllModals();
      },
      error: (error) => {
        this.loadingService.hide();
        console.error('❌ Error al eliminar:', error);
        this.toastService.showError('Error al eliminar tipo de documento: ' + (error.message || 'Error desconocido'));
      }
    });
  }

  onNew() {
    console.log('Preparando formulario para nuevo tipo de documento');
    // Limpiar todos los modales, mantener la compañía seleccionada
    const ciaValue = this.tipoDocumentoForm.get('cia')?.value;
    const nombreCia = this.tipoDocumentoForm.get('nombre-cia')?.value;
    
    this.cleanupAllModals();
    
    // Restaurar la compañía si fue seleccionada
    if (ciaValue && nombreCia) {
      this.tipoDocumentoForm.patchValue({
        cia: ciaValue,
        'nombre-cia': nombreCia
      });
    }
    
    this.toastService.showInfo('Formulario listo para nuevo tipo de documento');
  }

  onClear(): void {
    console.log('Limpiando formulario');
    // Limpiar completamente todos los modales y datos
    this.cleanupAllModals();
    this.toastService.showInfo('Formulario limpiado');
  }

  // Generar reportes
  async onGenerateReport(): Promise<void> {
    const compania = this.tipoDocumentoForm.get('cia')?.value;
    
    if (!compania) {
      this.toastService.showWarning('Debe seleccionar una compañía para generar el reporte');
      return;
    }

    try {
      this.loadingState.set(true);
      const fechaActual = new Date().toISOString().split('T')[0];
      
      const response = await this.ccService.generarReporteTipoDocumento(compania.toString(), fechaActual, 'pdf').toPromise();
      
      if (response?.response?.pcArchPDF || response?.response?.pcArchCSV) {
        this.reportResponse = response.response;
        this.showReportModal.set(true);
      } else {
        this.toastService.showError('No se pudo generar el reporte');
      }
    } catch (error) {
      console.error('Error generando reporte:', error);
      this.toastService.showError('Error al generar el reporte');
    } finally {
      this.loadingState.set(false);
    }
  }

  downloadReportPDF(): void {
    if (!this.reportResponse?.pcArchPDF) {
      this.toastService.showError('No se pudo generar el reporte PDF');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchPDF, 'reporte-tipo-documento.pdf', 'application/pdf');
    this.toastService.showSuccess('Reporte PDF descargado exitosamente');
    this.showReportModal.set(false);
  }

  downloadReportCSV(): void {
    if (!this.reportResponse?.pcArchCSV) {
      this.toastService.showError('No se pudo generar el reporte CSV');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchCSV, 'reporte-tipo-documento.csv', 'text/csv');
    this.toastService.showSuccess('Reporte CSV descargado exitosamente');
    this.showReportModal.set(false);
  }

  closeReportModal(): void {
    this.showReportModal.set(false);
    this.reportResponse = null;
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(url);
      this.toastService.showSuccess(`Archivo ${filename} descargado exitosamente`);
    } catch (error) {
      console.error('Error al descargar el archivo:', error);
      this.toastService.showError('Error al descargar el archivo');
    }
  }

  // Método auxiliar para resetear el formulario
  private resetForm() {
    this.tipoDocumentoForm.reset();
    this.tipoDocumentoForm.patchValue({
      cia: '',
      'nombre-cia': '',
      tipodoc: '',
      'nombre-tdoc': '',
      'siglas-tdoc': '',
      'clase-tdoc': '',
      'numped-tdoc': 0,
      'profac-tdoc': '',
      'text-tdoc': '',
      'afecxc-tdoc': false,
      'afesta-tdoc': false,
      'afeinv-tdoc': false
    });
    this.companiaSeleccionada.set(null);
    this.tipoDocumentoSeleccionado.set(null);
    this.tiposDisponibles.set([]);
  }

  // Método para limpiar completamente todos los modales y datos
  private cleanupAllModals() {
    console.log('Limpiando todos los modales y datos...');
    this.showCompaniaModal.set(false);
    this.showTipoDocumentoModal.set(false);
    this.showCreateModal.set(false);
    this.showReportModal.set(false);
    this.tiposDisponibles.set([]);
    this.companiaSeleccionada.set(null);
    this.tipoDocumentoSeleccionado.set(null);
    this.reportResponse = null;
    this.resetForm();
    this.cdr.detectChanges();
    console.log('Todos los modales y datos han sido limpiados');
  }

  // Método auxiliar para marcar todos los campos como tocados
  private markAllFieldsAsTouched() {
    Object.keys(this.tipoDocumentoForm.controls).forEach(key => {
      this.tipoDocumentoForm.get(key)?.markAsTouched();
    });
    Object.keys(this.createTipoDocumentoForm.controls).forEach(key => {
      this.createTipoDocumentoForm.get(key)?.markAsTouched();
    });
  }

  // CREATE Modal Methods
  openCreateModal(): void {
    const cia = this.tipoDocumentoForm.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }
    this.createTipoDocumentoForm.reset();
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
    this.createTipoDocumentoForm.reset();
  }

  async onSaveNew(): Promise<void> {
    if (!this.createTipoDocumentoForm.valid) {
      this.toastService.showError('Por favor complete todos los campos obligatorios');
      return;
    }

    const companiaId = this.tipoDocumentoForm.get('cia')?.value;
    const today = new Date();
    const dateCtrl = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    const user = this.ccService.getAuthParams();
    
    try {
      this.loadingState.set(true);
      
      const payload = {
        tcctipdoc: [{
          cia: companiaId,
          tipodoc: this.createTipoDocumentoForm.get('tipodoc')?.value,  // Incluir código
          'nombre-tdoc': this.createTipoDocumentoForm.get('nombre-tdoc')?.value || '',
          'siglas-tdoc': this.createTipoDocumentoForm.get('siglas-tdoc')?.value || '',
          'clase-tdoc': this.createTipoDocumentoForm.get('clase-tdoc')?.value || 0,
          'numped-tdoc': this.createTipoDocumentoForm.get('numped-tdoc')?.value || 0,
          'profac-tdoc': this.createTipoDocumentoForm.get('profac-tdoc')?.value || 0,
          'text-tdoc': this.createTipoDocumentoForm.get('text-tdoc')?.value || '',
          'afecxc-tdoc': this.createTipoDocumentoForm.get('afecxc-tdoc')?.value || false,
          'afesta-tdoc': this.createTipoDocumentoForm.get('afesta-tdoc')?.value || false,
          'afeinv-tdoc': this.createTipoDocumentoForm.get('afeinv-tdoc')?.value || false,
          'Agrega-Tdoc': '            ',
          'date-ctrl': dateCtrl,
          'login-ctrl': user?.pcLogin || '',
          tparent: user?.pcLogin || ''
        }]
      };
      
      console.log('📝 Payload CREATE:', JSON.stringify(payload, null, 2));
      
      const response = await this.ccService.updateTipoDocumento(payload);
      
      console.log('📥 Respuesta CREATE:', response);
      
      if (response?.dsRespuesta?.tcctipdoc?.[0]?.terrores?.[0]) {
        const error = response.dsRespuesta.tcctipdoc[0].terrores[0];
        this.toastService.showSuccess(error.descripcion || 'Tipo de documento creado correctamente');
        // Limpiar completamente todos los modales y datos
        this.cleanupAllModals();
      } else {
        this.toastService.showError('No se pudo procesar la respuesta del servidor');
      }
    } catch (error) {
      console.error('Error al guardar:', error);
      this.toastService.showError('Error al guardar el tipo de documento');
    } finally {
      this.loadingState.set(false);
    }
  }

  goBack(): void {
    this.router.navigate(['/']);
  }
}