import { Component, inject, signal, OnInit, computed, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { AuthService } from '../../../core/services/auth.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { TipoNegocioModalComponent } from '../../../shared/components/tipo-negocio-modal/tipo-negocio-modal.component';
import { CompaniaRecord } from '../../../core/interfaces/cc.interface';
import { CCService } from '../../../core/services/cc.service';

export interface TipoNegocioRecord {
  negocio: number;
  cia: number;
  'nombre-cia': string;
  'nombre-neg': string;
  'text-neg': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'Agrega-Nego'?: string;
  tparent?: string;
}

@Component({
  selector: 'app-mant-tipo-de-negocio',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent, TipoNegocioModalComponent],
  templateUrl: './mant-tipo-de-negocio.component.html',
  styleUrls: ['./mant-tipo-de-negocio.component.css']
})
export class MantTipoDeNegocioComponent implements OnInit {
  private fb = inject(FormBuilder);
  private modalService = inject(ModalService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private ccService = inject(CCService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private auth = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);

  tipoNegocioForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Tipo de Negocio`);
  
  createTipoNegocioForm!: FormGroup;
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  negocioSeleccionado = signal<TipoNegocioRecord | null>(null);

  // Control de modales
  showCompaniaModal = signal(false);
  showNegocioModal = signal(false);
  showCreateModal = signal(false);
  showReportModal = signal(false);
  negociosDisponibles = signal<TipoNegocioRecord[]>([]);

  // Datos de reporte
  reportResponse: any = null;

  ngOnInit() {
    console.log('🔄 MantTipoDeNegocioComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    console.log('✅ MantTipoDeNegocioComponent inicializado correctamente');
  }

  private initializeForm(): void {
    this.tipoNegocioForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      negocio: ['', [Validators.required]],
      'nombre-neg': ['', [Validators.required]],
      'text-neg': ['']
    });

    this.createTipoNegocioForm = this.fb.group({
      negocio: ['', [Validators.required, Validators.min(1)]],
      'nombre-neg': ['', [Validators.required]],
      'text-neg': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.tipoNegocioForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.tipoNegocioForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.tipoNegocioForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.limpiarNegocio();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.tipoNegocioForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.tipoNegocioForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.tipoNegocioForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
    this.limpiarNegocio();
  }

  // ==================== MODAL DE NEGOCIO ====================
  async buscarNegocio(): Promise<void> {
    const companiaId = this.tipoNegocioForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getCENegocio(companiaId);
      
      if (response?.dsRespuesta?.tccnegoci && response.dsRespuesta.tccnegoci.length > 0) {
        this.negociosDisponibles.set(response.dsRespuesta.tccnegoci);
        this.showNegocioModal.set(true);
      } else {
        this.toastService.showWarning('No se encontraron tipos de negocio para esta compañía');
      }
    } catch (error) {
      console.error('Error al buscar tipos de negocio:', error);
      this.toastService.showError('Error al buscar tipos de negocio');
    } finally {
      this.loadingState.set(false);
    }
  }

  closeNegocioModal(): void {
    this.showNegocioModal.set(false);
  }

  /** Cargar tipos de negocio disponibles */
  async onNegocioSelected(negocio: TipoNegocioRecord): Promise<void> {
    const companiaId = this.tipoNegocioForm.get('cia')?.value;
    if (!companiaId) return;

    this.loadingState.set(true);
    try {
      // Load fresh data from server
      const response = await this.ccService.getCENegocio(companiaId);
      const negociosActualizados = response?.dsRespuesta?.tccnegoci || [];
      const negocioActualizado = negociosActualizados.find((n: TipoNegocioRecord) => n.negocio === negocio.negocio);

      if (negocioActualizado) {
        this.negocioSeleccionado.set(negocioActualizado);
        this.tipoNegocioForm.patchValue({
          negocio: negocioActualizado.negocio,
          'nombre-neg': negocioActualizado['nombre-neg'],
          'text-neg': negocioActualizado['text-neg']
        });
        this.toastService.showSuccess(`Negocio "${negocioActualizado['nombre-neg']}" cargado`);
      }
    } catch (error) {
      console.error('Error al recargar negocio:', error);
      // Fallback to local data
      this.negocioSeleccionado.set(negocio);
      this.tipoNegocioForm.patchValue({
        negocio: negocio.negocio,
        'nombre-neg': negocio['nombre-neg'],
        'text-neg': negocio['text-neg']
      });
    } finally {
      this.loadingState.set(false);
      this.closeNegocioModal();
    }
  }

  async onNegocioLeave(): Promise<void> {
    const companiaId = this.tipoNegocioForm.get('cia')?.value;
    const negocioId = this.tipoNegocioForm.get('negocio')?.value;
    
    if (!companiaId || !negocioId) {
      this.limpiarNegocio();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveNegocio(companiaId, negocioId);
      
      if (response?.dsRespuesta?.tccnegoci && response.dsRespuesta.tccnegoci.length > 0) {
        const negocio = response.dsRespuesta.tccnegoci[0];
        this.negocioSeleccionado.set(negocio);
        this.tipoNegocioForm.patchValue({
          'nombre-neg': negocio['nombre-neg'],
          'text-neg': negocio['text-neg']
        });
      } else {
        this.toastService.showError('Tipo de negocio no encontrado');
        this.limpiarNegocio();
      }
    } catch (error) {
      console.error('Error al buscar tipo de negocio:', error);
      this.toastService.showError('Error al buscar el tipo de negocio');
      this.limpiarNegocio();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarNegocio(): void {
    this.negocioSeleccionado.set(null);
    this.tipoNegocioForm.patchValue({
      negocio: '',
      'nombre-neg': '',
      'text-neg': ''
    });
  }

  // ==================== ACCIONES CRUD ====================
  async onSubmit(): Promise<void> {
    if (this.tipoNegocioForm.invalid) {
      this.toastService.showError('Por favor complete todos los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const formData = this.tipoNegocioForm.getRawValue();
      const userLogin = this.auth.user()?.pcLogin || '';
      
      const payload = {
        tccnegoci: [{
          'Agrega-Nego': formData['Agrega-Nego'] || '',
          cia: formData.cia,
          'nombre-cia': formData['nombre-cia'],
          'date-ctrl': formData['date-ctrl'] || new Date().toISOString().split('T')[0],
          'login-ctrl': userLogin,
          negocio: formData.negocio,
          'nombre-neg': formData['nombre-neg'],
          'text-neg': formData['text-neg'] || '',
          tparent: userLogin
        }]
      };

      const response = await this.ccService.updateTipoNegocio(payload);
      
      if (response?.dsRespuesta?.tccnegoci && response.dsRespuesta.tccnegoci.length > 0) {
        const result = response.dsRespuesta.tccnegoci[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Operación exitosa');
        } else {
          this.toastService.showSuccess('Tipo de negocio guardado exitosamente');
        }
        this.onClear();
        this.closeNegocioModal();
        await this.loadNegocios();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al guardar:', error);
      this.toastService.showError('Error al guardar el tipo de negocio');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onDelete(): Promise<void> {
    const companiaId = this.tipoNegocioForm.get('cia')?.value;
    const negocioId = this.tipoNegocioForm.get('negocio')?.value;

    if (!companiaId || !negocioId) {
      this.toastService.showError('Debe seleccionar una compañía y un tipo de negocio para eliminar');
      return;
    }

    const confirmed = confirm('¿Está seguro de eliminar este tipo de negocio?\nEsta acción no se puede deshacer');

    if (!confirmed) return;

    try {
      this.loadingState.set(true);
      const response = await this.ccService.deleteTipoNegocio(companiaId, negocioId);
      
      if (response?.dsRespuesta?.tccnegoci && response.dsRespuesta.tccnegoci.length > 0) {
        const result = response.dsRespuesta.tccnegoci[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Registro eliminado');
        } else {
          this.toastService.showSuccess('Tipo de negocio eliminado exitosamente');
        }
        this.onClear();
        this.closeNegocioModal();
        await this.loadNegocios();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al eliminar:', error);
      this.toastService.showError('Error al eliminar el tipo de negocio');
    } finally {
      this.loadingState.set(false);
    }
  }

  private async loadNegocios(): Promise<void> {
    const companiaId = this.tipoNegocioForm.get('cia')?.value;
    
    if (!companiaId) {
      return;
    }

    try {
      const response = await this.ccService.getCENegocio(companiaId.toString());
      
      if (response?.dsRespuesta?.tccnegoci && response.dsRespuesta.tccnegoci.length > 0) {
        const allNegocios = response.dsRespuesta.tccnegoci;
        const filteredNegocios = allNegocios.filter((neg: any) => 
          !neg.cia || neg.cia === companiaId || neg.cia.toString() === companiaId.toString()
        );
        
        const negociosToShow = filteredNegocios.length > 0 ? filteredNegocios : allNegocios;
        this.negociosDisponibles.set(negociosToShow);
        console.log('✅ Negocios recargados');
      }
    } catch (error) {
      console.error('Error al cargar negocios:', error);
    }
  }

  onClear(): void {
    this.tipoNegocioForm.reset();
    this.companiaSeleccionada.set(null);
    this.negocioSeleccionado.set(null);
  }

  async onGenerateReport(): Promise<void> {
    const companiaId = this.tipoNegocioForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía para generar reporte');
      return;
    }

    try {
      this.loadingState.set(true);
      const today = new Date();
      const pcFecha = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      
      // Usar endpoint específico GetCC2006 para Tipo de Negocio
      const response = await this.ccService.generarReporteTipoNegocio(
        companiaId.toString(),
        pcFecha
      ).toPromise();
      
      // Acceder a response.response porque la API devuelve estructura anidada
      const reportData = response?.response || response;
      
      if (reportData?.pcArchPDF || reportData?.pcArchCSV) {
        this.reportResponse = reportData;
        this.showReportModal.set(true);
      } else {
        console.error('Estructura de respuesta inesperada:', response);
        this.toastService.showError('No se pudo generar el reporte');
      }
    } catch (error) {
      console.error('Error generando reporte:', error);
      this.toastService.showError('Error al generar el reporte');
    } finally {
      this.loadingState.set(false);
    }
  }

  downloadReportPDF(): void {
    if (!this.reportResponse?.pcArchPDF) {
      this.toastService.showError('No se pudo generar el reporte PDF');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchPDF, 'reporte-tipo-negocio.pdf', 'application/pdf');
    this.toastService.showSuccess('Reporte PDF descargado exitosamente');
    this.showReportModal.set(false);
  }

  downloadReportCSV(): void {
    if (!this.reportResponse?.pcArchCSV) {
      this.toastService.showError('No se pudo generar el reporte CSV');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchCSV, 'reporte-tipo-negocio.csv', 'text/csv');
    this.toastService.showSuccess('Reporte CSV descargado exitosamente');
    this.showReportModal.set(false);
  }

  closeReportModal(): void {
    this.showReportModal.set(false);
    this.reportResponse = null;
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(url);
      this.toastService.showSuccess(`Archivo ${filename} descargado exitosamente`);
    } catch (error) {
      console.error('Error al descargar el archivo:', error);
      this.toastService.showError('Error al descargar el archivo');
    }
  }

  // CREATE Modal Methods
  openCreateModal(): void {
    const cia = this.tipoNegocioForm.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }
    this.createTipoNegocioForm.reset();
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
    this.createTipoNegocioForm.reset();
  }

  async onSaveNew(): Promise<void> {
    if (this.createTipoNegocioForm.invalid) {
      this.toastService.showError('Por favor complete los campos requeridos');
      return;
    }

    const companiaId = this.tipoNegocioForm.get('cia')?.value;
    const nombreCia = this.tipoNegocioForm.get('nombre-cia')?.value;
    const agregaNegoValue = this.tipoNegocioForm.get('Agrega-Nego')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      
      const formData = this.createTipoNegocioForm.value;
      
      console.log('🔄 Creando tipo de negocio:', {
        cia: companiaId,
        ...formData
      });

      // 🔴 USAR EL MISMO ENDPOINT DE ACTUALIZACIÓN PARA CREAR
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
      const userLogin = this.auth.user()?.pcLogin || '';
      
      const payload = {
        tccnegoci: [{
          'Agrega-Nego': agregaNegoValue || '',
          cia: companiaId,
          'nombre-cia': nombreCia || '',
          'date-ctrl': today,
          'login-ctrl': userLogin,
          negocio: formData.negocio,
          'nombre-neg': formData['nombre-neg'],
          'text-neg': formData['text-neg'] || '',
          tparent: userLogin
        }]
      };

      const response = await this.ccService.updateTipoNegocio(payload);
      
      if (response?.dsRespuesta?.tccnegoci && response.dsRespuesta.tccnegoci.length > 0) {
        const result = response.dsRespuesta.tccnegoci[0];
        
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Tipo de negocio creado exitosamente');
        } else {
          this.toastService.showSuccess('Tipo de negocio creado exitosamente');
        }
        
        console.log('✅ Tipo de negocio creado');
        this.onClear();
        this.closeNegocioModal();
        await this.loadNegocios();
        this.cdr.detectChanges();
        this.closeCreateModal();
      } else {
        console.warn('⚠️ Respuesta inválida del servidor:', response);
        this.toastService.showWarning('Respuesta inválida del servidor');
      }
    } catch (error) {
      console.error('❌ Error al crear tipo de negocio:', error);
      const errorMessage = (error as any)?.error?.mensaje || (error as any)?.message || 'Error desconocido';
      this.toastService.showError('Error al crear: ' + errorMessage);
    } finally {
      this.loadingState.set(false);
    }
  }

  goBack(): void {
    this.router.navigate(['/']);
  }
}
