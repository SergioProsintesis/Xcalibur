import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { catchError, of } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../core/services/auth.service';
import { TablaRecord, TablaResponse, CompaniaResponse, UpdateTablaRequest, DeleteTablaRequest } from './cctablas.interface';

/**
 * CC0032 - Mantenimiento de Tablas 1 a 5
 * Servicio para gestionar tablas dinámicas
 */
@Injectable({
  providedIn: 'root'
})
export class CctablasService {
  private http = inject(HttpClient);
  private auth = inject(AuthService);
  private apiUrl = environment.apiUrl;

  /**
   * Obtiene los parámetros de autenticación
   */
  private getAuthParams() {
    const user = this.auth.user();
    return {
      pcLogin: user?.pcLogin || '',
      pcSuper: user?.pcSuper || '',
      pcToken: user?.pcToken || ''
    };
  }

  /**
   * Obtiene la lista de compañías (GetCECompanias)
   */
  async getCECompanias() {
    try {
      const params = this.getAuthParams();
      const response = await firstValueFrom(
        this.http.get<CompaniaResponse>(`${this.apiUrl}/GetCECompanias`, { params })
          .pipe(catchError((error: HttpErrorResponse) => {
            console.error('Error en getCECompanias:', error);
            return of({ dsRespuesta: { data: [] } } as CompaniaResponse);
          }))
      );
      return response.dsRespuesta.data || [];
    } catch (error) {
      console.error('Exception en getCECompanias:', error);
      return [];
    }
  }

  /**
   * Valida selección de compañía (GetLeaveGEcias)
   */
  async getLeaveCompania(cia: number) {
    try {
      const params = {
        ...this.getAuthParams(),
        cia: cia.toString()
      };
      const response = await firstValueFrom(
        this.http.get<CompaniaResponse>(`${this.apiUrl}/GetLeaveGEcias`, { params })
          .pipe(catchError(() => of({ dsRespuesta: { data: [] } } as CompaniaResponse)))
      );
      return response.dsRespuesta.data?.[0] || null;
    } catch (error) {
      console.error('Exception en getLeaveCompania:', error);
      return null;
    }
  }

  /**
   * Obtiene las tablas disponibles para una compañía
   * Asumiendo endpoint similar a otros: GetCETablas-cc0032
   */
  async getCETablas(tabla: number, cia: number) {
    try {
      const params = {
        ...this.getAuthParams(),
        tabla: tabla.toString(),
        cia: cia.toString()
      };
      const response = await firstValueFrom(
        this.http.get<TablaResponse>(`${this.apiUrl}/GetCETablas-cc0032`, { params })
          .pipe(catchError(() => of({ dsRespuesta: { data: [] } } as TablaResponse)))
      );
      return response.dsRespuesta.data || [];
    } catch (error) {
      console.error('Exception en getCETablas:', error);
      return [];
    }
  }

  /**
   * Obtiene detalles de una tabla específica (GetLeaveTabla-cc0032)
   */
  async getLeaveTabla(tabla: number, cia: number) {
    try {
      const params = {
        ...this.getAuthParams(),
        tabla: tabla.toString(),
        cia: cia.toString()
      };
      const response = await firstValueFrom(
        this.http.get<TablaResponse>(`${this.apiUrl}/GetLeaveTabla-cc0032`, { params })
          .pipe(catchError(() => of({ dsRespuesta: { data: [] } } as TablaResponse)))
      );
      return response.dsRespuesta.data?.[0] || null;
    } catch (error) {
      console.error('Exception en getLeaveTabla:', error);
      return null;
    }
  }

  /**
   * Crea o actualiza una tabla (UpdateCcTabla-cc0032)
   */
  async updateTabla(tabla: number, cia: number, nombreTabla: string, textTabla: string) {
    try {
      const params = {
        ...this.getAuthParams(),
        tabla: tabla.toString(),
        cia: cia.toString(),
        'nombre-tabla': nombreTabla,
        'text-tabla': textTabla
      };
      const response = await firstValueFrom(
        this.http.get<any>(`${this.apiUrl}/UpdateCcTabla-cc0032`, { params })
          .pipe(catchError((error: HttpErrorResponse) => {
            console.error('Error en updateTabla:', error);
            return of({ dsRespuesta: { error: error.statusText } });
          }))
      );
      return response;
    } catch (error) {
      console.error('Exception en updateTabla:', error);
      throw error;
    }
  }

  /**
   * Elimina una tabla (DelccTabla-cc0032)
   */
  async deleteTabla(tabla: number, cia: number) {
    try {
      const params = {
        ...this.getAuthParams(),
        tabla: tabla.toString(),
        cia: cia.toString()
      };
      const response = await firstValueFrom(
        this.http.get<any>(`${this.apiUrl}/DelccTabla-cc0032`, { params })
          .pipe(catchError((error: HttpErrorResponse) => {
            console.error('Error en deleteTabla:', error);
            return of({ dsRespuesta: { error: error.statusText } });
          }))
      );
      return response;
    } catch (error) {
      console.error('Exception en deleteTabla:', error);
      throw error;
    }
  }
}
