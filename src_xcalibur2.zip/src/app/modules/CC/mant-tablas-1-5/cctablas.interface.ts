/**
 * CC0032 - Mantenimiento de Tablas 1 a 5
 * Interfaz para la gestión de tablas dinámicas
 */

export interface CompaniaRecord {
  cia: number;
  'nombre-cia': string;
}

export interface CompaniaResponse {
  dsRespuesta: {
    data: CompaniaRecord[];
  };
}

export interface TablaRecord {
  tabla: number;
  cia: number;
  'nombre-cia'?: string;
  'nombre-tabla': string;
  'text-tabla'?: string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'Agrega-Tabla'?: string;
  tparent?: string;
}

export interface TablaResponse {
  dsRespuesta: {
    data: TablaRecord[];
  };
}

export interface TablasRequest {
  pcLogin: string;
  pcSuper: string;
  pcToken: string;
  tabla: number;
  cia: number;
}

export interface UpdateTablaRequest extends TablasRequest {
  'nombre-tabla': string;
  'text-tabla': string;
}

export interface DeleteTablaRequest extends TablasRequest {}
