import { Component, inject, signal, OnInit, computed, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { AuthService } from '../../../core/services/auth.service';
import { CctablasService } from './cctablas.service';
import { TablaRecord, CompaniaRecord } from './cctablas.interface';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';

@Component({
  selector: 'app-mant-tablas-1-5',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent],
  templateUrl: './mant-tablas-1-5.component.html',
  styleUrls: ['./mant-tablas-1-5.component.css']
})
export class MantTablas15Component implements OnInit {
  private fb = inject(FormBuilder);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private cctablasService = inject(CctablasService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private authService = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);

  tablaForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Tablas 1-5`);
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  tablaSeleccionada = signal<TablaRecord | null>(null);

  // Control de modales
  showCompaniaModal = signal(false);
  showTablaModal = signal(false);
  showCreateModal = signal(false);
  isEditMode = signal(false);
  tablasDisponibles = signal<TablaRecord[]>([]);
  createTablaForm!: FormGroup;

  ngOnInit() {
    console.log('🔄 MantTablas15Component inicializado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
  }

  private initializeForm(): void {
    this.tablaForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      tabla: ['', [Validators.required, Validators.min(1)]],
      'nombre-tabla': ['', [Validators.required]],
      'text-tabla': ['']
    });

    this.createTablaForm = this.fb.group({
      tabla: ['', [Validators.required, Validators.min(1)]],
      'nombre-tabla': ['', [Validators.required]],
      'text-tabla': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.tablaForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.tablaForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.tablaForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.showCompaniaModal.set(false);
    this.onCompaniaLeave();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.tablaForm.get('cia')?.value;
    if (ciaValue && ciaValue > 0) {
      await this.loadTablas(ciaValue);
    }
  }

  // ==================== LOAD TABLAS ====================
  private async loadDatos(): Promise<void> {
    const cia = this.tablaForm.get('cia')?.value;
    if (cia && cia > 0) {
      await this.loadTablas(cia);
    }
  }

  private async loadTablas(cia: number): Promise<void> {
    try {
      this.loadingState.set(true);
      const tablas = await this.cctablasService.getCETablas(0, cia);
      this.tablasDisponibles.set(tablas);
      this.tablaForm.patchValue({
        tabla: '',
        'nombre-tabla': '',
        'text-tabla': ''
      });
      this.tablaSeleccionada.set(null);
    } catch (error) {
      console.error('Error loading tablas:', error);
      this.toastService.showError('Error al cargar las tablas');
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== MODAL DE TABLAS ====================
  buscarTabla(): void {
    const ciaValue = this.tablaForm.get('cia')?.value;
    if (!ciaValue || ciaValue <= 0) {
      this.toastService.showWarning('Seleccione una compañía primero');
      return;
    }
    this.showTablaModal.set(true);
  }

  closeTablaModal(): void {
    this.showTablaModal.set(false);
  }

  closeTabla15Modal(): void {
    this.showTablaModal.set(false);
  }

  async onTablaSelected(tabla: TablaRecord): Promise<void> {
    this.tablaSeleccionada.set(tabla);
    this.showTablaModal.set(false);

    this.tablaForm.patchValue({
      tabla: tabla.tabla,
      'nombre-tabla': tabla['nombre-tabla'],
      'text-tabla': tabla['text-tabla'] || ''
    });

    this.isEditMode.set(true);
    this.showCreateModal.set(false);
    await this.onTablaLeave();
  }

  async onTablaLeave(): Promise<void> {
    const tablaValue = this.tablaForm.get('tabla')?.value;
    const ciaValue = this.tablaForm.get('cia')?.value;

    if (tablaValue && ciaValue) {
      try {
        this.loadingState.set(true);
        const tablaDetail = await this.cctablasService.getLeaveTabla(tablaValue, ciaValue);
        if (tablaDetail) {
          this.tablaForm.patchValue({
            'nombre-tabla': tablaDetail['nombre-tabla'],
            'text-tabla': tablaDetail['text-tabla'] || ''
          });
          this.tablaSeleccionada.set(tablaDetail);
        }
      } catch (error) {
        console.error('Error getting tabla details:', error);
      } finally {
        this.loadingState.set(false);
      }
    }
  }

  // ==================== FORM ACTIONS ====================
  async onSubmit(): Promise<void> {
    if (!this.tablaForm.valid) {
      this.toastService.showWarning('Por favor complete los campos requeridos');
      return;
    }

    const formValue = this.tablaForm.value;
    const tabla = formValue.tabla;
    const cia = formValue.cia;
    const nombreTabla = formValue['nombre-tabla'];
    const textTabla = formValue['text-tabla'];

    if (!tabla || !nombreTabla) {
      this.toastService.showError('Tabla y nombre son requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      await this.cctablasService.updateTabla(tabla, cia, nombreTabla, textTabla);
      this.toastService.showSuccess('Tabla guardada exitosamente');
      this.onClear();
      this.closeTabla15Modal();
      await this.loadDatos();
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Error saving tabla:', error);
      this.toastService.showError('Error al guardar la tabla');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onDelete(): Promise<void> {
    if (!this.tablaSeleccionada()) {
      this.toastService.showWarning('Seleccione una tabla para eliminar');
      return;
    }

    const tabla = this.tablaSeleccionada();
    if (confirm(`¿Está seguro de que desea eliminar la tabla ${tabla?.['nombre-tabla']}?`)) {
      try {
        this.loadingState.set(true);
        await this.cctablasService.deleteTabla(tabla!.tabla, tabla!.cia);
        this.onClear();
        this.closeTabla15Modal();
        await this.loadDatos();
        this.cdr.detectChanges();
      } catch (error) {
        console.error('Error deleting tabla:', error);
        this.toastService.showError('Error al eliminar la tabla');
      } finally {
        this.loadingState.set(false);
      }
    }
  }

  onClear(): void {
    this.tablaForm.reset();
    this.companiaSeleccionada.set(null);
    this.tablaSeleccionada.set(null);
    this.tablasDisponibles.set([]);
    this.isEditMode.set(false);
    this.showCreateModal.set(false);
  }

  openCreateModal(): void {
    const ciaValue = this.tablaForm.get('cia')?.value;
    if (!ciaValue || ciaValue <= 0) {
      this.toastService.showWarning('Seleccione una compañía primero');
      return;
    }
    this.createTablaForm.reset();
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
  }

  async onCreateSubmit(): Promise<void> {
    if (!this.createTablaForm.valid) {
      this.toastService.showWarning('Por favor complete los campos requeridos');
      return;
    }

    const formValue = this.createTablaForm.value;
    const cia = this.tablaForm.get('cia')?.value;

    try {
      this.loadingState.set(true);
      await this.cctablasService.updateTabla(
        formValue.tabla,
        cia,
        formValue['nombre-tabla'],
        formValue['text-tabla'] || ''
      );
      this.onClear();
      this.closeTabla15Modal();
      await this.loadDatos();
      this.cdr.detectChanges();
      this.closeCreateModal();
    } catch (error) {
      console.error('Error creating tabla:', error);
      this.toastService.showError('Error al crear la tabla');
    } finally {
      this.loadingState.set(false);
    }
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }

  isLoading(): boolean {
    return this.loadingState();
  }
}
