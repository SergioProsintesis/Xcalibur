import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../core/services/auth.service';
import { CC0026Response, CctipdocRecord } from './cc0026.interface';

@Injectable({
  providedIn: 'root'
})
export class CC0026Service {
  private http = inject(HttpClient);
  private auth = inject(AuthService);

  // ==================== CONSULTAS EMERGENTES ====================

  /**
   * Obtiene lista de compañías (Consulta emergente)
   */
  getCECompanias(): Observable<CC0026Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECompanias?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CC0026Response>(url);
  }

  /**
   * Obtiene tipos de documento (Consulta emergente)
   */
  getCETipodoc(pcCompania: number): Observable<CC0026Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCETipodoc?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CC0026Response>(url);
  }

  /**
   * Obtiene cuentas contables (Consulta emergente)
   */
  getCECuenta(pcCompania: number): Observable<CC0026Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECuentaCCxC?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CC0026Response>(url);
  }

  /**
   * Obtiene ubicaciones (Consulta emergente)
   */
  getCEUbicacion(pcCompania: number): Observable<CC0026Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEUbicacionCxC?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CC0026Response>(url);
  }

  /**
   * Obtiene centros de costo (Consulta emergente)
   */
  getCECentro(pcCompania: number): Observable<CC0026Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECentroCCxC?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CC0026Response>(url);
  }

  /**
   * Obtiene auxiliares (Consulta emergente)
   */
  getCEAuxiliar(pcCompania: number): Observable<CC0026Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEAuxiliarCxC?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CC0026Response>(url);
  }

  // ==================== EVENTOS LEAVE ====================

  /**
   * Evento Leave del campo Compañía
   */
  getLeaveCompania(pcCompania: number): Promise<CC0026Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveGEciasCxC?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CC0026Response>(url).toPromise() as Promise<CC0026Response>;
  }

  /**
   * Evento Leave del campo Tipo Documento
   */
  getLeaveTipodoc(pcCompania: number, pcTipoDoc: number): Promise<CC0026Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveTipodoc_cc0026?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcTipoDoc=${encodeURIComponent(pcTipoDoc.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CC0026Response>(url).toPromise() as Promise<CC0026Response>;
  }

  /**
   * Evento Leave del campo Cuenta
   */
  getLeaveCuenta(pcCompania: number, pcCuenta: string): Promise<CC0026Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCuenta-cc0046?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcCuenta=${encodeURIComponent(pcCuenta)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CC0026Response>(url).toPromise() as Promise<CC0026Response>;
  }

  /**
   * Evento Leave del campo Ubicación
   */
  getLeaveUbicacion(pcCompania: number): Promise<CC0026Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveUbicacionCxC?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CC0026Response>(url).toPromise() as Promise<CC0026Response>;
  }

  /**
   * Evento Leave del campo Centro de Costo
   */
  getLeaveCentro(pcCompania: number, pcCuentaC: string, pcCentro: number): Promise<CC0026Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCentroCCxC?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcCuentaC=${encodeURIComponent(pcCuentaC)}&pcCentro=${encodeURIComponent(pcCentro.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CC0026Response>(url).toPromise() as Promise<CC0026Response>;
  }

  /**
   * Evento Leave del campo Auxiliar
   */
  getLeaveAuxiliar(pcCompania: number, pcCuentaC: string, pcAuxiliar: number): Promise<CC0026Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveAuxiliarCxC?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcCuentaC=${encodeURIComponent(pcCuentaC)}&pcAuxiliar=${encodeURIComponent(pcAuxiliar.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<CC0026Response>(url).toPromise() as Promise<CC0026Response>;
  }

  // ==================== CRUD ====================

  /**
   * Actualiza un registro de Tipo de Documento Contable
   */
  updateCctipdoc(payload: CctipdocRecord): Promise<CC0026Response> {
    const url = `${environment.apiUrl}/UpdateCctipdoc_cc0026`;
    return this.http.put<CC0026Response>(url, { tcctipdoc3: [payload] }).toPromise() as Promise<CC0026Response>;
  }

  /**
   * Elimina un registro de Tipo de Documento Contable (blanquea datos contables)
   */
  deleteCctipdoc(pcCompania: number, pcTipoDoc: number): Promise<CC0026Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/DelCctipdoc_cc0026?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcTipoDoc=${encodeURIComponent(pcTipoDoc.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.delete<CC0026Response>(url).toPromise() as Promise<CC0026Response>;
  }
}
