// CC0026 - MANT. CONTABLE TIPO DOCUMENTO Interfaces

export interface CctipdocRecord {
  'cia': number;
  'tipodoc': number;
  'nombre-tdoc': string;
  'siglas-tdoc': string;
  'clase-tdoc': number;
  'cuentam1': string;
  'nombre-cta': string;
  'centrom1': number;
  'nombre-cen': string;
  'ubicacionm1': number;
  'nombre-ubic': string;
  'auxiliarm1': number;
  'nombre-aux': string;
  'afecxc-tdoc'?: boolean;
  'afeinv-tdoc'?: boolean;
  'afesta-tdoc'?: boolean;
  'numfac-tdoc'?: number;
  'numped-tdoc'?: number;
  'profac-tdoc'?: number;
  'text-tdoc'?: string;
  'tipcomi'?: number;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'agrega-numcon'?: number;
  'tparent'?: string;
}

export interface CompaniaRecord {
  'cia': number;
  'nombre-cia': string;
  'nit': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface TipodocRecord {
  'tipodoc': number;
  'nombre-tdoc': string;
  'siglas-tdoc': string;
  'clase-tdoc': number;
  'cia': number;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CuentaRecord {
  'cuenta': string;
  'nombre-cta': string;
  'cia': number;
  'moneda'?: number;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface UbicacionRecord {
  'ubicacion': number;
  'nombre-ubic': string;
  'cia': number;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CentroRecord {
  'centro': number;
  'nombre-cen': string;
  'cia': number;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface AuxiliarRecord {
  'auxiliar': number;
  'nombre-aux': string;
  'cia': number;
  'cuenta'?: string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CC0026Response {
  'dsRespuesta': {
    'tcctipdoc3'?: CctipdocRecord[];
    'tgecias'?: CompaniaRecord[];
    'tcctipdoc'?: TipodocRecord[];
    'tcgcontab'?: CuentaRecord[];
    'tcgubicac'?: UbicacionRecord[];
    'tgecencos'?: CentroRecord[];
    'tcgmaeaux'?: AuxiliarRecord[];
  };
}
