import { Component, inject, signal, OnInit, computed, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { CC0026Service } from './cc0026.service';
import { 
  CctipdocRecord, 
  CompaniaRecord, 
  TipodocRecord,
  CuentaRecord,
  UbicacionRecord,
  CentroRecord,
  AuxiliarRecord 
} from './cc0026.interface';

@Component({
  selector: 'app-mant-contable-tipo-documento',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent],
  templateUrl: './mant-contable-tipo-documento.component.html',
  styleUrls: ['./mant-contable-tipo-documento.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MantContableTipoDocumentoComponent implements OnInit {
  private fb = inject(FormBuilder);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private cc0026Service = inject(CC0026Service);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);

  tipoDocumentoForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento Contable Tipo Documento`);
  loadingState = signal<boolean>(false);
  isEditMode = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  tipodocSeleccionado = signal<TipodocRecord | null>(null);
  cuentaSeleccionada = signal<CuentaRecord | null>(null);
  ubicacionSeleccionada = signal<UbicacionRecord | null>(null);
  centroSeleccionado = signal<CentroRecord | null>(null);
  auxiliarSeleccionado = signal<AuxiliarRecord | null>(null);

  // Listas disponibles
  tipodocList = signal<TipodocRecord[]>([]);
  cuentaList = signal<CuentaRecord[]>([]);
  ubicacionList = signal<UbicacionRecord[]>([]);
  centroList = signal<CentroRecord[]>([]);
  auxiliarList = signal<AuxiliarRecord[]>([]);

  // Control de modales
  showCompaniaModal = signal(false);
  showTipodocModal = signal(false);
  showCuentaModal = signal(false);
  showUbicacionModal = signal(false);
  showCentroModal = signal(false);
  showAuxiliarModal = signal(false);
  showCreateModal = signal(false);

  // Búsqueda en modales
  tipodocSearch = signal('');
  cuentaSearch = signal('');
  ubicacionSearch = signal('');
  centroSearch = signal('');
  auxiliarSearch = signal('');

  // Listas filtradas
  filteredTipodocList = computed(() => {
    const query = this.tipodocSearch().toLowerCase();
    return this.tipodocList().filter(item =>
      item.tipodoc.toString().includes(query) ||
      item['nombre-tdoc'].toLowerCase().includes(query)
    );
  });

  filteredCuentaList = computed(() => {
    const query = this.cuentaSearch().toLowerCase();
    return this.cuentaList().filter(item =>
      item.cuenta.toLowerCase().includes(query) ||
      item['nombre-cta'].toLowerCase().includes(query)
    );
  });

  filteredUbicacionList = computed(() => {
    const query = this.ubicacionSearch().toLowerCase();
    return this.ubicacionList().filter(item =>
      item.ubicacion.toString().includes(query) ||
      item['nombre-ubic'].toLowerCase().includes(query)
    );
  });

  filteredCentroList = computed(() => {
    const query = this.centroSearch().toLowerCase();
    return this.centroList().filter(item =>
      item.centro.toString().includes(query) ||
      item['nombre-cen'].toLowerCase().includes(query)
    );
  });

  filteredAuxiliarList = computed(() => {
    const query = this.auxiliarSearch().toLowerCase();
    return this.auxiliarList().filter(item =>
      item.auxiliar.toString().includes(query) ||
      item['nombre-aux'].toLowerCase().includes(query)
    );
  });

  // Formulario de creación
  createForm!: FormGroup;

  ngOnInit(): void {
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
  }

  private initializeForm(): void {
    this.tipoDocumentoForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      tipodoc: ['', [Validators.required, Validators.min(1)]],
      'nombre-tdoc': [{ value: '', disabled: true }],
      'siglas-tdoc': [''],
      'clase-tdoc': [{ value: '', disabled: true }],
      'cuentam1': ['', [Validators.required]],
      'nombre-cta': [{ value: '', disabled: true }],
      'centrom1': [''],
      'nombre-cen': [{ value: '', disabled: true }],
      'ubicacionm1': [''],
      'nombre-ubic': [{ value: '', disabled: true }],
      'auxiliarm1': [''],
      'nombre-aux': [{ value: '', disabled: true }],
      'text-tdoc': ['']
    });

    this.createForm = this.fb.group({
      tipodoc: ['', [Validators.required, Validators.min(1)]],
      'nombre-tdoc': ['', [Validators.required]],
      'siglas-tdoc': [''],
      'clase-tdoc': ['', [Validators.required]],
      'cuentam1': ['', [Validators.required]],
      'centrom1': [''],
      'ubicacionm1': [''],
      'auxiliarm1': [''],
      'text-tdoc': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.tipoDocumentoForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.tipoDocumentoForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.tipoDocumentoForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.limpiarTipodoc();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.tipoDocumentoForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.cc0026Service.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.tipoDocumentoForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarCompania(): void {
    this.tipoDocumentoForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
    this.companiaSeleccionada.set(null);
    this.limpiarTipodoc();
  }

  // ==================== MODAL DE TIPO DOCUMENTO ====================
  async buscarTipodoc(): Promise<void> {
    const cia = this.tipoDocumentoForm.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }
    
    try {
      this.loadingState.set(true);
      await this.loadTipodocListAsync();
    } catch (error) {
      console.error('Error in buscarTipodoc:', error);
      this.toastService.showError('Error al buscar tipos de documento');
    } finally {
      this.loadingState.set(false);
      this.showTipodocModal.set(true);
    }
  }

  private loadTipodocListAsync(): Promise<void> {
    return new Promise((resolve) => {
      const cia = this.tipoDocumentoForm.get('cia')?.value;
      if (!cia) {
        resolve();
        return;
      }

      try {
        this.cc0026Service.getCETipodoc(cia).subscribe({
          next: (response) => {
            if (response?.dsRespuesta?.tcctipdoc) {
              this.tipodocList.set(response.dsRespuesta.tcctipdoc);
            }
            resolve();
          },
          error: (err) => {
            console.error('Error cargando tipos documento:', err);
            this.toastService.showError('Error al cargar tipos de documento');
            resolve();
          }
        });
      } catch (error) {
        console.error('Error:', error);
        resolve();
      }
    });
  }

  closeTipodocModal(): void {
    this.showTipodocModal.set(false);
    this.tipodocSearch.set('');
  }

  onTipodocSelected(tipodoc: TipodocRecord): void {
    this.tipodocSeleccionado.set(tipodoc);
    this.tipoDocumentoForm.patchValue({
      tipodoc: tipodoc.tipodoc,
      'nombre-tdoc': tipodoc['nombre-tdoc'],
      'siglas-tdoc': tipodoc['siglas-tdoc'],
      'clase-tdoc': tipodoc['clase-tdoc']
    });
    this.closeTipodocModal();
    this.limpiarCuenta();
  }

  async onTipodocLeave(): Promise<void> {
    const ciaValue = this.tipoDocumentoForm.get('cia')?.value;
    const tipodocValue = this.tipoDocumentoForm.get('tipodoc')?.value;
    
    if (!ciaValue || !tipodocValue) {
      this.limpiarTipodoc();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.cc0026Service.getLeaveTipodoc(ciaValue, tipodocValue);
      
      if (response?.dsRespuesta?.tcctipdoc3 && response.dsRespuesta.tcctipdoc3.length > 0) {
        const tipodoc = response.dsRespuesta.tcctipdoc3[0];
        this.tipodocSeleccionado.set(tipodoc);
        this.tipoDocumentoForm.patchValue({
          'nombre-tdoc': tipodoc['nombre-tdoc'],
          'siglas-tdoc': tipodoc['siglas-tdoc'],
          'clase-tdoc': tipodoc['clase-tdoc'],
          'cuentam1': tipodoc['cuentam1'],
          'nombre-cta': tipodoc['nombre-cta'],
          'centrom1': tipodoc['centrom1'],
          'nombre-cen': tipodoc['nombre-cen'],
          'ubicacionm1': tipodoc['ubicacionm1'],
          'nombre-ubic': tipodoc['nombre-ubic'],
          'auxiliarm1': tipodoc['auxiliarm1'],
          'nombre-aux': tipodoc['nombre-aux'],
          'text-tdoc': tipodoc['text-tdoc']
        });
        this.isEditMode.set(true);
        await this.loadCuentaListAsync();
      } else {
        this.toastService.showWarning('Tipo de documento no encontrado');
        this.limpiarTipodoc();
      }
    } catch (error) {
      console.error('Error al buscar tipo documento:', error);
      this.toastService.showError('Error al buscar el tipo de documento');
      this.limpiarTipodoc();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarTipodoc(): void {
    this.tipoDocumentoForm.patchValue({
      tipodoc: '',
      'nombre-tdoc': '',
      'siglas-tdoc': '',
      'clase-tdoc': ''
    });
    this.tipodocSeleccionado.set(null);
    this.isEditMode.set(false);
    this.limpiarCuenta();
  }

  // ==================== MODAL DE CUENTA ====================
  async buscarCuenta(): Promise<void> {
    const cia = this.tipoDocumentoForm.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }
    
    try {
      this.loadingState.set(true);
      if (this.cuentaList().length === 0) {
        await this.loadCuentaListAsync();
      }
    } catch (error) {
      console.error('Error in buscarCuenta:', error);
      this.toastService.showError('Error al buscar cuentas');
    } finally {
      this.loadingState.set(false);
      this.showCuentaModal.set(true);
    }
  }

  private loadCuentaListAsync(): Promise<void> {
    return new Promise((resolve) => {
      const cia = this.tipoDocumentoForm.get('cia')?.value;
      if (!cia) {
        resolve();
        return;
      }

      try {
        this.cc0026Service.getCECuenta(cia).subscribe({
          next: (response) => {
            if (response?.dsRespuesta?.tcgcontab) {
              this.cuentaList.set(response.dsRespuesta.tcgcontab);
            }
            resolve();
          },
          error: (err) => {
            console.error('Error cargando cuentas:', err);
            resolve();
          }
        });
      } catch (error) {
        console.error('Error:', error);
        resolve();
      }
    });
  }

  private loadCentroListAsync(): Promise<void> {
    return new Promise((resolve) => {
      const cia = this.tipoDocumentoForm.get('cia')?.value;
      if (!cia) {
        resolve();
        return;
      }

      try {
        this.cc0026Service.getCECentro(cia).subscribe({
          next: (response) => {
            if (response?.dsRespuesta?.tgecencos) {
              this.centroList.set(response.dsRespuesta.tgecencos);
            }
            resolve();
          },
          error: (err) => {
            console.error('Error cargando centros:', err);
            resolve();
          }
        });
      } catch (error) {
        console.error('Error:', error);
        resolve();
      }
    });
  }

  private loadAuxiliarListAsync(): Promise<void> {
    return new Promise((resolve) => {
      const cia = this.tipoDocumentoForm.get('cia')?.value;
      if (!cia) {
        resolve();
        return;
      }

      try {
        this.cc0026Service.getCEAuxiliar(cia).subscribe({
          next: (response) => {
            if (response?.dsRespuesta?.tcgmaeaux) {
              this.auxiliarList.set(response.dsRespuesta.tcgmaeaux);
            }
            resolve();
          },
          error: (err) => {
            console.error('Error cargando auxiliares:', err);
            resolve();
          }
        });
      } catch (error) {
        console.error('Error:', error);
        resolve();
      }
    });
  }

  onCuentaSelected(cuenta: CuentaRecord): void {
    this.cuentaSeleccionada.set(cuenta);
    this.tipoDocumentoForm.patchValue({
      'cuentam1': cuenta.cuenta,
      'nombre-cta': cuenta['nombre-cta']
    });
    this.closeCuentaModal();
  }

  async onCuentaLeave(): Promise<void> {
    const ciaValue = this.tipoDocumentoForm.get('cia')?.value;
    const cuentaValue = this.tipoDocumentoForm.get('cuentam1')?.value;
    
    if (!ciaValue || !cuentaValue) {
      this.limpiarCuenta();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.cc0026Service.getLeaveCuenta(ciaValue, cuentaValue);
      
      if (response?.dsRespuesta?.tcgcontab && response.dsRespuesta.tcgcontab.length > 0) {
        const cuenta = response.dsRespuesta.tcgcontab[0];
        this.cuentaSeleccionada.set(cuenta);
        this.tipoDocumentoForm.patchValue({
          'nombre-cta': cuenta['nombre-cta']
        });
        await this.loadCentroListAsync();
      } else {
        this.toastService.showWarning('Cuenta no encontrada');
        this.limpiarCuenta();
      }
    } catch (error) {
      console.error('Error al buscar cuenta:', error);
      this.toastService.showError('Error al buscar la cuenta');
      this.limpiarCuenta();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarCuenta(): void {
    this.tipoDocumentoForm.patchValue({
      'cuentam1': '',
      'nombre-cta': ''
    });
    this.cuentaSeleccionada.set(null);
  }

  closeCuentaModal(): void {
    this.showCuentaModal.set(false);
    this.cuentaSearch.set('');
  }

  // ==================== MODAL DE UBICACIÓN ====================
  async buscarUbicacion(): Promise<void> {
    const cia = this.tipoDocumentoForm.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }
    
    try {
      this.loadingState.set(true);
      await this.loadUbicacionListAsync();
    } catch (error) {
      console.error('Error in buscarUbicacion:', error);
      this.toastService.showError('Error al buscar ubicaciones');
    } finally {
      this.loadingState.set(false);
      this.showUbicacionModal.set(true);
    }
  }

  private loadUbicacionListAsync(): Promise<void> {
    return new Promise((resolve) => {
      const cia = this.tipoDocumentoForm.get('cia')?.value;
      if (!cia) {
        resolve();
        return;
      }

      try {
        this.cc0026Service.getCEUbicacion(cia).subscribe({
          next: (response) => {
            if (response?.dsRespuesta?.tcgubicac) {
              this.ubicacionList.set(response.dsRespuesta.tcgubicac);
            }
            resolve();
          },
          error: (err) => {
            console.error('Error cargando ubicaciones:', err);
            resolve();
          }
        });
      } catch (error) {
        console.error('Error:', error);
        resolve();
      }
    });
  }

  closeUbicacionModal(): void {
    this.showUbicacionModal.set(false);
    this.ubicacionSearch.set('');
  }

  onUbicacionSelected(ubicacion: UbicacionRecord): void {
    this.ubicacionSeleccionada.set(ubicacion);
    this.tipoDocumentoForm.patchValue({
      'ubicacionm1': ubicacion.ubicacion,
      'nombre-ubic': ubicacion['nombre-ubic']
    });
    this.closeUbicacionModal();
  }

  private limpiarUbicacion(): void {
    this.tipoDocumentoForm.patchValue({
      'ubicacionm1': '',
      'nombre-ubic': ''
    });
    this.ubicacionSeleccionada.set(null);
  }

  // ==================== MODAL DE CENTRO ====================
  async buscarCentro(): Promise<void> {
    const cia = this.tipoDocumentoForm.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }
    
    try {
      this.loadingState.set(true);
      await this.loadCentroListAsync();
    } catch (error) {
      console.error('Error in buscarCentro:', error);
      this.toastService.showError('Error al buscar centros');
    } finally {
      this.loadingState.set(false);
      this.showCentroModal.set(true);
    }
  }

  closeCentroModal(): void {
    this.showCentroModal.set(false);
    this.centroSearch.set('');
  }

  onCentroSelected(centro: CentroRecord): void {
    this.centroSeleccionado.set(centro);
    this.tipoDocumentoForm.patchValue({
      'centrom1': centro.centro,
      'nombre-cen': centro['nombre-cen']
    });
    this.closeCentroModal();
  }

  private limpiarCentro(): void {
    this.tipoDocumentoForm.patchValue({
      'centrom1': '',
      'nombre-cen': ''
    });
    this.centroSeleccionado.set(null);
  }

  // ==================== MODAL DE AUXILIAR ====================
  async buscarAuxiliar(): Promise<void> {
    const cia = this.tipoDocumentoForm.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }
    
    try {
      this.loadingState.set(true);
      await this.loadAuxiliarListAsync();
    } catch (error) {
      console.error('Error in buscarAuxiliar:', error);
      this.toastService.showError('Error al buscar auxiliares');
    } finally {
      this.loadingState.set(false);
      this.showAuxiliarModal.set(true);
    }
  }

  closeAuxiliarModal(): void {
    this.showAuxiliarModal.set(false);
    this.auxiliarSearch.set('');
  }

  onAuxiliarSelected(auxiliar: AuxiliarRecord): void {
    this.auxiliarSeleccionado.set(auxiliar);
    this.tipoDocumentoForm.patchValue({
      'auxiliarm1': auxiliar.auxiliar,
      'nombre-aux': auxiliar['nombre-aux']
    });
    this.closeAuxiliarModal();
  }

  private limpiarAuxiliar(): void {
    this.tipoDocumentoForm.patchValue({
      'auxiliarm1': '',
      'nombre-aux': ''
    });
    this.auxiliarSeleccionado.set(null);
  }

  // ==================== CRUD ====================
  openCreateModal(): void {
    this.createForm.reset();
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
  }

  async onCreateSubmit(): Promise<void> {
    if (this.createForm.invalid) {
      this.toastService.showError('Por favor complete los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      this.loadingService.show();

      const formData = this.createForm.getRawValue();
      const cia = this.tipoDocumentoForm.get('cia')?.value;

      const payload: CctipdocRecord = {
        cia,
        'tipodoc': formData.tipodoc,
        'nombre-tdoc': formData['nombre-tdoc'],
        'siglas-tdoc': formData['siglas-tdoc'],
        'clase-tdoc': formData['clase-tdoc'],
        'cuentam1': formData['cuentam1'],
        'nombre-cta': '',
        'centrom1': formData['centrom1'] || 0,
        'nombre-cen': '',
        'ubicacionm1': formData['ubicacionm1'] || 0,
        'nombre-ubic': '',
        'auxiliarm1': formData['auxiliarm1'] || 0,
        'nombre-aux': '',
        'text-tdoc': formData['text-tdoc']
      };

      const response = await this.cc0026Service.updateCctipdoc(payload);

      if (response?.dsRespuesta?.tcctipdoc3) {
        this.toastService.showSuccess('Registro guardado correctamente');
        this.closeCreateModal();
        this.tipoDocumentoForm.reset();
        this.companiaSeleccionada.set(null);
        this.tipodocSeleccionado.set(null);
      } else {
        this.toastService.showError('Error al guardar el registro');
      }
    } catch (error) {
      console.error('Error guardando registro:', error);
      this.toastService.showError('Error al guardar el registro');
    } finally {
      this.loadingState.set(false);
      this.loadingService.hide();
    }
  }

  async onSubmit(): Promise<void> {
    if (this.tipoDocumentoForm.invalid) {
      this.toastService.showError('Por favor complete los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      this.loadingService.show();

      const formData = this.tipoDocumentoForm.getRawValue();

      const payload: CctipdocRecord = {
        'cia': formData.cia,
        'tipodoc': formData.tipodoc,
        'nombre-tdoc': formData['nombre-tdoc'],
        'siglas-tdoc': formData['siglas-tdoc'],
        'clase-tdoc': formData['clase-tdoc'],
        'cuentam1': formData['cuentam1'],
        'nombre-cta': formData['nombre-cta'],
        'centrom1': formData['centrom1'] || 0,
        'nombre-cen': formData['nombre-cen'],
        'ubicacionm1': formData['ubicacionm1'] || 0,
        'nombre-ubic': formData['nombre-ubic'],
        'auxiliarm1': formData['auxiliarm1'] || 0,
        'nombre-aux': formData['nombre-aux'],
        'text-tdoc': formData['text-tdoc']
      };

      const response = await this.cc0026Service.updateCctipdoc(payload);

      if (response?.dsRespuesta?.tcctipdoc3) {
        this.toastService.showSuccess('Registro actualizado correctamente');
      } else {
        this.toastService.showError('Error al actualizar el registro');
      }
    } catch (error) {
      console.error('Error actualizando registro:', error);
      this.toastService.showError('Error al actualizar el registro');
    } finally {
      this.loadingState.set(false);
      this.loadingService.hide();
    }
  }

  async onDelete(): Promise<void> {
    if (!this.isEditMode()) {
      this.toastService.showError('Debe seleccionar un registro para eliminar');
      return;
    }

    const cia = this.tipoDocumentoForm.get('cia')?.value;
    const tipodoc = this.tipoDocumentoForm.get('tipodoc')?.value;

    if (!cia || !tipodoc) {
      this.toastService.showError('Debe seleccionar compañía y tipo documento');
      return;
    }

    try {
      this.loadingState.set(true);
      this.loadingService.show();

      const response = await this.cc0026Service.deleteCctipdoc(cia, tipodoc);

      if (response?.dsRespuesta?.tcctipdoc3) {
        this.toastService.showSuccess('Registro eliminado correctamente');
        this.onClear();
      } else {
        this.toastService.showError('Error al eliminar el registro');
      }
    } catch (error) {
      console.error('Error eliminando registro:', error);
      this.toastService.showError('Error al eliminar el registro');
    } finally {
      this.loadingState.set(false);
      this.loadingService.hide();
    }
  }

  onClear(): void {
    this.tipoDocumentoForm.reset();
    this.createForm.reset();
    this.companiaSeleccionada.set(null);
    this.tipodocSeleccionado.set(null);
    this.cuentaSeleccionada.set(null);
    this.ubicacionSeleccionada.set(null);
    this.centroSeleccionado.set(null);
    this.auxiliarSeleccionado.set(null);
    this.isEditMode.set(false);
  }

  goBack(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }
}
