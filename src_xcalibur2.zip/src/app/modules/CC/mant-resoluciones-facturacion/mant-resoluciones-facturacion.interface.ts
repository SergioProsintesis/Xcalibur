export interface CompanyResponse {
  dsRespuesta: {
    tgecias: Company[];
  };
}

export interface Company {
  cia: number;
  'nombre-cia': string;
}

export interface ResolutionObservation {
  'Agrega-Obsg'?: string;
  cia: number;
  'nombre-cia': string;
  'obser1-obs'?: string;
  'obser2-obs'?: string;
  'obser3-obs'?: string;
  'obser4-obs'?: string;
  'obser5-obs'?: string;
  'obser6-obs'?: string;
  'obser7-obs'?: string;
  'teobser7-obs'?: string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  tparent?: string;
  terrores?: Array<{ codigo: string; descripcion: string; tPARENT?: string }>;
}

export interface ResolutionResponse {
  dsRespuesta: {
    tfaobsgen: ResolutionObservation[];
  };
}
