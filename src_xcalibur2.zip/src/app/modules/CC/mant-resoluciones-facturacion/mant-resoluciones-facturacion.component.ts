import { Component, OnInit, inject, signal, computed, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { MantResolucionesFacturacionService } from './mant-resoluciones-facturacion.service';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { Company, ResolutionObservation } from './mant-resoluciones-facturacion.interface';
import { CompaniaRecord } from '../../../core/interfaces/cc.interface';

@Component({
  selector: 'app-mant-resoluciones-facturacion',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, CompaniaModalComponent],
  templateUrl: './mant-resoluciones-facturacion.component.html',
  styleUrl: './mant-resoluciones-facturacion.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MantResolucionesFacturacionComponent implements OnInit {
  private fb = inject(FormBuilder);
  private service = inject(MantResolucionesFacturacionService);
  private authService = inject(AuthService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private cdr = inject(ChangeDetectorRef);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);

  // Form and state
  form!: FormGroup;
  companies = signal<Company[]>([]);
  selectedCompany = signal<Company | null>(null);
  selectedResolution = signal<ResolutionObservation | null>(null);
  loadingState = signal(false);
  isEditMode = signal(false);
  
  // Signals for modals
  showCompaniaModal = signal(false);
  showCreateModal = signal(false);
  
  // Forms
  createResolutionForm!: FormGroup;

  // Computed
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento Resoluciones Facturación`);

  ngOnInit(): void {
    console.log('🔄 MantResolucionesFacturacionComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initForm();
    this.initCreateForm();
    this.loadCompanies();
    console.log('✅ MantResolucionesFacturacionComponent inicializado correctamente');
  }

  // ==================== FORM INITIALIZATION ====================
  private initForm(): void {
    this.form = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      'obser1-obs': ['', [Validators.required]],
      'obser2-obs': ['', [Validators.required]],
      'obser3-obs': [''],
      'obser4-obs': [''],
      'obser5-obs': [''],
      'obser6-obs': [''],
      'obser7-obs': [''],
      'teobser7-obs': ['']
    });
  }

  private initCreateForm(): void {
    this.createResolutionForm = this.fb.group({
      'obser1-obs': ['', [Validators.required]],
      'obser2-obs': ['', [Validators.required]],
      'obser3-obs': [''],
      'obser4-obs': [''],
      'obser5-obs': [''],
      'obser6-obs': [''],
      'obser7-obs': [''],
      'teobser7-obs': ['']
    });
  }

  // ==================== LOAD DATA ====================
  private async loadCompanies(): Promise<void> {
    try {
      const user = this.authService.user();
      if (user && user.pcLogin && user.pcSuper && user.pcToken) {
        const response = await this.service.getCompanies(user.pcLogin, user.pcSuper, user.pcToken);
        this.companies.set(response.dsRespuesta.tgecias);
      }
    } catch (error) {
      console.error('Error loading companies:', error);
      this.toastService.showError('Error al cargar las compañías');
    }
  }

  // ==================== VALIDATIONS ====================
  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (!field?.errors) return '';
    if (field.errors['required']) return 'Este campo es requerido';
    if (field.errors['min']) return `Valor mínimo: ${field.errors['min'].min}`;
    return 'Error en el campo';
  }

  // ==================== COMPANY MODAL ====================
  buscarCompania(): void {
    if (this.companies().length === 0) {
      this.toastService.showWarning('No hay compañías disponibles');
      return;
    }
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.selectedCompany.set(compania);
    this.form.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.loadData();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.form.get('cia')?.value;
    if (!ciaValue) {
      return;
    }
    const company = this.companies().find((c: Company) => c.cia.toString() === ciaValue.toString());
    if (company) {
      this.selectedCompany.set(company);
      this.form.patchValue({ 'nombre-cia': company['nombre-cia'] });
      await this.loadData();
    } else {
      this.toastService.showError('Compañía no encontrada');
      this.form.patchValue({ cia: '' });
      this.selectedCompany.set(null);
    }
  }

  // ==================== LOAD DATA ====================
  private async loadData(): Promise<void> {
    try {
      const ciaValue = this.form.get('cia')?.value;
      const user = this.authService.user();
      if (ciaValue && user && user.pcLogin && user.pcSuper && user.pcToken) {
        this.loadingState.set(true);
        const response = await this.service.getLeaveData(ciaValue, user.pcLogin, user.pcSuper, user.pcToken);
        if (response.dsRespuesta.tfaobsgen.length > 0) {
          const data = response.dsRespuesta.tfaobsgen[0];
          this.selectedResolution.set(data);
          this.isEditMode.set(true);
          this.form.patchValue({
            'obser1-obs': data['obser1-obs'] || '',
            'obser2-obs': data['obser2-obs'] || '',
            'obser3-obs': data['obser3-obs'] || '',
            'obser4-obs': data['obser4-obs'] || '',
            'obser5-obs': data['obser5-obs'] || '',
            'obser6-obs': data['obser6-obs'] || '',
            'obser7-obs': data['obser7-obs'] || '',
            'teobser7-obs': data['teobser7-obs'] || ''
          });
          this.toastService.showSuccess('Datos cargados correctamente');
        } else {
          console.log('Sin observaciones registradas para esta compañía');
          this.selectedResolution.set(null);
          this.isEditMode.set(false);
          this.form.patchValue({
            'obser1-obs': '',
            'obser2-obs': '',
            'obser3-obs': '',
            'obser4-obs': '',
            'obser5-obs': '',
            'obser6-obs': '',
            'obser7-obs': '',
            'teobser7-obs': ''
          });
        }
      }
    } catch (error) {
      console.error('Error loading data:', error);
      this.toastService.showError('Error al cargar los datos');
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== CREATE MODAL ====================
  openCreateModal(): void {
    const companiaId = this.form.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    this.createResolutionForm.reset();
    this.isEditMode.set(false);
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
    this.createResolutionForm.reset();
  }

  async onCreateSubmit(): Promise<void> {
    if (this.createResolutionForm.invalid) {
      this.toastService.showError('Por favor complete los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const user = this.authService.user();
      const companiaId = this.form.get('cia')?.value;
      const nombreCompania = this.form.get('nombre-cia')?.value;
      const formData = this.createResolutionForm.value;
      
      if (user && user.pcLogin && user.pcSuper && user.pcToken) {
        const payload = {
          tfaobsgen: [{
            'Agrega-Obsg': '',
            cia: parseInt(companiaId),
            'nombre-cia': nombreCompania,
            'obser1-obs': formData['obser1-obs'],
            'obser2-obs': formData['obser2-obs'],
            'obser3-obs': formData['obser3-obs'],
            'obser4-obs': formData['obser4-obs'],
            'obser5-obs': formData['obser5-obs'],
            'obser6-obs': formData['obser6-obs'],
            'obser7-obs': formData['obser7-obs'],
            'teobser7-obs': formData['teobser7-obs'],
            'date-ctrl': new Date().toISOString().split('T')[0],
            'login-ctrl': user.pcLogin,
            tparent: user.pcLogin
          }]
        };

        const response = await this.service.updateData(payload);
        if (response?.dsRespuesta?.tfaobsgen && response.dsRespuesta.tfaobsgen.length > 0) {
          const result = response.dsRespuesta.tfaobsgen[0];
          if (result.terrores && result.terrores.length > 0) {
            const error = result.terrores[0];
            this.toastService.showSuccess(error.descripcion || 'Resolución creada exitosamente');
          } else {
            this.toastService.showSuccess('Resolución creada exitosamente');
          }
          this.closeCreateModal();
          await this.loadData();
          this.cdr.detectChanges();
        }
      }
    } catch (error) {
      console.error('Error al crear:', error);
      this.toastService.showError('Error al crear la resolución');
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== CRUD OPERATIONS ====================
  async onSave(): Promise<void> {
    if (this.form.invalid) {
      this.toastService.showError('Por favor complete todos los campos requeridos');
      return;
    }
    try {
      this.loadingState.set(true);
      const user = this.authService.user();
      if (user && user.pcLogin && user.pcSuper && user.pcToken) {
        const formValue = this.form.getRawValue();
        const selectedCompany = this.selectedCompany();

        const payload = {
          tfaobsgen: [{
            'Agrega-Obsg': '',
            cia: parseInt(formValue.cia),
            'nombre-cia': selectedCompany?.['nombre-cia'] || '',
            'obser1-obs': formValue['obser1-obs'],
            'obser2-obs': formValue['obser2-obs'],
            'obser3-obs': formValue['obser3-obs'],
            'obser4-obs': formValue['obser4-obs'],
            'obser5-obs': formValue['obser5-obs'],
            'obser6-obs': formValue['obser6-obs'],
            'obser7-obs': formValue['obser7-obs'],
            'teobser7-obs': formValue['teobser7-obs'],
            'date-ctrl': new Date().toISOString().split('T')[0],
            'login-ctrl': user.pcLogin,
            tparent: user.pcLogin
          }]
        };

        console.log('🔄 Enviando actualización:', payload);
        const response = await this.service.updateData(payload);

        if (response?.dsRespuesta?.tfaobsgen && response.dsRespuesta.tfaobsgen.length > 0) {
          const result = response.dsRespuesta.tfaobsgen[0];
          if (result.terrores && result.terrores.length > 0) {
            const error = result.terrores[0];
            this.toastService.showSuccess(error.descripcion || 'Datos guardados correctamente');
          } else {
            this.toastService.showSuccess('Datos guardados correctamente');
          }
          this.cdr.detectChanges();
        }
      }
    } catch (error) {
      console.error('Error saving data:', error);
      this.toastService.showError('Error al guardar los datos');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onDelete(): Promise<void> {
    const companiaId = this.form.get('cia')?.value;

    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía para eliminar');
      return;
    }

    const confirmed = confirm('¿Está seguro de eliminar esta resolución facturación?\nEsta acción no se puede deshacer');

    if (!confirmed) return;

    try {
      this.loadingState.set(true);
      const user = this.authService.user();
      if (user && user.pcLogin && user.pcSuper && user.pcToken) {
        await this.service.deleteData(companiaId, user.pcLogin, user.pcSuper, user.pcToken);
        this.toastService.showSuccess('Resolución eliminada exitosamente');
        this.onClear();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al eliminar:', error);
      this.toastService.showError('Error al eliminar la resolución');
    } finally {
      this.loadingState.set(false);
    }
  }

  onClear(): void {
    this.form.reset();
    this.selectedCompany.set(null);
    this.selectedResolution.set(null);
    this.isEditMode.set(false);
    this.toastService.showInfo('Formulario limpiado');
  }

  onGenerarReporte(): void {
    this.toastService.showInfo('Funcionalidad de reporte en desarrollo');
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }
}
