import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { CompanyResponse, ReportResponse } from './reporte-facturacion-fecha.interface';

@Injectable({
  providedIn: 'root'
})
export class ReporteFacturacionFechaService {
  private apiUrl = 'http://184.168.30.44:8810/XcaliburWeb/rest/ServiciosXcaliburWeb';
  loadingState = signal(false);

  constructor(private http: HttpClient) {}

  async getCompanies(pcLogin: string, pcSuper: string, pcToken: string): Promise<CompanyResponse> {
    this.loadingState.set(true);
    try {
      const params = new HttpParams()
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      return await this.http.get<CompanyResponse>(`${this.apiUrl}/GetCECompanias`, { params }).toPromise() as CompanyResponse;
    } finally {
      this.loadingState.set(false);
    }
  }

  async getReport(cia: string, fechaInicial: string, fechaFinal: string, pcLogin: string, pcSuper: string, pcToken: string): Promise<ReportResponse> {
    this.loadingState.set(true);
    try {
      const params = new HttpParams()
        .set('cia', cia)
        .set('fechaInicial', fechaInicial)
        .set('fechaFinal', fechaFinal)
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      return await this.http.get<ReportResponse>(`${this.apiUrl}/GetReportePS5113`, { params }).toPromise() as ReportResponse;
    } finally {
      this.loadingState.set(false);
    }
  }
}
