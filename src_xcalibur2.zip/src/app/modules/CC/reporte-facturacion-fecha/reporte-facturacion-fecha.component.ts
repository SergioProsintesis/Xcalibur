import { Component, OnInit, signal } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReporteFacturacionFechaService } from './reporte-facturacion-fecha.service';
import { AuthService } from '../../../core/services/auth.service';
import { Company } from './reporte-facturacion-fecha.interface';

@Component({
  selector: 'app-reporte-facturacion-fecha',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './reporte-facturacion-fecha.component.html',
  styleUrl: './reporte-facturacion-fecha.component.css'
})
export class ReporteFacturacionFechaComponent implements OnInit {
  form!: FormGroup;
  companies = signal<Company[]>([]);
  isLoading = signal(false);
  reportData = signal<any[]>([]);

  constructor(
    private fb: FormBuilder,
    private service: ReporteFacturacionFechaService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.loadCompanies();
  }

  private initForm(): void {
    this.form = this.fb.group({
      cia: ['', Validators.required],
      fecha_inicial: ['', Validators.required],
      fecha_final: ['', Validators.required]
    });
  }

  private async loadCompanies(): Promise<void> {
    try {
      const user = this.authService.user();
      if (user && user.pcLogin && user.pcSuper && user.pcToken) {
        const response = await this.service.getCompanies(user.pcLogin, user.pcSuper, user.pcToken);
        this.companies.set(response.dsRespuesta.tgecias);
      }
    } catch (error) {
      console.error('Error loading companies:', error);
    }
  }

  async onGenerateReport(): Promise<void> {
    if (this.form.invalid) return;
    try {
      this.isLoading.set(true);
      const user = this.authService.user();
      if (user && user.pcLogin && user.pcSuper && user.pcToken) {
        const formValue = this.form.value;
        const response = await this.service.getReport(
          formValue.cia,
          formValue.fecha_inicial,
          formValue.fecha_final,
          user.pcLogin,
          user.pcSuper,
          user.pcToken
        );
        this.reportData.set(response.dsRespuesta.reportData);
        alert('Reporte generado exitosamente');
      }
    } catch (error) {
      console.error('Error generating report:', error);
      alert('Error al generar reporte');
    } finally {
      this.isLoading.set(false);
    }
  }

  onCancel(): void {
    this.form.reset();
    this.reportData.set([]);
  }
}
