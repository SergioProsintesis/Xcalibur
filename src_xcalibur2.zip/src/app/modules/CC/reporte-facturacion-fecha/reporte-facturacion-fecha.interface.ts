export interface CompanyResponse {
  dsRespuesta: {
    tgecias: Company[];
  };
}

export interface Company {
  cia: number;
  nombre_cia: string;
}

export interface ReportPS5113 {
  cia: number;
  fecha_inicial: string;
  fecha_final: string;
}

export interface ReportResponse {
  dsRespuesta: {
    reportData: any[];
  };
}
