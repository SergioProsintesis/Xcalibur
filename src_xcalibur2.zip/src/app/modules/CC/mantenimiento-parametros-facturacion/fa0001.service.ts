import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../core/services/auth.service';
import { FA0001Response, FaparameRecord } from './fa0001.interface';

@Injectable({
  providedIn: 'root'
})
export class Fa0001Service {
  private http = inject(HttpClient);
  private auth = inject(AuthService);

  // ==================== CONSULTAS EMERGENTES ====================

  /**
   * Obtiene lista de compañías
   */
  getCECompanias(): Observable<FA0001Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECompanias?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<FA0001Response>(url);
  }

  /**
   * Obtiene compañía en evento Leave
   */
  getLeaveCia(pcCompania: number): Observable<FA0001Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCia_fa0001?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<FA0001Response>(url);
  }

  /**
   * Obtiene tipos de documento
   */
  getCETipoDoc(pcCompania: number): Observable<FA0001Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCETipoDoc-cc0014?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<FA0001Response>(url);
  }

  // ==================== CRUD OPERATIONS ====================

  /**
   * Crea o actualiza parámetros de facturación
   */
  updateFaparame(record: FaparameRecord): Observable<FA0001Response> {
    const url = `${environment.apiUrl}/Updatefaparame_fa0001`;
    return this.http.put<FA0001Response>(url, { tfaparame: [record] });
  }
}
