// FA0001 - PARAMETROS FACTURACION Interfaces

export interface FaparameRecord {
  'cia': number;
  'nropreimpresor'?: string;
  'nroprefactura'?: string;
  'nroprenotac'?: string;
  'nroprencc'?: string;
  'nropre_remision'?: string;
  'nropre_ordvendedor'?: string;
  'nropre_cotizacion'?: string;
  'nropre_cenvio'?: string;
  'fact-electronica'?: boolean;
  'tipodoc-ne'?: string;
  'tipodoc-cot'?: string;
  'tipodoc-traspaso'?: string;
  'tipcom'?: string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CompaniaRecord {
  'cia': number;
  'nombre-cia': string;
  'nit': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface TipoDocRecord {
  'tipodoc': string;
  'nombre-doc': string;
  'cia': number;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface FA0001Response {
  'dsRespuesta': {
    'tfaparame'?: FaparameRecord[];
    'tgecias'?: CompaniaRecord[];
    'tcctipdoc'?: TipoDocRecord[];
  };
}
