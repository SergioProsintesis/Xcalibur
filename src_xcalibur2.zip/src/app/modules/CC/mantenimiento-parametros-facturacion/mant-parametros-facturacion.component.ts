import { Component, inject, signal, OnInit, computed, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { Fa0001Service } from './fa0001.service';
import { AuthService } from '../../../core/services/auth.service';
import { CompaniaRecord, FaparameRecord } from './fa0001.interface';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-mant-parametros-facturacion',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent, FormsModule],
  templateUrl: './mant-parametros-facturacion.component.html',
  styleUrls: ['./mant-parametros-facturacion.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MantParametrosFacturacionComponent implements OnInit {
  private fb = inject(FormBuilder);
  private modalService = inject(ModalService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private fa0001Service = inject(Fa0001Service);
  private authService = inject(AuthService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);

  // Form
  mant_parametros_form!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Parámetros de Facturación`);

  // State
  loadingState = signal<boolean>(false);
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  parametrosActuales = signal<FaparameRecord | null>(null);
  parametrosCargados = signal<FaparameRecord[]>([]);
  
  // Modal
  showCompaniaModal = signal(false);
  isEditMode = signal(false);

  ngOnInit() {
    console.log('🔄 MantParametrosFacturacionComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initForm();
    this.loadCompanias();
    console.log('✅ MantParametrosFacturacionComponent inicializado correctamente');
  }

  private initForm(): void {
    this.mant_parametros_form = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      'indicativo-cia': [{ value: '', disabled: true }],
      'nropreimpresor': [''],
      'nroprefactura': [''],
      'nroprenotac': [''],
      'nroprencc': [''],
      'nropre-remision': [''],
      'nropre-ordvendedor': [''],
      'nropre-cotizacion': [''],
      'nropre-cenvio': [''],
      'fact-electronica': [false],
      'tipodoc-ne': [''],
      'tipodoc-cot': [''],
      'tipodoc-traspaso': [''],
      'tipcom': [''],
      'observaciones': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.mant_parametros_form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.mant_parametros_form.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== CARGA DE DATOS ====================
  async loadCompanias(): Promise<void> {
    try {
      this.loadingState.set(true);
      // Comprobar si tenemos datos cacheados
      const parametros = await this.fa0001Service.getCECompanias().toPromise();
      if (parametros?.dsRespuesta?.tfaparame) {
        this.parametrosCargados.set(parametros.dsRespuesta.tfaparame);
      }
    } catch (error) {
      console.error('Error cargando compañías:', error);
      this.toastService.showError('Error al cargar compañías');
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== MODAL DE COMPAÑÍA ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.mant_parametros_form.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.cargarParametros();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.mant_parametros_form.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.fa0001Service.getLeaveCia(ciaValue).toPromise();
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.mant_parametros_form.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
        await this.cargarParametros();
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.mant_parametros_form.patchValue({
      cia: '',
      'nombre-cia': ''
    });
    this.limpiarParametros();
  }

  // ==================== CARGA DE PARÁMETROS ====================
  async cargarParametros(): Promise<void> {
    const ciaValue = this.mant_parametros_form.get('cia')?.value;
    
    if (!ciaValue) {
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.fa0001Service.getLeaveCia(ciaValue).toPromise();
      
      if (response?.dsRespuesta?.tfaparame && response.dsRespuesta.tfaparame.length > 0) {
        const parametro = response.dsRespuesta.tfaparame[0];
        this.parametrosActuales.set(parametro);
        this.cargarDatosEnFormulario(parametro);
        this.isEditMode.set(true);
        this.toastService.showSuccess('Parámetros cargados correctamente');
      } else {
        this.limpiarParametros();
        this.isEditMode.set(false);
      }
    } catch (error) {
      console.error('Error al cargar parámetros:', error);
      this.toastService.showError('Error al cargar los parámetros');
      this.limpiarParametros();
    } finally {
      this.loadingState.set(false);
    }
  }

  private cargarDatosEnFormulario(parametro: FaparameRecord): void {
    this.mant_parametros_form.patchValue({
      'nropreimpresor': parametro['nropreimpresor'] || '',
      'nroprefactura': parametro['nroprefactura'] || '',
      'nroprenotac': parametro['nroprenotac'] || '',
      'nroprencc': parametro['nroprencc'] || '',
      'nropre-remision': parametro['nropre_remision'] || '',
      'nropre-ordvendedor': parametro['nropre_ordvendedor'] || '',
      'nropre-cotizacion': parametro['nropre_cotizacion'] || '',
      'nropre-cenvio': parametro['nropre_cenvio'] || '',
      'fact-electronica': parametro['fact-electronica'] || false,
      'tipodoc-ne': parametro['tipodoc-ne'] || '',
      'tipodoc-cot': parametro['tipodoc-cot'] || '',
      'tipodoc-traspaso': parametro['tipodoc-traspaso'] || '',
      'tipcom': parametro['tipcom'] || ''
    });
  }

  private limpiarParametros(): void {
    this.parametrosActuales.set(null);
    this.mant_parametros_form.patchValue({
      'nropreimpresor': '',
      'nroprefactura': '',
      'nroprenotac': '',
      'nroprencc': '',
      'nropre-remision': '',
      'nropre-ordvendedor': '',
      'nropre-cotizacion': '',
      'nropre-cenvio': '',
      'fact-electronica': false,
      'tipodoc-ne': '',
      'tipodoc-cot': '',
      'tipodoc-traspaso': '',
      'tipcom': '',
      'observaciones': ''
    });
  }

  // ==================== SAVE ====================
  async onSubmit(): Promise<void> {
    if (!this.mant_parametros_form.valid) {
      this.toastService.showError('Verifique los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const formValue = this.mant_parametros_form.getRawValue();
      
      const parametro: FaparameRecord = {
        cia: formValue.cia,
        'nropreimpresor': formValue['nropreimpresor'],
        'nroprefactura': formValue['nroprefactura'],
        'nroprenotac': formValue['nroprenotac'],
        'nroprencc': formValue['nroprencc'],
        'nropre_remision': formValue['nropre-remision'],
        'nropre_ordvendedor': formValue['nropre-ordvendedor'],
        'nropre_cotizacion': formValue['nropre-cotizacion'],
        'nropre_cenvio': formValue['nropre-cenvio'],
        'fact-electronica': formValue['fact-electronica'],
        'tipodoc-ne': formValue['tipodoc-ne'],
        'tipodoc-cot': formValue['tipodoc-cot'],
        'tipodoc-traspaso': formValue['tipodoc-traspaso'],
        'tipcom': formValue['tipcom']
      };

      const response = await this.fa0001Service.updateFaparame(parametro).toPromise();
      
      if (response) {
        this.toastService.showSuccess('Parámetros guardados correctamente');
        this.parametrosActuales.set(parametro);
        this.isEditMode.set(true);
      }
    } catch (error) {
      console.error('Error al guardar parámetros:', error);
      this.toastService.showError('Error al guardar los parámetros');
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== LIMPIAR ====================
  onClear(): void {
    if (!this.companiaSeleccionada()) {
      this.mant_parametros_form.reset();
      this.limpiarCompania();
      return;
    }

    this.mant_parametros_form.patchValue({
      'nropreimpresor': '',
      'nroprefactura': '',
      'nroprenotac': '',
      'nroprencc': '',
      'nropre-remision': '',
      'nropre-ordvendedor': '',
      'nropre-cotizacion': '',
      'nropre-cenvio': '',
      'fact-electronica': false,
      'tipodoc-ne': '',
      'tipodoc-cot': '',
      'tipodoc-traspaso': '',
      'tipcom': '',
      'observaciones': ''
    });
    this.mant_parametros_form.markAsUntouched();
    this.isEditMode.set(false);
  }

  // ==================== NAVEGACIÓN ====================
  goBack(): void {
    this.router.navigate(['/dashboard']);
  }
}
