import { Component, inject, signal, OnInit, computed, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { ReporteDeFacturacionRecurrenteService } from './reporte-de-facturacion-recurrente.service';
import { CompaniaRecord, FacturaRecurrenteRecord } from './reporte-de-facturacion-recurrente.interface';

@Component({
  selector: 'app-reporte-de-facturacion-recurrente',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent],
  templateUrl: './reporte-de-facturacion-recurrente.component.html',
  styleUrls: ['./reporte-de-facturacion-recurrente.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ReporteDeFacturacionRecurrenteComponent implements OnInit {
  private fb = inject(FormBuilder);
  private modalService = inject(ModalService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private service = inject(ReporteDeFacturacionRecurrenteService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  reporteForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}FA5220 - Reporte de Facturación Recurrente`);
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  facturasRecurrentes = signal<FacturaRecurrenteRecord[]>([]);

  // Control de modales
  showCompaniaModal = signal(false);

  ngOnInit() {
    console.log('🔄 ReporteDeFacturacionRecurrenteComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    console.log('✅ ReporteDeFacturacionRecurrenteComponent inicializado correctamente');
  }

  private initializeForm(): void {
    this.reporteForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }]
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.reporteForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.reporteForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.reporteForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.loadFacturasRecurrentes();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.reporteForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.service.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.reporteForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
        this.loadFacturasRecurrentes();
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.facturasRecurrentes.set([]);
    this.reporteForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
  }

  // ==================== CARGAR DATOS ====================
  private async loadFacturasRecurrentes(): Promise<void> {
    const ciaValue = this.reporteForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.facturasRecurrentes.set([]);
      return;
    }

    try {
      this.loadingState.set(true);
      const facturas = await this.service.getFacturasRecurrentes(ciaValue);
      this.facturasRecurrentes.set(facturas);
    } catch (error) {
      console.error('Error al cargar facturas recurrentes:', error);
      this.toastService.showError('Error al cargar las facturas recurrentes');
      this.facturasRecurrentes.set([]);
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  // ==================== ACCIONES ====================
  onLimpiar(): void {
    this.reporteForm.reset();
    this.limpiarCompania();
    this.cdr.markForCheck();
  }

  onGenerarReporte(): void {
    if (this.reporteForm.invalid) {
      this.toastService.showError('Por favor, complete los campos requeridos');
      return;
    }

    if (this.facturasRecurrentes().length === 0) {
      this.toastService.showWarning('No hay facturas recurrentes para este período');
      return;
    }

    this.toastService.showSuccess('Reporte generado correctamente');
    this.cdr.markForCheck();
  }

  onVolver(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }
}
