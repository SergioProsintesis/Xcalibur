export interface CompaniaRecord {
  cia: number;
  'nombre-cia': string;
}

export interface FacturaRecurrenteRecord {
  'numero-fact': string;
  cia: number;
  'nombre-cia': string;
  'numero-cliente': string;
  'nombre-cliente': string;
  'fecha-fact': string;
  'valor-fact': number;
  'estado-fact': string;
  'proxima-recurrencia': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
}

export interface CompaniasResponse {
  dsRespuesta?: {
    tgecias: CompaniaRecord[];
  };
}

export interface FacturasRecurrentesResponse {
  dsRespuesta?: {
    tfafact: FacturaRecurrenteRecord[];
  };
}
