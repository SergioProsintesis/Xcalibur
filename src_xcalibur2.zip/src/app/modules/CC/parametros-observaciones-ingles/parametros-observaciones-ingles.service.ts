import { Injectable, inject, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { FaIngObs, GetFaIngObsResponse, UpdateFaIngObsRequest, UpdateFaIngObsResponse } from './parametros-observaciones-ingles.interface';

@Injectable({
  providedIn: 'root'
})
export class ParametrosObservacionesInglesService {
  private readonly http = inject(HttpClient);
  loadingState = signal(false);

  async getCompanias(pcLogin: string, pcSuper: string, pcToken: string): Promise<any[]> {
    this.loadingState.set(true);
    try {
      const endpoint = `${environment.apiUrl}/GetCECompanias`;
      let params = new HttpParams()
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      
      const response = await this.http.get<any>(endpoint, { params }).toPromise();
      return response?.dsRespuesta?.tgecias || [];
    } catch (error) {
      console.error('Error fetching companies:', error);
      throw error;
    } finally {
      this.loadingState.set(false);
    }
  }

  async getObservacionesByCompania(
    pcCompania: string,
    pcLogin: string,
    pcSuper: string,
    pcToken: string
  ): Promise<FaIngObs | null> {
    this.loadingState.set(true);
    try {
      const endpoint = `${environment.apiUrl}/GetLeaveCia_ps5141`;
      let params = new HttpParams()
        .set('pcCompania', pcCompania)
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      
      const response = await this.http.get<GetFaIngObsResponse>(endpoint, { params }).toPromise();
      return response?.dsRespuesta?.tfaingobs?.[0] || null;
    } catch (error) {
      console.error('Error fetching observations:', error);
      throw error;
    } finally {
      this.loadingState.set(false);
    }
  }

  async updateObservaciones(
    faIngObs: FaIngObs,
    pcLogin: string,
    pcSuper: string,
    pcToken: string
  ): Promise<FaIngObs | null> {
    this.loadingState.set(true);
    try {
      const endpoint = `${environment.apiUrl}/Updatefaingobs_PS5141`;
      const payload: UpdateFaIngObsRequest = {
        tfaingobs: [faIngObs]
      };
      
      let params = new HttpParams()
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      
      const response = await this.http.put<UpdateFaIngObsResponse>(endpoint, payload, { params }).toPromise();
      return response?.dsRespuesta?.tfaingobs?.[0] || null;
    } catch (error) {
      console.error('Error updating observations:', error);
      throw error;
    } finally {
      this.loadingState.set(false);
    }
  }
}
