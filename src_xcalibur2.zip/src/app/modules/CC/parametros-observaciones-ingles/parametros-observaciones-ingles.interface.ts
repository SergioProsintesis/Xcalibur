export interface FaIngObs {
  'Agrega-Ingobs': string;
  cia: number;
  'nombre-cia': string;
  'date-ctrl': string;
  'Ingobs1-obs': string;
 'Ingobs2-obs': string;
  'Ingobs3-obs': string;
  'Ingobs4-obs': string;
  'Ingobs5-obs': string;
  'Ingobs6-obs': string;
  'Ingobs7-obs': string;
  'teIngobs7-obs': string;
  'login-ctrl': string;
  tparent: string;
}

export interface FaIngObsResponse {
  tfaingobs: FaIngObs[];
}

export interface GetFaIngObsResponse {
  dsRespuesta: FaIngObsResponse;
}

export interface UpdateFaIngObsRequest {
  tfaingobs: FaIngObs[];
}

export interface UpdateFaIngObsResponse {
  dsRespuesta: {
    tfaingobs: (FaIngObs & { terrores?: { codigo: string; descripcion: string; tPARENT: string }[] })[];
  };
}
