import { Component, inject, signal, OnInit, computed, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ToastService } from '../../../core/services/toast.service';
import { AuthService } from '../../../core/services/auth.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { ParametrosObservacionesInglesService } from './parametros-observaciones-ingles.service';
import { FaIngObs } from './parametros-observaciones-ingles.interface';

export interface CompaniaRecord {
  'cod-cia': number;
  'nombre-cia': string;
  cia: number;
}

@Component({
  selector: 'app-mant-parametros-observaciones',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './mant-parametros-observaciones.component.html',
  styleUrls: ['./mant-parametros-observaciones.component.css']
})
export class MantParametrosObservacionesComponent implements OnInit {
  private fb = inject(FormBuilder);
  private toastService = inject(ToastService);
  private auth = inject(AuthService);
  private service = inject(ParametrosObservacionesInglesService);
  private router = inject(Router);
  private loadingService = inject(LoadingService);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  // Page title computed
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Parámetros Observaciones en Inglés`);

  // Estado general
  loadingState = signal<boolean>(false);
  companiasList = signal<CompaniaRecord[]>([]);
  companiaSeleccionada = signal<CompaniaRecord | null>(null);

  // Formulario
  form!: FormGroup;

  // Datos cargados
  faIngObsData = signal<FaIngObs | null>(null);

  ngOnInit() {
    console.log('🔄 MantParametrosObservacionesComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.inicializarFormulario();
    this.cargarCompanias();
    console.log('✅ MantParametrosObservacionesComponent inicializado correctamente');
  }

  private inicializarFormulario() {
    this.form = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      Ingobs1Obs: [''],
      Ingobs2Obs: [''],
      Ingobs3Obs: [''],
      Ingobs4Obs: [''],
      Ingobs5Obs: [''],
      Ingobs6Obs: [''],
      Ingobs7Obs: [''],
      teIngobs7Obs: ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== CARGA DE DATOS ====================
  private async cargarCompanias() {
    try {
      this.loadingState.set(true);
      const user = this.auth.user();
      const pcLogin = user?.pcLogin || '';
      const pcSuper = user?.pcSuper || '';
      const pcToken = user?.pcToken || '';

      const companias = await this.service.getCompanias(pcLogin, pcSuper, pcToken);
      this.companiasList.set(companias);

      if (companias && companias.length > 0) {
        const firstCompania = companias[0];
        this.form.patchValue({ 
          cia: firstCompania.cia || firstCompania['cod-cia'],
          'nombre-cia': firstCompania['nombre-cia']
        });
        this.companiaSeleccionada.set(firstCompania);
        await this.cargarObservaciones();
      }
    } catch (error) {
      this.toastService.showError('Error al cargar compañías');
      console.error(error);
    } finally {
      this.loadingState.set(false);
    }
  }

  async onCompaniaChange() {
    const codigoCompania = this.form.get('cia')?.value;
    const compania = this.companiasList().find(c => c.cia === codigoCompania || c['cod-cia'] === codigoCompania);
    if (compania) {
      this.form.patchValue({ 'nombre-cia': compania['nombre-cia'] });
      this.companiaSeleccionada.set(compania);
    }
    await this.cargarObservaciones();
  }

  private async cargarObservaciones() {
    try {
      this.loadingState.set(true);
      const codigoCompania = this.form.get('cia')?.value;
      const user = this.auth.user();
      const pcLogin = user?.pcLogin || '';
      const pcSuper = user?.pcSuper || '';
      const pcToken = user?.pcToken || '';

      const faIngObs = await this.service.getObservacionesByCompania(
        codigoCompania,
        pcLogin,
        pcSuper,
        pcToken
      );

      this.faIngObsData.set(faIngObs);

      if (faIngObs) {
        this.form.patchValue({
          Ingobs1Obs: faIngObs['Ingobs1-obs'] || '',
          Ingobs2Obs: faIngObs['Ingobs2-obs'] || '',
          Ingobs3Obs: faIngObs['Ingobs3-obs'] || '',
          Ingobs4Obs: faIngObs['Ingobs4-obs'] || '',
          Ingobs5Obs: faIngObs['Ingobs5-obs'] || '',
          Ingobs6Obs: faIngObs['Ingobs6-obs'] || '',
          Ingobs7Obs: faIngObs['Ingobs7-obs'] || '',
          teIngobs7Obs: faIngObs['teIngobs7-obs'] || ''
        });
      }
    } catch (error) {
      this.toastService.showError('Error al cargar observaciones');
      console.error(error);
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== GUARDAR ====================
  async onSubmit() {
    if (this.form.invalid) {
      this.toastService.showWarning('Por favor complete los campos requeridos');
      return;
    }

    await this.guardar();
  }

  async guardar() {
    if (this.form.invalid) {
      this.toastService.showWarning('Por favor complete los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const user = this.auth.user();
      const pcLogin = user?.pcLogin || '';
      const pcSuper = user?.pcSuper || '';
      const pcToken = user?.pcToken || '';

      const currentData = this.faIngObsData() || {} as any;
      const faIngObs: FaIngObs = {
        ...currentData,
        cia: this.form.get('cia')?.value || currentData.cia,
        'Ingobs1-obs': this.form.get('Ingobs1Obs')?.value || '',
        'Ingobs2-obs': this.form.get('Ingobs2Obs')?.value || '',
        'Ingobs3-obs': this.form.get('Ingobs3Obs')?.value || '',
        'Ingobs4-obs': this.form.get('Ingobs4Obs')?.value || '',
        'Ingobs5-obs': this.form.get('Ingobs5Obs')?.value || '',
        'Ingobs6-obs': this.form.get('Ingobs6Obs')?.value || '',
        'Ingobs7-obs': this.form.get('Ingobs7Obs')?.value || '',
        'teIngobs7-obs': this.form.get('teIngobs7Obs')?.value || '',
        'Agrega-Ingobs': currentData['Agrega-Ingobs'] || '',
        'nombre-cia': currentData['nombre-cia'] || '',
        'date-ctrl': currentData['date-ctrl'] || '',
        'login-ctrl': currentData['login-ctrl'] || '',
        tparent: currentData.tparent || ''
      };

      await this.service.updateObservaciones(faIngObs, pcLogin, pcSuper, pcToken);
      this.toastService.showSuccess('Observaciones actualizadas correctamente');
      this.cdr.markForCheck();
      await this.cargarObservaciones();
    } catch (error) {
      this.toastService.showError('Error al guardar observaciones');
      console.error(error);
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== LIMPIAR Y NAVEGAR ====================
  limpiar() {
    this.form.reset();
    if (this.companiasList().length > 0) {
      const firstCompania = this.companiasList()[0];
      this.form.patchValue({ 
        cia: firstCompania.cia || firstCompania['cod-cia'],
        'nombre-cia': firstCompania['nombre-cia']
      });
    }
  }

  volver() {
    this.router.navigate(['/dashboard']);
  }
}
