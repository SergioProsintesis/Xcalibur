import { Injectable, inject, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { GeciaRecord, FadetallRecord, UpdateFadetallResponse } from './arg0284.interface';

@Injectable({ providedIn: 'root' })
export class Arg0284Service {
  private readonly http = inject(HttpClient);
  loadingState = signal(false);

  async getCompanias(pcLogin: string, pcSuper: string, pcToken: string): Promise<GeciaRecord[]> {
    try {
      this.loadingState.set(true);
      const params = new HttpParams()
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);

      const url = `${environment.apiUrl}/GetCECompanias`;
      const response = await this.http.get<any>(url, { params }).toPromise();
      return response?.dsRespuesta?.tgecias || [];
    } catch (error) {
      console.error('Error loading companies:', error);
      throw error;
    } finally {
      this.loadingState.set(false);
    }
  }

  async getCompaniaLeave(pcCompania: number, pcLogin: string, pcSuper: string, pcToken: string): Promise<GeciaRecord | null> {
    try {
      this.loadingState.set(true);
      const params = new HttpParams()
        .set('pcCompania', pcCompania.toString())
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);

      const url = `${environment.apiUrl}/GetLeaveGEcias`;
      const response = await this.http.get<any>(url, { params }).toPromise();
      return response?.dsRespuesta?.tgecias?.[0] || null;
    } catch (error) {
      console.error('Error in company leave:', error);
      throw error;
    } finally {
      this.loadingState.set(false);
    }
  }

  async getFacturaDetalle(
    pcCompania: number,
    pcFactura: number,
    pcEmpresa: number,
    pcSecuencia: number,
    pcLogin: string,
    pcSuper: string,
    pcToken: string
  ): Promise<FadetallRecord | null> {
    try {
      this.loadingState.set(true);
      const params = new HttpParams()
        .set('pcCompania', pcCompania.toString())
        .set('pcFactura', pcFactura.toString())
        .set('pcEmpresa', pcEmpresa.toString())
        .set('pcSecuencia', pcSecuencia.toString())
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);

      const url = `${environment.apiUrl}/GetLeaveSecuencia-arg0284`;
      const response = await this.http.get<any>(url, { params }).toPromise();
      return response?.dsRespuesta?.tdetallef?.[0] || null;
    } catch (error) {
      console.error('Error loading ractura detail:', error);
      throw error;
    } finally {
      this.loadingState.set(false);
    }
  }

  async updateFacturaDetalle(
    fadetall: FadetallRecord,
    pcLogin: string,
    pcSuper: string,
    pcToken: string
  ): Promise<FadetallRecord | null> {
    try {
      this.loadingState.set(true);
      const payload = { tdetallef: [fadetall] };
      const params = new HttpParams()
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);

      const url = `${environment.apiUrl}/UpdateDatosFactura`;
      const response = await this.http.put<UpdateFadetallResponse>(url, payload, { params }).toPromise();
      return response?.tdetallef?.[0] || response?.dsRespuesta?.tdetallef?.[0] || null;
    } catch (error) {
      console.error('Error updating ractura detail:', error);
      throw error;
    } finally {
      this.loadingState.set(false);
    }
  }
}
