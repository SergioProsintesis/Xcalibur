export interface GeciaRecord {
  'cia': number;
  'nombre-cia': string;
  'cod-cia'?: number;
  'tparent': string;
}

export interface GeciaResponse {
  tgecias: GeciaRecord[];
}

export interface GetGeciaResponse {
  dsRespuesta: GeciaResponse;
}

export interface FadetallRecord {
  'cia'?: number;
  'nombre-cia'?: string;
  'num-doc'?: number;
  'empresa'?: number;
  'nombre-emp'?: string;
  'centro'?: number;
  'nombre-cen'?: string;
  'articulo'?: string;
  'secuencia'?: number;
  'nombre-fdet'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
  'terrores'?: ErrorRecord[];
}

export interface ErrorRecord {
  'codigo': string;
  'descripcion': string;
  'tPARENT': string;
}

export interface FadetallResponse {
  tdetallef: FadetallRecord[];
}

export interface UpdateFadetallRequest {
  tdetallef: FadetallRecord[];
}

export interface UpdateFadetallResponse {
  dsRespuesta?: FadetallResponse;
  tdetallef?: FadetallRecord[];
}
