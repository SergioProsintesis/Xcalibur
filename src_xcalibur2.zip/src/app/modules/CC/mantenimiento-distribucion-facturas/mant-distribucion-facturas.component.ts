import { Component, inject, signal, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ToastService } from '../../../core/services/toast.service';
import { AuthService } from '../../../core/services/auth.service';
import { Arg0284Service } from './arg0284.service';
import { GeciaRecord, FadetallRecord } from './arg0284.interface';

@Component({
  selector: 'app-mant-distribucion-facturas',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './mant-distribucion-facturas.component.html',
  styleUrls: ['./mant-distribucion-facturas.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MantDistribucionFacturasComponent implements OnInit {
  private fb = inject(FormBuilder);
  private toastService = inject(ToastService);
  private auth = inject(AuthService);
  private service = inject(Arg0284Service);
  private router = inject(Router);

  // Estado general
  loadingState = this.service.loadingState;
  companiasList = signal<GeciaRecord[]>([]);
  companiaSeleccionada = signal<GeciaRecord | null>(null);

  // Formulario
  form!: FormGroup;

  // Datos cargados
  fadetallData = signal<FadetallRecord | null>(null);

  ngOnInit() {
    this.inicializarFormulario();
    this.cargarCompanias();
  }

  private inicializarFormulario() {
    this.form = this.fb.group({
      cia: ['', Validators.required],
      'num-doc': ['', Validators.required],
      empresa: ['', Validators.required],
      secuencia: ['', Validators.required],
      centro: [''],
      articulo: [''],
      'nombre-fdet': ['']
    });
  }

  private async cargarCompanias() {
    try {
      this.loadingState.set(true);
      const user = this.auth.user();
      const pcLogin = user?.pcLogin || '';
      const pcSuper = user?.pcSuper || '';
      const pcToken = user?.pcToken || '';

      const companias = await this.service.getCompanias(pcLogin, pcSuper, pcToken);
      this.companiasList.set(companias);

      if (companias && companias.length > 0) {
        this.form.patchValue({ cia: companias[0].cia });
        this.companiaSeleccionada.set(companias[0]);
      }
    } catch (error) {
      this.toastService.showError('Error al cargar compañías');
      console.error(error);
    } finally {
      this.loadingState.set(false);
    }
  }

  async onCompaniaChange() {
    const codigoCompania = this.form.get('cia')?.value;
    const compania = this.companiasList().find(c => c.cia === codigoCompania);
    this.companiaSeleccionada.set(compania || null);
  }

  async onCompaniaLeave() {
    const ciaValue = this.form.get('cia')?.value;
    if (!ciaValue) {
      return;
    }
    const compania = this.companiasList().find(
      (c: GeciaRecord) => c.cia.toString() === ciaValue.toString()
    );
    if (compania) {
      this.companiaSeleccionada.set(compania);
      this.form.patchValue({ 'nombre-cia': compania['nombre-cia'] });
    } else {
      this.toastService.showError('Compañía no encontrada');
      this.form.patchValue({ cia: '' });
      this.companiaSeleccionada.set( null);
    }
  }

  buscarCompania(): void {
    const ciaValue = this.form.get('cia')?.value;
    if (!ciaValue || this.companiasList().length === 0) {
      this.toastService.showWarning('No hay compañías disponibles');
      return;
    }
    const compania = this.companiasList().find(c => c.cia.toString() === ciaValue.toString());
    if (compania) {
      this.companiaSeleccionada.set(compania);
      this.form.patchValue({ 'nombre-cia': compania['nombre-cia'] });
      this.toastService.showSuccess('Compañía seleccionada');
    } else {
      this.toastService.showError('Compañía no encontrada. Intente de nuevo.');
      this.toastService.showWarning('Ingrese el código de compañía');
    }
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (!field) return '';
    if (field.hasError('required')) return 'Este campo es requerido';
    return 'Error en el campo';
  }

  async buscarFactura() {
    try {
      this.loadingState.set(true);
      const codigoCompania = this.form.get('cia')?.value;
      const numDoc = this.form.get('num-doc')?.value;
      const empresa = this.form.get('empresa')?.value;
      const secuencia = this.form.get('secuencia')?.value;

      if (!codigoCompania || !numDoc || !empresa || !secuencia) {
        this.toastService.showWarning('Complete todos los campos para buscar');
        return;
      }

      const user = this.auth.user();
      const pcLogin = user?.pcLogin || '';
      const pcSuper = user?.pcSuper || '';
      const pcToken = user?.pcToken || '';

      const fadetall = await this.service.getFacturaDetalle(
        codigoCompania,
        numDoc,
        empresa,
        secuencia,
        pcLogin,
        pcSuper,
        pcToken
      );

      if (fadetall) {
        this.fadetallData.set(fadetall);
        this.form.patchValue({
          centro: fadetall['centro'] || '',
          articulo: fadetall['articulo'] || '',
          'nombre-fdet': fadetall['nombre-fdet'] || ''
        });
        this.toastService.showSuccess('Factura cargada');
      } else {
        this.toastService.showWarning('Factura no encontrada');
      }
    } catch (error) {
      this.toastService.showError('Error al buscar factura');
      console.error(error);
    } finally {
      this.loadingState.set(false);
    }
  }

  async guardar() {
    if (this.form.invalid) {
      this.toastService.showWarning('Por favor complete los campos requeridos');
      return;
    }

    if (!this.fadetallData()) {
      this.toastService.showWarning('Primero debe buscar una factura');
      return;
    }

    try {
      this.loadingState.set(true);
      const user = this.auth.user();
      const pcLogin = user?.pcLogin || '';
      const pcSuper = user?.pcSuper || '';
      const pcToken = user?.pcToken || '';

      const fadetall: FadetallRecord = {
        ...this.fadetallData(),
        'cia': this.form.get('cia')?.value,
        'num-doc': this.form.get('num-doc')?.value,
        'empresa': this.form.get('empresa')?.value,
        'secuencia': this.form.get('secuencia')?.value,
        'centro': this.form.get('centro')?.value || 0,
        'articulo': this.form.get('articulo')?.value || '',
        'nombre-fdet': this.form.get('nombre-fdet')?.value || ''
      };

      await this.service.updateFacturaDetalle(fadetall, pcLogin, pcSuper, pcToken);
      this.toastService.showSuccess('Factura actualizada correctamente');
      this.limpiar();
    } catch (error) {
      this.toastService.showError('Error al guardar');
      console.error(error);
    } finally {
      this.loadingState.set(false);
    }
  }

  limpiar() {
    this.form.reset();
    this.fadetallData.set(null);
    if (this.companiasList().length > 0) {
      this.form.patchValue({ cia: this.companiasList()[0].cia });
    }
  }

  volver() {
    this.router.navigate(['/dashboard']);
  }
}
