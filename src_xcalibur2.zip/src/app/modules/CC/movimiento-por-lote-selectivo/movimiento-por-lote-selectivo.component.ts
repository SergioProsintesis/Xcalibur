import { Component, OnDestroy, OnInit, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Observable, Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';

import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CCService } from '../../../core/services/cc.service';
import { CompaniaRecord, GenerarReporteResponse } from '../../../core/interfaces/cc.interface';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';

@Component({
  selector: 'app-movimiento-por-lote-selectivo',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, CompaniaModalComponent],
  templateUrl: './movimiento-por-lote-selectivo.component.html',
  styleUrls: ['./movimiento-por-lote-selectivo.component.css']
})
export class MovimientoPorLoteSelectivoComponent implements OnInit, OnDestroy {
  form: FormGroup;
  searchForm: FormGroup;
  isLoading = signal(false);
  showCompaniaModal = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  isGeneratingReport = signal(false);
  
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Movimiento por Lote Selectivo`);
  
  companiasList = signal<CompaniaRecord[]>([]);
  filteredCompaniasList = signal<CompaniaRecord[]>([]);
  isLoadingCompanias = signal(false);
  
  private destroy$ = new Subject<void>();
  private programContext = inject(ProgramContextService);

  private escapeHtml(text: string): string {
    const map: { [key: string]: string } = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, (char) => map[char]);
  }

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
    private loading: LoadingService,
    private ccService: CCService,
    private router: Router
  ) {
    this.form = this.fb.group({
      compania: ['', Validators.required],
      loteD: ['', Validators.required],
      loteH: ['', Validators.required],
      loteDia: [''],
      fecha: ['', Validators.required]
    });

    this.searchForm = this.fb.group({
      search: ['']
    });
  }

  ngOnInit(): void {
    this.loadCompanias();
  }

  private loadCompanias(): void {
    this.isLoadingCompanias.set(true);
    
    this.ccService.getCompanias()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (companias) => {
          this.companiasList.set(companias);
          this.filteredCompaniasList.set(companias);
          this.isLoadingCompanias.set(false);
        },
        error: (err) => {
          console.error('Error loading companies:', err);
          this.toast.showError('Error al cargar las compañías');
          this.isLoadingCompanias.set(false);
        }
      });
  }

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
    this.searchForm.reset();
    this.filteredCompaniasList.set(this.companiasList());
  }

  onCompaniaBlur(): void {
    const value = this.form.get('compania')?.value;
    if (value && value.toString().length > 0) {
      this.validateCompania(value);
    }
  }

  private validateCompania(codigo: string): void {
    // First check if it exists in the local list
    const compania = this.companiasList().find(c => c.cia.toString() === codigo.toString());
    if (compania) {
      this.selectedCompania.set(compania);
      this.form.patchValue({ compania: compania.cia.toString() });
      const ctrl = this.form.get('compania');
      if (ctrl?.hasError('notFound')) {
        const errors = { ...(ctrl.errors || {}) };
        delete errors['notFound'];
        ctrl.setErrors(Object.keys(errors).length ? errors : null);
      }
    } else {
      // If not found locally, validate with GetLeaveGEcias endpoint
      this.ccService.validateCompania(codigo)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: (result: CompaniaRecord | null) => {
            if (result) {
              this.selectedCompania.set(result);
              this.form.patchValue({ compania: codigo });
              const ctrl = this.form.get('compania');
              if (ctrl?.hasError('notFound')) {
                const errors = { ...(ctrl.errors || {}) };
                delete errors['notFound'];
                ctrl.setErrors(Object.keys(errors).length ? errors : null);
              }
            } else {
              this.selectedCompania.set(null);
              this.form.get('compania')?.setErrors({ notFound: true });
            }
          },
          error: (err: any) => {
            console.error('Error validating company:', err);
            this.selectedCompania.set(null);
            this.form.get('compania')?.setErrors({ notFound: true });
          }
        });
    }
  }

  onSelectCompania(compania: CompaniaRecord): void {
    this.form.patchValue({
      compania: compania.cia.toString()
    });
    this.selectedCompania.set(compania);
    this.showCompaniaModal.set(false);
  }

  onCloseModal(): void {
    this.showCompaniaModal.set(false);
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getErrorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (field?.hasError('required')) {
      return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} es requerido`;
    }
    return '';
  }

  onGenerarReporte(formato: string): void {
    if (!this.form.valid) {
      this.toast.showError('Por favor complete todos los campos requeridos');
      return;
    }

    this.isGeneratingReport.set(true);

    const { compania, loteD, loteH, loteDia, fecha } = this.form.value;

    this.ccService.getCC2241(compania, loteD, loteH, loteDia || '', fecha)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          if (!response) {
            this.toast.showError('No se pudo generar el reporte');
            this.isGeneratingReport.set(false);
            return;
          }

          if (formato === 'excel') {
            this.downloadFile(response.pcArchCSV || '', 'text/csv', 'movimiento_lote_selectivo.csv');
          } else if (formato === 'pdf') {
            this.downloadFile(response.pcArchPDF || '', 'application/pdf', 'movimiento_lote_selectivo.pdf');
          } else if (formato === 'pantalla') {
            this.viewInBrowser(response.pcArchPDF || '');
          }

          this.isGeneratingReport.set(false);
          this.toast.showSuccess('Reporte generado exitosamente');
        },
        error: (err) => {
          console.error('Error generating report:', err);
          this.toast.showError('Error al generar el reporte');
          this.isGeneratingReport.set(false);
        }
      });
  }

  private downloadFile(base64Data: string, mimeType: string, filename: string): void {
    try {
      const binaryString = atob(base64Data);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: mimeType });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading file:', error);
      this.toast.showError('Error al descargar el archivo');
    }
  }

  private viewInBrowser(base64Data: string): void {
    try {
      const binaryString = atob(base64Data);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      window.open(url, '_blank');
    } catch (error) {
      console.error('Error viewing file in browser:', error);
      this.toast.showError('Error al abrir el archivo');
    }
  }

  onClear(): void {
    this.form.reset();
    this.selectedCompania.set(null);
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
