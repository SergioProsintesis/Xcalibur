import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { CompanyResponse, LiquidationBase, LiquidationResponse } from './mant-bases-liquidacion.interface';

@Injectable({
  providedIn: 'root'
})
export class MantBasesLiquidacionService {
  private apiUrl = 'http://184.168.30.44:8810/XcaliburWeb/rest/ServiciosXcaliburWeb';
  loadingState = signal(false);

  constructor(private http: HttpClient) {}

  async getCompanies(pcLogin: string, pcSuper: string, pcToken: string): Promise<CompanyResponse> {
    this.loadingState.set(true);
    try {
      const params = new HttpParams()
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      return await this.http.get<CompanyResponse>(`${this.apiUrl}/GetCECompanias`, { params }).toPromise() as CompanyResponse;
    } finally {
      this.loadingState.set(false);
    }
  }

  async getLeaveData(pcCompania: string, pcLogin: string, pcSuper: string, pcToken: string): Promise<LiquidationResponse> {
    this.loadingState.set(true);
    try {
      const params = new HttpParams()
        .set('pcCompania', pcCompania)
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      return await this.http.get<LiquidationResponse>(`${this.apiUrl}/GetLeaveCia_fa5220`, { params }).toPromise() as LiquidationResponse;
    } finally {
      this.loadingState.set(false);
    }
  }

  async updateData(data: LiquidationBase): Promise<LiquidationResponse> {
    this.loadingState.set(true);
    try {
      const payload = {
        tbases: [data]
      };
      return await this.http.put<LiquidationResponse>(`${this.apiUrl}/Updatebases_fa5220`, payload).toPromise() as LiquidationResponse;
    } finally {
      this.loadingState.set(false);
    }
  }
}
