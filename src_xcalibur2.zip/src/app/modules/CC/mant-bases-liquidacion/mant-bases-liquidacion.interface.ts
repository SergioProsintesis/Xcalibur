export interface CompanyResponse {
  dsRespuesta: {
    tgecias: Company[];
  };
}

export interface Company {
  cia: number;
  nombre_cia: string;
}

export interface LiquidationBase {
  cia: number;
  nombre_cia: string;
  base: string;
  porcentaje: number;
  vigencia: string;
}

export interface LiquidationResponse {
  dsRespuesta: {
    tbases: LiquidationBase[];
  };
}
