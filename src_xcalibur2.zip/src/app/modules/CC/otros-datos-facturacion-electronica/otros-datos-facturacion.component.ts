import { Component, inject, signal, OnInit, computed, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { Fa5002Service } from './fa5002.service';
import { GeciaRecord, CompaniaRecord, UpdateGeciasDatBRequest } from './fa5002.interface';

@Component({
  selector: 'app-otros-datos-facturacion',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent],
  templateUrl: './otros-datos-facturacion.component.html',
  styleUrls: ['./otros-datos-facturacion.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class OtrosDatosFacturacionComponent implements OnInit {
  private fb = inject(FormBuilder);
  private toastService = inject(ToastService);
  private service = inject(Fa5002Service);
  private router = inject(Router);
  private loadingService = inject(LoadingService);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  dataForm!: FormGroup;
  createGeciasForm!: FormGroup;
  loadingState = signal<boolean>(false);
  
  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  geciaSeleccionada = signal<GeciaRecord | null>(null);
  
  // Control de modales
  showCompaniaModal = signal(false);
  showCreateModal = signal(false);
  isEditMode = signal(false);
  
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Otros Datos Facturación Electrónica`);

  ngOnInit(): void {
    this.initializeForm();
  }

  private initializeForm(): void {
    this.dataForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      Resolucion: ['', Validators.required],
      Fecha_inicial: ['', Validators.required],
      Fecha_final: ['', Validators.required],
      Prefijo: [''],
      Rango_inicial: ['', Validators.required],
      Rango_final: ['', Validators.required],
      Indicativo: [''],
      'Aviso_fact_rest': ['']
    });

    this.createGeciasForm = this.fb.group({
      Resolucion: ['', [Validators.required]],
      Fecha_inicial: ['', [Validators.required]],
      Fecha_final: ['', [Validators.required]],
      Prefijo: [''],
      Rango_inicial: ['', [Validators.required, Validators.min(1)]],
      Rango_final: ['', [Validators.required, Validators.min(1)]],
      Indicativo: [''],
      'Aviso_fact_rest': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.dataForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.dataForm.get(fieldName);
    if (!field?.errors) return '';
    
    if (field.errors['required']) return 'Este campo es requerido';
    if (field.errors['min']) return `Valor mínimo: ${field.errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.dataForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.loadData();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.dataForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      await this.loadData();
    } catch (error) {
      console.error('Error al cargar datos:', error);
      this.toastService.showError('Error al cargar datos de la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.dataForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
    this.limpiarDatos();
  }

  private limpiarDatos(): void {
    this.geciaSeleccionada.set(null);
    this.isEditMode.set(false);
    this.dataForm.patchValue({
      Resolucion: '',
      Fecha_inicial: '',
      Fecha_final: '',
      Prefijo: '',
      Rango_inicial: '',
      Rango_final: '',
      Indicativo: '',
      'Aviso_fact_rest': ''
    });
  }

  private async loadData(): Promise<void> {
    try {
      this.loadingState.set(true);
      const codigoCompania = this.dataForm.get('cia')?.value;
      
      if (!codigoCompania) {
        this.limpiarDatos();
        return;
      }

      const response = await this.service.getLeaveCia(codigoCompania);
      
      if (response?.dsRespuesta?.tgeciasDatB && response.dsRespuesta.tgeciasDatB.length > 0) {
        const gecia = response.dsRespuesta.tgeciasDatB[0];
        this.geciaSeleccionada.set(gecia);
        this.dataForm.patchValue({
          'Resolucion': gecia.Resolucion || '',
          'Fecha_inicial': gecia.Fecha_inicial || '',
          'Fecha_final': gecia.Fecha_final || '',
          'Prefijo': gecia.Prefijo || '',
          'Rango_inicial': gecia.Rango_inicial || '',
          'Rango_final': gecia.Rango_final || '',
          'Indicativo': gecia.Indicativo || '',
          'Aviso_fact_rest': gecia['Aviso_fact_rest'] || ''
        });
        this.isEditMode.set(true);
      } else {
        this.limpiarDatos();
      }
    } catch (error) {
      console.error('Error al cargar datos:', error);
      this.toastService.showError('Error al cargar datos');
      this.limpiarDatos();
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== ACCIONES CRUD ====================
  async onSubmit(): Promise<void> {
    if (this.dataForm.invalid) {
      this.toastService.showError('Por favor complete los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const formData = this.dataForm.getRawValue();
      
      const payload = {
        tgeciasDatB: [{
          cia: formData.cia,
          'nombre-cia': formData['nombre-cia'],
          Resolucion: formData.Resolucion || '',
          Fecha_inicial: formData.Fecha_inicial || '',
          Fecha_final: formData.Fecha_final || '',
          Prefijo: formData.Prefijo || '',
          Rango_inicial: formData.Rango_inicial || '',
          Rango_final: formData.Rango_final || '',
          Indicativo: formData.Indicativo || '',
          'Aviso_fact_rest': formData['Aviso_fact_rest'] || '',
          'login-ctrl': '',
          'date-ctrl': new Date().toISOString().split('T')[0],
          tparent: ''
        }]
      };

      const response = await this.service.updateGeciasPayload(payload);
      
      if (response?.dsRespuesta?.tgeciasDatB && response.dsRespuesta.tgeciasDatB.length > 0) {
        const result = response.dsRespuesta.tgeciasDatB[0];
        if (result.terrores && result.terrores.length > 0) {
          this.toastService.showSuccess(result.terrores[0].descripcion || 'Datos actualizados correctamente');
        } else {
          this.toastService.showSuccess('Datos actualizados correctamente');
        }
        this.geciaSeleccionada.set(result);
        this.isEditMode.set(true);
      }
    } catch (error) {
      console.error('Error al guardar:', error);
      this.toastService.showError('Error al guardar los datos');
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== CREAR NUEVO REGISTRO ====================
  openCreateModal(): void {
    const companiaId = this.dataForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    this.createGeciasForm.reset();
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
    this.createGeciasForm.reset();
  }

  async onCreateSubmit(): Promise<void> {
    if (this.createGeciasForm.invalid) {
      this.toastService.showError('Por favor complete los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const companiaId = this.dataForm.get('cia')?.value;
      const nombreCompania = this.dataForm.get('nombre-cia')?.value;
      const formData = this.createGeciasForm.value;

      const payload = {
        tgeciasDatB: [{
          cia: companiaId,
          'nombre-cia': nombreCompania,
          Resolucion: formData.Resolucion || '',
          Fecha_inicial: formData.Fecha_inicial || '',
          Fecha_final: formData.Fecha_final || '',
          Prefijo: formData.Prefijo || '',
          Rango_inicial: formData.Rango_inicial || '',
          Rango_final: formData.Rango_final || '',
          Indicativo: formData.Indicativo || '',
          'Aviso_fact_rest': formData['Aviso_fact_rest'] || '',
          'login-ctrl': '',
          'date-ctrl': new Date().toISOString().split('T')[0],
          tparent: ''
        }]
      };

      const response = await this.service.updateGeciasPayload(payload);
      
      if (response?.dsRespuesta?.tgeciasDatB && response.dsRespuesta.tgeciasDatB.length > 0) {
        const result = response.dsRespuesta.tgeciasDatB[0];
        if (result.terrores && result.terrores.length > 0) {
          this.toastService.showSuccess(result.terrores[0].descripcion || 'Registro de resolución creado exitosamente');
        } else {
          this.toastService.showSuccess('Registro de resolución creado exitosamente');
        }
        this.onClear();
        this.closeCreateModal();
        await this.loadData();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al crear:', error);
      this.toastService.showError('Error al crear el registro de resolución');
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== ELIMINAR REGISTRO ====================
  async onDelete(): Promise<void> {
    const companiaId = this.dataForm.get('cia')?.value;

    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía y una resolución para eliminar');
      return;
    }

    const confirmed = confirm('¿Está seguro de eliminar este registro de resolución?\nEsta acción no se puede deshacer');

    if (!confirmed) return;

    try {
      this.loadingState.set(true);
      
      const payload = {
        tgeciasDatB: [{
          cia: companiaId,
          Resolucion: this.geciaSeleccionada()?.Resolucion || '',
          'Borrar-Gecia': 'S',
          'login-ctrl': '',
          'date-ctrl': new Date().toISOString().split('T')[0],
          tparent: ''
        }]
      };

      const response = await this.service.updateGeciasPayload(payload);
      
      if (response?.dsRespuesta?.tgeciasDatB && response.dsRespuesta.tgeciasDatB.length > 0) {
        const result = response.dsRespuesta.tgeciasDatB[0];
        if (result.terrores && result.terrores.length > 0) {
          this.toastService.showSuccess(result.terrores[0].descripcion || 'Registro eliminado');
        } else {
          this.toastService.showSuccess('Registro de resolución eliminado exitosamente');
        }
        this.onClear();
        this.limpiarDatos();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al eliminar:', error);
      this.toastService.showError('Error al eliminar el registro');
    } finally {
      this.loadingState.set(false);
    }
  }

  onClear(): void {
    this.dataForm.reset();
    this.companiaSeleccionada.set(null);
    this.geciaSeleccionada.set(null);
    this.isEditMode.set(false);
  }

  goBack(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }
}
