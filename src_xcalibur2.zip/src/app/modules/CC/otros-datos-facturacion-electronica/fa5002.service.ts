import { Injectable, inject, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../core/services/auth.service';
import { GeciaRecord, CompaniaRecord, GetCompaniaResponse, GetGeciasDatBResponse, UpdateGeciasDatBResponse, UpdateGeciasDatBRequest } from './fa5002.interface';

@Injectable({
  providedIn: 'root'
})
export class Fa5002Service {
  private readonly http = inject(HttpClient);
  private readonly auth = inject(AuthService);
  loadingState = signal(false);

  async getCompanias(pcLogin: string, pcSuper: string, pcToken: string): Promise<CompaniaRecord[]> {
    try {
      this.loadingState.set(true);
      const params = new HttpParams()
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);

      const url = `${environment.apiUrl}/GetCECompanias`;
      const response = await this.http.get<GetCompaniaResponse>(url, { params }).toPromise();
      return response?.dsRespuesta?.tgecias || [];
    } catch (error) {
      console.error('Error fetching companies:', error);
      throw error;
    } finally {
      this.loadingState.set(false);
    }
  }

  async getCompaniaLeave(pcCompania: number, pcLogin: string, pcSuper: string, pcToken: string): Promise<GeciaRecord | null> {
    try {
      this.loadingState.set(true);
      const params = new HttpParams()
        .set('pcCompania', pcCompania.toString())
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);

      const url = `${environment.apiUrl}/GetLeaveCia_fa5002`;
      const response = await this.http.get<GetGeciasDatBResponse>(url, { params }).toPromise();
      return response?.dsRespuesta?.tgeciasDatB?.[0] || null;
    } catch (error) {
      console.error('Error fetching company leave:', error);
      throw error;
    } finally {
      this.loadingState.set(false);
    }
  }

  async getLeaveCia(pcCompania: number): Promise<GetGeciasDatBResponse> {
    try {
      this.loadingState.set(true);
      const user = this.auth.user();
      if (!user) throw new Error('Usuario no autenticado');
      
      const params = new HttpParams()
        .set('pcCompania', pcCompania.toString())
        .set('pcLogin', user.pcLogin || '')
        .set('pcSuper', user.pcSuper || '')
        .set('pcToken', user.pcToken || '');

      const url = `${environment.apiUrl}/GetLeaveCia_fa5002`;
      const response = await this.http.get<GetGeciasDatBResponse>(url, { params }).toPromise();
      return response || { dsRespuesta: { tgeciasDatB: [] } };
    } catch (error) {
      console.error('Error fetching company leave:', error);
      throw error;
    } finally {
      this.loadingState.set(false);
    }
  }

  async updateGecias(gecia: GeciaRecord, pcLogin: string, pcSuper: string, pcToken: string): Promise<GeciaRecord | null> {
    try {
      this.loadingState.set(true);
      const payload = { tgeciasDatB: [gecia] };
      const params = new HttpParams()
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);

      const url = `${environment.apiUrl}/Updategecias_fa5002`;
      const response = await this.http.put<UpdateGeciasDatBResponse>(url, payload, { params }).toPromise();
      return response?.tgeciasDatB?.[0] || response?.dsRespuesta?.tgeciasDatB?.[0] || null;
    } catch (error) {
      console.error('Error updating company:', error);
      throw error;
    } finally {
      this.loadingState.set(false);
    }
  }

  async updateGeciasPayload(payload: UpdateGeciasDatBRequest): Promise<UpdateGeciasDatBResponse> {
    try {
      this.loadingState.set(true);
      const user = this.auth.user();
      if (!user) throw new Error('Usuario no autenticado');
      
      const params = new HttpParams()
        .set('pcLogin', user.pcLogin || '')
        .set('pcSuper', user.pcSuper || '')
        .set('pcToken', user.pcToken || '');

      const url = `${environment.apiUrl}/Updategecias_fa5002`;
      const response = await this.http.put<UpdateGeciasDatBResponse>(url, payload, { params }).toPromise();
      return response || { dsRespuesta: { tgeciasDatB: [] } };
    } catch (error) {
      console.error('Error updating company:', error);
      throw error;
    } finally {
      this.loadingState.set(false);
    }
  }
}
