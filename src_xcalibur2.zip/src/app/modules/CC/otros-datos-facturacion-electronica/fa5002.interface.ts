// FA5002 - OTROS DATOS FACTURACION ELECTRONICA Interfaces

export interface GeciaRecord {
  'cia'?: number;
  'nombre-cia'?: string;
  'Resolucion'?: string;
  'Fecha_inicial'?: string;
  'Fecha_final'?: string;
  'Prefijo'?: string;
  'Rango_inicial'?: string;
  'Rango_final'?: string;
  'Indicativo'?: string;
  'Aviso_fact_rest'?: string;
  'login-ctrl'?: string;
  'date-ctrl'?: string;
  'tparent'?: string;
  'terrores'?: ErrorRecord[];
}

export interface ErrorRecord {
  'codigo': string;
  'descripcion': string;
  'tPARENT': string;
}

export interface CompaniaRecord {
  'cia': number;
  'nombre-cia': string;
  'tparent': string;
}

export interface CompaniaResponse {
  tgecias: CompaniaRecord[];
}

export interface GetCompaniaResponse {
  dsRespuesta: CompaniaResponse;
}

export interface GeciasDatBResponse {
  tgeciasDatB: GeciaRecord[];
}

export interface GetGeciasDatBResponse {
  dsRespuesta: GeciasDatBResponse;
}

export interface UpdateGeciasDatBRequest {
  tgeciasDatB: GeciaRecord[];
}

export interface UpdateGeciasDatBResponse {
  dsRespuesta?: GeciasDatBResponse;
  tgeciasDatB?: GeciaRecord[];
}
