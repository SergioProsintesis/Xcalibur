import { Component, inject, signal, OnInit, computed, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { DescuentoModalComponent, DescuentoOption } from './descuento-modal/descuento-modal.component';
import { CuentaModalComponent, CuentaOption } from './cuenta-modal/cuenta-modal.component';
import { UbicacionModalComponent, UbicacionOption } from './ubicacion-modal/ubicacion-modal.component';
import { CentroCostoModalComponent, CentroCostoOption } from './centro-costo-modal/centro-costo-modal.component';
import { AuxiliarModalComponent, AuxiliarOption } from './auxiliar-modal/auxiliar-modal.component';
import { CompaniaRecord } from '../../../core/interfaces/cc.interface';
import { CCService } from '../../../core/services/cc.service';

export interface DescuentoRecord {
  'descue-tdes': number;
  cia: number;
  'nombre-cia'?: string;
  'nombre-tdes': string;
  'porcen-tdes': number;
  gravable: boolean;
  cuenta: string;
  'des-cuenta'?: string;
  ubicacion: number;
  'des-ubicacion'?: string;
  centro: number;
  'des-centro'?: string;
  auxiliar: number;
  'des-auxiliar'?: string;
  'text-tdes': string;
  'Agrega-Tabd'?: string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  tparent?: string;
}

@Component({
  selector: 'app-mant-descuentos',
  standalone: true,
  imports: [
    ReactiveFormsModule, 
    CommonModule, 
    CompaniaModalComponent, 
    DescuentoModalComponent,
    CuentaModalComponent,
    UbicacionModalComponent,
    CentroCostoModalComponent,
    AuxiliarModalComponent
  ],
  templateUrl: './mant-descuentos.component.html',
  styleUrls: ['./mant-descuentos.component.css']
})
export class MantDescuentosComponent implements OnInit {
  private fb = inject(FormBuilder);
  private ccService = inject(CCService);
  private router = inject(Router);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  descuentoForm!: FormGroup;
  createDescuentoForm!: FormGroup;
  loadingState = signal(false);
  
  // Título concatenado con el código del programa - usando el signal directamente para reactividad
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Descuentos`);
  
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  descuentoSeleccionado = signal<DescuentoRecord | null>(null);
  
  showCompaniaModal = signal(false);
  showDescuentoModal = signal(false);
  showCuentaModal = signal(false);
  showUbicacionModal = signal(false);
  showCentroCostoModal = signal(false);
  showAuxiliarModal = signal(false);
  showCreateModal = signal(false);
  showReportModal = signal(false);
  
  descuentosDisponibles = signal<DescuentoOption[]>([]);
  cuentasDisponibles = signal<CuentaOption[]>([]);
  ubicacionesDisponibles = signal<UbicacionOption[]>([]);
  centrosDisponibles = signal<CentroCostoOption[]>([]);
  
  // Datos de reporte
  reportResponse: any = null;
  auxiliaresDisponibles = signal<AuxiliarOption[]>([]);

  ngOnInit() {
    console.log('🔄 MantDescuentosComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    console.log('✅ MantDescuentosComponent inicializado correctamente');
  }

  private initializeForm(): void {
    this.descuentoForm = this.fb.group({
      cia: [null, [Validators.required, Validators.min(1)]],
      'nombre-cia': [{value: '', disabled: true}],
      'descue-tdes': [null, [Validators.required]],
      'nombre-tdes': [''],
      'porcen-tdes': [0],
      gravable: [false],
      cuenta: [''],
      'des-cuenta': [''],
      ubicacion: [0],
      'des-ubicacion': [''],
      centro: [0],
      'des-centro': [''],
      auxiliar: [0],
      'des-auxiliar': [''],
      'text-tdes': ['']
    });

    this.createDescuentoForm = this.fb.group({
      'descue-tdes': ['', [Validators.required, Validators.min(1)]],
      'nombre-tdes': ['', [Validators.required]],
      'porcen-tdes': [0, [Validators.required, Validators.min(0)]],
      gravable: [false],
      cuenta: [''],
      'des-cuenta': [''],
      ubicacion: [0],
      'des-ubicacion': [''],
      centro: [0],
      'des-centro': [''],
      auxiliar: [0],
      'des-auxiliar': [''],
      'text-tdes': ['']
    });
  }

  // ==================== COMPAÑÍA ====================
  
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.descuentoForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.limpiarDescuento();
  }

  async onCompaniaLeave(): Promise<void> {
    const companiaId = this.descuentoForm.get('cia')?.value;
    if (!companiaId) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const observable = this.ccService.validateCompania(companiaId.toString());
      const response = await observable.toPromise();
      
      if (response && response['nombre-cia']) {
        this.companiaSeleccionada.set(response);
        this.descuentoForm.patchValue({
          'nombre-cia': response['nombre-cia']
        });
        await this.cargarDescuentos(companiaId);
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error validando compañía:', error);
      this.toastService.showError('Error al validar compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
    }
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.descuentoForm.patchValue({
      cia: null,
      'nombre-cia': ''
    });
    this.limpiarDescuento();
  }

  // ==================== DESCUENTO ====================
  
  async cargarDescuentos(companiaId: number): Promise<void> {
    try {
      const response = await this.ccService.getCEDescuento(companiaId.toString());
      if (response?.dsRespuesta?.tcctabdes) {
        this.descuentosDisponibles.set(response.dsRespuesta.tcctabdes);
      }
    } catch (error) {
      console.error('Error cargando descuentos:', error);
    }
  }

  buscarDescuento(): void {
    const companiaId = this.descuentoForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Debe seleccionar una compañía primero');
      return;
    }
    this.showDescuentoModal.set(true);
  }

  async onDescuentoSelected(descuento: DescuentoOption): Promise<void> {
    this.descuentoForm.patchValue({
      'descue-tdes': descuento['descue-tdes'],
      'nombre-tdes': descuento['nombre-tdes'],
      'porcen-tdes': descuento['porcen-tdes'],
      gravable: descuento.gravable,
      cuenta: descuento.cuenta,
      'des-cuenta': descuento['des-cuenta'],
      ubicacion: descuento.ubicacion,
      'des-ubicacion': descuento['des-ubicacion'],
      centro: descuento.centro,
      'des-centro': descuento['des-centro'],
      auxiliar: descuento.auxiliar,
      'des-auxiliar': descuento['des-auxiliar'],
      'text-tdes': descuento['text-tdes']
    });
    this.closeDescuentoModal();
    
    // Cargar descripciones de campos relacionados de manera automática
    await this.loadDescuentoDescriptions();
  }

  private async loadDescuentoDescriptions(): Promise<void> {
    await Promise.all([
      this.onCuentaLeave(),
      this.onUbicacionLeave(),
      this.onCentroCostoLeave(),
      this.onAuxiliarLeave()
    ]);
  }

  async onDescuentoLeave(): Promise<void> {
    const companiaId = this.descuentoForm.get('cia')?.value;
    const descuentoId = this.descuentoForm.get('descue-tdes')?.value;
    
    if (!companiaId || !descuentoId) {
      this.limpiarDescuento();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveDescuento(companiaId.toString(), descuentoId);
      
      if (response?.dsRespuesta?.tcctabdes?.[0]) {
        const descuento = response.dsRespuesta.tcctabdes[0];
        this.descuentoSeleccionado.set(descuento);
        this.descuentoForm.patchValue({
          'nombre-tdes': descuento['nombre-tdes'],
          'porcen-tdes': descuento['porcen-tdes'],
          gravable: descuento.gravable,
          cuenta: descuento.cuenta,
          'des-cuenta': descuento['des-cuenta'],
          ubicacion: descuento.ubicacion,
          'des-ubicacion': descuento['des-ubicacion'],
          centro: descuento.centro,
          'des-centro': descuento['des-centro'],
          auxiliar: descuento.auxiliar,
          'des-auxiliar': descuento['des-auxiliar'],
          'text-tdes': descuento['text-tdes']
        });
        this.closeDescuentoModal();
        
        // Cargar descripciones de campos relacionados
        await this.onCuentaLeave();
        await this.onUbicacionLeave();
        await this.onCentroCostoLeave();
        await this.onAuxiliarLeave();
      } else {
        this.toastService.showError('Descuento no encontrado');
        this.limpiarDescuento();
      }
    } catch (error) {
      console.error('Error validando descuento:', error);
      this.toastService.showError('Error al validar descuento');
      this.limpiarDescuento();
    } finally {
      this.loadingState.set(false);
    }
  }

  closeDescuentoModal(): void {
    this.showDescuentoModal.set(false);
  }

  private limpiarDescuento(): void {
    this.descuentoSeleccionado.set(null);
    this.descuentoForm.patchValue({
      'descue-tdes': null,
      'nombre-tdes': '',
      'porcen-tdes': 0,
      gravable: false,
      cuenta: '',
      'des-cuenta': '',
      ubicacion: 0,
      'des-ubicacion': '',
      centro: 0,
      'des-centro': '',
      auxiliar: 0,
      'des-auxiliar': '',
      'text-tdes': ''
    });
  }

  // ==================== CARGAR DATOS DE MODALES ====================
  
  async cargarCuentas(companiaId: number): Promise<void> {
    try {
      const response = await this.ccService.getCECuentaCCxC(companiaId.toString());
      if (response?.dsRespuesta?.cccontab) {
        this.cuentasDisponibles.set(response.dsRespuesta.cccontab);
      }
    } catch (error) {
      console.error('Error cargando cuentas:', error);
    }
  }

  async cargarCentros(companiaId: number): Promise<void> {
    try {
      const response = await this.ccService.getCECentro(companiaId.toString());
      if (response?.dsRespuesta?.gecencos) {
        this.centrosDisponibles.set(response.dsRespuesta.gecencos);
      }
    } catch (error) {
      console.error('Error cargando centros:', error);
    }
  }

  async cargarUbicaciones(companiaId: number): Promise<void> {
    try {
      const response = await this.ccService.getCEUbicacion(companiaId.toString());
      if (response?.dsRespuesta?.ccubicac) {
        this.ubicacionesDisponibles.set(response.dsRespuesta.ccubicac);
      }
    } catch (error) {
      console.error('Error cargando ubicaciones:', error);
    }
  }

  async cargarAuxiliares(companiaId: number, cuenta: string): Promise<void> {
    try {
      console.log('[cargarAuxiliares] Iniciando carga:', { companiaId, cuenta });
      const response = await this.ccService.getCEAuxiliarCxC(companiaId.toString(), cuenta);
      console.log('[cargarAuxiliares] Respuesta completa:', response);
      
      // Buscar en diferentes posibles estructuras de respuesta
      let auxiliares: AuxiliarOption[] | undefined = response?.dsRespuesta?.tcgmaeaux || 
                        response?.tcgmaeaux || 
                        response?.cgmaeaux || 
                        response?.tgmaeaux || 
                        response?.auxiliares;
      
      if (auxiliares && Array.isArray(auxiliares)) {
        console.log('[cargarAuxiliares] Auxiliares encontrados:', auxiliares.length);
        this.auxiliaresDisponibles.set(auxiliares);
      } else {
        console.warn('[cargarAuxiliares] No se encontraron auxiliares en la respuesta', { response });
        this.auxiliaresDisponibles.set([]);
      }
    } catch (error) {
      console.error('[cargarAuxiliares] Error:', error);
      this.auxiliaresDisponibles.set([]);
    }
  }

  // ==================== CUENTA ====================
  
  buscarCuenta(): void {
    const companiaId = this.descuentoForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Debe seleccionar una compañía primero');
      return;
    }
    this.cargarCuentas(companiaId);
    this.showCuentaModal.set(true);
  }

  onCuentaSelected(cuenta: CuentaOption): void {
    if (this.showCreateModal()) {
      this.createDescuentoForm.patchValue({
        cuenta: cuenta.cuenta,
        'des-cuenta': cuenta['nombre-cta']
      });
    } else {
      this.descuentoForm.patchValue({
        cuenta: cuenta.cuenta,
        'des-cuenta': cuenta['nombre-cta']
      });
    }
    this.closeCuentaModal();
  }

  async onCuentaLeave(): Promise<void> {
    const companiaId = this.descuentoForm.get('cia')?.value;
    const cuentaId = this.descuentoForm.get('cuenta')?.value;
    
    if (!companiaId || !cuentaId) {
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveCuenta(companiaId.toString(), cuentaId);
      
      if (response?.dsRespuesta?.tcgcontab?.[0]) {
        const cuenta = response.dsRespuesta.tcgcontab[0];
        this.descuentoForm.patchValue({
          'des-cuenta': cuenta['nombre-cta']
        });
      }
    } catch (error) {
      console.error('Error validando cuenta:', error);
    } finally {
      this.loadingState.set(false);
    }
  }

  closeCuentaModal(): void {
    this.showCuentaModal.set(false);
  }

  // ==================== UBICACIÓN ====================
  
  buscarUbicacion(): void {
    const companiaId = this.descuentoForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Debe seleccionar una compañía primero');
      return;
    }
    this.cargarUbicaciones(companiaId);
    this.showUbicacionModal.set(true);
  }

  onUbicacionSelected(ubicacion: UbicacionOption): void {
    if (this.showCreateModal()) {
      this.createDescuentoForm.patchValue({
        ubicacion: ubicacion.ubicacion,
        'des-ubicacion': ubicacion['nombre-ubic']
      });
    } else {
      this.descuentoForm.patchValue({
        ubicacion: ubicacion.ubicacion,
        'des-ubicacion': ubicacion['nombre-ubic']
      });
    }
    this.closeUbicacionModal();
  }

  async onUbicacionLeave(): Promise<void> {
    const companiaId = this.descuentoForm.get('cia')?.value;
    const ubicacionId = this.descuentoForm.get('ubicacion')?.value;
    
    if (!companiaId || !ubicacionId) {
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveUbicacion(companiaId, ubicacionId);
      
      if (response?.dsRespuesta?.tcgubicac?.[0]) {
        const ubicacion = response.dsRespuesta.tcgubicac[0];
        this.descuentoForm.patchValue({
          'des-ubicacion': ubicacion['nombre-ubic']
        });
      }
    } catch (error) {
      console.error('Error validando ubicación:', error);
    } finally {
      this.loadingState.set(false);
    }
  }

  closeUbicacionModal(): void {
    this.showUbicacionModal.set(false);
  }

  // ==================== CENTRO DE COSTO ====================
  
  buscarCentroCosto(): void {
    const companiaId = this.descuentoForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Debe seleccionar una compañía primero');
      return;
    }
    this.cargarCentros(companiaId);
    this.showCentroCostoModal.set(true);
  }

  onCentroCostoSelected(centro: CentroCostoOption): void {
    if (this.showCreateModal()) {
      this.createDescuentoForm.patchValue({
        centro: centro.centro,
        'des-centro': centro['nombre-cen']
      });
    } else {
      this.descuentoForm.patchValue({
        centro: centro.centro,
        'des-centro': centro['nombre-cen']
      });
    }
    this.closeCentroCostoModal();
  }

  async onCentroCostoLeave(): Promise<void> {
    const companiaId = this.descuentoForm.get('cia')?.value;
    const centroId = this.descuentoForm.get('centro')?.value;
    
    if (!companiaId || !centroId) {
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveCentro(companiaId, centroId);
      
      if (response?.dsRespuesta?.tgecencos?.[0]) {
        const centro = response.dsRespuesta.tgecencos[0];
        this.descuentoForm.patchValue({
          'des-centro': centro['nombre-cen']
        });
      }
    } catch (error) {
      console.error('Error validando centro:', error);
    } finally {
      this.loadingState.set(false);
    }
  }

  closeCentroCostoModal(): void {
    this.showCentroCostoModal.set(false);
  }

  // ==================== AUXILIAR ====================
  
  buscarAuxiliar(): void {
    const companiaId = this.descuentoForm.get('cia')?.value;
    const cuenta = this.showCreateModal() 
      ? this.createDescuentoForm.get('cuenta')?.value
      : this.descuentoForm.get('cuenta')?.value;
    
    if (!companiaId) {
      this.toastService.showWarning('Debe seleccionar una compañía primero');
      return;
    }
    if (!cuenta) {
      this.toastService.showWarning('Debe seleccionar una cuenta primero');
      return;
    }
    this.cargarAuxiliares(companiaId, cuenta);
    this.showAuxiliarModal.set(true);
  }

  onAuxiliarSelected(auxiliar: AuxiliarOption): void {
    if (this.showCreateModal()) {
      this.createDescuentoForm.patchValue({
        auxiliar: auxiliar.auxiliar,
        'des-auxiliar': auxiliar['nombre-aux']
      });
    } else {
      this.descuentoForm.patchValue({
        auxiliar: auxiliar.auxiliar,
        'des-auxiliar': auxiliar['nombre-aux']
      });
    }
    this.closeAuxiliarModal();
  }

  async onAuxiliarLeave(): Promise<void> {
    const companiaId = this.descuentoForm.get('cia')?.value;
    const cuentaId = this.descuentoForm.get('cuenta')?.value;
    const auxiliarId = this.descuentoForm.get('auxiliar')?.value;
    
    if (!companiaId || !cuentaId || !auxiliarId) {
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveAuxiliar(companiaId.toString(), cuentaId, auxiliarId);
      
      if (response?.dsRespuesta?.tcgmaeaux?.[0]) {
        const auxiliar = response.dsRespuesta.tcgmaeaux[0];
        this.descuentoForm.patchValue({
          'des-auxiliar': auxiliar['nombre-aux']
        });
      }
    } catch (error) {
      console.error('Error validando auxiliar:', error);
    } finally {
      this.loadingState.set(false);
    }
  }

  closeAuxiliarModal(): void {
    this.showAuxiliarModal.set(false);
  }

  // ==================== MÉTODOS WRAPPER PARA MODAL DE CREACIÓN ====================
  
  buscarCuentaFromModal(): void {
    const companiaId = this.descuentoForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Debe seleccionar una compañía primero');
      return;
    }
    this.cargarCuentas(companiaId);
    this.showCuentaModal.set(true);
  }

  buscarUbicacionFromModal(): void {
    const companiaId = this.descuentoForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Debe seleccionar una compañía primero');
      return;
    }
    this.cargarUbicaciones(companiaId);
    this.showUbicacionModal.set(true);
  }

  buscarCentroCostoFromModal(): void {
    const companiaId = this.descuentoForm.get('cia')?.value;
    if (!companiaId) {
      this.toastService.showWarning('Debe seleccionar una compañía primero');
      return;
    }
    this.cargarCentros(companiaId);
    this.showCentroCostoModal.set(true);
  }

  buscarAuxiliarFromModal(): void {
    const companiaId = this.descuentoForm.get('cia')?.value;
    const cuenta = this.createDescuentoForm.get('cuenta')?.value;
    
    if (!companiaId) {
      this.toastService.showWarning('Debe seleccionar una compañía primero');
      return;
    }
    if (!cuenta) {
      this.toastService.showWarning('Debe seleccionar una cuenta primero');
      return;
    }
    this.cargarAuxiliares(companiaId, cuenta);
    this.showAuxiliarModal.set(true);
  }

  // ==================== LEAVES DEL MODAL DE CREAR ====================

  async onCuentaLeaveFromModal(): Promise<void> {
    const companiaId = this.descuentoForm.get('cia')?.value;
    const cuentaId = this.createDescuentoForm.get('cuenta')?.value;
    
    if (!companiaId || !cuentaId) {
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveCuenta(companiaId.toString(), cuentaId);
      
      if (response?.dsRespuesta?.tcgcontab?.[0]) {
        const cuenta = response.dsRespuesta.tcgcontab[0];
        this.createDescuentoForm.patchValue({
          'des-cuenta': cuenta['nombre-cta']
        });
      }
    } catch (error) {
      console.error('Error validando cuenta:', error);
    } finally {
      this.loadingState.set(false);
    }
  }

  async onUbicacionLeaveFromModal(): Promise<void> {
    const companiaId = this.descuentoForm.get('cia')?.value;
    const ubicacionId = this.createDescuentoForm.get('ubicacion')?.value;
    
    if (!companiaId || !ubicacionId) {
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveUbicacion(companiaId, ubicacionId);
      
      if (response?.dsRespuesta?.tcgubicac?.[0]) {
        const ubicacion = response.dsRespuesta.tcgubicac[0];
        this.createDescuentoForm.patchValue({
          'des-ubicacion': ubicacion['nombre-ubic']
        });
      }
    } catch (error) {
      console.error('Error validando ubicación:', error);
    } finally {
      this.loadingState.set(false);
    }
  }

  async onCentroCostoLeaveFromModal(): Promise<void> {
    const companiaId = this.descuentoForm.get('cia')?.value;
    const centroId = this.createDescuentoForm.get('centro')?.value;
    
    if (!companiaId || !centroId) {
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveCentro(companiaId, centroId);
      
      if (response?.dsRespuesta?.tgecencos?.[0]) {
        const centro = response.dsRespuesta.tgecencos[0];
        this.createDescuentoForm.patchValue({
          'des-centro': centro['nombre-cen']
        });
      }
    } catch (error) {
      console.error('Error validando centro:', error);
    } finally {
      this.loadingState.set(false);
    }
  }

  async onAuxiliarLeaveFromModal(): Promise<void> {
    const companiaId = this.descuentoForm.get('cia')?.value;
    const cuentaId = this.createDescuentoForm.get('cuenta')?.value;
    const auxiliarId = this.createDescuentoForm.get('auxiliar')?.value;
    
    if (!companiaId || !cuentaId || !auxiliarId) {
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveAuxiliar(companiaId.toString(), cuentaId, auxiliarId);
      
      if (response?.dsRespuesta?.tcgmaeaux?.[0]) {
        const auxiliar = response.dsRespuesta.tcgmaeaux[0];
        this.createDescuentoForm.patchValue({
          'des-auxiliar': auxiliar['nombre-aux']
        });
      }
    } catch (error) {
      console.error('Error validando auxiliar:', error);
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== CRUD OPERATIONS ====================

  async onSubmit(): Promise<void> {
    if (this.descuentoForm.invalid) {
      this.toastService.showWarning('Por favor complete todos los campos requeridos');
      return;
    }

    const formValue = this.descuentoForm.getRawValue();
    
    const payload = {
      tcctabdes: [{
        'Agrega-Tabd': '',
        auxiliar: formValue.auxiliar || 0,
        'des-auxiliar': formValue['des-auxiliar'] || '',
        centro: formValue.centro || 0,
        'des-centro': formValue['des-centro'] || '',
        cia: formValue.cia,
        cuenta: formValue.cuenta,
        'des-cuenta': formValue['des-cuenta'] || '',
        'date-ctrl': formValue['date-ctrl'] || new Date().toISOString().split('T')[0],
        'descue-tdes': formValue['descue-tdes'],
        gravable: formValue.gravable || false,
        'login-ctrl': '',
        'nombre-tdes': formValue['nombre-tdes'],
        'porcen-tdes': formValue['porcen-tdes'] || 0.00,
        'text-tdes': formValue['text-tdes'] || '',
        ubicacion: formValue.ubicacion || 0,
        'des-ubicacion': formValue['des-ubicacion'] || '',
        tparent: ''
      }]
    };

    try {
      this.loadingState.set(true);
      const response = await this.ccService.updateDescuento(payload);
      
      if (response?.dsRespuesta?.tcctabdes?.[0]?.terrores?.[0]) {
        const error = response.dsRespuesta.tcctabdes[0].terrores[0];
        this.toastService.showSuccess(error.descripcion);
        this.onClear();
        this.closeDescuentoModal();
        await this.cargarDescuentos(formValue.cia);
      } else {
        this.toastService.showSuccess('Descuento guardado exitosamente');
        this.onClear();
        this.closeDescuentoModal();
        await this.cargarDescuentos(formValue.cia);
      }
    } catch (error) {
      console.error('Error guardando descuento:', error);
      this.toastService.showError('Error al guardar el descuento');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onDelete(): Promise<void> {
    const companiaId = this.descuentoForm.get('cia')?.value;
    const descuentoId = this.descuentoForm.get('descue-tdes')?.value;

    if (!companiaId || !descuentoId) {
      this.toastService.showWarning('No hay descuento seleccionado para eliminar');
      return;
    }

    const confirmar = confirm('¿Está seguro de eliminar este descuento?');
    if (!confirmar) return;

    try {
      this.loadingState.set(true);
      const response = await this.ccService.deleteDescuento(companiaId.toString(), descuentoId);
      
      if (response?.dsRespuesta?.tcctabdes?.[0]?.terrores?.[0]) {
        const error = response.dsRespuesta.tcctabdes[0].terrores[0];
        this.toastService.showSuccess(error.descripcion);
        this.onClear();
        this.closeDescuentoModal();
        await this.cargarDescuentos(companiaId);
      } else {
        this.toastService.showSuccess('Descuento eliminado exitosamente');
        this.onClear();
      }
    } catch (error) {
      console.error('Error eliminando descuento:', error);
      this.toastService.showError('Error al eliminar el descuento');
    } finally {
      this.loadingState.set(false);
    }
  }

  onClear(): void {
    this.descuentoForm.reset({
      cia: null,
      'nombre-cia': '',
      'descue-tdes': null,
      'nombre-tdes': '',
      'porcen-tdes': 0,
      gravable: false,
      cuenta: '',
      'des-cuenta': '',
      ubicacion: 0,
      'des-ubicacion': '',
      centro: 0,
      'des-centro': '',
      auxiliar: 0,
      'des-auxiliar': '',
      'text-tdes': ''
    });
    this.companiaSeleccionada.set(null);
    this.descuentoSeleccionado.set(null);
  }

  async onGenerateReport(): Promise<void> {
    const companiaId = this.descuentoForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía para generar reporte');
      return;
    }

    try {
      this.loadingState.set(true);
      const today = new Date();
      const pcFecha = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      
      const response = await this.ccService.getCC2046(
        companiaId.toString(),
        pcFecha
      ).toPromise();
      
      if (response?.pcArchPDF || response?.pcArchCSV) {
        this.reportResponse = response;
        this.showReportModal.set(true);
      } else {
        this.toastService.showError('No se pudo generar el reporte');
      }
    } catch (error) {
      console.error('Error generando reporte:', error);
      this.toastService.showError('Error al generar el reporte');
    } finally {
      this.loadingState.set(false);
    }
  }

  downloadReportPDF(): void {
    if (!this.reportResponse?.pcArchPDF) {
      this.toastService.showError('No se pudo generar el reporte PDF');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchPDF, 'reporte-descuentos.pdf', 'application/pdf');
    this.toastService.showSuccess('Reporte PDF descargado exitosamente');
    this.showReportModal.set(false);
  }

  downloadReportCSV(): void {
    if (!this.reportResponse?.pcArchCSV) {
      this.toastService.showError('No se pudo generar el reporte CSV');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchCSV, 'reporte-descuentos.csv', 'text/csv');
    this.toastService.showSuccess('Reporte CSV descargado exitosamente');
    this.showReportModal.set(false);
  }

  closeReportModal(): void {
    this.showReportModal.set(false);
    this.reportResponse = null;
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error al descargar el archivo:', error);
      this.toastService.showError('Error al descargar el archivo');
    }
  }

  // CREATE Modal Methods
  openCreateModal(): void {
    const cia = this.descuentoForm.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }
    this.createDescuentoForm.reset();
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
    this.createDescuentoForm.reset();
  }

  async onSaveNew(): Promise<void> {
    if (this.createDescuentoForm.invalid) {
      this.toastService.showError('Por favor complete los campos requeridos');
      return;
    }

    const cia = this.descuentoForm.get('cia')?.value;
    const auth = this.ccService.getAuthParams();
    const today = new Date();
    const dateCtrl = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

    const formValues = this.createDescuentoForm.getRawValue();
    
    const formData = {
      cia,
      'descue-tdes': formValues['descue-tdes'],
      'nombre-tdes': formValues['nombre-tdes'],
      'porcen-tdes': formValues['porcen-tdes'] || 0,
      gravable: formValues.gravable || false,
      cuenta: formValues.cuenta || '',
      ubicacion: formValues.ubicacion || 0,
      centro: formValues.centro || 0,
      auxiliar: formValues.auxiliar || 0,
      'text-tdes': formValues['text-tdes'] || '',
      'date-ctrl': dateCtrl,
      ...auth
    };

    this.loadingService.show();
    this.loadingState.set(true);

    try {
      const response = await this.ccService.createDescuentoAsync(formData);
      this.loadingService.hide();
      this.loadingState.set(false);

      console.log('Respuesta al crear descuento:', response);

      if (response) {
        // Verificar si hay respuesta en la estructura esperada
        if (response?.dsRespuesta?.tcctabdes?.[0]?.terrores?.[0]) {
          const error = response.dsRespuesta.tcctabdes[0].terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Descuento creado exitosamente');
        } else {
          this.toastService.showSuccess('Descuento creado exitosamente');
        }
        
        this.closeCreateModal();
        
        // Recargar lista de descuentos
        await this.cargarDescuentos(cia);
        
        // Limpiar el formulario principal
        this.onClear();
      } else {
        this.toastService.showError('No se pudo procesar la respuesta del servidor');
      }
    } catch (error) {
      this.loadingService.hide();
      this.loadingState.set(false);
      console.error('Error al crear descuento:', error);
      this.toastService.showError('Error al crear descuento: ' + (error instanceof Error ? error.message : 'Error desconocido'));
    }
  }

  goBack(): void {
    this.router.navigate(['/']);
  }

  isInvalid(fieldName: string): boolean {
    const field = this.descuentoForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.descuentoForm.get(fieldName);
    if (field?.hasError('required')) return 'Este campo es requerido';
    if (field?.hasError('min')) return 'El valor debe ser mayor a 0';
    return '';
  }
}

