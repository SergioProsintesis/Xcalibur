import { Component, EventEmitter, Input, Output, OnChanges, SimpleChanges, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CCService } from '../../../../core/services/cc.service';

export interface CentroCostoOption {
  centro: number;
  'nombre-cen': string;
}

@Component({
  selector: 'app-centro-costo-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './centro-costo-modal.component.html',
  styleUrls: ['./centro-costo-modal.component.css']
})
export class CentroCostoModalComponent implements OnChanges {
  @Input() visible = false;
  @Input() companiaId: string = '';
  @Input() centroValue: number = 0;
  @Output() centroSelected = new EventEmitter<CentroCostoOption>();
  @Output() closed = new EventEmitter<void>();

  centros = signal<CentroCostoOption[]>([]);
  centrosFiltrados = signal<CentroCostoOption[]>([]);
  searchTerm = signal('');
  isLoading = signal(false);

  constructor(private ccService: CCService) {}

  ngOnChanges(changes: SimpleChanges): void {
    // Cargar cuando el modal se hace visible
    if (changes['visible'] && changes['visible'].currentValue && this.companiaId) {
      console.log('✅ Cargando centros - visible=true');
      this.loadCentros();
    }
    // Cargar cuando cambia companiaId
    if (changes['companiaId'] && !changes['companiaId'].firstChange && this.visible && this.companiaId) {
      console.log('✅ Recargando centros - companiaId cambió');
      this.loadCentros();
    }
  }

  private async loadCentros(): Promise<void> {
    if (!this.companiaId) {
      console.warn('⚠️ No se puede cargar centros - falta companiaId', { companiaId: this.companiaId });
      return;
    }
    
    this.isLoading.set(true);
    console.log('🔄 Iniciando carga de centros...', { companiaId: this.companiaId });
    try {
      // Siempre cargar todos los centros
      const response = await this.ccService.getCECentro(this.companiaId);
      
      console.log('📦 Respuesta del servicio:', response);
      
      // Extraer el array de centros
      const centros = response?.dsRespuesta?.tgecencos;
      
      if (centros) {
        this.centros.set(centros);
        this.centrosFiltrados.set(centros);
        this.searchTerm.set('');
        console.log('✅ Centros cargados:', centros.length);
      } else {
        console.warn('⚠️ Estructura de respuesta inesperada:', response);
      }
    } catch (error) {
      console.error('❌ Error loading centros:', error);
    } finally {
      this.isLoading.set(false);
    }
  }

  onSearch(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.searchTerm.set(value);
    this.filterCentros(value);
  }

  private filterCentros(searchTerm: string): void {
    if (!searchTerm) {
      this.centrosFiltrados.set(this.centros());
      return;
    }

    const filtered = this.centros().filter(centro => 
      centro.centro?.toString().includes(searchTerm) ||
      centro['nombre-cen']?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    this.centrosFiltrados.set(filtered);
  }

  selectCentro(centro: CentroCostoOption): void {
    this.centroSelected.emit(centro);
    this.close();
  }

  close(): void {
    this.searchTerm.set('');
    this.closed.emit();
  }
}
