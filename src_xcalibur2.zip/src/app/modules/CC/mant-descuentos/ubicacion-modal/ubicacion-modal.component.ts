import { Component, EventEmitter, Input, Output, OnChanges, SimpleChanges, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CCService } from '../../../../core/services/cc.service';

export interface UbicacionOption {
  ubicacion: number;
  'nombre-ubic': string;
}

@Component({
  selector: 'app-ubicacion-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './ubicacion-modal.component.html',
  styleUrls: ['./ubicacion-modal.component.css']
})
export class UbicacionModalComponent implements OnChanges {
  @Input() visible = false;
  @Input() companiaId: string = '';
  @Input() ubicacionValue: number = 0;
  @Output() ubicacionSelected = new EventEmitter<UbicacionOption>();
  @Output() closed = new EventEmitter<void>();

  ubicaciones = signal<UbicacionOption[]>([]);
  ubicacionesFiltradas = signal<UbicacionOption[]>([]);
  searchTerm = signal('');
  isLoading = signal(false);

  constructor(private ccService: CCService) {}

  ngOnChanges(changes: SimpleChanges): void {
    // Cargar cuando el modal se hace visible
    if (changes['visible'] && changes['visible'].currentValue && this.companiaId) {
      console.log('✅ Cargando ubicaciones - visible=true');
      this.loadUbicaciones();
    }
    // Cargar cuando cambia companiaId
    if (changes['companiaId'] && !changes['companiaId'].firstChange && this.visible && this.companiaId) {
      console.log('✅ Recargando ubicaciones - companiaId cambió');
      this.loadUbicaciones();
    }
  }

  private async loadUbicaciones(): Promise<void> {
    if (!this.companiaId) {
      console.warn('⚠️ No se puede cargar ubicaciones - falta companiaId', { companiaId: this.companiaId });
      return;
    }
    
    this.isLoading.set(true);
    console.log('🔄 Iniciando carga de ubicaciones...', { companiaId: this.companiaId });
    try {
      // Siempre cargar todas las ubicaciones
      const response = await this.ccService.getCEUbicacion(this.companiaId);
      
      console.log('📦 Respuesta del servicio:', response);
      
      // Extraer el array de ubicaciones
      const ubicaciones = response?.dsRespuesta?.tcgubicac;
      
      if (ubicaciones) {
        this.ubicaciones.set(ubicaciones);
        this.ubicacionesFiltradas.set(ubicaciones);
        this.searchTerm.set('');
        console.log('✅ Ubicaciones cargadas:', ubicaciones.length);
      } else {
        console.warn('⚠️ Estructura de respuesta inesperada:', response);
      }
    } catch (error) {
      console.error('❌ Error loading ubicaciones:', error);
    } finally {
      this.isLoading.set(false);
    }
  }

  onSearch(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.searchTerm.set(value);
    this.filterUbicaciones(value);
  }

  private filterUbicaciones(searchTerm: string): void {
    if (!searchTerm) {
      this.ubicacionesFiltradas.set(this.ubicaciones());
      return;
    }

    const filtered = this.ubicaciones().filter(ubic => 
      ubic.ubicacion?.toString().includes(searchTerm) ||
      ubic['nombre-ubic']?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    this.ubicacionesFiltradas.set(filtered);
  }

  selectUbicacion(ubicacion: UbicacionOption): void {
    this.ubicacionSelected.emit(ubicacion);
    this.close();
  }

  close(): void {
    this.searchTerm.set('');
    this.closed.emit();
  }
}
