import { Component, EventEmitter, Input, Output, OnChanges, SimpleChanges, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CCService } from '../../../../core/services/cc.service';

export interface AuxiliarOption {
  auxiliar: number;
  'nombre-aux': string;
}

@Component({
  selector: 'app-auxiliar-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './auxiliar-modal.component.html',
  styleUrls: ['./auxiliar-modal.component.css']
})
export class AuxiliarModalComponent implements OnChanges {
  @Input() visible = false;
  @Input() companiaId: string = '';
  @Input() cuentaValue: string = '';
  @Input() auxiliarValue: number = 0;
  @Output() auxiliarSelected = new EventEmitter<AuxiliarOption>();
  @Output() closed = new EventEmitter<void>();

  auxiliares = signal<AuxiliarOption[]>([]);
  auxiliaresFiltrados = signal<AuxiliarOption[]>([]);
  searchTerm = signal('');
  isLoading = signal(false);

  constructor(private ccService: CCService) {}

  ngOnChanges(changes: SimpleChanges): void {
    // Cargar cuando el modal se hace visible
    if (changes['visible'] && changes['visible'].currentValue && this.companiaId && this.cuentaValue) {
      console.log('[AuxiliarModal] ngOnChanges - visible=true, cargando auxiliares', { companiaId: this.companiaId, cuentaValue: this.cuentaValue });
      this.loadAuxiliares();
    }
    // Cargar cuando cambia companiaId o cuentaValue
    if ((changes['companiaId'] && !changes['companiaId'].firstChange || 
         changes['cuentaValue'] && !changes['cuentaValue'].firstChange) && 
        this.visible && this.companiaId && this.cuentaValue) {
      console.log('[AuxiliarModal] ngOnChanges - parámetros cambiaron, recargando', { companiaId: this.companiaId, cuentaValue: this.cuentaValue });
      this.loadAuxiliares();
    }
  }

  private async loadAuxiliares(): Promise<void> {
    if (!this.companiaId || !this.cuentaValue) {
      console.warn('⚠️ No se puede cargar auxiliares - falta companiaId o cuentaValue', { companiaId: this.companiaId, cuentaValue: this.cuentaValue });
      return;
    }
    
    this.isLoading.set(true);
    console.log('🔄 Iniciando carga de auxiliares...', { companiaId: this.companiaId, cuentaValue: this.cuentaValue });
    try {
      // Siempre cargar todos los auxiliares para la cuenta
      const response = await this.ccService.getCEAuxiliarCxC(this.companiaId, this.cuentaValue);
      
      console.log('📦 Respuesta del servicio (completa):', response);
      
      // Extraer el array de auxiliares - probar múltiples estructuras
      let auxiliares = response?.dsRespuesta?.tcgmaeaux || 
                       response?.tcgmaeaux || 
                       response?.cgmaeaux || 
                       response?.tgmaeaux ||
                       response?.auxiliares;
      
      if (auxiliares && Array.isArray(auxiliares)) {
        this.auxiliares.set(auxiliares);
        this.auxiliaresFiltrados.set(auxiliares);
        this.searchTerm.set('');
        console.log('✅ Auxiliares cargados:', auxiliares.length);
      } else {
        console.warn('⚠️ Estructura de respuesta inesperada o vacía:', response);
        this.auxiliares.set([]);
        this.auxiliaresFiltrados.set([]);
      }
    } catch (error) {
      console.error('❌ Error loading auxiliares:', error);
      this.auxiliares.set([]);
      this.auxiliaresFiltrados.set([]);
    } finally {
      this.isLoading.set(false);
    }
  }

  onSearch(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.searchTerm.set(value);
    this.filterAuxiliares(value);
  }

  private filterAuxiliares(searchTerm: string): void {
    if (!searchTerm) {
      this.auxiliaresFiltrados.set(this.auxiliares());
      return;
    }

    const filtered = this.auxiliares().filter(aux => 
      aux.auxiliar?.toString().includes(searchTerm) ||
      aux['nombre-aux']?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    this.auxiliaresFiltrados.set(filtered);
  }

  selectAuxiliar(auxiliar: AuxiliarOption): void {
    this.auxiliarSelected.emit(auxiliar);
    this.close();
  }

  close(): void {
    this.searchTerm.set('');
    this.closed.emit();
  }
}
