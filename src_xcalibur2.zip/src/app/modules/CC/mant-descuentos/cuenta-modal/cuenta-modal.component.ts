import { Component, EventEmitter, Input, Output, OnChanges, SimpleChanges, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CCService } from '../../../../core/services/cc.service';

export interface CuentaOption {
  cuenta: string;
  'nombre-cta': string;
}

@Component({
  selector: 'app-cuenta-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './cuenta-modal.component.html',
  styleUrls: ['./cuenta-modal.component.css']
})
export class CuentaModalComponent implements OnChanges {
  @Input() visible = false;
  @Input() companiaId: string = '';
  @Input() cuentaValue: string = '';
  @Output() cuentaSelected = new EventEmitter<CuentaOption>();
  @Output() closed = new EventEmitter<void>();

  cuentas = signal<CuentaOption[]>([]);
  cuentasFiltradas = signal<CuentaOption[]>([]);
  searchTerm = signal('');
  isLoading = signal(false);

  constructor(private ccService: CCService) {}

  ngOnChanges(changes: SimpleChanges): void {
    // Cargar cuando el modal se hace visible Y hay companiaId
    if (changes['visible'] && changes['visible'].currentValue && this.companiaId) {
      console.log('✅ Cargando cuentas - visible=true');
      this.loadCuentas();
    }
    // Recargar cuando cambia companiaId
    if (changes['companiaId'] && !changes['companiaId'].firstChange && this.visible && this.companiaId) {
      console.log('✅ Recargando cuentas - companiaId cambió');
      this.loadCuentas();
    }
  }

  private async loadCuentas(): Promise<void> {
    if (!this.companiaId) {
      console.warn('⚠️ No se puede cargar cuentas - falta companiaId', { companiaId: this.companiaId });
      return;
    }
    
    this.isLoading.set(true);
    console.log('🔄 Iniciando carga de cuentas...', { companiaId: this.companiaId, cuentaValue: this.cuentaValue });
    try {
      // Siempre cargar todas las cuentas
      const response = await this.ccService.getCECuentaCCxC(this.companiaId);
      
      console.log('📦 Respuesta del servicio:', response);
      
      // Extraer el array de cuentas
      const cuentas = response?.dsRespuesta?.tcgcontab;
      
      if (cuentas) {
        this.cuentas.set(cuentas);
        this.cuentasFiltradas.set(cuentas);
        this.searchTerm.set('');
        console.log('✅ Cuentas cargadas:', cuentas.length);
      } else {
        console.warn('⚠️ Estructura de respuesta inesperada:', response);
      }
    } catch (error) {
      console.error('❌ Error loading cuentas:', error);
    } finally {
      this.isLoading.set(false);
    }
  }

  onSearch(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.searchTerm.set(value);
    this.filterCuentas(value);
  }

  private filterCuentas(searchTerm: string): void {
    if (!searchTerm) {
      this.cuentasFiltradas.set(this.cuentas());
      return;
    }

    const filtered = this.cuentas().filter(cuenta => 
      cuenta.cuenta?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cuenta['nombre-cta']?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    this.cuentasFiltradas.set(filtered);
  }

  selectCuenta(cuenta: CuentaOption): void {
    this.cuentaSelected.emit(cuenta);
    this.close();
  }

  close(): void {
    this.searchTerm.set('');
    this.closed.emit();
  }
}
