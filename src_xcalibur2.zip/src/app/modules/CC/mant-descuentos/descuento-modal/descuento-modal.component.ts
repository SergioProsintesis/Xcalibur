import { Component, EventEmitter, Input, OnDestroy, OnInit, OnChanges, SimpleChanges, Output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { debounceTime, distinctUntilChanged, Subject, takeUntil } from 'rxjs';
import { CCService } from '../../../../core/services/cc.service';

export interface DescuentoOption {
  'descue-tdes': number;
  'nombre-tdes': string;
  'porcen-tdes': number;
  gravable: boolean;
  cuenta: string;
  'des-cuenta': string;
  ubicacion: number;
  'des-ubicacion': string;
  centro: number;
  'des-centro': string;
  auxiliar: number;
  'des-auxiliar': string;
  'text-tdes': string;
}

@Component({
  selector: 'app-descuento-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './descuento-modal.component.html',
  styleUrls: ['./descuento-modal.component.css']
})
export class DescuentoModalComponent implements OnInit, OnDestroy, OnChanges {
  @Input() show = false;
  @Input() companiaId: number | null = null;
  @Output() descuentoSelected = new EventEmitter<DescuentoOption>();
  @Output() closeModal = new EventEmitter<void>();

  searchForm: FormGroup;
  descuentos = signal<DescuentoOption[]>([]);
  filteredDescuentos = signal<DescuentoOption[]>([]);
  isLoading = signal(false);
  
  private destroy$ = new Subject<void>();

  constructor(
    private fb: FormBuilder,
    private ccService: CCService
  ) {
    this.searchForm = this.fb.group({ search: [''] });
  }

  ngOnInit(): void {
    this.searchForm.get('search')!.valueChanges.pipe(
      takeUntil(this.destroy$),
      debounceTime(300),
      distinctUntilChanged()
    ).subscribe(searchTerm => this.filterDescuentos(searchTerm));
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Cargar descuentos cuando el modal se abre
    if (changes['show'] && changes['show'].currentValue && this.companiaId) {
      this.loadDescuentos();
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private async loadDescuentos(): Promise<void> {
    if (!this.companiaId) return;
    
    this.isLoading.set(true);
    try {
      const response = await this.ccService.getCEDescuento(this.companiaId.toString());
      if (response?.dsRespuesta?.tcctabdes) {
        this.descuentos.set(response.dsRespuesta.tcctabdes);
        this.filteredDescuentos.set(response.dsRespuesta.tcctabdes);
      }
    } catch (error) {
      console.error('Error loading descuentos:', error);
    } finally {
      this.isLoading.set(false);
    }
  }

  private filterDescuentos(searchTerm: string): void {
    if (!searchTerm) {
      this.filteredDescuentos.set(this.descuentos());
      return;
    }

    const filtered = this.descuentos().filter(desc => 
      desc['descue-tdes']?.toString().includes(searchTerm) ||
      desc['nombre-tdes']?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    this.filteredDescuentos.set(filtered);
  }

  onSelect(descuento: DescuentoOption): void {
    this.descuentoSelected.emit(descuento);
  }

  onClose(): void {
    this.closeModal.emit();
  }
}
