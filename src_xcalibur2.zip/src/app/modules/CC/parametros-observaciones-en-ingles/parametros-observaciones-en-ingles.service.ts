import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../../../core/services/auth.service';

export interface ParametrosObservacionesRecord {
  'Agrega-Ingobs'?: string;
  cia: number;
  'nombre-cia': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'Ingobs1-obs'?: string;
  'Ingobs2-obs'?: string;
  'Ingobs3-obs'?: string;
  'Ingobs4-obs'?: string;
  'Ingobs5-obs'?: string;
  'Ingobs6-obs'?: string;
  'Ingobs7-obs'?: string;
  'teIngobs7-obs'?: string;
  tparent?: string;
}

@Injectable({
  providedIn: 'root'
})
export class ParametrosObservacionesEnInglesService {
  private http = inject(HttpClient);
  private authService = inject(AuthService);
  private baseUrl = 'http://184.168.30.44:8810/XcaliburWeb/rest/ServiciosXcaliburWeb';

  /**
   * GetLeaveCia_ps5141 - Obtiene los parámetros de observaciones para una compañía
   */
  async getLeaveCompania(cia: number): Promise<any> {
    try {
      const user = this.authService.user();
      const params = {
        pcCompania: cia.toString(),
        pcLogin: user?.pcLogin || '',
        pcSuper: user?.pcSuper || '',
        pcToken: user?.pcToken || ''
      };

      return await firstValueFrom(
        this.http.get(`${this.baseUrl}/GetLeaveCia_ps5141`, { params })
      );
    } catch (error) {
      console.error('Error en getLeaveCompania:', error);
      throw error;
    }
  }

  /**
   * Updatefaingobs_PS5141 - Crea o actualiza registros de observaciones en inglés
   */
  async saveParametro(parametro: ParametrosObservacionesRecord): Promise<any> {
    try {
      const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
      const body = {
        tfaingobs: [parametro]
      };

      return await firstValueFrom(
        this.http.put(`${this.baseUrl}/Updatefaingobs_PS5141`, body, { headers })
      );
    } catch (error) {
      console.error('Error en saveParametro:', error);
      throw error;
    }
  }

  /**
   * GetCECompanias - Obtiene la lista de compañías disponibles
   */
  async getCompanias(): Promise<any> {
    try {
      const user = this.authService.user();
      const params = {
        pcLogin: user?.pcLogin || '',
        pcSuper: user?.pcSuper || '',
        pcToken: user?.pcToken || ''
      };

      return await firstValueFrom(
        this.http.get(`${this.baseUrl}/GetCECompanias`, { params })
      );
    } catch (error) {
      console.error('Error en getCompanias:', error);
      throw error;
    }
  }
}
