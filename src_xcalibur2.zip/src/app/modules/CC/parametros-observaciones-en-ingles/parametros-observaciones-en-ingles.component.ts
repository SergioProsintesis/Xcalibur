import { Component, inject, signal, OnInit, computed, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { ParametrosObservacionesEnInglesService, ParametrosObservacionesRecord } from './parametros-observaciones-en-ingles.service';
import { CompaniaRecord } from '../../../core/interfaces/cc.interface';

@Component({
  selector: 'app-parametros-observaciones-en-ingles',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent],
  templateUrl: './parametros-observaciones-en-ingles.component.html',
  styleUrls: ['./parametros-observaciones-en-ingles.component.css']
})
export class ParametrosObservacionesEnInglesComponent implements OnInit {
  private fb = inject(FormBuilder);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private service = inject(ParametrosObservacionesEnInglesService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  parametroForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}PS5141 - Parámetros Observaciones en Inglés`);
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  parametroActual = signal<ParametrosObservacionesRecord | null>(null);
  companias = signal<CompaniaRecord[]>([]);

  // Control de modales
  showCompaniaModal = signal(false);
  showCreateModal = signal(false);
  showDeleteModal = signal(false);
  isEditMode = signal(false);

  ngOnInit() {
    console.log('🔄 ParametrosObservacionesEnInglesComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    this.loadCompanias();
    console.log('✅ ParametrosObservacionesEnInglesComponent inicializado correctamente');
  }

  private async loadCompanias(): Promise<void> {
    try {
      this.loadingState.set(true);
      const response = await this.service.getCompanias();
      if (response?.dsRespuesta?.tgecias) {
        this.companias.set(response.dsRespuesta.tgecias);
      }
    } catch (error) {
      console.error('Error al cargar compañías:', error);
      this.toastService.showError('Error al cargar las compañías');
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  private initializeForm(): void {
    this.parametroForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      'Ingobs1-obs': [''],
      'Ingobs2-obs': [''],
      'Ingobs3-obs': [''],
      'Ingobs4-obs': [''],
      'Ingobs5-obs': [''],
      'Ingobs6-obs': [''],
      'Ingobs7-obs': [''],
      'teIngobs7-obs': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.parametroForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.parametroForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }



  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.parametroForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.loadParametro();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.parametroForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.service.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.parametroForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
        this.loadParametro();
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.parametroActual.set(null);
    this.parametroForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
  }

  // ==================== CARGAR DATOS ====================
  private async loadParametro(): Promise<void> {
    const ciaValue = this.parametroForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.parametroActual.set(null);
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.service.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tfaingobs && response.dsRespuesta.tfaingobs.length > 0) {
        const parametro = response.dsRespuesta.tfaingobs[0];
        this.parametroActual.set(parametro);
        this.parametroForm.patchValue({
          'Ingobs1-obs': parametro['Ingobs1-obs'] || '',
          'Ingobs2-obs': parametro['Ingobs2-obs'] || '',
          'Ingobs3-obs': parametro['Ingobs3-obs'] || '',
          'Ingobs4-obs': parametro['Ingobs4-obs'] || '',
          'Ingobs5-obs': parametro['Ingobs5-obs'] || '',
          'Ingobs6-obs': parametro['Ingobs6-obs'] || '',
          'Ingobs7-obs': parametro['Ingobs7-obs'] || '',
          'teIngobs7-obs': parametro['teIngobs7-obs'] || ''
        });
      } else {
        this.parametroActual.set(null);
      }
    } catch (error) {
      console.error('Error al cargar parámetro:', error);
      this.toastService.showError('Error al cargar los parámetros');
      this.parametroActual.set(null);
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  // ==================== ACCIONES ====================
  onLimpiar(): void {
    this.parametroForm.patchValue({
      'Ingobs1-obs': '',
      'Ingobs2-obs': '',
      'Ingobs3-obs': '',
      'Ingobs4-obs': '',
      'Ingobs5-obs': '',
      'Ingobs6-obs': '',
      'Ingobs7-obs': '',
      'teIngobs7-obs': ''
    });
    this.isEditMode.set(false);
    this.cdr.markForCheck();
  }

  onGuardar(): void {
    if (!this.parametroForm.get('cia')?.value) {
      this.toastService.showError('Por favor, seleccione una compañía');
      return;
    }

    const ciaValue = this.parametroForm.get('cia')?.value;
    const nombreCia = this.parametroForm.get('nombre-cia')?.value;

    const parametro: ParametrosObservacionesRecord = {
      cia: ciaValue,
      'nombre-cia': nombreCia,
      'Ingobs1-obs': this.parametroForm.get('Ingobs1-obs')?.value || '',
      'Ingobs2-obs': this.parametroForm.get('Ingobs2-obs')?.value || '',
      'Ingobs3-obs': this.parametroForm.get('Ingobs3-obs')?.value || '',
      'Ingobs4-obs': this.parametroForm.get('Ingobs4-obs')?.value || '',
      'Ingobs5-obs': this.parametroForm.get('Ingobs5-obs')?.value || '',
      'Ingobs6-obs': this.parametroForm.get('Ingobs6-obs')?.value || '',
      'Ingobs7-obs': this.parametroForm.get('Ingobs7-obs')?.value || '',
      'teIngobs7-obs': this.parametroForm.get('teIngobs7-obs')?.value || '',
      'login-ctrl': '',
      'date-ctrl': new Date().toISOString().split('T')[0],
      tparent: ''
    };

    this.guardarParametro(parametro);
  }

  private async guardarParametro(parametro: ParametrosObservacionesRecord): Promise<void> {
    try {
      this.loadingState.set(true);
      await this.service.saveParametro(parametro);
      this.toastService.showSuccess('Parámetros guardados correctamente');
      this.parametroActual.set(parametro);
      this.isEditMode.set(false);
    } catch (error) {
      console.error('Error al guardar parámetro:', error);
      this.toastService.showError('Error al guardar los parámetros');
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  onEliminar(): void {
    if (!this.parametroActual()) {
      this.toastService.showError('No hay parámetros para eliminar');
      return;
    }
    this.showDeleteModal.set(true);
  }

  closeDeleteModal(): void {
    this.showDeleteModal.set(false);
  }

  confirmarEliminar(): void {
    const parametro = this.parametroActual();
    if (!parametro) {
      this.toastService.showError('No hay parámetros para eliminar');
      return;
    }

    // Crear un parámetro vacío para "eliminar"
    const parametroVacio: ParametrosObservacionesRecord = {
      cia: parametro.cia,
      'nombre-cia': parametro['nombre-cia'],
      'Ingobs1-obs': '',
      'Ingobs2-obs': '',
      'Ingobs3-obs': '',
      'Ingobs4-obs': '',
      'Ingobs5-obs': '',
      'Ingobs6-obs': '',
      'Ingobs7-obs': '',
      'teIngobs7-obs': ''
    };

    this.guardarParametro(parametroVacio);
    this.closeDeleteModal();
    this.onLimpiar();
  }

  onVolver(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }
}
