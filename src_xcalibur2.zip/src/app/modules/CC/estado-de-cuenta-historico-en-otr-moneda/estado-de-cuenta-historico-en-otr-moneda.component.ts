import { Component, OnDestroy, OnInit, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Observable, Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';

import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CCService } from '../../../core/services/cc.service';
import { CompaniaRecord, GenerarReporteResponse } from '../../../core/interfaces/cc.interface';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { EmpresaModalComponent } from '../reporte-movimiento-del-dia/empresa-modal/empresa-modal.component';

interface EmpresaRecord {
  empresa: number;
  'nombre-emp': string;
  nit: string;
  cia: number;
}

@Component({
  selector: 'app-estado-de-cuenta-historico-en-otr-moneda',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, CompaniaModalComponent, EmpresaModalComponent],
  templateUrl: './estado-de-cuenta-historico-en-otr-moneda.component.html',
  styleUrls: ['./estado-de-cuenta-historico-en-otr-moneda.component.css']
})
export class EstadoDeCuentaHistoricoEnOtrMonedaComponent implements OnInit, OnDestroy {
  form: FormGroup;
  searchForm: FormGroup;
  isLoading = signal(false);
  showCompaniaModal = signal(false);
  showEmpresaDesdeModal = signal(false);
  showEmpresaHastaModal = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  selectedEmpresaDesde = signal<EmpresaRecord | null>(null);
  selectedEmpresaHasta = signal<EmpresaRecord | null>(null);
  isGeneratingReport = signal(false);
  
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Estado de Cuenta Histórico en Otra Moneda`);
  
  companiasList = signal<CompaniaRecord[]>([]);
  filteredCompaniasList = signal<CompaniaRecord[]>([]);
  isLoadingCompanias = signal(false);
  
  private destroy$ = new Subject<void>();
  private programContext = inject(ProgramContextService);

  private escapeHtml(text: string): string {
    const map: { [key: string]: string } = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, (char) => map[char]);
  }

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
    private loading: LoadingService,
    private ccService: CCService,
    private router: Router
  ) {
    this.form = this.fb.group({
      compania: ['', Validators.required],
      empresaDesde: ['', Validators.required],
      nombreEmpresaDesde: [{value: '', disabled: true}],
      empresaHasta: ['', Validators.required],
      nombreEmpresaHasta: [{value: '', disabled: true}],
      fechaInicio: ['', Validators.required],
      fechaFin: ['', Validators.required]
    });

    this.searchForm = this.fb.group({
      search: ['']
    });
  }

  ngOnInit(): void {
    this.loadCompanias();
  }

  private loadCompanias(): void {
    this.isLoadingCompanias.set(true);
    
    this.ccService.getCompanias()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (companias) => {
          this.companiasList.set(companias);
          this.filteredCompaniasList.set(companias);
          this.isLoadingCompanias.set(false);
        },
        error: (err) => {
          console.error('Error loading companies:', err);
          this.toast.showError('Error al cargar las compañías');
          this.isLoadingCompanias.set(false);
        }
      });
  }

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
    this.searchForm.reset();
    this.filteredCompaniasList.set(this.companiasList());
  }

  onSelectCompania(compania: CompaniaRecord): void {
    this.form.patchValue({
      compania: compania.cia
    });
    this.selectedCompania.set(compania);
    this.showCompaniaModal.set(false);
    // Limpiar empresas cuando cambia compañía
    this.selectedEmpresaDesde.set(null);
    this.selectedEmpresaHasta.set(null);
    this.form.patchValue({
      empresaDesde: '',
      nombreEmpresaDesde: '',
      empresaHasta: '',
      nombreEmpresaHasta: ''
    });
  }

  onCompaniaBlur(): void {
    const value = this.form.get('compania')?.value;
    if (value && value.toString().length > 0) {
      this.validateCompania(value);
    }
  }

  private validateCompania(codigo: string): void {
    this.ccService.validateCompania(codigo).subscribe({
      next: (compania) => {
        if (compania) {
          this.selectedCompania.set(compania);
          const ctrl = this.form.get('compania');
          if (ctrl?.hasError('notFound')) {
            const errors = { ...(ctrl.errors || {}) };
            delete errors['notFound'];
            ctrl.setErrors(Object.keys(errors).length ? errors : null);
          }
        } else {
          this.selectedCompania.set(null);
          this.form.get('compania')?.setErrors({ notFound: true });
        }
      },
      error: (err) => {
        console.error('Error validating compania:', err);
        this.toast.showError('Error al validar la compañía');
      }
    });
  }

  onOpenEmpresaDesdeModal(): void {
    const compania = this.form.get('compania')?.value;
    if (!compania) {
      this.toast.showWarning('Seleccione una compañía primero');
      return;
    }
    this.showEmpresaDesdeModal.set(true);
  }

  onOpenEmpresaHastaModal(): void {
    const compania = this.form.get('compania')?.value;
    if (!compania) {
      this.toast.showWarning('Seleccione una compañía primero');
      return;
    }
    this.showEmpresaHastaModal.set(true);
  }

  onSelectEmpresaDesde(empresa: EmpresaRecord): void {
    this.selectedEmpresaDesde.set(empresa);
    this.form.patchValue({
      empresaDesde: empresa.empresa.toString(),
      nombreEmpresaDesde: empresa['nombre-emp'] || ''
    });
    this.showEmpresaDesdeModal.set(false);
    this.validateEmpresaDesde(empresa.empresa.toString());
  }

  onSelectEmpresaHasta(empresa: EmpresaRecord): void {
    this.selectedEmpresaHasta.set(empresa);
    this.form.patchValue({
      empresaHasta: empresa.empresa.toString(),
      nombreEmpresaHasta: empresa['nombre-emp'] || ''
    });
    this.showEmpresaHastaModal.set(false);
    this.validateEmpresaHasta(empresa.empresa.toString());
  }

  onEmpresaDesdeBlur(): void {
    const value = this.form.get('empresaDesde')?.value;
    if (value && value.toString().length > 0) {
      this.validateEmpresaDesde(value);
    }
  }

  private validateEmpresaDesde(codigo: string): void {
    const compania = this.form.get('compania')?.value;
    if (!compania) return;

    this.ccService.validateEmpresa(compania, codigo).subscribe({
      next: (empresa) => {
        if (empresa) {
          this.selectedEmpresaDesde.set(empresa);
          this.form.patchValue({ 
            nombreEmpresaDesde: empresa['nombre-emp'] || ''
          });
          const ctrl = this.form.get('empresaDesde');
          if (ctrl?.hasError('notFound')) {
            const errors = { ...(ctrl.errors || {}) };
            delete errors['notFound'];
            ctrl.setErrors(Object.keys(errors).length ? errors : null);
          }
        } else {
          this.selectedEmpresaDesde.set(null);
          this.form.patchValue({ nombreEmpresaDesde: '' });
          this.form.get('empresaDesde')?.setErrors({ notFound: true });
        }
      },
      error: (err) => {
        console.error('Error validating empresaDesde:', err);
        this.toast.showError('Error al validar la empresa');
      }
    });
  }

  onEmpresaHastaBlur(): void {
    const value = this.form.get('empresaHasta')?.value;
    if (value && value.toString().length > 0) {
      this.validateEmpresaHasta(value);
    }
  }

  private validateEmpresaHasta(codigo: string): void {
    const compania = this.form.get('compania')?.value;
    if (!compania) return;

    this.ccService.validateEmpresa(compania, codigo).subscribe({
      next: (empresa) => {
        if (empresa) {
          this.selectedEmpresaHasta.set(empresa);
          this.form.patchValue({ 
            nombreEmpresaHasta: empresa['nombre-emp'] || ''
          });
          const ctrl = this.form.get('empresaHasta');
          if (ctrl?.hasError('notFound')) {
            const errors = { ...(ctrl.errors || {}) };
            delete errors['notFound'];
            ctrl.setErrors(Object.keys(errors).length ? errors : null);
          }
        } else {
          this.selectedEmpresaHasta.set(null);
          this.form.patchValue({ nombreEmpresaHasta: '' });
          this.form.get('empresaHasta')?.setErrors({ notFound: true });
        }
      },
      error: (err) => {
        console.error('Error validating empresaHasta:', err);
        this.toast.showError('Error al validar la empresa');
      }
    });
  }

  onCloseModal(): void {
    this.showCompaniaModal.set(false);
    this.showEmpresaDesdeModal.set(false);
    this.showEmpresaHastaModal.set(false);
    this.searchForm.reset();
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getErrorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (!field) return '';

    if (field.hasError('required')) return 'Este campo es requerido';
    if (field.hasError('pattern')) return 'Formato inválido';
    
    return 'Error en el campo';
  }

  trackByCompania(index: number, compania: CompaniaRecord): number {
    return compania.cia;
  }

  onGenerarReporte(formato: 'excel' | 'pdf' | 'pantalla'): void {
    if (!this.form.valid) {
      this.toast.showError('Por favor complete los campos requeridos');
      return;
    }

    this.isGeneratingReport.set(true);
    const pcCompania = this.form.get('compania')?.value;
    const pcFechaD = this.form.get('fechaInicio')?.value;
    const pcFechaH = this.form.get('fechaFin')?.value;

    // TODO: Reemplazar con el endpoint correcto para estado de cuenta histórico en otra moneda
    // Por ahora se usa PS5034 como placeholder - cambiar por el endpoint real
    const reportCall = this.ccService.getPS5034(pcCompania, pcFechaD, pcFechaH);

    reportCall
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isGeneratingReport.set(false);
          if (response) {
            this.handleReporteResponse(response, formato);
            this.toast.showSuccess(`Reporte generado en formato ${formato}`);
          } else {
            this.toast.showError('No se pudo generar el reporte');
          }
        },
        error: (err: any) => {
          this.isGeneratingReport.set(false);
          console.error('Error generating report:', err);
          this.toast.showError('Error al generar el reporte');
        }
      });
  }

  private handleReporteResponse(response: string | GenerarReporteResponse['response'], formato: string): void {
    if (typeof response === 'string') {
      if (formato === 'excel') {
        this.downloadBase64File(response, 'application/vnd.ms-excel', 'reporte.xls');
      } else if (formato === 'pantalla') {
        this.viewExcelInBrowser(response);
      }
    } else if (response) {
      if (formato === 'excel') {
        if (response.pcArchXLS) {
          this.downloadBase64File(response.pcArchXLS, 'application/vnd.ms-excel', 'reporte.xls');
        } else if (response.pcArchCSV) {
          this.downloadBase64File(response.pcArchCSV, 'text/csv', 'reporte.csv');
        }
      } else if (formato === 'pdf' && response.pcArchPDF) {
        this.downloadBase64File(response.pcArchPDF, 'application/pdf', 'reporte.pdf');
      } else if (formato === 'pantalla') {
        if (response.pcArchXLS) {
          this.viewExcelInBrowser(response.pcArchXLS);
        } else if (response.pcArchCSV) {
          this.viewCSVInBrowser(response.pcArchCSV);
        }
      }
    }
  }

  private viewExcelInBrowser(base64Data: string): void {
    try {
      const excelData = 'data:application/vnd.ms-excel;base64,' + base64Data;
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head>
              <title>Reporte Excel</title>
            </head>
            <body>
              <iframe src="${excelData}" width="100%" height="100%"></iframe>
            </body>
          </html>
        `);
        newWindow.document.close();
      }
    } catch (error) {
      console.error('Error mostrando Excel:', error);
      this.toast.showError('Error al mostrar el Excel');
    }
  }

  private viewCSVInBrowser(base64Data: string): void {
    try {
      const csvText = atob(base64Data);
      const escapedText = this.escapeHtml(csvText);
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head>
              <title>Reporte CSV</title>
              <style>
                body { 
                  font-family: 'Courier New', monospace; 
                  padding: 20px; 
                  background: #f5f5f5;
                }
                .content {
                  background: white;
                  padding: 20px;
                  border-radius: 4px;
                  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                  white-space: pre-wrap;
                  word-wrap: break-word;
                  max-width: 1200px;
                  margin: 0 auto;
                }
                .print-btn {
                  margin-bottom: 20px;
                  padding: 10px 20px;
                  background: #003087;
                  color: white;
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
                  font-size: 14px;
                }
                .print-btn:hover {
                  background: #002060;
                }
              </style>
            </head>
            <body>
              <button class="print-btn" onclick="window.print()">Imprimir</button>
              <div class="content">${escapedText}</div>
            </body>
          </html>
        `);
        newWindow.document.close();
      }
    } catch (error) {
      console.error('Error mostrando CSV:', error);
      this.toast.showError('Error al mostrar el CSV');
    }
  }

  private downloadBase64File(base64Data: string, mimeType: string, fileName: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error descargando archivo:', error);
      this.toast.showError('Error al descargar el archivo');
    }
  }

  onClear(): void {
    this.form.reset();
    this.selectedCompania.set(null);
    this.selectedEmpresaDesde.set(null);
    this.selectedEmpresaHasta.set(null);
  }

  goBack(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
