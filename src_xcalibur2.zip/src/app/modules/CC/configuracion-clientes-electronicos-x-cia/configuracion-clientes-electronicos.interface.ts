export interface CompaniaRecord {
  cia: number;
  'nombre-cia': string;
}

export interface ConfiguracionClienteElectronicoRecord {
  'codigo-config': string;
  cia: number;
  'nombre-cia': string;
  'cliente-electronico': boolean;
  'habilitado': boolean;
  'email-notificacion': string;
  'frecuencia-envio': string;
  'formato-factura': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
}

export interface CompaniasResponse {
  dsRespuesta?: {
    tgecias: CompaniaRecord[];
  };
}

export interface ConfiguracionesResponse {
  dsRespuesta?: {
    tconfig: ConfiguracionClienteElectronicoRecord[];
  };
}
