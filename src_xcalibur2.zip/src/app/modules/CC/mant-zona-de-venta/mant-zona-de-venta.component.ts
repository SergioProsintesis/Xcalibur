import { Component, inject, signal, OnInit, computed, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { ZonaVentaModalComponent } from '../../../shared/components/zona-venta-modal/zona-venta-modal.component';
import { CompaniaRecord } from '../../../core/interfaces/cc.interface';
import { CCService } from '../../../core/services/cc.service';

export interface ZonaVentaRecord {
  zona: number;
  cia: number;
  'nombre-cia': string;
  'nombre-zon': string;
  'text-zon': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  tparent?: string;
}

@Component({
  selector: 'app-mant-zona-de-venta',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent, ZonaVentaModalComponent],
  templateUrl: './mant-zona-de-venta.component.html',
  styleUrls: ['./mant-zona-de-venta.component.css']
})
export class MantZonaDeVentaComponent implements OnInit {
  private fb = inject(FormBuilder);
  private modalService = inject(ModalService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private ccService = inject(CCService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  zonaVentaForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Zona de Venta`);
  createZonaVentaForm!: FormGroup;
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  zonaSeleccionada = signal<ZonaVentaRecord | null>(null);

  // Control de modales
  showCompaniaModal = signal(false);
  showZonaModal = signal(false);
  showCreateModal = signal(false);
  showReportModal = signal(false);
  zonasDisponibles = signal<ZonaVentaRecord[]>([]);
  reportResponse: any = null;

  ngOnInit() {
    console.log('🔄 MantZonaDeVentaComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    console.log('✅ MantZonaDeVentaComponent inicializado correctamente');
  }

  private initializeForm(): void {
    this.zonaVentaForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      zona: ['', [Validators.required, Validators.min(1)]],
      'nombre-zon': ['', [Validators.required, Validators.minLength(1)]],
      'text-zon': ['']
    });

    this.createZonaVentaForm = this.fb.group({
      zona: ['', [Validators.required, Validators.min(1)]],
      'nombre-zon': ['', [Validators.required, Validators.minLength(1)]],
      'text-zon': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.zonaVentaForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.zonaVentaForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.zonaVentaForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.limpiarZona();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.zonaVentaForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.zonaVentaForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.zonaVentaForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
    this.limpiarZona();
  }

  // ==================== MODAL DE ZONA ====================
  async buscarZona(): Promise<void> {
    const companiaId = this.zonaVentaForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getCEZona(companiaId);
      
      if (response?.dsRespuesta?.tcczona && response.dsRespuesta.tcczona.length > 0) {
        this.zonasDisponibles.set(response.dsRespuesta.tcczona);
        this.showZonaModal.set(true);
      } else {
        this.toastService.showWarning('No se encontraron zonas para esta compañía');
      }
    } catch (error) {
      console.error('Error al buscar zonas:', error);
      this.toastService.showError('Error al buscar zonas');
    } finally {
      this.loadingState.set(false);
    }
  }

  closeZonaModal(): void {
    this.showZonaModal.set(false);
  }
  /** Cargar zonas disponibles */
  async loadZonasDisponibles(): Promise<void> {
    const companiaId = this.zonaVentaForm.get('cia')?.value;
    if (!companiaId) {
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getCEZona(companiaId);
      
      if (response?.dsRespuesta?.tcczonas && response.dsRespuesta.tcczonas.length > 0) {
        this.zonasDisponibles.set(response.dsRespuesta.tcczonas);
        console.log('✅ Zonas de venta recargadas');
      }
    } catch (error) {
      console.error('❌ Error al recargar zonas de venta:', error);
    } finally {
      this.loadingState.set(false);
    }
  }

  async onZonaSelected(zona: ZonaVentaRecord): Promise<void> {
    const companiaId = this.zonaVentaForm.get('cia')?.value;
    if (!companiaId) return;

    this.loadingState.set(true);
    try {
      // Load fresh data from server
      const response = await this.ccService.getCEZona(companiaId);
      const zonasActualizadas = response?.dsRespuesta?.tcczonas || [];
      const zonaActualizada = zonasActualizadas.find((z: ZonaVentaRecord) => z.zona === zona.zona);

      if (zonaActualizada) {
        this.zonaSeleccionada.set(zonaActualizada);
        this.zonaVentaForm.patchValue({
          zona: zonaActualizada.zona,
          'nombre-zon': zonaActualizada['nombre-zon'],
          'text-zon': zonaActualizada['text-zon']
        });
        this.toastService.showSuccess(`Zona "${zonaActualizada['nombre-zon']}" cargada`);
      }
    } catch (error) {
      console.error('Error al recargar zona:', error);
      // Fallback to local data
      this.zonaSeleccionada.set(zona);
      this.zonaVentaForm.patchValue({
        zona: zona.zona,
        'nombre-zon': zona['nombre-zon'],
        'text-zon': zona['text-zon']
      });
    } finally {
      this.loadingState.set(false);
      this.closeZonaModal();
    }
  }

  async onZonaLeave(): Promise<void> {
    const companiaId = this.zonaVentaForm.get('cia')?.value;
    const zonaId = this.zonaVentaForm.get('zona')?.value;
    
    if (!companiaId || !zonaId) {
      this.limpiarZona();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveZona(companiaId, zonaId);
      
      if (response?.dsRespuesta?.tcczona && response.dsRespuesta.tcczona.length > 0) {
        const zona = response.dsRespuesta.tcczona[0];
        this.zonaSeleccionada.set(zona);
        this.zonaVentaForm.patchValue({
          'nombre-zon': zona['nombre-zon'],
          'text-zon': zona['text-zon']
        });
      } else {
        this.toastService.showError('Zona no encontrada');
        this.limpiarZona();
      }
    } catch (error) {
      console.error('Error al buscar zona:', error);
      this.toastService.showError('Error al buscar la zona');
      this.limpiarZona();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarZona(): void {
    this.zonaSeleccionada.set(null);
    this.zonaVentaForm.patchValue({
      zona: '',
      'nombre-zon': '',
      'text-zon': ''
    });
  }

  // ==================== ACCIONES CRUD ====================
  async onSubmit(): Promise<void> {
    if (this.zonaVentaForm.invalid) {
      this.toastService.showError('Por favor complete todos los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const formData = this.zonaVentaForm.getRawValue();
      
      const payload = {
        tcczona: [{
          cia: formData.cia,
          zona: formData.zona,
          'nombre-zon': formData['nombre-zon'],
          'text-zon': formData['text-zon']
        }]
      };

      const response = await this.ccService.updateZonaVenta(payload);
      
      if (response?.dsRespuesta?.tcczona && response.dsRespuesta.tcczona.length > 0) {
        const result = response.dsRespuesta.tcczona[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Operación exitosa');
        } else {
          this.toastService.showSuccess('Zona de venta guardada exitosamente');
        }
        this.onClear();
        this.closeZonaModal();
        await this.loadZonasDisponibles();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al guardar:', error);
      this.toastService.showError('Error al guardar la zona de venta');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onDelete(): Promise<void> {
    const companiaId = this.zonaVentaForm.get('cia')?.value;
    const zonaId = this.zonaVentaForm.get('zona')?.value;

    if (!companiaId || !zonaId) {
      this.toastService.showError('Debe seleccionar una compañía y una zona para eliminar');
      return;
    }

    const confirmed = confirm('¿Está seguro de eliminar esta zona de venta?\nEsta acción no se puede deshacer');

    if (!confirmed) return;

    try {
      this.loadingState.set(true);
      const response = await this.ccService.deleteZonaVenta(companiaId, zonaId);
      
      if (response?.dsRespuesta?.tcczona && response.dsRespuesta.tcczona.length > 0) {
        const result = response.dsRespuesta.tcczona[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Registro eliminado');
        } else {
          this.toastService.showSuccess('Zona de venta eliminada exitosamente');
        }
        this.onClear();
        this.closeZonaModal();
        await this.loadZonasDisponibles();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al eliminar:', error);
      this.toastService.showError('Error al eliminar la zona de venta');
    } finally {
      this.loadingState.set(false);
    }
  }

  onClear(): void {
    this.zonaVentaForm.reset();
    this.companiaSeleccionada.set(null);
    this.zonaSeleccionada.set(null);
  }

  // CREATE Modal Methods
  openCreateModal(): void {
    const cia = this.zonaVentaForm.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }
    this.createZonaVentaForm.reset();
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
    this.createZonaVentaForm.reset();
  }

  async onSaveNew(): Promise<void> {
    if (this.createZonaVentaForm.invalid) {
      this.toastService.showError('Por favor complete los campos requeridos');
      return;
    }

    const cia = this.zonaVentaForm.get('cia')?.value;
    if (!cia) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    const formData = {
      cia,
      zona: this.createZonaVentaForm.get('zona')?.value,
      'nombre-zon': this.createZonaVentaForm.get('nombre-zon')?.value,
      'text-zon': this.createZonaVentaForm.get('text-zon')?.value
    };

    this.loadingService.show();
    this.loadingState.set(true);

    try {
      const response = await this.ccService.createZonaVentaAsync(formData);
      this.loadingService.hide();
      this.loadingState.set(false);

      if (response?.dsRespuesta?.tcczona && response.dsRespuesta.tcczona.length > 0) {
        const result = response.dsRespuesta.tcczona[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Zona de venta creada exitosamente');
        } else {
          this.toastService.showSuccess('Zona de venta creada exitosamente');
        }
        this.closeCreateModal();
        
        // Recargar lista y actualizar el formulario principal
        await this.loadZonasDisponibles();
        this.zonaVentaForm.patchValue({
          zona: formData.zona,
          'nombre-zon': formData['nombre-zon'],
          'text-zon': formData['text-zon']
        });
      } else {
        this.toastService.showError('Error: respuesta inválida del servidor');
      }
    } catch (error) {
      this.loadingService.hide();
      this.loadingState.set(false);
      console.error('❌ Error al crear zona de venta:', error);
      this.toastService.showError('Error al crear zona de venta. Verifique los datos e intente nuevamente.');
    }
  }

  goBack(): void {
    this.router.navigate(['/']);
  }

  onGenerateReport(): void {
    const companiaId = this.zonaVentaForm.get('cia')?.value;
    const pcFecha = new Date().toISOString().split('T')[0];

    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía');
      return;
    }

    this.loadingService.show();

    this.ccService.generarReporteZonaVenta(companiaId.toString(), pcFecha).subscribe({
      next: (response) => {
        this.loadingService.hide();
        if (response?.pcArchPDF || response?.pcArchCSV) {
          this.reportResponse = response;
          this.showReportModal.set(true);
        } else {
          this.toastService.showError('No se pudo generar el reporte');
        }
      },
      error: (err) => {
        this.loadingService.hide();
        this.toastService.showError('Error al generar el reporte');
        console.error('Error generarReporteZonaVenta:', err);
      }
    });
  }

  downloadReportPDF(): void {
    if (this.reportResponse?.pcArchPDF) {
      this.downloadFile(this.reportResponse.pcArchPDF, 'ZonaVenta_Reporte.pdf', 'application/pdf');
      this.showReportModal.set(false);
    }
  }

  downloadReportCSV(): void {
    if (this.reportResponse?.pcArchCSV) {
      this.downloadFile(this.reportResponse.pcArchCSV, 'ZonaVenta_Reporte.csv', 'text/csv');
      this.showReportModal.set(false);
    }
  }

  closeReportModal(): void {
    this.showReportModal.set(false);
    this.reportResponse = null;
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    // Mock download - in real app would convert base64 to blob
    const link = document.createElement('a');
    link.href = `data:${mimeType};base64,${base64Data}`;
    link.download = filename;
    link.click();
  }
}
