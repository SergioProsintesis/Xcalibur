import { Component, inject, signal, OnInit, computed, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { CausaSuspensionModalComponent } from '../../../shared/components/causa-suspension-modal/causa-suspension-modal.component';
import { CompaniaRecord } from '../../../core/interfaces/cc.interface';
import { CCService } from '../../../core/services/cc.service';

export interface CausaSuspensionRecord {
  'causa-susp': number;
  cia: number;
  'nombre-cia': string;
  'nombre-caus': string;
  'text-caus': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  tparent?: string;
}

@Component({
  selector: 'app-mant-causa-de-suspension',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent, CausaSuspensionModalComponent],
  templateUrl: './mant-causa-de-suspension.component.html',
  styleUrls: ['./mant-causa-de-suspension.component.css']
})
export class MantCausaDeSuspensionComponent implements OnInit {
  private fb = inject(FormBuilder);
  private modalService = inject(ModalService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private ccService = inject(CCService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  causaSuspensionForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Causa de Suspensión`);
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  causaSuspensionSeleccionada = signal<CausaSuspensionRecord | null>(null);

  // Control de modales
  showCompaniaModal = signal(false);
  showCausaSuspensionModal = signal(false);
  showCreateModal = signal(false);
  showReportModal = signal(false);
  isEditMode = signal(false);
  causasDisponibles = signal<CausaSuspensionRecord[]>([]);
  
  // Datos de reporte
  reportResponse: any = null;
  
  // Formulario de creación
  createCausaForm!: FormGroup;

  ngOnInit() {
    console.log('🔄 MantCausaDeSuspensionComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    console.log('✅ MantCausaDeSuspensionComponent inicializado correctamente');
  }

  private initializeForm(): void {
    this.causaSuspensionForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      'causa-susp': ['', [Validators.required]],
      'nombre-caus': [''],
      'text-caus': ['']
    });

    this.createCausaForm = this.fb.group({
      'causa-susp': ['', [Validators.required, Validators.min(1)]],
      'nombre-caus': ['', [Validators.required]],
      'text-caus': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.causaSuspensionForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.causaSuspensionForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.causaSuspensionForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.limpiarCausaSuspension();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.causaSuspensionForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.causaSuspensionForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.causaSuspensionForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
    this.limpiarCausaSuspension();
  }

  // ==================== MODAL DE CAUSA DE SUSPENSIÓN ====================
  async buscarCausaSuspension(): Promise<void> {
    const companiaId = this.causaSuspensionForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getCECausaSuspension(companiaId);
      
      if (response?.dsRespuesta?.tcccausus && response.dsRespuesta.tcccausus.length > 0) {
        this.causasDisponibles.set(response.dsRespuesta.tcccausus);
        this.showCausaSuspensionModal.set(true);
      } else {
        this.toastService.showWarning('No se encontraron causas de suspensión para esta compañía');
      }
    } catch (error) {
      console.error('Error al buscar causas de suspensión:', error);
      this.toastService.showError('Error al buscar causas de suspensión');
    } finally {
      this.loadingState.set(false);
    }
  }

  // Cargar causas de suspensión SIN abrir modal (solo para recarga de datos)
  private async loadCausasSuspension(): Promise<void> {
    const companiaId = this.causaSuspensionForm.get('cia')?.value;
    
    if (!companiaId) {
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getCECausaSuspension(companiaId);
      
      if (response?.dsRespuesta?.tcccausus && response.dsRespuesta.tcccausus.length > 0) {
        this.causasDisponibles.set(response.dsRespuesta.tcccausus);
        console.log('✅ Causas de suspensión recargadas');
      }
    } catch (error) {
      console.error('Error al recargar causas de suspensión:', error);
    } finally {
      this.loadingState.set(false);
    }
  }

  closeCausaSuspensionModal(): void {
    this.showCausaSuspensionModal.set(false);
  }

  /** Método alias para compatibilidad */
  closeShowModal(): void {
    this.showCausaSuspensionModal.set(false);
  }

  async onCausaSuspensionSelected(causa: CausaSuspensionRecord): Promise<void> {
    const companiaId = this.causaSuspensionForm.get('cia')?.value;
    if (!companiaId) return;

    this.loadingState.set(true);
    try {
      // Load fresh data from server
      const response = await this.ccService.getCECausaSuspension(companiaId);
      const causasActualizadas = response?.dsRespuesta?.tcccausus || [];
      const causaActualizada = causasActualizadas.find((c: CausaSuspensionRecord) => c['causa-susp'] === causa['causa-susp']);

      if (causaActualizada) {
        this.causaSuspensionSeleccionada.set(causaActualizada);
        this.causaSuspensionForm.patchValue({
          'causa-susp': causaActualizada['causa-susp'],
          'nombre-caus': causaActualizada['nombre-caus'],
          'text-caus': causaActualizada['text-caus']
        });
        this.isEditMode.set(true);
        this.toastService.showSuccess(`Causa "${causaActualizada['nombre-caus']}" cargada`);
      }
    } catch (error) {
      console.error('Error al recargar causa de suspensión:', error);
      // Fallback to local data
      this.causaSuspensionSeleccionada.set(causa);
      this.causaSuspensionForm.patchValue({
        'causa-susp': causa['causa-susp'],
        'nombre-caus': causa['nombre-caus'],
        'text-caus': causa['text-caus']
      });
      this.isEditMode.set(true);
    } finally {
      this.loadingState.set(false);
      this.closeCausaSuspensionModal();
    }
  }

  async onCausaSuspensionLeave(): Promise<void> {
    const companiaId = this.causaSuspensionForm.get('cia')?.value;
    const causaId = this.causaSuspensionForm.get('causa-susp')?.value;
    
    if (!companiaId || !causaId) {
      this.limpiarCausaSuspension();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveCausaSuspension(companiaId, causaId);
      
      if (response?.dsRespuesta?.tcccausus && response.dsRespuesta.tcccausus.length > 0) {
        const causa = response.dsRespuesta.tcccausus[0];
        this.causaSuspensionSeleccionada.set(causa);
        this.causaSuspensionForm.patchValue({
          'nombre-caus': causa['nombre-caus'],
          'text-caus': causa['text-caus']
        });
      } else {
        this.toastService.showError('Causa de suspensión no encontrada');
        this.limpiarCausaSuspension();
      }
    } catch (error) {
      console.error('Error al buscar causa de suspensión:', error);
      this.toastService.showError('Error al buscar la causa de suspensión');
      this.limpiarCausaSuspension();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarCausaSuspension(): void {
    this.causaSuspensionSeleccionada.set(null);
    this.isEditMode.set(false);  // Desactivar modo edición
    this.causaSuspensionForm.patchValue({
      'causa-susp': '',
      'nombre-caus': '',
      'text-caus': ''
    });
  }

  // ==================== ACCIONES CRUD ====================
  openCreateModal(): void {
    const companiaId = this.causaSuspensionForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    this.createCausaForm.reset();
    this.isEditMode.set(false);
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
    this.createCausaForm.reset();
  }

  async onCreateSubmit(): Promise<void> {
    if (this.createCausaForm.invalid) {
      this.toastService.showError('Por favor complete los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const companiaId = this.causaSuspensionForm.get('cia')?.value;
      const nombreCompania = this.causaSuspensionForm.get('nombre-cia')?.value;
      const formData = this.createCausaForm.value;
      const auth = this.ccService.getAuthParams();

      const payload = {
        tcccausus: [{
          'Agrega-Caus': '',
          cia: companiaId,
          'causa-susp': formData['causa-susp'],
          'nombre-cia': nombreCompania,
          'date-ctrl': new Date().toISOString().split('T')[0],
          'login-ctrl': auth.pcLogin || 'user',
          'nombre-caus': formData['nombre-caus'],
          'text-caus': formData['text-caus'] || '',
          tparent: auth.pcLogin || 'user'
        }]
      };

      console.log('🔄 Enviando creación:', payload);

      // Usar el mismo método updateCausaSuspension (UPSERT)
      const response = await this.ccService.updateCausaSuspension(payload);

      if (response?.dsRespuesta?.tcccausus && response.dsRespuesta.tcccausus.length > 0) {
        const result = response.dsRespuesta.tcccausus[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Causa de suspensión creada exitosamente');
        } else {
          this.toastService.showSuccess('Causa de suspensión creada exitosamente');
        }
        this.onClear();
        this.closeShowModal();
        await this.loadCausasSuspension();
        this.cdr.detectChanges();
        this.closeCreateModal();
      }
    } catch (error) {
      console.error('Error al crear:', error);
      this.toastService.showError('Error al crear la causa de suspensión');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onSubmit(): Promise<void> {
    if (!this.causaSuspensionForm.get('cia')?.value || !this.causaSuspensionForm.get('causa-susp')?.value) {
      this.toastService.showError('Por favor complete todos los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const formData = this.causaSuspensionForm.getRawValue();
      const auth = this.ccService.getAuthParams();
      
      const payload = {
        tcccausus: [{
          'Agrega-Caus': '',
          'causa-susp': formData['causa-susp'],
          cia: formData.cia,
          'nombre-cia': formData['nombre-cia'],
          'date-ctrl': new Date().toISOString().split('T')[0],
          'login-ctrl': auth.pcLogin || 'user',
          'nombre-caus': formData['nombre-caus'] || '',
          'text-caus': formData['text-caus'] || '',
          tparent: auth.pcLogin || 'user'
        }]
      };

      console.log('🔄 Enviando actualización:', payload);

      const response = await this.ccService.updateCausaSuspension(payload);
      
      if (response?.dsRespuesta?.tcccausus && response.dsRespuesta.tcccausus.length > 0) {
        const result = response.dsRespuesta.tcccausus[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Causa de suspensión actualizada exitosamente');
        } else {
          this.toastService.showSuccess('Causa de suspensión actualizada exitosamente');
        }
        this.onClear();
        this.closeShowModal();
        // Recargar el registro para reflejar cambios
        const updated = {
          'causa-susp': formData['causa-susp'],
          cia: formData.cia,
          'nombre-cia': formData['nombre-cia'],
          'nombre-caus': formData['nombre-caus'],
          'text-caus': formData['text-caus']
        };
        this.causaSuspensionSeleccionada.set(updated);
        this.isEditMode.set(true);
        await this.loadCausasSuspension();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al guardar:', error);
      this.toastService.showError('Error al guardar la causa de suspensión');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onDelete(): Promise<void> {
    const companiaId = this.causaSuspensionForm.get('cia')?.value;
    const causaId = this.causaSuspensionForm.get('causa-susp')?.value;

    if (!companiaId || !causaId) {
      this.toastService.showError('Debe seleccionar una compañía y una causa de suspensión para eliminar');
      return;
    }

    const confirmed = confirm('¿Está seguro de eliminar esta causa de suspensión?\nEsta acción no se puede deshacer');

    if (!confirmed) return;

    try {
      this.loadingState.set(true);
      const response = await this.ccService.deleteCausaSuspension(companiaId, causaId);
      
      if (response?.dsRespuesta?.tcccausus && response.dsRespuesta.tcccausus.length > 0) {
        const result = response.dsRespuesta.tcccausus[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Registro eliminado');
        } else {
          this.toastService.showSuccess('Causa de suspensión eliminada exitosamente');
        }
        this.onClear();
        this.closeShowModal();
        await this.loadCausasSuspension();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al eliminar:', error);
      this.toastService.showError('Error al eliminar la causa de suspensión');
    } finally {
      this.loadingState.set(false);
    }
  }

  onClear(): void {
    this.causaSuspensionForm.reset();
    this.companiaSeleccionada.set(null);
    this.causaSuspensionSeleccionada.set(null);
    this.isEditMode.set(false);
  }

  async onGenerateReport(): Promise<void> {
    const companiaId = this.causaSuspensionForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía para generar reporte');
      return;
    }

    try {
      this.loadingState.set(true);
      const today = new Date();
      const pcFecha = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      
      // Usar endpoint específico Getcc2003 para Causa de Suspensión
      const response = await this.ccService.generarReporteCausaSuspension(
        companiaId.toString(),
        pcFecha
      ).toPromise();
      
      // Acceder a response.response porque la API devuelve estructura anidada
      const reportData = response?.response || response;
      
      if (reportData?.pcArchPDF || reportData?.pcArchCSV) {
        this.reportResponse = reportData;
        this.showReportModal.set(true);
      } else {
        console.error('Estructura de respuesta inesperada:', response);
        this.toastService.showError('No se pudo generar el reporte');
      }
    } catch (error) {
      console.error('Error generando reporte:', error);
      this.toastService.showError('Error al generar el reporte');
    } finally {
      this.loadingState.set(false);
    }
  }

  downloadReportPDF(): void {
    if (!this.reportResponse?.pcArchPDF) {
      this.toastService.showError('No se pudo generar el reporte PDF');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchPDF, 'reporte-causa-suspension.pdf', 'application/pdf');
    this.toastService.showSuccess('Reporte PDF descargado exitosamente');
    this.showReportModal.set(false);
  }

  downloadReportCSV(): void {
    if (!this.reportResponse?.pcArchCSV) {
      this.toastService.showError('No se pudo generar el reporte CSV');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchCSV, 'reporte-causa-suspension.csv', 'text/csv');
    this.toastService.showSuccess('Reporte CSV descargado exitosamente');
    this.showReportModal.set(false);
  }

  closeReportModal(): void {
    this.showReportModal.set(false);
    this.reportResponse = null;
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error al descargar el archivo:', error);
      this.toastService.showError('Error al descargar el archivo');
    }
  }

  goBack(): void {
    this.router.navigate(['/']);
  }
}
