/**
 * CC0008-CC0012 - Mantenimiento de Tablas Generales (Tablas 1-5)
 * Interfaz para la gestión de tablas dinámicas con soporte para todas las tablas
 */

export interface CompaniaRecord {
  cia: number;
  'nombre-cia': string;
  nit?: string;
  'direc-cia'?: string;
  'telefo-cia'?: string;
}

export interface CompaniaResponse {
  dsRespuesta: {
    tgecias: CompaniaRecord[];
  };
}

// Tabla 1 (CC0008)
export interface CCTabla1Record {
  'codigo-cob1': number;
  cia: number;
  'nombre-cia': string;
  'nombre-cob1': string;
  'text-cob1': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'Agrega-Tabl'?: string;
  tparent?: string;
}

// Tabla 2 (CC0009)
export interface CCTabla2Record {
  'codigo-cob2': number;
  cia: number;
  'nombre-cia': string;
  'nombre-cob2': string;
  'text-cob2': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'Agrega-Tabl'?: string;
  tparent?: string;
}

// Tabla 3 (CC0010)
export interface CCTabla3Record {
  'codigo-cob3': number;
  cia: number;
  'nombre-cia': string;
  'nombre-cob3': string;
  'text-cob3': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'Agrega-Tabl'?: string;
  tparent?: string;
}

// Tabla 4 (CC0011)
export interface CCTabla4Record {
  'codigo-cob4': number;
  cia: number;
  'nombre-cia': string;
  'nombre-cob4': string;
  'text-cob4': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'Agrega-Tabl'?: string;
  tparent?: string;
}

// Tabla 5 (CC0012)
export interface CCTabla5Record {
  'codigo-cob5': number;
  cia: number;
  'nombre-cia': string;
  'nombre-cob5': string;
  'text-cob5': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'Agrega-Tabl'?: string;
  tparent?: string;
}

// Tipo union para soportar todas las tablas
export type TablaGenericRecord = CCTabla1Record | CCTabla2Record | CCTabla3Record | CCTabla4Record | CCTabla5Record;

export interface TablaResponse<T> {
  dsRespuesta: {
    [key: string]: T[];
  };
}

export interface TablaDefinition {
  numero: number;
  nombre: string;
  cc: string;
  descripcion: string;
  codigoField: string;
  nombreField: string;
  textField: string;
  getEndpoint: string;
  leaveEndpoint: string;
  updateEndpoint: string;
  deleteEndpoint: string;
  dataKey: string;
}

export const TABLA_DEFINITIONS: TablaDefinition[] = [
  {
    numero: 1,
    nombre: 'Tabla 1',
    cc: 'CC0008',
    descripcion: 'Line of Services',
    codigoField: 'codigo-cob1',
    nombreField: 'nombre-cob1',
    textField: 'text-cob1',
    getEndpoint: 'GetCECctabla1_cc0008',
    leaveEndpoint: 'GetLeaveCodigoCob1_cc0008',
    updateEndpoint: 'Updatecctabla1_cc0008',
    deleteEndpoint: 'DelCctabla1_cc0008',
    dataKey: 'tcctabla1'
  },
  {
    numero: 2,
    nombre: 'Tabla 2',
    cc: 'CC0009',
    descripcion: 'Subline of',
    codigoField: 'codigo-cob2',
    nombreField: 'nombre-cob2',
    textField: 'text-cob2',
    getEndpoint: 'GetCECctabla2_CC0009',
    leaveEndpoint: 'GetLeaveCodigoCob2_CC0009',
    updateEndpoint: 'Updatecctabla2_CC0009',
    deleteEndpoint: 'DelCctabla2_CC0009',
    dataKey: 'tcctabla2'
  },
  {
    numero: 3,
    nombre: 'Tabla 3',
    cc: 'CC0010',
    descripcion: 'Product Group',
    codigoField: 'codigo-cob3',
    nombreField: 'nombre-cob3',
    textField: 'text-cob3',
    getEndpoint: 'GetCECctabla3_cc0010',
    leaveEndpoint: 'GetLeaveCodigoCob3_cc0010',
    updateEndpoint: 'Updatecctabla3_cc0010',
    deleteEndpoint: 'DelCctabla3_cc0010',
    dataKey: 'tcctabla3'
  },
  {
    numero: 4,
    nombre: 'Tabla 4',
    cc: 'CC0011',
    descripcion: 'Affinity',
    codigoField: 'codigo-cob4',
    nombreField: 'nombre-cob4',
    textField: 'text-cob4',
    getEndpoint: 'GetCECctabla4_cc0011',
    leaveEndpoint: 'GetLeaveCodigoCob4_cc0011',
    updateEndpoint: 'Updatecctabla4_cc0011',
    deleteEndpoint: 'DelCctabla4_cc0011',
    dataKey: 'tcctabla4'
  },
  {
    numero: 5,
    nombre: 'Tabla 5',
    cc: 'CC0012',
    descripcion: 'Nombre Tabla 5',
    codigoField: 'codigo-cob5',
    nombreField: 'nombre-cob5',
    textField: 'text-cob5',
    getEndpoint: 'GetCEcctabla5_CC0012',
    leaveEndpoint: 'GetLeaveCodigoCob4_CC0012',
    updateEndpoint: 'Updatecctabla5_CC0012',
    deleteEndpoint: 'Delcctabla5_CC0012',
    dataKey: 'tcctabla5'
  }
];
