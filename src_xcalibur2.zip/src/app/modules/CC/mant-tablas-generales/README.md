# Documentación: Componente Mantenimiento de Tablas Generales (1-5)

## Resumen Ejecutivo

Se ha creado exitosamente el componente **Mantenimiento de Tablas Generales** que permite gestionar de forma centralizada las 5 tablas de cuentas por cobrar (CC0008-CC0012).

## Archivos Creados

```
src/app/modules/CC/mant-tablas-generales/
├── mant-tablas-generales.component.ts       (Componente principal)
├── mant-tablas-generales.component.html     (Template HTML)
├── mant-tablas-generales.component.css      (Estilos)
├── mant-tablas-generales.service.ts         (Servicio de API)
└── mant-tablas-generales.interface.ts       (Interfaces TypeScript)
```

## Funcionalidades Principales

### 1. **Selector Dinámico de Tablas**
El usuario puede seleccionar entre 5 tablas disponibles:
- **Tabla 1** (CC0008): Tabla Común Uno
- **Tabla 2** (CC0009): Tabla Común Dos
- **Tabla 3** (CC0010): Tabla Común Tres
- **Tabla 4** (CC0011): Tabla Común Cuatro
- **Tabla 5** (CC0012): Tabla Común Cinco

### 2. **Modal de Compañía**
- Permite seleccionar una compañía
- Carga datos de compañía automáticamente
- Valida la selección con evento Leave

### 3. **Campos Dinámicos**
Al cambiar de tabla, los campos se ajustan automáticamente:
- **Código**: número de identificación único (1-5 según tabla)
- **Nombre**: descripción del registro
- **Comentario**: texto adicional

### 4. **Operaciones CRUD**
- ✅ **Crear**: Nuevo registro con validación
- ✅ **Leer**: Carga y visualización de registros
- ✅ **Actualizar**: Modificación de registros existentes
- ✅ **Eliminar**: Eliminación con confirmación

### 5. **Interfaz Moderna**
- Diseño responsive
- Modal para crear nuevos registros
- Tabla interactiva de registros disponibles
- Validaciones en tiempo real
- Mensajes de éxito/error con Toast

## Endpoints Utilizados

### Tabla 1 (CC0008)
```
GET: GetCECctabla1_cc0008          → Obtener registros
GET: GetLeaveCodigoCob1_cc0008     → Validar código
PUT: Updatecctabla1_cc0008         → Crear/Actualizar
DEL: DelCctabla1_cc0008            → Eliminar
```

### Tabla 2 (CC0009)
```
GET: GetCECctabla2_CC0009          → Obtener registros
GET: GetLeaveCodigoCob2_CC0009     → Validar código
PUT: Updatecctabla2_CC0009         → Crear/Actualizar
DEL: DelCctabla2_CC0009            → Eliminar
```

### Tabla 3 (CC0010)
```
GET: GetCECctabla3_cc0010          → Obtener registros
GET: GetLeaveCodigoCob3_cc0010     → Validar código
PUT: Updatecctabla3_cc0010         → Crear/Actualizar
DEL: DelCctabla3_cc0010            → Eliminar
```

### Tabla 4 (CC0011)
```
GET: GetCECctabla4_cc0011          → Obtener registros
GET: GetLeaveCodigoCob4_cc0011     → Validar código
PUT: Updatecctabla4_cc0011         → Crear/Actualizar
DEL: DelCctabla4_cc0011            → Eliminar
```

### Tabla 5 (CC0012)
```
GET: GetCEcctabla5_CC0012          → Obtener registros
GET: GetLeaveCodigoCob4_CC0012     → Validar código
PUT: Updatecctabla5_CC0012         → Crear/Actualizar
DEL: Delcctabla5_CC0012            → Eliminar
```

## Rutas Configuradas

### En `app.routes.ts`:
```typescript
{ 
  path: 'cuentas-por-cobrar/mant-tablas-generales', 
  component: MantTablasGeneralesComponent 
}
```

**URL de acceso**: `/cuentas-por-cobrar/mant-tablas-generales`

## Estructura de Datos

### Interfaces Principales

#### TablaDefinition
Define la configuración para cada tabla:
```typescript
interface TablaDefinition {
  numero: number;              // 1-5
  nombre: string;              // "Tabla 1", etc
  cc: string;                  // "CC0008", etc
  codigoField: string;         // "codigo-cob1", etc
  nombreField: string;         // "nombre-cob1", etc
  textField: string;           // "text-cob1", etc
  getEndpoint: string;         // Endpoint GET
  leaveEndpoint: string;       // Endpoint validación
  updateEndpoint: string;      // Endpoint PUT
  deleteEndpoint: string;      // Endpoint DELETE
  dataKey: string;             // "tcctabla1", etc
}
```

#### Registros de Tabla
Cada tabla tiene su interfaz específica (CCTabla1Record, CCTabla2Record, etc.) con campos:
- `codigo-cob[N]`: Código único
- `cia`: ID de compañía
- `nombre-cia`: Nombre de compañía
- `nombre-cob[N]`: Nombre del registro
- `text-cob[N]`: Comentario/descripción
- `date-ctrl`: Fecha de control
- `login-ctrl`: Usuario que modificó
- `tparent`: Usuario propietario

## Componentes Relacionados

### Modales Utilizados
- **CompaniaModalComponent**: Para seleccionar compañía

### Servicios Inyectados
- **MantTablasGeneralesService**: Llamadas API
- **FormBuilder**: Construcción de formularios
- **ToastService**: Notificaciones
- **LoadingService**: Estado de carga
- **ProgramContextService**: Contexto de programa
- **AuthService**: Datos de autenticación
- **Router**: Navegación

## Validaciones Implementadas

✅ **Compañía**: Requerida, valor mínimo 1
✅ **Tabla**: Requerida, selección obligatoria
✅ **Código**: Requerido, valor mínimo 1
✅ **Nombre**: Requerido para crear/actualizar
✅ **Comentario**: Opcional

## Estados y Flujos

### Flujo de Consulta
1. Seleccionar compañía → Load compañía y campos
2. Seleccionar tabla → Cargar lista de registros
3. Buscar registro → Modal con tabla de registros
4. Hacer clic en registro → Cargar datos en formulario

### Flujo de Creación
1. Seleccionar compañía y tabla
2. Hacer clic en "Nuevo"
3. Completar formulario modal
4. Guardar → Actualizar lista
5. Confirmación con Toast

### Flujo de Actualización
1. Seleccionar registro existente
2. Modificar campos
3. Guardar → Validar cambios
4. Confirmación con Toast

### Flujo de Eliminación
1. Seleccionar registro
2. Hacer clic en "Eliminar"
3. Confirmar en dialog
4. Eliminar → Actualizar lista
5. Confirmación con Toast

## Estilos Aplicados

El componente utiliza un diseño moderno con:
- Gradientes en headers
- Sombras suaves
- Transiciones suaves
- Colores corporativos (Púrpura #667eea)
- Diseño responsivo (mobile, tablet, desktop)
- Iconos SVG integrados

## Cómo Usar el Componente

### Acceso desde Menú
El componente se accede a través de:
```
Cuentas x Cobrar → Procesos Eventuales → Mant. Tablas Generales
```
(Nota: El menú se configura en la base de datos)

### Acceso Directo por URL
```
http://localhost:4200/cuentas-por-cobrar/mant-tablas-generales
```

### Flujo Básico
1. **Seleccionar Compañía**: Hacer clic en el ícono de búsqueda
2. **Seleccionar Tabla**: Elegir tabla 1-5 del dropdown
3. **Buscar Registro**: Hacer clic en el ícono de búsqueda (opcional)
4. **Modificar o Crear**: Editar campos y guardar

## Mensajes de Usuario

### Éxito
- "Registro guardado exitosamente"
- "Registro eliminado exitosamente"
- "Registro creado exitosamente"

### Error
- "Error al cargar los registros de la tabla"
- "Error al guardar el registro"
- "Error al eliminar el registro"

### Advertencia
- "Seleccione una compañía primero"
- "Seleccione una tabla primero"
- "Por favor complete los campos requeridos"

## Notas Técnicas

### State Management
- Uso de **Angular Signals** para reactividad
- `signal()` para estado observable
- `computed()` para valores derivados

### Validación de Formularios
- Reactive Forms con `FormBuilder`
- Validadores: `required`, `min`
- Estados dirty/touched para mostrar errores

### Manejo Asincrónico
- Promises para operaciones async
- Try-catch para manejo de errores
- Loading state durante operaciones

### Seguridad
- Autenticación requerida (guard)
- Parámetros de token en todas las peticiones
- Validación de datos en cliente

## Mantenimiento Futuro

### Posibles Mejoras
1. Agregar paginación a tabla de registros
2. Filtro avanzado por fecha o usuario
3. Exportación a Excel
4. Búsqueda en cliente (client-side)
5. Caching de datos de compañías
6. Soporte offline
7. Historial de cambios (auditoría)

### Cambios Esperados
Si se agregan nuevas tablas:
1. Agregar interfaz en `.interface.ts`
2. Agregar definición en `TABLA_DEFINITIONS`
3. Agregar métodos en `.service.ts`
4. El componente funcionará automáticamente

## Testeo

### Casos de Prueba Principales
- [ ] Seleccionar compañía válida
- [ ] Cambiar entre tablas
- [ ] Crear nuevo registro
- [ ] Editar registro existente
- [ ] Eliminar registro con confirmación
- [ ] Validaciones de campos requeridos
- [ ] Manejo de errores de API
- [ ] Responsividad en móvil

## Soporte y Contacto

Para reportar problemas o solicitar cambios, contactar al equipo de desarrollo.

---

**Fecha de Creación**: 2025-01-21
**Versión**: 1.0
**Estado**: Producción
