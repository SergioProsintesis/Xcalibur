import { Component, inject, signal, OnInit, computed, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CCService } from '../../../core/services/cc.service';
import { MantTablasGeneralesService } from './mant-tablas-generales.service';
import { TablaGenericRecord, CompaniaRecord, TABLA_DEFINITIONS, TablaDefinition } from './mant-tablas-generales.interface';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';

// Force recompilation with updated colors and styles
@Component({
  selector: 'app-mant-tablas-generales',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent],
  templateUrl: './mant-tablas-generales.component.html',
  styleUrls: ['./mant-tablas-generales.component.css']
})
export class MantTablasGeneralesComponent implements OnInit {
  private fb = inject(FormBuilder);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private tablasService = inject(MantTablasGeneralesService);
  private ccService = inject(CCService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  // Formularios reactivos
  tablaForm!: FormGroup;
  createTablaForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Tablas Generales (1-5)`);
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  tablaSeleccionada = signal<TablaGenericRecord | null>(null);
  selectedTableNumber = signal<number | null>(null);
  selectedTableDefinition = signal<TablaDefinition | null>(null);

  // Control de modales
  showCompaniaModal = signal(false);
  showCreateModal = signal(false);
  showRegistroModal = signal(false);
  showTablaModal = signal(false);
  showTablaCodeModal = signal(false);
  showReportModal = signal(false);
  isEditMode = signal(false);
  registrosDisponibles = signal<TablaGenericRecord[]>([]);
  tablasDisponibles = signal<TablaGenericRecord[]>([]);
  tablaCodeRecords = signal<TablaGenericRecord[]>([]);
  
  // Datos de reporte
  reportResponse: any = null;

  ngOnInit() {
    console.log('🔄 MantTablasGeneralesComponent inicializado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
  }

  private initializeForm(): void {
    this.tablaForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      'tabla-numero': ['', [Validators.required]],
      'tabla-codigo': ['', [Validators.required, Validators.min(1)]],
      'nombre': ['', [Validators.required]],
      'comentario': []
    });

    this.createTablaForm = this.fb.group({
      codigo: ['', [Validators.required, Validators.min(1)]],
      nombre: ['', [Validators.required]],
      comentario: ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.tablaForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.tablaForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaLeave(): void {
    const ciaValue = this.tablaForm.get('cia')?.value;
    
    if (!ciaValue) {
      return;
    }

    this.loadingState.set(true);
    this.ccService.validateCompania(ciaValue.toString()).subscribe({
      next: (compania) => {
        this.loadingState.set(false);
        if (compania) {
          this.companiaSeleccionada.set(compania);
          // Habilitar temporalmente el campo para actualizar su valor
          const nombreCiaControl = this.tablaForm.get('nombre-cia');
          if (nombreCiaControl?.disabled) {
            nombreCiaControl.enable();
            nombreCiaControl.patchValue(compania['nombre-cia']);
            nombreCiaControl.disable();
          } else {
            nombreCiaControl?.patchValue(compania['nombre-cia']);
          }
          // Cargar registros después de validar la compañía
          this.loadRegistros();
        } else {
          this.toastService.showWarning('Compañía no encontrada');
          const nombreCiaControl = this.tablaForm.get('nombre-cia');
          if (nombreCiaControl?.disabled) {
            nombreCiaControl.enable();
            nombreCiaControl.patchValue('');
            nombreCiaControl.disable();
          } else {
            nombreCiaControl?.patchValue('');
          }
          this.tablaForm.patchValue({
            'tabla-codigo': '',
            'nombre': '',
            'comentario': ''
          });
          this.companiaSeleccionada.set(null);
        }
      },
      error: (err) => {
        this.loadingState.set(false);
        console.error('❌ Error validando compañía:', err);
        this.toastService.showError('Error al validar compañía');
      }
    });
  }

  async onTablaCodigoLeave(): Promise<void> {
    const tableNumber = this.selectedTableNumber();
    const cia = this.tablaForm.get('cia')?.value;
    const tablaCodigoValue = this.tablaForm.get('tabla-codigo')?.value;

    if (!tableNumber || !cia || !tablaCodigoValue) {
      return;
    }

    try {
      this.loadingState.set(true);
      const definition = this.selectedTableDefinition();
      
      if (!definition) {
        this.toastService.showError('Tabla no definida');
        return;
      }

      // Usar el servicio para obtener el registro específico
      const registros = await this.tablasService.getTablas(tableNumber, cia);
      
      // Buscar el registro que coincida con el código ingresado
      const registroEncontrado = registros.find(
        reg => (reg as any)[definition.codigoField].toString() === tablaCodigoValue.toString()
      );

      if (registroEncontrado) {
        console.log('✅ Registro encontrado:', registroEncontrado);
        this.tablaSeleccionada.set(registroEncontrado);
        
        // Llenar el formulario con los datos del registro
        this.tablaForm.patchValue({
          'nombre': (registroEncontrado as any)[definition.nombreField],
          'comentario': (registroEncontrado as any)[definition.textField] || ''
        });
        
        this.isEditMode.set(true);
      } else {
        console.warn('⚠️ Registro no encontrado para código:', tablaCodigoValue);
        this.toastService.showWarning('Registro no encontrado');
        this.tablaSeleccionada.set(null);
        this.tablaForm.patchValue({
          'nombre': '',
          'comentario': ''
        });
      }
    } catch (error) {
      console.error('❌ Error en onTablaCodigoLeave:', error);
      this.toastService.showError('Error al buscar el registro');
    } finally {
      this.loadingState.set(false);
    }
  }

  onCompaniaSeleccionada(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.tablaForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.showCompaniaModal.set(false);
  }

  // ==================== BUSCAR REGISTROS ====================
  async buscarRegistros(): Promise<void> {
    await this.loadRegistros();
    this.cdr.detectChanges();
  }

  // ==================== ABRIR MODAL CREAR ====================
  abrirCrearModal(): void {
    this.isEditMode.set(false);
    this.createTablaForm.reset({
      codigo: '',
      nombre: '',
      comentario: ''
    });
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
    this.isEditMode.set(false);
    this.createTablaForm.reset();
  }

  // ==================== LIMPIAR FORMULARIO ====================
  limpiar(): void {
    this.tablaForm.patchValue({
      'tabla-numero': '',
      'cia': '',
      'nombre-cia': '',
      'nombre': '',
      'comentario': ''
    });
    this.selectedTableNumber.set(null);
    this.selectedTableDefinition.set(null);
    this.registrosDisponibles.set([]);
    this.createTablaForm.reset();
    this.isEditMode.set(false);
  }

  // ==================== OBTER LABELS DINÁMICOS ====================
  getNombreFieldLabel(): string {
    const definition = this.selectedTableDefinition();
    if (!definition) return 'Nombre';
    return definition.nombreField.replace('-', ' ').toUpperCase();
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.tablaForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.showCompaniaModal.set(false);
  }

  // ==================== TABLA SELECTION ====================
  onTablaSelectionChange(): void {
    const tableNumberValue = this.tablaForm.get('tabla-numero')?.value;
    const tableNumber = tableNumberValue ? parseInt(tableNumberValue.toString(), 10) : null;

    if (tableNumber) {
      const definition = TABLA_DEFINITIONS.find(t => t.numero === tableNumber);
      this.selectedTableNumber.set(tableNumber);
      this.selectedTableDefinition.set(definition || null);
      
      // Limpiar campos y registros
      this.tablaForm.patchValue({
        'cia': '',
        'nombre-cia': '',
        'tabla-codigo': '',
        'nombre': '',
        'comentario': ''
      });
      
      this.tablaSeleccionada.set(null);
      this.registrosDisponibles.set([]);
      this.tablaCodeRecords.set([]);
      this.isEditMode.set(false);
    } else {
      this.selectedTableDefinition.set(null);
      this.selectedTableNumber.set(null);
    }
  }

  // Alias for HTML template
  onTablaChange(): void {
    this.onTablaSelectionChange();
  }

  // ==================== LOAD REGISTROS ====================
  private async loadRegistros(): Promise<void> {
    const tableNumberValue = this.selectedTableNumber();
    const tableNumber = tableNumberValue ? (typeof tableNumberValue === 'string' ? parseInt(tableNumberValue, 10) : tableNumberValue) : null;
    const cia = this.tablaForm.get('cia')?.value;

    if (!tableNumber || !cia || cia <= 0) {
      return;
    }

    try {
      this.loadingState.set(true);
      const registros = await this.tablasService.getTablas(tableNumber, cia);
      this.registrosDisponibles.set(registros);
      console.log(`✅ Registros cargados para tabla ${tableNumber}: ${registros.length} registros`);
    } catch (error) {
      console.error('Error loading registros:', error);
      this.toastService.showError('Error al cargar los registros de la tabla');
    } finally {
      this.loadingState.set(false);
    }
  }

  // ==================== SELECCIONAR REGISTRO ====================
  seleccionarRegistro(registro: TablaGenericRecord): void {
    this.tablaSeleccionada.set(registro);
    const definition = this.selectedTableDefinition();
    if (!definition) return;

    const codigo = this.getValorRegistro(registro, definition.codigoField);
    const nombre = this.getValorRegistro(registro, definition.nombreField);
    const descripcion = this.getValorRegistro(registro, definition.textField);

    // Cargar los datos en el formulario de creación (modal)
    this.createTablaForm.patchValue({
      'codigo': codigo,
      'nombre': nombre,
      'comentario': descripcion || ''
    });

    this.isEditMode.set(true);
    this.showCreateModal.set(true);
  }

  // Helper para obtener valor dinámico del registro
  private getValorRegistro(registro: any, field: string): any {
    return registro[field];
  }

  // ==================== FORM ACTIONS ====================
  async onSubmit(): Promise<void> {
    if (!this.tablaForm.valid) {
      this.toastService.showWarning('Por favor complete los campos requeridos');
      return;
    }

    const tableNumberValue = this.tablaForm.get('tabla-numero')?.value;
    const tableNumber = tableNumberValue ? parseInt(tableNumberValue.toString(), 10) : null;
    const cia = this.tablaForm.get('cia')?.value;
    const tablaCodigoValue = this.tablaForm.get('tabla-codigo')?.value;
    const nombre = this.tablaForm.get('nombre')?.value;
    const comentario = this.tablaForm.get('comentario')?.value;

    if (!tablaCodigoValue || !nombre) {
      this.toastService.showError('Código y nombre son requeridos');
      return;
    }

    if (!tableNumber || !cia) {
      this.toastService.showError('Seleccione compañía y tabla');
      return;
    }

    try {
      this.loadingState.set(true);
      // Convertir tabla-codigo a número si es necesario
      const codigo = typeof tablaCodigoValue === 'string' ? parseInt(tablaCodigoValue, 10) : tablaCodigoValue;
      await this.tablasService.updateTabla(tableNumber, cia, codigo, nombre, comentario || '');
      this.toastService.showSuccess('Registro guardado exitosamente');
      await this.loadTablas();
      this.cdr.detectChanges();
      this.onClear();
    } catch (error) {
      console.error('Error saving tabla:', error);
      this.toastService.showError('Error al guardar el registro');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onDelete(): Promise<void> {
    if (!this.tablaSeleccionada()) {
      this.toastService.showWarning('Seleccione un registro para eliminar');
      return;
    }

    const definition = this.selectedTableDefinition();
    if (!definition) return;

    const tabla = this.tablaSeleccionada() as any;
    const nombre = tabla[definition.nombreField];

    if (confirm(`¿Está seguro de que desea eliminar: ${nombre}?`)) {
      try {
        this.loadingState.set(true);
        const tableNumberValue = this.tablaForm.get('tabla-numero')?.value;
        const tableNumber = tableNumberValue ? parseInt(tableNumberValue.toString(), 10) : null;
        const cia = this.tablaForm.get('cia')?.value;
        const codigo = tabla[definition.codigoField];

        if (!tableNumber || !cia) {
          this.toastService.showError('Seleccione compañía y tabla');
          return;
        }

        await this.tablasService.deleteTabla(tableNumber, cia, codigo);
        this.toastService.showSuccess('Registro eliminado exitosamente');
        await this.loadTablas();
        this.cdr.detectChanges();
        this.onClear();
      } catch (error) {
        console.error('Error deleting tabla:', error);
        this.toastService.showError('Error al eliminar el registro');
      } finally {
        this.loadingState.set(false);
      }
    }
  }

  onClear(): void {
    this.tablaForm.reset();
    this.companiaSeleccionada.set(null);
    this.tablaSeleccionada.set(null);
    this.registrosDisponibles.set([]);
    this.tablasDisponibles.set([]);
    this.selectedTableDefinition.set(null);
    this.selectedTableNumber.set(null);
    this.isEditMode.set(false);
    this.showCreateModal.set(false);
  }

  openCreateModal(): void {
    const tableNumberValue = this.tablaForm.get('tabla-numero')?.value;
    const tableNumber = tableNumberValue ? parseInt(tableNumberValue.toString(), 10) : null;
    const cia = this.tablaForm.get('cia')?.value;

    if (!cia || cia <= 0) {
      this.toastService.showWarning('Seleccione una compañía primero');
      return;
    }

    if (!tableNumber) {
      this.toastService.showWarning('Seleccione una tabla primero');
      return;
    }

    this.createTablaForm.reset();
    this.isEditMode.set(false);
    this.tablaSeleccionada.set(null);
    this.showCreateModal.set(true);
  }

  async onCreateSubmit(): Promise<void> {
    if (!this.createTablaForm.valid) {
      this.toastService.showWarning('Por favor complete los campos requeridos');
      return;
    }

    const tableNumberValue = this.tablaForm.get('tabla-numero')?.value;
    const tableNumber = tableNumberValue ? parseInt(tableNumberValue.toString(), 10) : null;
    const cia = this.tablaForm.get('cia')?.value;

    if (!tableNumber || !cia) {
      this.toastService.showError('Seleccione compañía y tabla');
      return;
    }

    const formValue = this.createTablaForm.value;

    try {
      this.loadingState.set(true);
      await this.tablasService.updateTabla(
        tableNumber,
        cia,
        formValue.codigo,
        formValue.nombre,
        formValue.comentario || ''
      );
      this.toastService.showSuccess('Registro creado exitosamente');
      this.closeCreateModal();
      await this.loadRegistros();
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Error creating tabla:', error);
      this.toastService.showError('Error al crear el registro');
    } finally {
      this.loadingState.set(false);
    }
  }

  async loadTablas(): Promise<void> {
    await this.loadRegistros();
    this.cdr.detectChanges();
  }

  closeTablaModal(): void {
    this.showTablaModal.set(false);
  }

  onTablaSelected(tabla: TablaGenericRecord): void {
    this.seleccionarRegistro(tabla);
    this.showTablaModal.set(false);
  }

  getTablaDefinitions() {
    return TABLA_DEFINITIONS;
  }

  getTableLabel(tableNumber: number | null): string {
    if (!tableNumber) return 'N/A';
    const definition = TABLA_DEFINITIONS.find(t => t.numero === tableNumber);
    return definition ? `Tabla ${definition.numero}` : 'N/A';
  }

  getTableDescription(tableNumber: number | null): string {
    if (!tableNumber) return 'N/A';
    
    const definition = TABLA_DEFINITIONS.find(t => t.numero === tableNumber);
    return definition ? definition.descripcion : 'N/A';
  }

  buscarTabla(): void {
    this.showTablaModal.set(true);
  }

  // ==================== TABLA CODE MODAL METHODS ====================
  /**
   * Abre el modal para seleccionar el código de tabla
   * Carga los registros de la tabla seleccionada
   */
  async buscarTablaCode(): Promise<void> {
    const tableNumber = this.selectedTableNumber();
    const cia = this.tablaForm.get('cia')?.value;

    if (!tableNumber) {
      this.toastService.showWarning('Seleccione una tabla primero');
      return;
    }

    if (!cia || cia <= 0) {
      this.toastService.showWarning('Seleccione una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      console.log('🔵 [COMPONENT] buscarTablaCode - Tabla:', tableNumber);
      console.log('🔵 [COMPONENT] buscarTablaCode - Compañía:', cia);
      
      const records = await this.tablasService.getTablas(tableNumber, cia);
      
      console.log('🔵 [COMPONENT] buscarTablaCode - Registros recibidos:', records);
      console.log('🔵 [COMPONENT] buscarTablaCode - Cantidad:', records?.length || 0);
      
      this.tablaCodeRecords.set(records);
      this.showTablaCodeModal.set(true);
      
      if (!records || records.length === 0) {
        this.toastService.showWarning('No se encontraron registros para esta tabla y compañía');
      }
    } catch (error) {
      console.error('🔴 [COMPONENT] buscarTablaCode - Error:', error);
      this.toastService.showError('Error al cargar los registros de la tabla');
    } finally {
      this.loadingState.set(false);
    }
  }

  /**
   * Cierra el modal de tabla código
   */
  closeTablaCodeModal(): void {
    this.showTablaCodeModal.set(false);
    this.tablaCodeRecords.set([]);
  }

  /**
   * Selecciona un registro del modal de tabla código
   * @param record Registro seleccionado
   */
  selectTablaCode(record: TablaGenericRecord): void {
    const definition = this.selectedTableDefinition();
    if (!definition) return;

    const codigo = this.getCodigoFromRecord(record);
    const nombre = this.getNombreFromRecord(record);
    const comentario = this.getTextoValue(record);

    this.tablaForm.patchValue({
      'tabla-codigo': codigo,
      'nombre': nombre,
      'comentario': comentario
    });

    this.closeTablaCodeModal();
  }

  /**
   * Extrae el código de un registro basado en la tabla seleccionada
   * @param record Registro de la tabla
   * @returns Valor del código
   */
  getCodigoFromRecord(record: TablaGenericRecord): string {
    const definition = this.selectedTableDefinition();
    if (!definition) return '';
    return record[definition.codigoField as keyof TablaGenericRecord]?.toString() || '';
  }

  /**
   * Extrae el nombre de un registro basado en la tabla seleccionada
   * @param record Registro de la tabla
   * @returns Valor del nombre
   */
  getNombreFromRecord(record: TablaGenericRecord): string {
    const definition = this.selectedTableDefinition();
    if (!definition) return '';
    return record[definition.nombreField as keyof TablaGenericRecord]?.toString() || '';
  }

  // ==================== HELPER METHODS ====================
  getCodigoFieldLabel(): string {
    const definition = this.selectedTableDefinition();
    if (!definition) return 'Código';
    
    switch (definition.numero) {
      case 1:
        return 'Código 1';
      case 2:
        return 'Código 2';
      case 3:
        return 'Código 3';
      case 4:
        return 'Código 4';
      case 5:
        return 'Código 5';
      default:
        return 'Código';
    }
  }

  // ==================== TEMPLATE HELPERS ====================
  /**
   * Obtiene el valor de un campo dinámico de una tabla
   * @param record Registro de la tabla
   * @param fieldName Nombre del campo a obtener
   * @returns Valor del campo
   */
  getFieldValue(record: any, fieldName: string | null | undefined): string {
    if (!fieldName) return '-';
    return record?.[fieldName]?.toString() || '-';
  }

  /**
   * Obtiene el valor de código de una tabla
   * @param record Registro de la tabla
   * @returns Valor del código
   */
  getCodigoValue(record: any): string {
    const fieldName = this.selectedTableDefinition()?.codigoField;
    return this.getFieldValue(record, fieldName);
  }

  /**
   * Obtiene el valor de nombre de una tabla
   * @param record Registro de la tabla
   * @returns Valor del nombre
   */
  getNombreValue(record: any): string {
    const fieldName = this.selectedTableDefinition()?.nombreField;
    return this.getFieldValue(record, fieldName);
  }

  /**
   * Obtiene el valor de comentario de una tabla
   * @param record Registro de la tabla
   * @returns Valor del comentario
   */
  getTextoValue(record: any): string {
    const fieldName = this.selectedTableDefinition()?.textField;
    return this.getFieldValue(record, fieldName);
  }

  /**
   * Alias para obtener comentario (compatible con HTML template)
   */
  getComentarioValue(record: any): string {
    return this.getTextoValue(record);
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }

  isLoading(): boolean {
    return this.loadingState();
  }

  // ==================== REPORTE METHODS ====================
  async onGenerateReport(): Promise<void> {
    const companiaId = this.tablaForm.get('cia')?.value;
    const tableNumber = this.selectedTableNumber();
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía para generar reporte');
      return;
    }

    if (!tableNumber) {
      this.toastService.showError('Debe seleccionar una tabla para generar reporte');
      return;
    }

    try {
      this.loadingState.set(true);
      const today = new Date();
      const pcFecha = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      
      // Seleccionar el servicio correcto según la tabla - usar endpoints específicos
      let response: any;
      switch (tableNumber) {
        case 1:
          response = await this.ccService.generarReporteTabla1(companiaId.toString(), pcFecha).toPromise();
          break;
        case 2:
          response = await this.ccService.generarReporteTabla2(companiaId.toString(), pcFecha).toPromise();
          break;
        case 3:
          response = await this.ccService.generarReporteTabla3(companiaId.toString(), pcFecha).toPromise();
          break;
        case 4:
          response = await this.ccService.generarReporteTabla4(companiaId.toString(), pcFecha).toPromise();
          break;
        case 5:
          response = await this.ccService.generarReporteTabla5(companiaId.toString(), pcFecha).toPromise();
          break;
        default:
          this.toastService.showError('Tabla no soportada');
          return;
      }

      // Acceder a response.response porque la API devuelve estructura anidada
      const reportData = response?.response || response;
      
      if (reportData?.pcArchPDF || reportData?.pcArchCSV) {
        this.reportResponse = reportData;
        this.showReportModal.set(true);
      } else {
        this.toastService.showError('No se pudo generar el reporte');
      }
    } catch (error) {
      console.error('Error generando reporte:', error);
      this.toastService.showError('Error al generar el reporte');
    } finally {
      this.loadingState.set(false);
    }
  }

  downloadReportPDF(): void {
    if (!this.reportResponse?.pcArchPDF) {
      this.toastService.showError('No se pudo generar el reporte PDF');
      return;
    }

    const tableNumber = this.selectedTableNumber();
    const filename = `reporte-tabla-${tableNumber}.pdf`;
    this.downloadFile(this.reportResponse.pcArchPDF, filename, 'application/pdf');
    this.toastService.showSuccess('Reporte PDF descargado exitosamente');
    this.showReportModal.set(false);
  }

  downloadReportCSV(): void {
    if (!this.reportResponse?.pcArchCSV) {
      this.toastService.showError('No se pudo generar el reporte CSV');
      return;
    }

    const tableNumber = this.selectedTableNumber();
    const filename = `reporte-tabla-${tableNumber}.csv`;
    this.downloadFile(this.reportResponse.pcArchCSV, filename, 'text/csv');
    this.toastService.showSuccess('Reporte CSV descargado exitosamente');
    this.showReportModal.set(false);
  }

  closeReportModal(): void {
    this.showReportModal.set(false);
    this.reportResponse = null;
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error al descargar el archivo:', error);
      this.toastService.showError('Error al descargar el archivo');
    }
  }
}
