import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../../../core/services/auth.service';
import { environment } from '../../../../environments/environment';
import {
  CompaniaRecord,
  CompaniaResponse,
  TablaGenericRecord,
  TablaResponse,
  TABLA_DEFINITIONS,
  TablaDefinition
} from './mant-tablas-generales.interface';

@Injectable({
  providedIn: 'root'
})
export class MantTablasGeneralesService {
  private http = inject(HttpClient);
  private authService = inject(AuthService);
  private baseUrl = environment.apiUrl;

  // ==================== COMPAÑÍAS ====================
  async getCompanias(): Promise<CompaniaRecord[]> {
    const user = this.authService.user();
    if (!user) throw new Error('Usuario no autenticado');

    const params = new HttpParams()
      .set('pcLogin', user.pcLogin || '')
      .set('pcSuper', user.pcSuper || '')
      .set('pcToken', user.pcToken || '');

    const response = await firstValueFrom(
      this.http.get<CompanyResponse>(`${this.baseUrl}/GetCECompanias`, { params })
    );

    return response.dsRespuesta?.tgecias || [];
  }

  // ==================== TABLAS DINÁMICAS ====================
  async getTablas(tableNumber: number, cia: number): Promise<TablaGenericRecord[]> {
    const tabla = this.getTablaDefinition(tableNumber);
    if (!tabla) throw new Error(`Tabla ${tableNumber} no está definida`);

    const user = this.authService.user();
    if (!user) throw new Error('Usuario no autenticado');

    const params = new HttpParams()
      .set('pcCompania', cia.toString())
      .set('pcLogin', user.pcLogin || '')
      .set('pcSuper', user.pcSuper || '')
      .set('pcToken', user.pcToken || '');

    const url = `${this.baseUrl}/${tabla.getEndpoint}`;
    console.log('🔵 [DEBUG] getTablas - Tabla:', tabla.numero);
    console.log('🔵 [DEBUG] getTablas - URL:', url);
    console.log('🔵 [DEBUG] getTablas - Params:', {
      pcCompania: cia,
      pcLogin: user.pcLogin,
      pcSuper: user.pcSuper,
      pcToken: user.pcToken ? '***' : ''
    });

    try {
      const response = await firstValueFrom(
        this.http.get<any>(url, { params })
      );
      
      console.log('🟢 [DEBUG] getTablas - Response completo:', response);
      console.log('🟢 [DEBUG] getTablas - dataKey:', tabla.dataKey);
      console.log('🟢 [DEBUG] getTablas - dsRespuesta:', response.dsRespuesta);
      
      const result = response.dsRespuesta?.[tabla.dataKey] || [];
      console.log('🟢 [DEBUG] getTablas - Resultado final:', result);
      
      return result;
    } catch (error) {
      console.error('🔴 [ERROR] getTablas:', error);
      throw error;
    }
  }

  async getTablaDetail(tableNumber: number, cia: number, codigo: number): Promise<TablaGenericRecord | null> {
    const tabla = this.getTablaDefinition(tableNumber);
    if (!tabla) throw new Error(`Tabla ${tableNumber} no está definida`);

    const user = this.authService.user();
    if (!user) throw new Error('Usuario no autenticado');

    const params = new HttpParams()
      .set('pcCompania', cia.toString())
      .set(this.getCodigoParamName(tableNumber), codigo.toString())
      .set('pcLogin', user.pcLogin || '')
      .set('pcSuper', user.pcSuper || '')
      .set('pcToken', user.pcToken || '');

    const response = await firstValueFrom(
      this.http.get<any>(`${this.baseUrl}/${tabla.leaveEndpoint}`, { params })
    );

    const records = response.dsRespuesta?.[tabla.dataKey] || [];
    return records.length > 0 ? records[0] : null;
  }

  async updateTabla(
    tableNumber: number,
    cia: number,
    codigo: number,
    nombre: string,
    texto: string = ''
  ): Promise<TablaGenericRecord> {
    const tabla = this.getTablaDefinition(tableNumber);
    if (!tabla) throw new Error(`Tabla ${tableNumber} no está definida`);

    const payload = this.buildTablaPayload(tableNumber, cia, codigo, nombre, texto);

    const response = await firstValueFrom(
      this.http.put<any>(`${this.baseUrl}/${tabla.updateEndpoint}`, payload)
    );

    const records = response.dsRespuesta?.[tabla.dataKey] || [];
    if (records.length > 0) {
      return records[0];
    }
    throw new Error('No se pudo guardar el registro');
  }

  async deleteTabla(tableNumber: number, cia: number, codigo: number): Promise<void> {
    const tabla = this.getTablaDefinition(tableNumber);
    if (!tabla) throw new Error(`Tabla ${tableNumber} no está definida`);

    const user = this.authService.user();
    if (!user) throw new Error('Usuario no autenticado');

    const params = new HttpParams()
      .set('pcCompania', cia.toString())
      .set(this.getCodigoParamName(tableNumber), codigo.toString())
      .set('pcLogin', user.pcLogin || '')
      .set('pcSuper', user.pcSuper || '')
      .set('pcToken', user.pcToken || '');

    await firstValueFrom(
      this.http.delete(`${this.baseUrl}/${tabla.deleteEndpoint}`, { params })
    );
  }

  // ==================== HELPER METHODS ====================
  private getTablaDefinition(tableNumber: number): TablaDefinition | undefined {
    return TABLA_DEFINITIONS.find(t => t.numero === tableNumber);
  }

  private getCodigoParamName(tableNumber: number): string {
    const tabla = this.getTablaDefinition(tableNumber);
    if (!tabla) return 'pcCodigo';

    switch (tableNumber) {
      case 1:
        return 'pcCodigo1';
      case 2:
        return 'pcCodigo2';
      case 3:
        return 'pcCodigo3';
      case 4:
        return 'pcCodigo4';
      case 5:
        return 'pcCodigo5';
      default:
        return 'pcCodigo';
    }
  }

  private buildTablaPayload(
    tableNumber: number,
    cia: number,
    codigo: number,
    nombre: string,
    texto: string
  ): any {
    const tabla = this.getTablaDefinition(tableNumber);
    if (!tabla) throw new Error(`Tabla ${tableNumber} no está definida`);

    const user = this.authService.user();
    if (!user) throw new Error('Usuario no autenticado');

    const payload: any = {
      [tabla.dataKey]: [
        {
          cia,
          [tabla.codigoField]: codigo,
          [tabla.nombreField]: nombre,
          [tabla.textField]: texto,
          'date-ctrl': new Date().toISOString().split('T')[0],
          'login-ctrl': user.pcLogin,
          tparent: user.pcLogin
        }
      ]
    };

    return payload;
  }
}

interface CompanyResponse {
  dsRespuesta: {
    tgecias: CompaniaRecord[];
  };
}
