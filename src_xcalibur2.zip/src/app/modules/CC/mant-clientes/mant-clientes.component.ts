import { Component, OnInit, signal } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MantClientesService } from './mant-clientes.service';
import { AuthService } from '../../../core/services/auth.service';
import { Company } from './mant-clientes.interface';

@Component({
  selector: 'app-mant-clientes',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './mant-clientes.component.html',
  styleUrl: './mant-clientes.component.css'
})
export class MantClientesComponent implements OnInit {
  form!: FormGroup;
  companies = signal<Company[]>([]);
  isLoading = signal(false);

  constructor(
    private fb: FormBuilder,
    private service: MantClientesService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.loadCompanies();
  }

  private initForm(): void {
    this.form = this.fb.group({
      cia: ['', Validators.required],
      cliente: ['', Validators.required],
      tipo_cliente: ['', Validators.required],
      estado: [false],
      observaciones: ['']
    });
  }

  private async loadCompanies(): Promise<void> {
    try {
      const user = this.authService.user();
      if (user && user.pcLogin && user.pcSuper && user.pcToken) {
        const response = await this.service.getCompanies(user.pcLogin, user.pcSuper, user.pcToken);
        this.companies.set(response.dsRespuesta.tgecias);
      }
    } catch (error) {
      console.error('Error loading companies:', error);
    }
  }

  async onCompanyChange(): Promise<void> {
    try {
      const ciaValue = this.form.get('cia')?.value;
      const user = this.authService.user();
      if (ciaValue && user && user.pcLogin && user.pcSuper && user.pcToken) {
        this.isLoading.set(true);
        const response = await this.service.getLeaveData(ciaValue, user.pcLogin, user.pcSuper, user.pcToken);
        if (response.dsRespuesta.tfaparame.length > 0) {
          const data = response.dsRespuesta.tfaparame[0];
          this.form.patchValue({
            cliente: data.cliente || '',
            tipo_cliente: data.tipo_cliente || '',
            estado: data.estado || false,
            observaciones: data.observaciones || ''
          });
        }
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      this.isLoading.set(false);
    }
  }

  async onSave(): Promise<void> {
    if (this.form.invalid) return;
    try {
      this.isLoading.set(true);
      const formValue = this.form.value;
      const data = {
        cia: parseInt(formValue.cia),
        nombre_cia: this.companies().find(c => c.cia === parseInt(formValue.cia))?.nombre_cia || '',
        cliente: formValue.cliente,
        tipo_cliente: formValue.tipo_cliente,
        estado: formValue.estado,
        observaciones: formValue.observaciones
      };
      await this.service.updateData(data);
      alert('Datos guardados exitosamente');
    } catch (error) {
      console.error('Error saving data:', error);
      alert('Error al guardar');
    } finally {
      this.isLoading.set(false);
    }
  }

  onCancel(): void {
    this.form.reset();
  }
}
