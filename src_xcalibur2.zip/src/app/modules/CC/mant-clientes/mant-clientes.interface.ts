export interface CompanyResponse {
  dsRespuesta: {
    tgecias: Company[];
  };
}

export interface Company {
  cia: number;
  nombre_cia: string;
}

export interface ClientParameter {
  cia: number;
  nombre_cia: string;
  cliente: string;
  tipo_cliente: string;
  estado: boolean;
  observaciones: string;
}

export interface ClientResponse {
  dsRespuesta: {
    tfaparame: ClientParameter[];
  };
}
