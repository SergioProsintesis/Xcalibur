import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { CompanyResponse, ClientParameter, ClientResponse } from './mant-clientes.interface';

@Injectable({
  providedIn: 'root'
})
export class MantClientesService {
  private apiUrl = 'http://184.168.30.44:8810/XcaliburWeb/rest/ServiciosXcaliburWeb';
  loadingState = signal(false);

  constructor(private http: HttpClient) {}

  async getCompanies(pcLogin: string, pcSuper: string, pcToken: string): Promise<CompanyResponse> {
    this.loadingState.set(true);
    try {
      const params = new HttpParams()
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      return await this.http.get<CompanyResponse>(`${this.apiUrl}/GetCECompanias`, { params }).toPromise() as CompanyResponse;
    } finally {
      this.loadingState.set(false);
    }
  }

  async getLeaveData(pcCompania: string, pcLogin: string, pcSuper: string, pcToken: string): Promise<ClientResponse> {
    this.loadingState.set(true);
    try {
      const params = new HttpParams()
        .set('pcCompania', pcCompania)
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      return await this.http.get<ClientResponse>(`${this.apiUrl}/GetLeaveCia_fa0001`, { params }).toPromise() as ClientResponse;
    } finally {
      this.loadingState.set(false);
    }
  }

  async updateData(data: ClientParameter): Promise<ClientResponse> {
    this.loadingState.set(true);
    try {
      const payload = {
        tfaclien: [data]
      };
      return await this.http.put<ClientResponse>(`${this.apiUrl}/Updatefaclien_fa0001`, payload).toPromise() as ClientResponse;
    } finally {
      this.loadingState.set(false);
    }
  }
}
