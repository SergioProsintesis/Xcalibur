import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { CompanyResponse, ReportResponse } from './reporte-ingresos-trimestre.interface';

@Injectable({
  providedIn: 'root'
})
export class ReporteIngresosTrimestresService {
  private apiUrl = 'http://184.168.30.44:8810/XcaliburWeb/rest/ServiciosXcaliburWeb';
  loadingState = signal(false);

  constructor(private http: HttpClient) {}

  async getCompanies(pcLogin: string, pcSuper: string, pcToken: string): Promise<CompanyResponse> {
    this.loadingState.set(true);
    try {
      const params = new HttpParams()
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      return await this.http.get<CompanyResponse>(`${this.apiUrl}/GetCECompanias`, { params }).toPromise() as CompanyResponse;
    } finally {
      this.loadingState.set(false);
    }
  }

  async getReport(cia: string, trimestre: string, año: string, pcLogin: string, pcSuper: string, pcToken: string): Promise<ReportResponse> {
    this.loadingState.set(true);
    try {
      const params = new HttpParams()
        .set('cia', cia)
        .set('trimestre', trimestre)
        .set('año', año)
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      return await this.http.get<ReportResponse>(`${this.apiUrl}/GetReporteARG5014`, { params }).toPromise() as ReportResponse;
    } finally {
      this.loadingState.set(false);
    }
  }
}
