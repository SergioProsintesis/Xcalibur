export interface CompanyResponse {
  dsRespuesta: {
    tgecias: Company[];
  };
}

export interface Company {
  cia: number;
  nombre_cia: string;
}

export interface ReportARG5014 {
  cia: number;
  trimestre: string;
  año: number;
}

export interface ReportResponse {
  dsRespuesta: {
    reportData: any[];
  };
}
