export interface CompaniaRecord {
  cia: number;
  'nombre-cia': string;
}

export interface ObservacionGeneralRecord {
  'codigo-obs': string;
  cia: number;
  'nombre-cia': string;
  'observacion': string;
  'activo': boolean;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
}

export interface CompaniasResponse {
  dsRespuesta?: {
    tgecias: CompaniaRecord[];
  };
}

export interface ObservacionesGeneralesResponse {
  dsRespuesta?: {
    tobsgen: ObservacionGeneralRecord[];
  };
}
