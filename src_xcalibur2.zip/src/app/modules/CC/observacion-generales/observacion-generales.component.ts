import { Component, inject, signal, OnInit, computed, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { ObservacionGeneralesService } from './observacion-generales.service';
import { CompaniaRecord, ObservacionGeneralRecord } from './observacion-generales.interface';

@Component({
  selector: 'app-observacion-generales',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent],
  templateUrl: './observacion-generales.component.html',
  styleUrls: ['./observacion-generales.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ObservacionGeneralesComponent implements OnInit {
  private fb = inject(FormBuilder);
  private modalService = inject(ModalService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private service = inject(ObservacionGeneralesService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  observacionesForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}FA5003 - Observaciones Generales`);
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  observacionesGenerales = signal<ObservacionGeneralRecord[]>([]);
  observacionEditando = signal<ObservacionGeneralRecord | null>(null);

  // Control de modales
  showCompaniaModal = signal(false);
  isEditMode = signal(false);

  ngOnInit() {
    console.log('🔄 ObservacionGeneralesComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    console.log('✅ ObservacionGeneralesComponent inicializado correctamente');
  }

  private initializeForm(): void {
    this.observacionesForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      'codigo-obs': [{ value: '', disabled: true }],
      'observacion': ['', [Validators.required]]
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.observacionesForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.observacionesForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.observacionesForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.loadObservacionesGenerales();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.observacionesForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.service.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.observacionesForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
        this.loadObservacionesGenerales();
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.observacionesGenerales.set([]);
    this.observacionesForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
  }

  // ==================== CARGAR DATOS ====================
  private async loadObservacionesGenerales(): Promise<void> {
    const ciaValue = this.observacionesForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.observacionesGenerales.set([]);
      return;
    }

    try {
      this.loadingState.set(true);
      const observaciones = await this.service.getObservacionesGenerales(ciaValue);
      this.observacionesGenerales.set(observaciones);
    } catch (error) {
      console.error('Error al cargar observaciones:', error);
      this.toastService.showError('Error al cargar las observaciones generales');
      this.observacionesGenerales.set([]);
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  // ==================== EDICIÓN ====================
  onEditar(observacion: ObservacionGeneralRecord): void {
    this.isEditMode.set(true);
    this.observacionEditando.set(observacion);
    this.observacionesForm.patchValue({
      'codigo-obs': observacion['codigo-obs'],
      'observacion': observacion.observacion
    });
    this.cdr.markForCheck();
  }

  onNuevo(): void {
    this.isEditMode.set(false);
    this.observacionEditando.set(null);
    this.observacionesForm.patchValue({
      'codigo-obs': '',
      'observacion': ''
    });
    this.cdr.markForCheck();
  }

  // ==================== ACCIONES ====================
  onLimpiar(): void {
    this.observacionesForm.patchValue({
      'codigo-obs': '',
      'observacion': ''
    });
    this.isEditMode.set(false);
    this.observacionEditando.set(null);
    this.cdr.markForCheck();
  }

  onGuardar(): void {
    if (this.observacionesForm.invalid) {
      this.toastService.showError('Por favor, complete los campos requeridos');
      return;
    }

    const ciaValue = this.observacionesForm.get('cia')?.value;
    const observacionValue = this.observacionesForm.get('observacion')?.value;

    const observacion: ObservacionGeneralRecord = {
      'codigo-obs': this.isEditMode() ? this.observacionEditando()?.['codigo-obs'] || '' : `OBS-${Date.now()}`,
      cia: ciaValue,
      'nombre-cia': this.observacionesForm.get('nombre-cia')?.value,
      observacion: observacionValue,
      activo: true
    };

    this.guardarObservacion(observacion);
  }

  private async guardarObservacion(observacion: ObservacionGeneralRecord): Promise<void> {
    try {
      this.loadingState.set(true);
      await this.service.saveObservacionGeneral(observacion);
      this.toastService.showSuccess(`Observación ${this.isEditMode() ? 'actualizada' : 'creada'} correctamente`);
      this.loadObservacionesGenerales();
      this.onLimpiar();
    } catch (error) {
      console.error('Error al guardar observación:', error);
      this.toastService.showError('Error al guardar la observación');
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  onEliminar(observacion: ObservacionGeneralRecord): void {
    if (confirm('¿Está seguro de que desea eliminar esta observación?')) {
      this.eliminarObservacion(observacion['codigo-obs'], observacion.cia);
    }
  }

  private async eliminarObservacion(codigoObs: string, cia: number): Promise<void> {
    try {
      this.loadingState.set(true);
      await this.service.deleteObservacionGeneral(codigoObs, cia);
      this.toastService.showSuccess('Observación eliminada correctamente');
      this.loadObservacionesGenerales();
    } catch (error) {
      console.error('Error al eliminar observación:', error);
      this.toastService.showError('Error al eliminar la observación');
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  onVolver(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }
}
