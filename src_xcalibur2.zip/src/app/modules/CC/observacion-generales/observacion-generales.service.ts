import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../core/services/auth.service';
import { CompaniasResponse, ObservacionesGeneralesResponse, CompaniaRecord, ObservacionGeneralRecord } from './observacion-generales.interface';

@Injectable({
  providedIn: 'root'
})
export class ObservacionGeneralesService {
  constructor(private http: HttpClient, private auth: AuthService) {}

  /** Obtener parámetros de autenticación */
  private getAuthParams(): { pcLogin: string; pcSuper: string; pcToken: string } {
    const user = this.auth.user();
    return {
      pcLogin: user?.pcLogin || '',
      pcSuper: user?.pcSuper || '',
      pcToken: user?.pcToken || ''
    };
  }

  /** Obtener todas las compañías */
  getCompanias(): Observable<CompaniaRecord[]> {
    const { pcLogin, pcSuper, pcToken } = this.getAuthParams();
    const url = `${environment.apiUrl}/GetCECompanias?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<CompaniasResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tgecias || []),
      catchError(err => {
        console.error('Error getCompanias', err);
        return of([]);
      })
    );
  }

  /** Validar compañía específica (evento Leave) */
  getLeaveCompania(cia: number): Promise<CompaniasResponse> {
    const { pcLogin, pcSuper, pcToken } = this.getAuthParams();
    const url = `${environment.apiUrl}/GetLeaveGEcias?pcCompania=${cia}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return new Promise((resolve, reject) => {
      this.http.get<CompaniasResponse>(url)
        .pipe(
          catchError(err => {
            console.error('Error getLeaveCompania', err);
            reject(err);
            return of({} as CompaniasResponse);
          })
        )
        .subscribe(res => resolve(res));
    });
  }

  /** Obtener observaciones generales de una compañía */
  getObservacionesGenerales(cia: number): Promise<ObservacionGeneralRecord[]> {
    const { pcLogin, pcSuper, pcToken } = this.getAuthParams();
    const url = `${environment.apiUrl}/GetLeaveGEcias?pcCompania=${cia}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return new Promise((resolve, reject) => {
      this.http.get<ObservacionesGeneralesResponse>(url)
        .pipe(
          map(res => res?.dsRespuesta?.tobsgen || []),
          catchError(err => {
            console.error('Error getObservacionesGenerales', err);
            reject(err);
            return of([]);
          })
        )
        .subscribe(res => resolve(res));
    });
  }

  /** Crear o actualizar observación general */
  saveObservacionGeneral(observacion: ObservacionGeneralRecord): Promise<any> {
    const { pcLogin, pcSuper, pcToken } = this.getAuthParams();
    const url = `${environment.apiUrl}/SaveObservacionGeneral`;

    const payload = {
      ...observacion,
      pcLogin,
      pcSuper,
      pcToken
    };

    return new Promise((resolve, reject) => {
      this.http.post(url, payload)
        .pipe(
          catchError(err => {
            console.error('Error saveObservacionGeneral', err);
            reject(err);
            return of(null);
          })
        )
        .subscribe(res => resolve(res));
    });
  }

  /** Eliminar observación general */
  deleteObservacionGeneral(codigoObs: string, cia: number): Promise<any> {
    const { pcLogin, pcSuper, pcToken } = this.getAuthParams();
    const url = `${environment.apiUrl}/DeleteObservacionGeneral`;

    const payload = {
      'codigo-obs': codigoObs,
      cia,
      pcLogin,
      pcSuper,
      pcToken
    };

    return new Promise((resolve, reject) => {
      this.http.post(url, payload)
        .pipe(
          catchError(err => {
            console.error('Error deleteObservacionGeneral', err);
            reject(err);
            return of(null);
          })
        )
        .subscribe(res => resolve(res));
    });
  }
}
