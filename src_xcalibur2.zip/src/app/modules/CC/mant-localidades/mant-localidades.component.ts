import { Component, inject, signal, OnInit, computed, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { LocalidadModalComponent } from '../../../shared/components/localidad-modal/localidad-modal.component';
import { CompaniaRecord } from '../../../core/interfaces/cc.interface';
import { CCService } from '../../../core/services/cc.service';

export interface LocalidadRecord {
  localidad: number;
  cia: number;
  'nombre-cia': string;
  'nombre-loc': string;
  'text-loc': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'Agrega-Loca'?: string;
  tparent?: string;
}

@Component({
  selector: 'app-mant-localidades',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent, LocalidadModalComponent],
  templateUrl: './mant-localidades.component.html',
  styleUrls: ['./mant-localidades.component.css']
})
export class MantLocalidadesComponent implements OnInit {
  private fb = inject(FormBuilder);
  private modalService = inject(ModalService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private ccService = inject(CCService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  localidadForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Localidades`);
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  localidadSeleccionada = signal<LocalidadRecord | null>(null);

  // Control de modales
  showCompaniaModal = signal(false);
  showLocalidadModal = signal(false);
  showCreateModal = signal(false);
  showReportModal = signal(false);
  isEditMode = signal(false);
  localidadesDisponibles = signal<LocalidadRecord[]>([]);
  createLocalidadForm!: FormGroup;
  reportResponse: any = null;

  ngOnInit() {
    console.log('🔄 MantLocalidadesComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    console.log('✅ MantLocalidadesComponent inicializado correctamente');
  }

  private initializeForm(): void {
    this.localidadForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      localidad: ['', [Validators.required]],
      'nombre-loc': [''],
      'text-loc': ['']
    });

    this.createLocalidadForm = this.fb.group({
      localidad: ['', [Validators.required, Validators.min(1)]],
      'nombre-loc': ['', [Validators.required]],
      'text-loc': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.localidadForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.localidadForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.localidadForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.limpiarLocalidad();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.localidadForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.localidadForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.localidadForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
    this.limpiarLocalidad();
  }

  // ==================== MODAL DE LOCALIDAD ====================
  async buscarLocalidad(): Promise<void> {
    const companiaId = this.localidadForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    try {
      this.loadingState.set(true);
      console.log('🔄 Buscando localidades para compañía:', companiaId);
      const response = await this.ccService.getCELocalidad(companiaId.toString());
      
      if (response?.dsRespuesta?.tcclocali && response.dsRespuesta.tcclocali.length > 0) {
        // Filter localidades by company if needed
        const allLocalidades = response.dsRespuesta.tcclocali;
        // Check if localidades have cia field; if so, filter by companiaId
        const filteredLocalidades = allLocalidades.filter((loc: any) => 
          !loc.cia || loc.cia === companiaId || loc.cia.toString() === companiaId.toString()
        );
        
        const localidadesToShow = filteredLocalidades.length > 0 ? filteredLocalidades : allLocalidades;
        
        this.localidadesDisponibles.set(localidadesToShow);
        console.log('✅ Localidades cargadas:', localidadesToShow.length, 'registros');
        this.showLocalidadModal.set(true);
      } else {
        this.toastService.showWarning('No se encontraron localidades');
      }
    } catch (error) {
      console.error('Error al buscar localidades:', error);
      this.toastService.showError('Error al buscar localidades');
    } finally {
      this.loadingState.set(false);
    }
  }

  closeLocalidadModal(): void {
    this.showLocalidadModal.set(false);
  }

  async onLocalidadSelected(localidad: LocalidadRecord): Promise<void> {
    const companiaId = this.localidadForm.get('cia')?.value;
    if (!companiaId) return;

    this.loadingState.set(true);
    try {
      // Load fresh data from server
      const response = await this.ccService.getCELocalidad(companiaId);
      const localidadesActualizadas = response?.dsRespuesta?.tcclocali || [];
      const localidadActualizada = localidadesActualizadas.find((l: LocalidadRecord) => l.localidad === localidad.localidad);

      if (localidadActualizada) {
        this.localidadSeleccionada.set(localidadActualizada);
        this.localidadForm.patchValue({
          localidad: localidadActualizada.localidad,
          'nombre-loc': localidadActualizada['nombre-loc'],
          'text-loc': localidadActualizada['text-loc']
        });
        this.isEditMode.set(true);
        this.toastService.showSuccess(`Localidad "${localidadActualizada['nombre-loc']}" cargada`);
      }
    } catch (error) {
      console.error('Error al recargar localidad:', error);
      // Fallback to local data
      this.localidadSeleccionada.set(localidad);
      this.localidadForm.patchValue({
        localidad: localidad.localidad,
        'nombre-loc': localidad['nombre-loc'],
        'text-loc': localidad['text-loc']
      });
      this.isEditMode.set(true);
    } finally {
      this.loadingState.set(false);
      this.closeLocalidadModal();
    }
  }

  async onLocalidadLeave(): Promise<void> {
    const companiaId = this.localidadForm.get('cia')?.value;
    const localidadId = this.localidadForm.get('localidad')?.value;
    
    if (!companiaId || !localidadId) {
      this.limpiarLocalidad();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.ccService.getLeaveLocalidad(companiaId, localidadId);
      
      if (response?.dsRespuesta?.tcclocali && response.dsRespuesta.tcclocali.length > 0) {
        const localidad = response.dsRespuesta.tcclocali[0];
        this.localidadSeleccionada.set(localidad);
        this.localidadForm.patchValue({
          'nombre-loc': localidad['nombre-loc'],
          'text-loc': localidad['text-loc']
        });
        this.isEditMode.set(true);
      } else {
        this.toastService.showError('Localidad no encontrada');
        this.limpiarLocalidad();
      }
    } catch (error) {
      console.error('Error al buscar localidad:', error);
      this.toastService.showError('Error al buscar la localidad');
      this.limpiarLocalidad();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarLocalidad(): void {
    this.localidadSeleccionada.set(null);
    this.isEditMode.set(false);
    this.localidadForm.patchValue({
      localidad: '',
      'nombre-loc': '',
      'text-loc': ''
    });
  }

  // ==================== ACCIONES CRUD ====================
  openCreateModal(): void {
    const companiaId = this.localidadForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía primero');
      return;
    }

    this.createLocalidadForm.reset();
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
    this.createLocalidadForm.reset();
  }

  async onCreateSubmit(): Promise<void> {
    if (this.createLocalidadForm.invalid) {
      this.toastService.showError('Por favor complete los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const companiaId = this.localidadForm.get('cia')?.value;
      const formData = this.createLocalidadForm.value;

      const payload = {
        tcclocali: [{
          cia: companiaId,
          localidad: formData.localidad,
          'nombre-loc': formData['nombre-loc'],
          'text-loc': formData['text-loc'] || ''
        }]
      };

      const response = await this.ccService.updateLocalidad(payload);

      if (response?.dsRespuesta?.tcclocali && response.dsRespuesta.tcclocali.length > 0) {
        const result = response.dsRespuesta.tcclocali[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Localidad creada exitosamente');
        } else {
          this.toastService.showSuccess('Localidad creada exitosamente');
        }
        this.onClear();
        this.closeLocalidadModal();
        await this.loadLocalidades();
        this.cdr.detectChanges();
        this.closeCreateModal();
      }
    } catch (error) {
      console.error('Error al crear:', error);
      this.toastService.showError('Error al crear la localidad');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onSubmit(): Promise<void> {
    if (!this.localidadForm.get('cia')?.value || !this.localidadForm.get('localidad')?.value) {
      this.toastService.showError('Por favor complete todos los campos requeridos');
      return;
    }

    try {
      this.loadingState.set(true);
      const formData = this.localidadForm.getRawValue();
      
      const payload = {
        tcclocali: [{
          cia: formData.cia,
          localidad: formData.localidad,
          'nombre-loc': formData['nombre-loc'],
          'text-loc': formData['text-loc']
        }]
      };

      const response = await this.ccService.updateLocalidad(payload);
      
      if (response?.dsRespuesta?.tcclocali && response.dsRespuesta.tcclocali.length > 0) {
        const result = response.dsRespuesta.tcclocali[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Localidad actualizada exitosamente');
        } else {
          this.toastService.showSuccess('Localidad actualizada exitosamente');
        }
        this.onClear();
        this.closeLocalidadModal();
        await this.loadLocalidades();
        this.cdr.detectChanges();
        this.isEditMode.set(true);
      }
    } catch (error) {
      console.error('Error al guardar:', error);
      this.toastService.showError('Error al guardar la localidad');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onDelete(): Promise<void> {
    const companiaId = this.localidadForm.get('cia')?.value;
    const localidadId = this.localidadForm.get('localidad')?.value;

    if (!companiaId || !localidadId) {
      this.toastService.showError('Debe seleccionar una compañía y una localidad para eliminar');
      return;
    }

    const confirmed = confirm('¿Está seguro de eliminar esta localidad?\nEsta acción no se puede deshacer');

    if (!confirmed) return;

    try {
      this.loadingState.set(true);
      const response = await this.ccService.deleteLocalidad(companiaId, localidadId);
      
      if (response?.dsRespuesta?.tcclocali && response.dsRespuesta.tcclocali.length > 0) {
        const result = response.dsRespuesta.tcclocali[0];
        if (result.terrores && result.terrores.length > 0) {
          const error = result.terrores[0];
          this.toastService.showSuccess(error.descripcion || 'Registro eliminado');
        } else {
          this.toastService.showSuccess('Localidad eliminada exitosamente');
        this.closeLocalidadModal();
        }
        this.onClear();
        await this.loadLocalidades();
        this.cdr.detectChanges();
      }
    } catch (error) {
      console.error('Error al eliminar:', error);
      this.toastService.showError('Error al eliminar la localidad');
    } finally {
      this.loadingState.set(false);
    }
  }

  private async loadLocalidades(): Promise<void> {
    const companiaId = this.localidadForm.get('cia')?.value;
    
    if (!companiaId) {
      return;
    }

    try {
      const response = await this.ccService.getCELocalidad(companiaId.toString());
      
      if (response?.dsRespuesta?.tcclocali && response.dsRespuesta.tcclocali.length > 0) {
        const allLocalidades = response.dsRespuesta.tcclocali;
        const filteredLocalidades = allLocalidades.filter((loc: any) => 
          !loc.cia || loc.cia === companiaId || loc.cia.toString() === companiaId.toString()
        );
        
        const localidadesToShow = filteredLocalidades.length > 0 ? filteredLocalidades : allLocalidades;
        
        this.localidadesDisponibles.set(localidadesToShow);
        console.log('✅ Localidades recargadas');
      }
    } catch (error) {
      console.error('Error al cargar localidades:', error);
    }
  }

  onClear(): void {
    this.localidadForm.reset();
    this.companiaSeleccionada.set(null);
    this.localidadSeleccionada.set(null);
    this.isEditMode.set(false);
  }

  async onGenerateReport(): Promise<void> {
    const companiaId = this.localidadForm.get('cia')?.value;
    
    if (!companiaId) {
      this.toastService.showError('Debe seleccionar una compañía para generar reporte');
      return;
    }

    try {
      this.loadingState.set(true);
      const today = new Date();
      const pcFecha = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      
      const response = await this.ccService.getReporteLocalidades(
        companiaId.toString(),
        pcFecha
      );
      
      if (!response) {
        this.toastService.showError('No se pudo generar el reporte');
        return;
      }

      // Guardar la respuesta y abrir el modal
      this.reportResponse = response;
      this.showReportModal.set(true);
    } catch (error) {
      console.error('Error generando reporte:', error);
      this.toastService.showError('Error al generar el reporte');
    } finally {
      this.loadingState.set(false);
    }
  }

  downloadReportPDF(): void {
    if (!this.reportResponse?.pcArchPDF) {
      this.toastService.showError('No se pudo generar el reporte PDF');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchPDF, 'reporte-localidades.pdf', 'application/pdf');
    this.toastService.showSuccess('Reporte PDF descargado exitosamente');
    this.showReportModal.set(false);
  }

  downloadReportCSV(): void {
    if (!this.reportResponse?.pcArchCSV) {
      this.toastService.showError('No se pudo generar el reporte CSV');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchCSV, 'reporte-localidades.csv', 'text/csv');
    this.toastService.showSuccess('Reporte CSV descargado exitosamente');
    this.showReportModal.set(false);
  }

  closeReportModal(): void {
    this.showReportModal.set(false);
    this.reportResponse = null;
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error al descargar el archivo:', error);
      this.toastService.showError('Error al descargar el archivo');
    }
  }

  goBack(): void {
    this.router.navigate(['/']);
  }
}
