export interface CompanyResponse {
  dsRespuesta: {
    tgecias: Company[];
  };
}

export interface Company {
  cia: number;
  nombre_cia: string;
}

export interface CostCenter {
  cia: number;
  nombre_cia: string;
  centro: string;
  nombre_centro: string;
}

export interface CostCenterResponse {
  dsRespuesta: {
    tcentros: CostCenter[];
  };
}
