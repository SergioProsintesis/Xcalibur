import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { CompanyResponse, CostCenter, CostCenterResponse } from './mant-centros-costos.interface';

@Injectable({
  providedIn: 'root'
})
export class MantCentrosCostosService {
  private apiUrl = 'http://184.168.30.44:8810/XcaliburWeb/rest/ServiciosXcaliburWeb';
  loadingState = signal(false);

  constructor(private http: HttpClient) {}

  async getCompanies(pcLogin: string, pcSuper: string, pcToken: string): Promise<CompanyResponse> {
    this.loadingState.set(true);
    try {
      const params = new HttpParams()
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      return await this.http.get<CompanyResponse>(`${this.apiUrl}/GetCECompanias`, { params }).toPromise() as CompanyResponse;
    } finally {
      this.loadingState.set(false);
    }
  }

  async getLeaveData(pcCompania: string, pcLogin: string, pcSuper: string, pcToken: string): Promise<CostCenterResponse> {
    this.loadingState.set(true);
    try {
      const params = new HttpParams()
        .set('pcCompania', pcCompania)
        .set('pcLogin', pcLogin)
        .set('pcSuper', pcSuper)
        .set('pcToken', pcToken);
      return await this.http.get<CostCenterResponse>(`${this.apiUrl}/GetLeaveCia_fa5212`, { params }).toPromise() as CostCenterResponse;
    } finally {
      this.loadingState.set(false);
    }
  }

  async updateData(data: CostCenter): Promise<CostCenterResponse> {
    this.loadingState.set(true);
    try {
      const payload = {
        tcentros: [data]
      };
      return await this.http.put<CostCenterResponse>(`${this.apiUrl}/Updatecentros_fa5212`, payload).toPromise() as CostCenterResponse;
    } finally {
      this.loadingState.set(false);
    }
  }
}
