import { Component, OnDestroy, OnInit, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { combineLatest, debounceTime, distinctUntilChanged, filter, startWith, Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';

import { AuthService } from '../../../../core/services/auth.service';
import { ToastService } from '../../../../core/services/toast.service';
import { LoadingService } from '../../../../core/services/loading.service';
import { CCService } from '../../../../core/services/cc.service';
import { ProgramContextService } from '../../../../core/services/program-context.service';
import { CompaniaRecord, ReporteOption, GenerarReporteResponse } from '../../../../core/interfaces/cc.interface';
import { CompaniaModalComponent } from './compania-modal/compania-modal.component';

@Component({
  selector: 'app-reporte-movimiento-mensual',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, CompaniaModalComponent],
  templateUrl: './reporte-movimiento-mensual.component.html',
  styleUrl: './reporte-movimiento-mensual.component.css'
})
export class ReporteMovimientoMensualComponent implements OnInit, OnDestroy {
  private programContext = inject(ProgramContextService);
  
  form: FormGroup;
  isLoading = signal(false);
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Reporte Movimiento Mensual`);
  showCompaniaModal = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  reportesOptions = signal<ReporteOption[]>([]);
  isGeneratingReport = signal(false);
  
  private destroy$ = new Subject<void>();
  private loadingReportes = false;

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
    private loading: LoadingService,
    private ccService: CCService,
    private router: Router
  ) {
    this.form = this.fb.group({
      compania: ['', Validators.required],
      fechaProceso: ['', Validators.required],
      reporte: [{ value: '', disabled: true }, Validators.required]
    });
  }

  ngOnInit(): void {
    // Fecha por defecto: hoy
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    this.form.patchValue({ fechaProceso: `${yyyy}-${mm}-${dd}` });

    // Validación de compañía con backend
    this.form.get('compania')!.valueChanges.pipe(
      takeUntil(this.destroy$),
      debounceTime(400),
      distinctUntilChanged(),
      filter(v => !!v && v.length > 0)
    ).subscribe(value => this.validateCompania(value));

    // Cargar reportes cuando cambien compañía o fecha
    combineLatest([
      this.form.get('compania')!.valueChanges.pipe(startWith(this.form.get('compania')?.value)),
      this.form.get('fechaProceso')!.valueChanges.pipe(startWith(this.form.get('fechaProceso')?.value))
    ]).pipe(
      takeUntil(this.destroy$),
      debounceTime(300),
      filter(([compania, fechaProceso]) => !!(compania && fechaProceso && this.form.get('compania')?.valid && this.form.get('fechaProceso')?.valid))
    ).subscribe(() => this.loadReportesOptions());
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private validateCompania(codigo: string) {
    this.ccService.validateCompania(codigo).subscribe(compania => {
      if (compania) {
        this.selectedCompania.set(compania);
        const ctrl = this.form.get('compania');
        if (ctrl?.hasError('notFound')) {
          const errors = { ...(ctrl.errors || {}) };
          delete errors['notFound'];
          ctrl.setErrors(Object.keys(errors).length ? errors : null);
        }
      } else {
        this.selectedCompania.set(null);
        this.form.get('compania')?.setErrors({ notFound: true });
      }
    });
  }

  private loadReportesOptions() {
    const { compania, fechaProceso } = this.form.value;
    if (!compania || !fechaProceso || this.loadingReportes) {
      this.form.get('reporte')?.disable();
      return;
    }

    this.loadingReportes = true;
    this.ccService.getReportesOptions(compania, fechaProceso, 'cc2202').subscribe({
      next: (reportes) => {
        this.reportesOptions.set(reportes);
        const reporteControl = this.form.get('reporte');
        if (reporteControl) {
          reporteControl.setValue('', { emitEvent: false });
        }
        if (reportes.length > 0) {
          reporteControl?.enable();
        } else {
          reporteControl?.disable();
        }
        this.loadingReportes = false;
      },
      error: (error) => {
        console.error('Error loading reportes:', error);
        this.loadingReportes = false;
        this.form.get('reporte')?.disable();
      }
    });
  }

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.selectedCompania.set(compania);
    this.form.patchValue({ compania: compania.cia.toString() });
    this.showCompaniaModal.set(false);
    this.validateCompania(compania.cia.toString());
  }

  onCloseModal(): void {
    this.showCompaniaModal.set(false);
  }

  onGenerarReporte(formato: 'excel' | 'pdf' | 'pantalla'): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.toast.showWarning('Complete todos los campos obligatorios');
      return;
    }

    const { compania, fechaProceso, reporte } = this.form.value;
    
    this.isGeneratingReport.set(true);
    this.loading.show();
    
    this.ccService.generarReporteGenerico(compania, fechaProceso, reporte, 'Si', 'cc2202').subscribe({
      next: (response) => {
        this.isGeneratingReport.set(false);
        this.loading.hide();
        
        if (response) {
          this.handleReporteGenerated(response, formato);
        } else {
          this.toast.showError('No se pudo generar el reporte');
        }
      },
      error: (err) => {
        this.isGeneratingReport.set(false);
        this.loading.hide();
        console.error('Error generando reporte:', err);
        this.toast.showError('Error al generar el reporte');
      }
    });
  }

  private handleReporteGenerated(response: GenerarReporteResponse['response'], formato: 'excel' | 'pdf' | 'pantalla'): void {
    switch (formato) {
      case 'excel':
        if (response.pcArchCSV) {
          this.downloadExcelFile(response.pcArchCSV);
        } else {
          this.toast.showError('No se pudo obtener el archivo CSV');
          return;
        }
        break;
      case 'pdf':
        if (response.pcArchPDF) {
          this.downloadPdfFile(response.pcArchPDF);
        } else {
          this.toast.showError('No se pudo obtener el archivo PDF');
          return;
        }
        break;
      case 'pantalla':
        if (response.pcArchCSV) {
          this.showReportInModal(response.pcArchCSV);
        } else {
          this.toast.showError('No se pudo obtener los datos para mostrar');
          return;
        }
        break;
    }
    
    const selectedReporte = this.reportesOptions().find(r => r["pcProg-Sel"] === this.form.value.reporte);
    this.toast.showSuccess(`Reporte "${selectedReporte?.["pcNombre-pro"] || 'generado'}" ${formato === 'pantalla' ? 'mostrado' : 'descargado'} exitosamente`);
  }

  private downloadExcelFile(content: string): void {
    try {
      let csvContent: string;
      
      if (this.isBase64(content)) {
        csvContent = atob(content);
      } else {
        csvContent = content;
      }

      const csvWithSemicolons = this.convertToCsvWithSemicolons(csvContent);
      const bom = '\uFEFF';
      const finalContent = bom + csvWithSemicolons;
      
      const selectedReporte = this.reportesOptions().find(r => r["pcProg-Sel"] === this.form.value.reporte);
      const filename = `${selectedReporte?.["pcNombre-pro"] || 'reporte'}_${this.form.value.fechaProceso}.csv`;
      
      const blob = new Blob([finalContent], { type: 'text/csv;charset=utf-8' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
    } catch (error) {
      console.error('Error procesando archivo Excel:', error);
      this.toast.showError('Error al procesar el archivo Excel');
    }
  }

  private convertToCsvWithSemicolons(content: string): string {
    try {
      const lines = content.split(/\r?\n/);
      const convertedLines: string[] = [];

      for (const line of lines) {
        if (line.trim()) {
          let convertedLine = line;
          if (line.includes('\t')) {
            convertedLine = line.split('\t').join(';');
          } else if (line.includes(',') && !line.includes(';')) {
            convertedLine = line.split(',').join(';');
          } else if (line.includes('|')) {
            convertedLine = line.split('|').join(';');
          }
          convertedLines.push(convertedLine);
        }
      }

      return convertedLines.join('\n');
    } catch (error) {
      console.error('Error convirtiendo a CSV:', error);
      return content;
    }
  }

  private downloadPdfFile(content: string): void {
    try {
      const selectedReporte = this.reportesOptions().find(r => r["pcProg-Sel"] === this.form.value.reporte);
      const filename = `${selectedReporte?.["pcNombre-pro"] || 'reporte'}_${this.form.value.fechaProceso}.pdf`;
      
      if (!content || content.trim().length === 0) {
        this.toast.showError('No se recibió contenido para el PDF');
        return;
      }
      
      const cleanContent = content.trim().replace(/\s/g, '');
      
      if (!this.isBase64(cleanContent)) {
        this.toast.showError('El contenido del PDF no es válido');
        return;
      }
      
      this.downloadFile(cleanContent, filename, 'application/pdf');
      
    } catch (error) {
      console.error('Error procesando archivo PDF:', error);
      this.toast.showError('Error al procesar el archivo PDF');
    }
  }

  private downloadFile(base64Data: string, filename: string, mimeType: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);

      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      window.URL.revokeObjectURL(url);

    } catch (error) {
      console.error(`Error al descargar ${filename}:`, error);
      this.toast.showError(`Error al descargar el archivo ${filename}`);
    }
  }

  private escapeHtml(text: string): string {
    const div = document.createElement('div');
    div.textContent = text || '';
    return div.innerHTML;
  }

  private isBase64(str: string): boolean {
    try {
      return btoa(atob(str)) === str;
    } catch (err) {
      return false;
    }
  }

  private showReportInModal(content: string): void {
    try {
      let csvData: string;
      if (this.isBase64(content)) {
        csvData = atob(content);
      } else {
        csvData = content;
      }

      const processedData = this.convertToCsvWithSemicolons(csvData);
      const lines = processedData.split('\n').filter(line => line.trim());
      
      if (lines.length === 0) {
        this.toast.showWarning('No hay datos para mostrar');
        return;
      }

      const headers = lines[0].split(';').map(h => h.trim());
      const rows = lines.slice(1).map(line => line.split(';').map(cell => cell.trim()));

      const newWindow = window.open('', '_blank', 'width=1200,height=800');
      if (newWindow) {
        newWindow.document.write(this.generateInteractiveTableHTML(headers, rows));
        newWindow.document.close();
      }
    } catch (error) {
      console.error('Error mostrando reporte:', error);
      this.toast.showError('Error al procesar los datos para visualización');
    }
  }

  private generateInteractiveTableHTML(headers: string[], rows: string[][]): string {
    const selectedReporte = this.reportesOptions().find(r => r["pcProg-Sel"] === this.form.value.reporte);
    const reportTitle = selectedReporte?.["pcNombre-pro"] || 'Reporte Movimiento Mensual';
    
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>${reportTitle}</title>
        <style>
          * { box-sizing: border-box; }
          body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            margin: 0; 
            padding: 20px; 
            background-color: #f5f5f5;
          }
          
          .container { 
            background: white; 
            border-radius: 8px; 
            padding: 20px; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
          }
          
          .header { 
            text-align: center; 
            margin-bottom: 20px; 
            padding-bottom: 15px;
            border-bottom: 2px solid #003087;
          }
          
          .header h1 { 
            color: #003087; 
            margin: 0; 
            font-size: 1.8rem;
          }
          
          .report-info { 
            display: flex; 
            justify-content: space-between; 
            margin: 15px 0; 
            font-size: 0.9rem; 
            color: #666;
          }
          
          .controls { 
            margin: 20px 0; 
            display: flex; 
            gap: 15px; 
            align-items: center; 
            flex-wrap: wrap;
          }
          
          .search-box { 
            flex: 1; 
            min-width: 200px; 
            padding: 8px 12px; 
            border: 1px solid #ddd; 
            border-radius: 4px; 
            font-size: 14px;
          }
          
          .pagination { 
            display: flex; 
            gap: 5px; 
            align-items: center;
          }
          
          .pagination button { 
            padding: 6px 12px; 
            border: 1px solid #ddd; 
            background: white; 
            cursor: pointer; 
            border-radius: 4px;
          }
          
          .pagination button:hover { background: #f0f0f0; }
          .pagination button:disabled { opacity: 0.5; cursor: not-allowed; }
          .pagination button.active { background: #003087; color: white; }
          
          .table-container { 
            overflow-x: auto; 
            border: 1px solid #ddd; 
            border-radius: 4px;
          }
          
          table { 
            width: 100%; 
            border-collapse: collapse; 
            font-size: 13px;
          }
          
          th { 
            background: #003087; 
            color: white; 
            padding: 12px 8px; 
            text-align: left; 
            font-weight: 600; 
            position: sticky; 
            top: 0; 
            z-index: 10;
            cursor: pointer;
            user-select: none;
          }
          
          th:hover { background: #002066; }
          
          td { 
            padding: 8px; 
            border-bottom: 1px solid #eee;
          }
          
          tbody tr:hover { background: #f8f9fa; }
          tbody tr:nth-child(even) { background: #fafbfc; }
          tbody tr:nth-child(even):hover { background: #f0f1f2; }
          
          .stats { 
            margin: 15px 0; 
            padding: 10px; 
            background: #f8f9fa; 
            border-radius: 4px; 
            font-size: 14px;
          }
          
          .no-results { 
            text-align: center; 
            padding: 40px; 
            color: #666; 
            font-style: italic;
          }
          
          .sort-indicator { 
            margin-left: 5px; 
            opacity: 0.6;
          }
          
          @media (max-width: 768px) {
            .controls { flex-direction: column; align-items: stretch; }
            .search-box { min-width: auto; }
            th, td { padding: 6px 4px; font-size: 12px; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>${reportTitle}</h1>
            <div class="report-info">
              <span><strong>Compañía:</strong> ${this.selectedCompania()?.["nombre-cia"] || this.form.value.compania}</span>
              <span><strong>Fecha:</strong> ${this.form.value.fechaProceso}</span>
              <span><strong>Generado:</strong> ${new Date().toLocaleString()}</span>
            </div>
          </div>
          
          <div class="controls">
            <input type="text" id="searchBox" class="search-box" placeholder="Buscar en todos los campos...">
            <div class="pagination" id="pagination"></div>
          </div>
          
          <div class="stats" id="stats"></div>
          
          <div class="table-container">
            <table id="dataTable">
              <thead>
                <tr>
                  ${headers.map((header, index) => 
                    `<th onclick="sortTable(${index})" title="Hacer clic para ordenar">
                      ${header}
                      <span class="sort-indicator" id="sort-${index}">↕️</span>
                     </th>`
                  ).join('')}
                </tr>
              </thead>
              <tbody id="tableBody">
              </tbody>
            </table>
            <div class="no-results" id="noResults" style="display: none;">
              No se encontraron resultados
            </div>
          </div>
        </div>
        
        <script>
          const originalData = ${JSON.stringify(rows)};
          let currentData = [...originalData];
          let currentPage = 1;
          const rowsPerPage = 50;
          let sortColumn = -1;
          let sortDirection = 'asc';
          
          function renderTable() {
            const tbody = document.getElementById('tableBody');
            const start = (currentPage - 1) * rowsPerPage;
            const end = start + rowsPerPage;
            const pageData = currentData.slice(start, end);
            
            if (pageData.length === 0 && currentData.length > 0) {
              currentPage = 1;
              renderTable();
              return;
            }
            
            tbody.innerHTML = pageData.map(row => 
              '<tr>' + row.map(cell => '<td>' + (cell || '') + '</td>').join('') + '</tr>'
            ).join('');
            
            updateStats();
            updatePagination();
            
            document.getElementById('noResults').style.display = 
              currentData.length === 0 ? 'block' : 'none';
            document.querySelector('.table-container table').style.display = 
              currentData.length === 0 ? 'none' : 'table';
          }
          
          function updateStats() {
            const stats = document.getElementById('stats');
            const total = currentData.length;
            const showing = Math.min(rowsPerPage, total - (currentPage - 1) * rowsPerPage);
            const from = total > 0 ? (currentPage - 1) * rowsPerPage + 1 : 0;
            const to = (currentPage - 1) * rowsPerPage + showing;
            
            stats.textContent = 'Mostrando ' + from + ' a ' + to + ' de ' + total + ' registros';
            if (total !== originalData.length) {
              stats.textContent += ' (filtrado de ' + originalData.length + ' registros totales)';
            }
          }
          
          function updatePagination() {
            const pagination = document.getElementById('pagination');
            const totalPages = Math.ceil(currentData.length / rowsPerPage);
            
            if (totalPages <= 1) {
              pagination.innerHTML = '';
              return;
            }
            
            let html = '';
            html += '<button onclick="goToPage(1)" ' + (currentPage === 1 ? 'disabled' : '') + '>« Primera</button>';
            html += '<button onclick="goToPage(' + (currentPage - 1) + ')" ' + (currentPage === 1 ? 'disabled' : '') + '>‹ Anterior</button>';
            
            let startPage = Math.max(1, currentPage - 2);
            let endPage = Math.min(totalPages, currentPage + 2);
            
            if (startPage > 1) {
              html += '<button onclick="goToPage(1)">1</button>';
              if (startPage > 2) html += '<span>...</span>';
            }
            
            for (let i = startPage; i <= endPage; i++) {
              html += '<button onclick="goToPage(' + i + ')" ' + 
                     (i === currentPage ? 'class="active"' : '') + '>' + i + '</button>';
            }
            
            if (endPage < totalPages) {
              if (endPage < totalPages - 1) html += '<span>...</span>';
              html += '<button onclick="goToPage(' + totalPages + ')">' + totalPages + '</button>';
            }
            
            html += '<button onclick="goToPage(' + (currentPage + 1) + ')" ' + (currentPage === totalPages ? 'disabled' : '') + '>Siguiente ›</button>';
            html += '<button onclick="goToPage(' + totalPages + ')" ' + (currentPage === totalPages ? 'disabled' : '') + '>Última »</button>';
            
            pagination.innerHTML = html;
          }
          
          function goToPage(page) {
            const totalPages = Math.ceil(currentData.length / rowsPerPage);
            if (page >= 1 && page <= totalPages) {
              currentPage = page;
              renderTable();
            }
          }
          
          function filterData() {
            const searchTerm = document.getElementById('searchBox').value.toLowerCase();
            currentData = originalData.filter(row => 
              row.some(cell => cell.toLowerCase().includes(searchTerm))
            );
            currentPage = 1;
            renderTable();
          }
          
          function sortTable(columnIndex) {
            if (sortColumn === columnIndex) {
              sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
            } else {
              sortColumn = columnIndex;
              sortDirection = 'asc';
            }
            
            currentData.sort((a, b) => {
              const aVal = a[columnIndex] || '';
              const bVal = b[columnIndex] || '';
              
              const aNum = parseFloat(aVal.replace(/[^0-9.-]/g, ''));
              const bNum = parseFloat(bVal.replace(/[^0-9.-]/g, ''));
              
              let result;
              if (!isNaN(aNum) && !isNaN(bNum)) {
                result = aNum - bNum;
              } else {
                result = aVal.localeCompare(bVal);
              }
              
              return sortDirection === 'asc' ? result : -result;
            });
            
            document.querySelectorAll('.sort-indicator').forEach(el => el.textContent = '↕️');
            document.getElementById('sort-' + columnIndex).textContent = 
              sortDirection === 'asc' ? '↑' : '↓';
            
            currentPage = 1;
            renderTable();
          }
          
          document.getElementById('searchBox').addEventListener('input', filterData);
          renderTable();
        </script>
      </body>
      </html>
    `;
  }

  onClear(): void {
    this.form.reset();
    this.selectedCompania.set(null);
    this.reportesOptions.set([]);
    
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    this.form.patchValue({ fechaProceso: `${yyyy}-${mm}-${dd}` });
  }

  goBack(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field?.invalid && field?.touched);
  }

  getErrorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (field?.hasError('required')) return 'Campo obligatorio';
    if (field?.hasError('notFound')) return 'Compañía no encontrada';
    return '';
  }

  trackByReporte(index: number, reporte: ReporteOption): string {
    return reporte['pcProg-Sel'];
  }
}
