import { Component, Input, OnDestroy, OnInit, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { combineLatest, debounceTime, distinctUntilChanged, filter, startWith, Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';

import { AuthService } from '../../../../core/services/auth.service';
import { ToastService } from '../../../../core/services/toast.service';
import { LoadingService } from '../../../../core/services/loading.service';
import { ProgramContextService } from '../../../../core/services/program-context.service';
import { CCService } from '../../../../core/services/cc.service';
import { CompaniaRecord, ReporteOption, GenerarReporteResponse } from '../../../../core/interfaces/cc.interface';

@Component({
  selector: 'app-reporte-generico',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './reporte-generico.component.html',
  styleUrls: ['./reporte-generico.component.css']
})
export class ReporteGenericoComponent implements OnInit, OnDestroy {
  @Input() pcPrograma: string = 'cc0047'; // Programa por defecto
  @Input() titulo: string = 'Reporte';
  @Input() mostrarActualiza: boolean = true; // Si mostrar el selector de Actualiza
  @Input() rutaVolver: string = '/cuentas-por-cobrar';

  form: FormGroup;
  searchForm: FormGroup;
  isLoading = signal(false);
  showCompaniaModal = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  reportesOptions = signal<ReporteOption[]>([]);
  isGeneratingReport = signal(false);
  
  // Título concatenado con el código del programa
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}${this.titulo}`);
  
  // Modal properties
  companiaSearch = signal('');
  companiasList = signal<CompaniaRecord[]>([]);
  filteredCompaniasList = signal<CompaniaRecord[]>([]);
  isLoadingCompanias = signal(false);
  
  private destroy$ = new Subject<void>();
  private loadingReportes = false;
  private programContext = inject(ProgramContextService);

  private escapeHtml(text: string): string {
    const map: { [key: string]: string } = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, (char) => map[char]);
  }

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
    private loading: LoadingService,
    private ccService: CCService,
    private router: Router
  ) {
    this.form = this.fb.group({
      compania: ['', Validators.required],
      fechaProceso: ['', Validators.required],
      actualiza: ['Si', Validators.required],
      reporte: [{ value: '', disabled: true }, Validators.required]
    });
    this.searchForm = this.fb.group({
      search: ['']
    });
  }

  ngOnInit(): void {
    // Ocultar campo actualiza si no es necesario
    if (!this.mostrarActualiza) {
      this.form.removeControl('actualiza');
    }

    // Inicializar formulario de búsqueda de compañía
    this.initializeSearchForm();
    this.loadCompanias();

    // Fecha por defecto: hoy
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    this.form.patchValue({ fechaProceso: `${yyyy}-${mm}-${dd}` });

    // Validación de compañía con backend
    this.form.get('compania')!.valueChanges.pipe(
      takeUntil(this.destroy$),
      debounceTime(400),
      distinctUntilChanged(),
      filter(v => !!v && v.length > 0)
    ).subscribe(value => this.validateCompania(value));

    // Cargar reportes cuando cambien compañía, fecha o actualiza
    const observables = [
      this.form.get('compania')!.valueChanges.pipe(startWith(this.form.get('compania')?.value)),
      this.form.get('fechaProceso')!.valueChanges.pipe(startWith(this.form.get('fechaProceso')?.value))
    ];

    if (this.mostrarActualiza) {
      observables.push(this.form.get('actualiza')!.valueChanges.pipe(startWith(this.form.get('actualiza')?.value)));
    }

    combineLatest(observables).pipe(
      takeUntil(this.destroy$),
      debounceTime(300),
      filter(([compania, fechaProceso]) => !!(compania && fechaProceso && this.form.get('compania')?.valid && this.form.get('fechaProceso')?.valid))
    ).subscribe(() => this.loadReportesOptions());
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  goBack(): void {
    this.router.navigate([this.rutaVolver]);
  }

  private validateCompania(codigo: string) {
    this.ccService.validateCompania(codigo).subscribe(compania => {
      if (compania) {
        this.selectedCompania.set(compania);
        const ctrl = this.form.get('compania');
        if (ctrl?.hasError('notFound')) {
          const errors = { ...(ctrl.errors || {}) };
          delete errors['notFound'];
          ctrl.setErrors(Object.keys(errors).length ? errors : null);
        }
      }
    });
  }

  private loadReportesOptions(): void {
    if (this.loadingReportes) return;
    
    const compania = this.form.get('compania')?.value;
    const fecha = this.form.get('fechaProceso')?.value;
    const actualiza = this.mostrarActualiza ? this.form.get('actualiza')?.value : 'Si';

    if (!compania || !fecha) return;

    this.loadingReportes = true;
    this.ccService.getReportesGenerico(compania, fecha, actualiza, this.pcPrograma).subscribe({
      next: (reportes) => {
        this.reportesOptions.set(reportes);
        this.form.get('reporte')?.enable();
        this.form.get('reporte')?.reset('');
        this.loadingReportes = false;
      },
      error: (err) => {
        console.error('Error cargando reportes:', err);
        this.toast.showError('Error al cargar reportes');
        this.reportesOptions.set([]);
        this.form.get('reporte')?.disable();
        this.loadingReportes = false;
      }
    });
  }

  onGenerarReporte(formato: 'excel' | 'pdf' | 'pantalla'): void {
    if (!this.form.valid) {
      this.toast.showError('Por favor complete todos los campos');
      return;
    }

    this.isGeneratingReport.set(true);
    const compania = this.form.get('compania')?.value;
    const fecha = this.form.get('fechaProceso')?.value;
    const reporte = this.form.get('reporte')?.value;
    const actualiza = this.mostrarActualiza ? this.form.get('actualiza')?.value : 'Si';

    this.ccService.generarReporteGenerico(compania, fecha, reporte, actualiza, this.pcPrograma).subscribe({
      next: (response) => {
        this.isGeneratingReport.set(false);
        
        if (response) {
          this.handleReporteResponse(response, formato, reporte, fecha);
          this.toast.showSuccess('Reporte generado correctamente');
        }
      },
      error: (err) => {
        console.error('Error generando reporte:', err);
        this.toast.showError('Error al generar reporte');
        this.isGeneratingReport.set(false);
      }
    });
  }

  private handleReporteResponse(response: any, formato: string, reporte: string, fecha: string): void {
    if (formato === 'pantalla') {
      // Show in browser
      if (response.pcArchPDF) {
        this.viewPDFInBrowser(response.pcArchPDF);
      } else if (response.pcArchCSV) {
        this.viewCSVInBrowser(response.pcArchCSV);
      }
    } else if (formato === 'excel') {
      // Download as CSV
      if (response.pcArchCSV) {
        this.downloadBase64File(response.pcArchCSV, 'text/csv', `${reporte}_${fecha}.csv`);
      }
    } else if (formato === 'pdf') {
      // Download as PDF
      if (response.pcArchPDF) {
        this.downloadBase64File(response.pcArchPDF, 'application/pdf', `${reporte}_${fecha}.pdf`);
      }
    }
  }

  private viewPDFInBrowser(base64Data: string): void {
    try {
      const pdfData = 'data:application/pdf;base64,' + base64Data;
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head>
              <title>Reporte PDF</title>
              <style>
                body { margin: 0; padding: 0; }
                embed { width: 100%; height: 100vh; }
              </style>
            </head>
            <body>
              <embed src="${pdfData}" type="application/pdf">
            </body>
          </html>
        `);
        newWindow.document.close();
      }
    } catch (error) {
      console.error('Error mostrando PDF:', error);
      this.toast.showError('Error al mostrar el PDF');
    }
  }

  private viewCSVInBrowser(base64Data: string): void {
    try {
      const csvText = atob(base64Data);
      const escapedText = this.escapeHtml(csvText);
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head>
              <title>Reporte CSV</title>
              <style>
                body { 
                  font-family: 'Courier New', monospace; 
                  padding: 20px; 
                  background: #f5f5f5;
                }
                .content {
                  background: white;
                  padding: 20px;
                  border-radius: 4px;
                  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                  white-space: pre-wrap;
                  word-wrap: break-word;
                  max-width: 1200px;
                  margin: 0 auto;
                }
                .print-btn {
                  margin-bottom: 20px;
                  padding: 10px 20px;
                  background: #003087;
                  color: white;
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
                  font-size: 14px;
                }
                .print-btn:hover {
                  background: #002060;
                }
              </style>
            </head>
            <body>
              <button class="print-btn" onclick="window.print()">Imprimir</button>
              <div class="content">${escapedText}</div>
            </body>
          </html>
        `);
        newWindow.document.close();
      }
    } catch (error) {
      console.error('Error mostrando CSV:', error);
      this.toast.showError('Error al mostrar el CSV');
    }
  }

  private downloadBase64File(base64Data: string, mimeType: string, fileName: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error descargando archivo:', error);
      this.toast.showError('Error al descargar el archivo');
    }
  }

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
  }

  onCloseModal(): void {
    this.showCompaniaModal.set(false);
    this.companiaSearch.set('');
    this.searchForm.get('search')?.reset('');
    this.filteredCompaniasList.set(this.companiasList());
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.form.patchValue({
      compania: compania.cia.toString()
    });
    this.selectedCompania.set(compania);
    this.onCloseModal();
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getErrorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (field?.hasError('required')) {
      return `${fieldName} es requerido`;
    }
    if (field?.hasError('notFound')) {
      return `${fieldName} no encontrado`;
    }
    return 'Campo inválido';
  }

  // ============ MÉTODOS PARA MODAL DE COMPAÑÍA ============

  private initializeSearchForm(): void {
    this.searchForm.get('search')!.valueChanges.pipe(
      takeUntil(this.destroy$),
      debounceTime(300),
      distinctUntilChanged()
    ).subscribe(searchTerm => this.filterCompanias(searchTerm));
  }

  private loadCompanias(): void {
    this.isLoadingCompanias.set(true);
    this.ccService.getCompanias().subscribe({
      next: (companias) => {
        this.companiasList.set(companias);
        this.filteredCompaniasList.set(companias);
        this.isLoadingCompanias.set(false);
      },
      error: (err) => {
        console.error('Error cargando compañías:', err);
        this.companiasList.set([]);
        this.filteredCompaniasList.set([]);
        this.isLoadingCompanias.set(false);
      }
    });
  }

  private filterCompanias(searchTerm: string): void {
    if (!searchTerm) {
      this.filteredCompaniasList.set(this.companiasList());
      return;
    }
    
    const term = searchTerm.toLowerCase();
    const filtered = this.companiasList().filter(compania => 
      compania['nombre-cia'].toLowerCase().includes(term) ||
      compania.nit.includes(searchTerm) ||
      compania.cia.toString().includes(searchTerm)
    );
    
    this.filteredCompaniasList.set(filtered);
  }

  trackByCompania(index: number, compania: CompaniaRecord): any {
    return compania.cia;
  }

  trackByReporte(index: number, reporte: ReporteOption): any {
    return reporte['pcProg-Sel'];
  }

  onClear(): void {
    this.form.reset({
      actualiza: 'Si'
    });
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    this.form.patchValue({ fechaProceso: `${yyyy}-${mm}-${dd}` });
    this.selectedCompania.set(null);
    this.reportesOptions.set([]);
  }
}
