import { Component } from '@angular/core';
import { ReporteRangoFechasComponent } from '../reporte-rango-fechas/reporte-rango-fechas.component';

@Component({
  selector: 'app-reporte-cc2205',
  standalone: true,
  imports: [ReporteRangoFechasComponent],
  template: `
    <app-reporte-rango-fechas
      [pcPrograma]="'cc2205'"
      [titulo]="'Reporte Diferencia en Cambio CxC Detallado'"
      [rutaVolver]="'/cuentas-por-cobrar'">
    </app-reporte-rango-fechas>
  `
})
export class ReporteCC2205Component {}
