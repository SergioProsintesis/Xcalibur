import { Component, OnDestroy, OnInit, signal, computed, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { combineLatest, debounceTime, distinctUntilChanged, filter, startWith, Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';

import { AuthService } from '../../../../core/services/auth.service';
import { ToastService } from '../../../../core/services/toast.service';
import { LoadingService } from '../../../../core/services/loading.service';
import { CCService } from '../../../../core/services/cc.service';
import { ProgramContextService } from '../../../../core/services/program-context.service';
import { CompaniaRecord, ReporteOption, GenerarReporteResponse } from '../../../../core/interfaces/cc.interface';
import { CompaniaModalComponent } from '../../reporte-movimiento-del-dia/compania-modal/compania-modal.component';

@Component({
  selector: 'app-conversion-monetaria',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, CompaniaModalComponent],
  templateUrl: './conversion-monetaria.component.html',
  styleUrls: ['./conversion-monetaria.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ConversionMonetariaComponent implements OnInit, OnDestroy {
  private programContext = inject(ProgramContextService);
  
  form: FormGroup;
  searchForm: FormGroup;
  isLoading = signal(false);
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Conversión Monetaria`);
  showCompaniaModal = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  reportesOptions = signal<ReporteOption[]>([]);
  isGeneratingReport = signal(false);
  
  // Modal properties
  companiaSearch = signal('');
  companiasList = signal<CompaniaRecord[]>([]);
  filteredCompaniasList = signal<CompaniaRecord[]>([]);
  isLoadingCompanias = signal(false);
  
  private destroy$ = new Subject<void>();
  private loadingReportes = false;

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
    private loading: LoadingService,
    private ccService: CCService,
    private router: Router
  ) {
    this.form = this.fb.group({
      compania: ['', Validators.required],
      fechaProceso: ['', Validators.required],
      actualiza: ['Si', Validators.required],
      reporte: [{ value: '', disabled: true }, Validators.required]
    });
    this.searchForm = this.fb.group({
      search: ['']
    });
  }

  ngOnInit(): void {
    // Inicializar formulario de búsqueda de compañía
    this.initializeSearchForm();
    this.loadCompanias();

    // Fecha por defecto: hoy
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    this.form.patchValue({ fechaProceso: `${yyyy}-${mm}-${dd}` });

    // Validación de compañía con backend
    this.form.get('compania')!.valueChanges.pipe(
      takeUntil(this.destroy$),
      debounceTime(400),
      distinctUntilChanged(),
      filter(v => !!v && v.length > 0)
    ).subscribe(value => this.validateCompania(value));

    // Cargar reportes cuando cambien compañía, fecha o actualiza
    combineLatest([
      this.form.get('compania')!.valueChanges.pipe(startWith(this.form.get('compania')?.value)),
      this.form.get('fechaProceso')!.valueChanges.pipe(startWith(this.form.get('fechaProceso')?.value)),
      this.form.get('actualiza')!.valueChanges.pipe(startWith(this.form.get('actualiza')?.value))
    ]).pipe(
      takeUntil(this.destroy$),
      debounceTime(300),
      filter(([compania, fechaProceso]) => !!(compania && fechaProceso && this.form.get('compania')?.valid && this.form.get('fechaProceso')?.valid))
    ).subscribe(() => this.loadReportesOptions());
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  goBack(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }

  private validateCompania(codigo: string) {
    this.ccService.validateCompania(codigo).subscribe(compania => {
      if (compania) {
        this.selectedCompania.set(compania);
        const ctrl = this.form.get('compania');
        if (ctrl?.hasError('notFound')) {
          const errors = { ...(ctrl.errors || {}) };
          delete errors['notFound'];
          ctrl.setErrors(Object.keys(errors).length ? errors : null);
        }
      } else {
        this.selectedCompania.set(null);
        this.form.get('compania')?.setErrors({ notFound: true });
      }
    });
  }

  private loadReportesOptions() {
    const { compania, fechaProceso, actualiza } = this.form.value;
    if (!compania || !fechaProceso || this.loadingReportes) {
      this.form.get('reporte')?.disable();
      return;
    }

    this.loadingReportes = true;
    console.log('Loading reportes for:', { compania, fechaProceso, actualiza });

    this.ccService.getReportesConversion(compania, fechaProceso, actualiza).subscribe({
      next: (reportes) => {
        console.log('Reportes loaded:', reportes.length);
        this.reportesOptions.set(reportes);
        
        const reporteControl = this.form.get('reporte');
        if (reporteControl) {
          reporteControl.setValue('', { emitEvent: false });
        }
        
        if (reportes.length > 0) {
          reporteControl?.enable();
        } else {
          reporteControl?.disable();
        }
        
        this.loadingReportes = false;
      },
      error: (error) => {
        console.error('Error loading reportes:', error);
        this.loadingReportes = false;
        this.form.get('reporte')?.disable();
      }
    });
  }

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
  }

  onSelectCompania(compania: CompaniaRecord): void {
    this.selectedCompania.set(compania);
    this.form.patchValue({ compania: compania.cia.toString() });
    this.showCompaniaModal.set(false);
    this.validateCompania(compania.cia.toString());
  }

  onCloseModal(): void {
    this.showCompaniaModal.set(false);
  }

  onClear(): void {
    this.form.reset();
    this.selectedCompania.set(null);
    this.reportesOptions.set([]);
  }

  onGenerarReporte(formato: 'excel' | 'pdf' | 'pantalla'): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.toast.showWarning('Complete todos los campos obligatorios');
      return;
    }

    const { compania, fechaProceso, actualiza, reporte } = this.form.value;
    
    this.isGeneratingReport.set(true);
    this.loading.show();
    
    this.ccService.generarReporteConversion(compania, fechaProceso, reporte, actualiza).subscribe({
      next: (response) => {
        this.isGeneratingReport.set(false);
        this.loading.hide();
        
        if (response) {
          this.handleReporteGenerated(response, formato);
        } else {
          this.toast.showError('No se pudo generar el reporte');
        }
      },
      error: (err) => {
        this.isGeneratingReport.set(false);
        this.loading.hide();
        console.error('Error generando reporte:', err);
        this.toast.showError('Error al generar el reporte');
      }
    });
  }

  private handleReporteGenerated(response: GenerarReporteResponse['response'], formato: 'excel' | 'pdf' | 'pantalla'): void {
    console.log('🎯 Respuesta completa recibida:', {
      csvExists: !!response.pcArchCSV,
      pdfExists: !!response.pcArchPDF
    });
    
    switch (formato) {
      case 'excel':
        if (response.pcArchCSV) {
          console.log('📊 Procesando Excel con CSV');
          this.downloadExcelFile(response.pcArchCSV);
        } else {
          this.toast.showError('No se pudo obtener el archivo CSV');
          return;
        }
        break;
      case 'pdf':
        if (response.pcArchPDF) {
          console.log('📄 Procesando PDF');
          this.downloadPdfFile(response.pcArchPDF);
        } else {
          this.toast.showError('No se pudo obtener el archivo PDF');
          return;
        }
        break;
      case 'pantalla':
        if (response.pcArchCSV) {
          console.log('🖥️ Procesando vista en pantalla con CSV');
          this.showReportInModal(response.pcArchCSV);
        } else {
          this.toast.showError('No se pudo obtener los datos para mostrar');
          return;
        }
        break;
    }
    
    const selectedReporte = this.reportesOptions().find(r => r["pcProg-Sel"] === this.form.value.reporte);
    this.toast.showSuccess(`Reporte "${selectedReporte?.["pcNombre-pro"] || 'generado'}" ${formato === 'pantalla' ? 'mostrado' : 'descargado'} exitosamente`);
  }

  private downloadExcelFile(content: string): void {
    try {
      let csvContent: string;
      
      if (this.isBase64(content)) {
        csvContent = atob(content);
      } else {
        csvContent = content;
      }

      const csvWithSemicolons = this.convertToCsvWithSemicolons(csvContent);
      
      const bom = '\uFEFF';
      const finalContent = bom + csvWithSemicolons;
      
      const selectedReporte = this.reportesOptions().find(r => r["pcProg-Sel"] === this.form.value.reporte);
      const filename = `${selectedReporte?.["pcNombre-pro"] || 'reporte'}_${this.form.value.fechaProceso}.csv`;
      
      const blob = new Blob([finalContent], { 
        type: 'text/csv;charset=utf-8' 
      });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      window.URL.revokeObjectURL(url);

      console.log(`✅ Archivo CSV ${filename} descargado exitosamente`);
      
    } catch (error) {
      console.error('Error procesando archivo Excel:', error);
      this.toast.showError('Error al procesar el archivo Excel');
    }
  }

  private downloadPdfFile(content: string): void {
    try {
      let pdfContent: string;
      
      if (this.isBase64(content)) {
        pdfContent = content;
      } else {
        pdfContent = btoa(unescape(encodeURIComponent(content)));
      }

      const selectedReporte = this.reportesOptions().find(r => r["pcProg-Sel"] === this.form.value.reporte);
      const filename = `${selectedReporte?.["pcNombre-pro"] || 'reporte'}_${this.form.value.fechaProceso}.pdf`;
      
      const byteCharacters = atob(pdfContent);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);

      const blob = new Blob([byteArray], { type: 'application/pdf' });
      
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      window.URL.revokeObjectURL(url);

      console.log(`✅ Archivo PDF ${filename} descargado exitosamente`);
      
    } catch (error) {
      console.error('Error procesando archivo PDF:', error);
      this.toast.showError('Error al procesar el archivo PDF');
    }
  }

  private convertToCsvWithSemicolons(content: string): string {
    try {
      const lines = content.split(/\r?\n/);
      const convertedLines: string[] = [];

      for (const line of lines) {
        if (line.trim()) {
          let convertedLine = line;
          
          if (line.includes('\t')) {
            convertedLine = line.split('\t').join(';');
          } else if (line.includes(',') && !line.includes(';')) {
            convertedLine = line.split(',').join(';');
          } else if (line.includes('|')) {
            convertedLine = line.split('|').join(';');
          }
          
          convertedLines.push(convertedLine);
        }
      }

      return convertedLines.join('\n');
    } catch (error) {
      console.error('Error converting CSV:', error);
      return content;
    }
  }

  private showReportInModal(csvContent: string): void {
    try {
      let parsedContent = csvContent;
      
      if (this.isBase64(csvContent)) {
        parsedContent = atob(csvContent);
      }

      const lines = parsedContent.split(/\r?\n/).filter(line => line.trim());
      
      if (lines.length > 0) {
        const headers = lines[0].split(';');
        const data = lines.slice(1).map(line => line.split(';'));

        console.log('📊 Datos de reporte:', { headers, rowCount: data.length });
      }
    } catch (error) {
      console.error('Error procesando datos para pantalla:', error);
      this.toast.showError('Error al procesar los datos');
    }
  }

  private isBase64(str: string): boolean {
    try {
      return btoa(atob(str)) === str;
    } catch (err) {
      return false;
    }
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getErrorMessage(fieldName: string): string {
    const control = this.form.get(fieldName);
    if (control?.hasError('required')) {
      return `${this.getFieldLabel(fieldName)} es requerido`;
    }
    if (control?.hasError('notFound')) {
      return `${this.getFieldLabel(fieldName)} no encontrado`;
    }
    return 'Campo inválido';
  }

  private getFieldLabel(fieldName: string): string {
    const labels: { [key: string]: string } = {
      compania: 'Compañía',
      fechaProceso: 'Fecha de Proceso',
      actualiza: 'Actualiza',
      reporte: 'Reporte'
    };
    return labels[fieldName] || fieldName;
  }

  trackByReporte(index: number, reporte: ReporteOption): string {
    return reporte['pcProg-Sel'];
  }

  // ============ MÉTODOS PARA MODAL DE COMPAÑÍA ============

  private initializeSearchForm(): void {
    this.searchForm.get('search')!.valueChanges.pipe(
      takeUntil(this.destroy$),
      debounceTime(300),
      distinctUntilChanged()
    ).subscribe(searchTerm => this.filterCompanias(searchTerm));
  }

  private loadCompanias(): void {
    this.isLoadingCompanias.set(true);
    this.ccService.getCompanias().subscribe({
      next: (companias) => {
        this.companiasList.set(companias);
        this.filteredCompaniasList.set(companias);
        this.isLoadingCompanias.set(false);
      },
      error: (err) => {
        console.error('Error loading companias:', err);
        this.isLoadingCompanias.set(false);
      }
    });
  }

  private filterCompanias(searchTerm: string): void {
    if (!searchTerm) {
      this.filteredCompaniasList.set(this.companiasList());
      return;
    }

    const filtered = this.companiasList().filter(compania => 
      compania['nombre-cia'].toLowerCase().includes(searchTerm.toLowerCase()) ||
      compania.nit.includes(searchTerm) ||
      compania.cia.toString().includes(searchTerm)
    );
    
    this.filteredCompaniasList.set(filtered);
  }

  trackByCompania(index: number, compania: CompaniaRecord): number {
    return compania.cia;
  }
}
