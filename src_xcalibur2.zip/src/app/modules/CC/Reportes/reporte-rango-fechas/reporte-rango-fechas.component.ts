import { Component, Input, OnDestroy, OnInit, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { combineLatest, debounceTime, distinctUntilChanged, filter, Observable, startWith, Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';

import { AuthService } from '../../../../core/services/auth.service';
import { ToastService } from '../../../../core/services/toast.service';
import { LoadingService } from '../../../../core/services/loading.service';
import { ProgramContextService } from '../../../../core/services/program-context.service';
import { CCService } from '../../../../core/services/cc.service';
import { CompaniaRecord, GenerarReporteResponse } from '../../../../core/interfaces/cc.interface';
import { CompaniaModalComponent } from '../../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { EmpresaModalComponent } from './empresa-modal/empresa-modal.component';

interface EmpresaRecord {
  empresa: number;
  'nombre-emp': string;
  'abrenom-emp': string;
  nit: string;
  'direc-emp': string;
  [key: string]: any;
}

@Component({
  selector: 'app-reporte-rango-fechas',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, CompaniaModalComponent, EmpresaModalComponent],
  templateUrl: './reporte-rango-fechas.component.html',
  styleUrls: ['./reporte-rango-fechas.component.css']
})
export class ReporteRangoFechasComponent implements OnInit, OnDestroy {
  @Input() pcPrograma: string = 'cc2205'; // Programa por defecto
  @Input() titulo: string = 'Reporte por Rango de Fechas';
  @Input() rutaVolver: string = '/cuentas-por-cobrar';

  form: FormGroup;
  searchForm: FormGroup;
  isLoading = signal(false);
  showCompaniaModal = signal(false);
  selectedCompania = signal<CompaniaRecord | null>(null);
  showEmpresaModal = signal(false);
  selectedEmpresaD = signal<EmpresaRecord | null>(null);
  selectedEmpresaH = signal<EmpresaRecord | null>(null);
  activeEmpresaField = signal<'empresaD' | 'empresaH'>('empresaD'); // Track which field is being edited
  isGeneratingReport = signal(false);
  
  // Título concatenado con el código del programa
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}${this.titulo}`);
  
  // Modal properties - Compañía
  companiaSearch = signal('');
  companiasList = signal<CompaniaRecord[]>([]);
  filteredCompaniasList = signal<CompaniaRecord[]>([]);
  isLoadingCompanias = signal(false);
  
  // Modal properties - Empresa
  empresaSearch = signal('');
  empresasList = signal<EmpresaRecord[]>([]);
  filteredEmpresasList = signal<EmpresaRecord[]>([]);
  isLoadingEmpresas = signal(false);
  
  private destroy$ = new Subject<void>();
  private programContext = inject(ProgramContextService);

  private escapeHtml(text: string): string {
    const map: { [key: string]: string } = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, (char) => map[char]);
  }

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
    private loading: LoadingService,
    private ccService: CCService,
    private router: Router
  ) {
    this.form = this.fb.group({
      compania: ['', Validators.required],
      fechaInicio: ['', Validators.required],
      fechaFin: ['', Validators.required],
      ciudad: [''],
      codServ: [''],
      indConsol: [''],
      empresaD: [''],
      empresaH: ['']
    });

    this.searchForm = this.fb.group({
      search: ['']
    });
  }

  ngOnInit(): void {
    console.log('[ReporteRangoFechas] Component initialized with programa:', this.pcPrograma);
    this.initializeForm();
  }

  private initializeForm(): void {
    this.loadCompanias();
    this.setupSearchListener();
  }

  private loadCompanias(): void {
    this.isLoadingCompanias.set(true);
    
    this.ccService.getCompanias()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (companias) => {
          this.companiasList.set(companias);
          this.filteredCompaniasList.set(companias);
          this.isLoadingCompanias.set(false);
        },
        error: (err) => {
          console.error('Error loading companies:', err);
          this.toast.showError('Error al cargar las compañías');
          this.isLoadingCompanias.set(false);
        }
      });
  }

  private setupSearchListener(): void {
    this.searchForm.get('search')?.valueChanges
      .pipe(
        startWith(''),
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe((searchTerm) => {
        this.filterCompanias(searchTerm);
      });
  }

  private filterCompanias(term: string): void {
    const filtered = this.companiasList().filter(cia =>
      cia.cia.toString().includes(term) ||
      cia['nombre-cia']?.toLowerCase().includes(term?.toLowerCase()) ||
      cia.nit?.includes(term)
    );
    this.filteredCompaniasList.set(filtered);
  }

  onOpenCompaniaModal(): void {
    this.showCompaniaModal.set(true);
    this.searchForm.reset();
    this.filteredCompaniasList.set(this.companiasList());
  }

  onSelectCompania(compania: CompaniaRecord): void {
    this.form.patchValue({
      compania: compania.cia
    });
    this.selectedCompania.set(compania);
    this.showCompaniaModal.set(false);
  }

  onCloseModal(): void {
    this.showCompaniaModal.set(false);
    this.searchForm.reset();
  }

  onOpenEmpresaModal(): void {
    const companiaId = this.form.get('compania')?.value;
    if (!companiaId) {
      this.toast.showError('Por favor seleccione una compañía primero');
      return;
    }
    this.showEmpresaModal.set(true);
  }

  onOpenEmpresaModalD(): void {
    console.log('[ReporteRangoFechas] Opening empresa modal for empresaD');
    this.activeEmpresaField.set('empresaD');
    this.onOpenEmpresaModal();
  }

  onOpenEmpresaModalH(): void {
    console.log('[ReporteRangoFechas] Opening empresa modal for empresaH');
    this.activeEmpresaField.set('empresaH');
    this.onOpenEmpresaModal();
  }

  onSelectEmpresa(empresa: EmpresaRecord): void {
    console.log('[ReporteRangoFechas] Empresa selected:', empresa);
    const field = this.activeEmpresaField();
    console.log('[ReporteRangoFechas] Setting field:', field, 'to:', empresa.empresa);
    
    this.form.patchValue({
      [field]: empresa.empresa
    });
    
    if (field === 'empresaD') {
      this.selectedEmpresaD.set(empresa);
    } else {
      this.selectedEmpresaH.set(empresa);
    }
    
    this.showEmpresaModal.set(false);
  }

  onCloseEmpresaModal(): void {
    this.showEmpresaModal.set(false);
  }

  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getErrorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (!field) return '';

    if (field.hasError('required')) return 'Este campo es requerido';
    if (field.hasError('pattern')) return 'Formato inválido';
    
    return 'Error en el campo';
  }

  trackByCompania(index: number, compania: CompaniaRecord): number {
    return compania.cia;
  }

  private convertDateFormat(dateStr: string): string {
    // Convierte YYYY-MM-DD a DD/MM/YYYY
    if (!dateStr) return '';
    const [year, month, day] = dateStr.split('-');
    return `${day}/${month}/${year}`;
  }

  onGenerarReporte(formato: 'excel' | 'pdf' | 'pantalla'): void {
    // Validar solo los campos obligatorios
    const pcCompania = this.form.get('compania')?.value;
    const pcFechaD = this.form.get('fechaInicio')?.value;
    const pcFechaH = this.form.get('fechaFin')?.value;

    if (!pcCompania || !pcFechaD || !pcFechaH) {
      this.toast.showError('Por favor complete los campos requeridos: Compañía, Fecha Inicio y Fecha Fin');
      return;
    }

    this.isGeneratingReport.set(true);
    
    // Convertir fechas a formato DD/MM/YYYY
    const pcFechaDFormatted = this.convertDateFormat(pcFechaD);
    const pcFechaHFormatted = this.convertDateFormat(pcFechaH);
    
    const pcCiudad = this.form.get('ciudad')?.value || ''; // Opcional, puede estar vacío
    const pcCodServ = this.form.get('codServ')?.value || ''; // Opcional, puede estar vacío
    const pcIndConsol = this.form.get('indConsol')?.value || '';
    const pcEmpresaD = this.form.get('empresaD')?.value || '1'; // Opcional, default '1'
    const pcEmpresaH = this.form.get('empresaH')?.value || '9999'; // Opcional, default '9999'

    // Call the specific method based on program
    let reportCall: Observable<any>;

    switch (this.pcPrograma.toLowerCase()) {
      case 'ps5034':
        reportCall = this.ccService.getPS5034(pcCompania, pcFechaDFormatted, pcFechaHFormatted);
        break;
      case 'ps5035':
        reportCall = this.ccService.getPS5035(pcCompania, pcFechaDFormatted, pcFechaHFormatted, pcCiudad, pcCodServ, pcIndConsol);
        break;
      case 'cc2205':
        reportCall = this.ccService.getCC2205(pcCompania, pcEmpresaD.toString(), pcEmpresaH.toString(), pcFechaDFormatted, pcFechaHFormatted);
        break;
      case 'ps5001':
        reportCall = this.ccService.getPS5001(pcCompania, pcFechaDFormatted, pcFechaHFormatted);
        break;
      case 'ps5023':
        reportCall = this.ccService.getPS5023(pcCompania, pcFechaDFormatted, pcFechaHFormatted);
        break;
      case 'ps5068':
        reportCall = this.ccService.getPS5068(pcCompania, pcFechaDFormatted, pcFechaHFormatted);
        break;
      default:
        this.toast.showError('Programa no soportado');
        this.isGeneratingReport.set(false);
        return;
    }

    reportCall
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          this.isGeneratingReport.set(false);
          if (response) {
            this.handleReporteResponse(response, formato);
            this.toast.showSuccess(`Reporte generado en formato ${formato}`);
          } else {
            this.toast.showError('No se pudo generar el reporte');
          }
        },
        error: (err: any) => {
          this.isGeneratingReport.set(false);
          console.error('Error generating report:', err);
          this.toast.showError('Error al generar el reporte');
        }
      });
  }

  private handleReporteResponse(response: string | GenerarReporteResponse['response'], formato: string): void {
    // Si es una string, es base64 directo del nuevo método
    if (typeof response === 'string') {
      if (formato === 'excel') {
        this.downloadBase64File(response, 'text/csv', 'reporte.csv');
      } else if (formato === 'pantalla') {
        this.viewCSVInBrowser(response);
      }
    } else if (response) {
      // Si es un objeto, maneja los campos específicos
      if (formato === 'excel') {
        if (response.pcArchCSV) {
          this.downloadBase64File(response.pcArchCSV, 'text/csv', 'reporte.csv');
        } else if (response.pcArchXLS) {
          this.downloadBase64File(response.pcArchXLS, 'application/vnd.ms-excel', 'reporte.xls');
        }
      } else if (formato === 'pdf' && response.pcArchPDF) {
        this.downloadBase64File(response.pcArchPDF, 'application/pdf', 'reporte.pdf');
      } else if (formato === 'pantalla') {
        if (response.pcArchPDF) {
          this.viewPDFInBrowser(response.pcArchPDF);
        } else if (response.pcArchCSV) {
          this.viewCSVInBrowser(response.pcArchCSV);
        } else if (response.pcArchXLS) {
          this.viewCSVInBrowser(response.pcArchXLS);
        }
      }
    }
  }

  private viewPDFInBrowser(base64Data: string): void {
    try {
      const pdfData = 'data:application/pdf;base64,' + base64Data;
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head>
              <title>Reporte PDF</title>
              <style>
                body { margin: 0; padding: 0; }
                embed { width: 100%; height: 100vh; }
              </style>
            </head>
            <body>
              <embed src="${pdfData}" type="application/pdf">
            </body>
          </html>
        `);
        newWindow.document.close();
      }
    } catch (error) {
      console.error('Error mostrando PDF:', error);
      this.toast.showError('Error al mostrar el PDF');
    }
  }

  private viewCSVInBrowser(base64Data: string): void {
    try {
      const csvText = atob(base64Data);
      const escapedText = this.escapeHtml(csvText);
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head>
              <title>Reporte CSV</title>
              <style>
                body { 
                  font-family: 'Courier New', monospace; 
                  padding: 20px; 
                  background: #f5f5f5;
                }
                .content {
                  background: white;
                  padding: 20px;
                  border-radius: 4px;
                  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                  white-space: pre-wrap;
                  word-wrap: break-word;
                  max-width: 1200px;
                  margin: 0 auto;
                }
                .print-btn {
                  margin-bottom: 20px;
                  padding: 10px 20px;
                  background: #003087;
                  color: white;
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
                  font-size: 14px;
                }
                .print-btn:hover {
                  background: #002060;
                }
              </style>
            </head>
            <body>
              <button class="print-btn" onclick="window.print()">Imprimir</button>
              <div class="content">${escapedText}</div>
            </body>
          </html>
        `);
        newWindow.document.close();
      }
    } catch (error) {
      console.error('Error mostrando CSV:', error);
      this.toast.showError('Error al mostrar el CSV');
    }
  }

  private downloadBase64File(base64Data: string, mimeType: string, fileName: string): void {
    try {
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error descargando archivo:', error);
      this.toast.showError('Error al descargar el archivo');
    }
  }

  onClear(): void {
    this.form.reset();
    this.selectedCompania.set(null);
  }

  goBack(): void {
    this.router.navigate([this.rutaVolver]);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
