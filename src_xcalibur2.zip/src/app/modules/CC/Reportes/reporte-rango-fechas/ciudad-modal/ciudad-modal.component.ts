import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, signal, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { debounceTime, distinctUntilChanged, Subject, takeUntil, startWith } from 'rxjs';

import { CCService } from '../../../../../core/services/cc.service';

interface CiudadRecord {
  pcCiudad: string;
  pcNombre_ciu: string;
  'pcNombre-ciu'?: string;
  Login_ctrl?: string;
  tparent?: string;
}

@Component({
  selector: 'app-ciudad-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  template: `
    <div class="modal-backdrop" *ngIf="show" (click)="onClose()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2 class="modal-title">Buscar Ciudad</h2>
          <button type="button" class="close-btn" (click)="onClose()">&times;</button>
        </div>

        <div class="modal-body">
          <form [formGroup]="searchForm" class="search-form">
            <div class="search-field">
              <label class="field-label">Buscar por código o nombre</label>
              <input type="text" formControlName="search" class="search-input" placeholder="Escriba para buscar...">
            </div>
          </form>

          <div class="ciudades-grid" *ngIf="filteredCiudades().length > 0; else noResults">
            <div class="grid-header">
              <div class="header-cell">Código</div>
              <div class="header-cell">Nombre</div>
              <div class="header-cell">Acción</div>
            </div>
            <div class="grid-body">
              <div class="grid-row" *ngFor="let ciudad of filteredCiudades(); trackBy: trackByCiudad">
                <div class="grid-cell">{{ ciudad.pcCiudad }}</div>
                <div class="grid-cell">{{ ciudad['pcNombre-ciu'] || ciudad.pcNombre_ciu }}</div>
                <div class="grid-cell">
                  <button type="button" class="select-btn" (click)="onSelectCiudad(ciudad)">
                    Seleccionar
                  </button>
                </div>
              </div>
            </div>
          </div>

          <ng-template #noResults>
            <div class="no-results" *ngIf="!isLoading()">
              <p>No se encontraron ciudades</p>
            </div>
          </ng-template>

          <div class="loading-indicator" *ngIf="isLoading()">
            <div class="spinner"></div>
            <span>Cargando ciudades...</span>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn-secondary" (click)="onClose()">Cancelar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .modal-content {
      background: white;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 700px;
      max-height: 80vh;
      display: flex;
      flex-direction: column;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .modal-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: #003087;
      margin: 0;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      cursor: pointer;
      color: #6b7280;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .close-btn:hover {
      color: #374151;
    }

    .modal-body {
      padding: 1.5rem;
      overflow-y: auto;
      flex: 1;
    }

    .search-form {
      margin-bottom: 1.5rem;
    }

    .search-field {
      display: flex;
      flex-direction: column;
    }

    .field-label {
      font-weight: 500;
      color: #374151;
      margin-bottom: 0.5rem;
    }

    .search-input {
      border: 1px solid #d1d5db;
      border-radius: 8px;
      padding: 0.75rem;
      font-size: 0.95rem;
      transition: all 0.2s;
    }

    .search-input:focus {
      outline: none;
      border-color: #003087;
      box-shadow: 0 0 0 2px rgba(0, 48, 135, 0.15);
    }

    .ciudades-grid {
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      overflow: hidden;
    }

    .grid-header {
      display: grid;
      grid-template-columns: 120px 1fr 120px;
      background: #f9fafb;
      border-bottom: 1px solid #e5e7eb;
    }

    .header-cell {
      padding: 0.75rem;
      font-weight: 600;
      font-size: 0.875rem;
      color: #374151;
      border-right: 1px solid #e5e7eb;
    }

    .header-cell:last-child {
      border-right: none;
    }

    .grid-body {
      max-height: 300px;
      overflow-y: auto;
    }

    .grid-row {
      display: grid;
      grid-template-columns: 120px 1fr 120px;
      border-bottom: 1px solid #f3f4f6;
    }

    .grid-row:hover {
      background: #f9fafb;
    }

    .grid-cell {
      padding: 0.75rem;
      font-size: 0.875rem;
      color: #374151;
      border-right: 1px solid #f3f4f6;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .grid-cell:last-child {
      border-right: none;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0.5rem;
    }

    .select-btn {
      background: #003087;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 0.5rem 1rem;
      font-size: 0.75rem;
      cursor: pointer;
      transition: all 0.2s;
      white-space: nowrap;
    }

    .select-btn:hover {
      background: #002060;
      transform: translateY(-1px);
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .select-btn:active {
      transform: translateY(0);
    }

    .no-results {
      text-align: center;
      padding: 2rem;
      color: #6b7280;
    }

    .loading-indicator {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }

    .spinner {
      border: 3px solid #e5e7eb;
      border-top: 3px solid #003087;
      border-radius: 50%;
      width: 40px;
      height: 40px;
      animation: spin 1s linear infinite;
      margin-bottom: 1rem;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .modal-footer {
      padding: 1rem 1.5rem;
      border-top: 1px solid #e5e7eb;
      display: flex;
      justify-content: flex-end;
      gap: 0.5rem;
    }

    .btn-secondary {
      background: #e5e7eb;
      color: #374151;
      border: none;
      border-radius: 6px;
      padding: 0.75rem 1.5rem;
      font-size: 0.875rem;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
    }

    .btn-secondary:hover {
      background: #d1d5db;
    }
  `]
})
export class CiudadModalComponent implements OnInit, OnDestroy, OnChanges {
  @Input() show = false;
  @Input() compania: number | null = null;
  @Output() closeModal = new EventEmitter<void>();
  @Output() ciudadSelected = new EventEmitter<CiudadRecord>();

  searchForm: FormGroup;
  ciudadesList = signal<CiudadRecord[]>([]);
  filteredCiudades = signal<CiudadRecord[]>([]);
  isLoading = signal(false);

  private destroy$ = new Subject<void>();

  constructor(
    private fb: FormBuilder,
    private ccService: CCService
  ) {
    this.searchForm = this.fb.group({
      search: ['']
    });
  }

  ngOnInit(): void {
    this.setupSearchListener();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['show'] && changes['show'].currentValue && this.compania) {
      this.loadCiudades();
    }
  }

  private loadCiudades(): void {
    if (!this.compania) return;

    this.isLoading.set(true);
    this.ccService.getCiudadesPS5035(this.compania.toString())
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          const ciudades = response?.dsRespuesta?.tCiudad || [];
          this.ciudadesList.set(ciudades);
          this.filteredCiudades.set(ciudades);
          this.isLoading.set(false);
        },
        error: (err: any) => {
          console.error('Error loading ciudades:', err);
          this.isLoading.set(false);
        }
      });
  }

  private setupSearchListener(): void {
    this.searchForm.get('search')?.valueChanges
      .pipe(
        startWith(''),
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe((searchTerm) => {
        this.filterCiudades(searchTerm);
      });
  }

  private filterCiudades(term: string): void {
    const filtered = this.ciudadesList().filter(ciudad =>
      ciudad.pcCiudad?.toString().includes(term) ||
      (ciudad['pcNombre-ciu'] || ciudad.pcNombre_ciu)?.toLowerCase().includes(term?.toLowerCase())
    );
    this.filteredCiudades.set(filtered);
  }

  onSelectCiudad(ciudad: CiudadRecord): void {
    this.ciudadSelected.emit(ciudad);
    this.onClose();
  }

  onClose(): void {
    this.closeModal.emit();
    this.searchForm.reset();
  }

  trackByCiudad(index: number, ciudad: CiudadRecord): string {
    return ciudad.pcCiudad;
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
