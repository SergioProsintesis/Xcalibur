import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnInit,
  OnDestroy,
  signal,
  effect,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { CCService } from '../../../../../core/services/cc.service';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';

interface EmpresaRecord {
  empresa: number;
  'nombre-emp': string;
  'abrenom-emp': string;
  nit: string;
  'direc-emp': string;
  'telefo-emp': string;
  'email-emp': string;
  cia: number;
  [key: string]: any;
}

@Component({
  selector: 'app-empresa-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  template: `
    <div class="modal-overlay" [hidden]="!show" (click)="onClose()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2>Seleccionar Empresa</h2>
          <button class="close-btn" (click)="onClose()">×</button>
        </div>

        <div class="modal-body">
          <div class="search-container">
            <input
              type="text"
              class="search-input"
              placeholder="Buscar por nombre, NIT o empresa..."
              [(ngModel)]="searchTerm"
              (ngModelChange)="filterEmpresas()">
          </div>

          <div class="modal-grid" *ngIf="!isLoading() && empresasList().length > 0">
            <div class="grid-header">
              <div class="col-empresa">Empresa</div>
              <div class="col-nombre">Nombre</div>
              <div class="col-nit">NIT</div>
              <div class="col-action"></div>
            </div>
            <div
              class="grid-row"
              *ngFor="let empresa of filteredEmpresasList(); trackBy: trackByEmpresa">
              <div class="col-empresa">{{ empresa.empresa }}</div>
              <div class="col-nombre">{{ empresa['nombre-emp'] }}</div>
              <div class="col-nit">{{ empresa.nit }}</div>
              <div class="col-action">
                <button
                  class="select-btn"
                  (click)="onSelectEmpresa(empresa)">
                  Seleccionar
                </button>
              </div>
            </div>
          </div>

          <div class="loading-message" *ngIf="isLoading()">
            Cargando empresas...
          </div>

          <div class="no-results" *ngIf="!isLoading() && empresasList().length === 0">
            No se encontraron empresas.
          </div>
        </div>

        <div class="modal-footer">
          <button class="btn-cancel" (click)="onClose()">Cancelar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 1000;
    }

    .modal-overlay[hidden] {
      display: none !important;
    }

    .modal-content {
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      width: 90%;
      max-width: 900px;
      max-height: 90vh;
      display: flex;
      flex-direction: column;
    }

    .modal-header {
      padding: 20px;
      border-bottom: 1px solid #e0e0e0;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .modal-header h2 {
      margin: 0;
      font-size: 18px;
      color: #333;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 24px;
      cursor: pointer;
      color: #666;
      padding: 0;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .close-btn:hover {
      color: #000;
    }

    .modal-body {
      padding: 20px;
      flex: 1;
      overflow-y: auto;
    }

    .search-container {
      margin-bottom: 20px;
    }

    .search-input {
      width: 100%;
      padding: 10px 12px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 14px;
      box-sizing: border-box;
    }

    .search-input:focus {
      outline: none;
      border-color: #0066cc;
      box-shadow: 0 0 0 2px rgba(0, 102, 204, 0.1);
    }

    .modal-grid {
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      overflow: hidden;
    }

    .grid-header {
      display: grid;
      grid-template-columns: 80px 1fr 120px 100px;
      gap: 0;
      background: #f5f5f5;
      font-weight: 600;
      font-size: 12px;
      color: #555;
      padding: 12px;
      border-bottom: 1px solid #ddd;
    }

    .grid-row {
      display: grid;
      grid-template-columns: 80px 1fr 120px 100px;
      gap: 0;
      padding: 12px;
      border-bottom: 1px solid #f0f0f0;
      align-items: center;
      font-size: 13px;
    }

    .grid-row:hover {
      background: #f9f9f9;
    }

    .col-empresa {
      padding-right: 12px;
    }

    .col-nombre {
      padding-right: 12px;
      color: #333;
      font-weight: 500;
    }

    .col-nit {
      padding-right: 12px;
      color: #666;
    }

    .col-action {
      padding-right: 12px;
    }

    .select-btn {
      padding: 6px 12px;
      background: #0066cc;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 12px;
      font-weight: 500;
      transition: background 0.2s;
      width: 100%;
    }

    .select-btn:hover {
      background: #0052a3;
    }

    .loading-message,
    .no-results {
      text-align: center;
      padding: 40px 20px;
      color: #999;
      font-size: 14px;
    }

    .modal-footer {
      padding: 15px 20px;
      border-top: 1px solid #e0e0e0;
      display: flex;
      justify-content: flex-end;
      gap: 10px;
    }

    .btn-cancel {
      padding: 8px 16px;
      background: #f0f0f0;
      color: #333;
      border: 1px solid #ddd;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      font-weight: 500;
      transition: background 0.2s;
    }

    .btn-cancel:hover {
      background: #e0e0e0;
    }
  `],
})
export class EmpresaModalComponent implements OnInit, OnDestroy, OnChanges {
  @Input() show: boolean = false;
  @Input() compania: number | null = null;
  @Output() closeModal = new EventEmitter<void>();
  @Output() empresaSelected = new EventEmitter<EmpresaRecord>();

  searchTerm: string = '';
  isLoading = signal(false);
  empresasList = signal<EmpresaRecord[]>([]);
  filteredEmpresasList = signal<EmpresaRecord[]>([]);

  private destroy$ = new Subject<void>();
  private searchSubject$ = new Subject<string>();

  constructor(private ccService: CCService) {}

  ngOnInit(): void {
    console.log('[EmpresaModal] Component initialized');
    this.searchSubject$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe(() => {
        this.filterEmpresas();
      });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['show'] && !changes['show'].firstChange) {
      console.log('[EmpresaModal] Show changed:', this.show, 'Compania:', this.compania);
      if (this.show && this.compania) {
        this.loadEmpresas();
      }
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadEmpresas(): void {
    if (!this.compania) {
      console.warn('[EmpresaModal] No compania provided');
      return;
    }

    console.log('[EmpresaModal] Loading empresas for compania:', this.compania);
    this.isLoading.set(true);
    this.ccService
      .getCEEmpresa(this.compania.toString())
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          console.log('[EmpresaModal] Response received:', response);
          const empresas = response?.tccempres2 || response || [];
          console.log('[EmpresaModal] Empresas found:', empresas.length);
          this.empresasList.set(empresas);
          this.filteredEmpresasList.set(empresas);
          this.isLoading.set(false);
        },
        error: (err: any) => {
          console.error('[EmpresaModal] Error loading empresas:', err);
          this.isLoading.set(false);
        },
      });
  }

  filterEmpresas(): void {
    const search = this.searchTerm.toLowerCase().trim();
    if (!search) {
      this.filteredEmpresasList.set(this.empresasList());
      return;
    }

    const filtered = this.empresasList().filter((empresa) => {
      return (
        empresa.empresa.toString().includes(search) ||
        empresa['nombre-emp'].toLowerCase().includes(search) ||
        empresa.nit.toLowerCase().includes(search) ||
        empresa['abrenom-emp'].toLowerCase().includes(search)
      );
    });

    this.filteredEmpresasList.set(filtered);
  }

  onSelectEmpresa(empresa: EmpresaRecord): void {
    this.empresaSelected.emit(empresa);
    this.onClose();
  }

  onClose(): void {
    this.searchTerm = '';
    this.closeModal.emit();
  }

  trackByEmpresa(index: number, empresa: EmpresaRecord): number {
    return empresa.empresa;
  }
}
