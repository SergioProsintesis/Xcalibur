// PS5113 - REPORTE FACTURAS SIN CUFE Interfaces

export interface Ps5113Record {
  'cia': number;
  'documento': string;
  'numero-doc': string;
  'fecha-doc'?: string;
  'cliente'?: string;
  'valor-doc'?: number;
  'estado'?: string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CompaniaRecord {
  'cia': number;
  'nombre-cia': string;
  'nit': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface PS5113Response {
  'dsRespuesta': {
    'tps5113'?: Ps5113Record[];
    'tgecias'?: CompaniaRecord[];
  };
}
