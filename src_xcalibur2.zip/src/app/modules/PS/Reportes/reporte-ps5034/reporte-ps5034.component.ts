import { Component } from '@angular/core';
import { ReporteRangoFechasComponent } from '../../../CC/Reportes/reporte-rango-fechas/reporte-rango-fechas.component';

@Component({
  selector: 'app-reporte-ps5034',
  standalone: true,
  imports: [ReporteRangoFechasComponent],
  template: `
    <app-reporte-rango-fechas
      [pcPrograma]="'ps5034'"
      [titulo]="'Notas Rango de Fechas'"
      [rutaVolver]="'/cuentas-por-cobrar'">
    </app-reporte-rango-fechas>
  `
})
export class ReportePS5034Component {}
