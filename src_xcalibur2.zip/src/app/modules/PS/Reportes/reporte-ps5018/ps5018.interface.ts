// PS5018 - REPORTE GASTOS FACTURACION Interfaces

export interface Ps5018Record {
  'cia': number;
  'periodo'?: string;
  'concepto'?: string;
  'valor-gasto'?: number;
  'codigo-gasto'?: string;
  'descripcion'?: string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CompaniaRecord {
  'cia': number;
  'nombre-cia': string;
  'nit': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface PS5018Response {
  'dsRespuesta': {
    'tps5018'?: Ps5018Record[];
    'tgecias'?: CompaniaRecord[];
  };
}
