import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../../environments/environment';
import { AuthService } from '../../../../core/services/auth.service';
import { PS5018Response } from './ps5018.interface';

@Injectable({
  providedIn: 'root'
})
export class Ps5018Service {
  private http = inject(HttpClient);
  private auth = inject(AuthService);

  // ==================== CONSULTAS EMERGENTES ====================

  /**
   * Obtiene lista de compañías
   */
  getCECompanias(): Observable<PS5018Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECompanias?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<PS5018Response>(url);
  }

  /**
   * Obtiene compañías en evento Leave (Cuentas por Cobrar)
   */
  getLeaveGEciasCxC(): Observable<PS5018Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveGEciasCxC?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<PS5018Response>(url);
  }

  // ==================== CONSULTAS ESPECIALIZADAS ====================

  /**
   * Obtiene reporte de gastos de facturación
   * @param pcCompania Código de compañía
   * @param pcFechaD Fecha desde (YYYY-MM-DD)
   * @param pcFechaH Fecha hasta (YYYY-MM-DD)
   * @param pcNombrePlano Nombre de plano para filtrado (opcional)
   */
  getPS5018(pcCompania: number, pcFechaD: string, pcFechaH: string, pcNombrePlano?: string): Observable<PS5018Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    let url = `${environment.apiUrl}/GetPS5018?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcFechaD=${encodeURIComponent(pcFechaD)}&pcFechaH=${encodeURIComponent(pcFechaH)}`;
    
    if (pcNombrePlano) {
      url += `&pcNombrePlano=${encodeURIComponent(pcNombrePlano)}`;
    }
    
    url += `&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    
    return this.http.get<PS5018Response>(url);
  }
}
