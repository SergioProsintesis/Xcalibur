import { Component } from '@angular/core';
import { ReporteRangoFechasComponent } from '../../../CC/Reportes/reporte-rango-fechas/reporte-rango-fechas.component';

@Component({
  selector: 'app-reporte-ps5023',
  standalone: true,
  imports: [ReporteRangoFechasComponent],
  template: `
    <app-reporte-rango-fechas
      [pcPrograma]="'ps5023'"
      [titulo]="'Reporte Facturación OFA por Rango de Fecha'"
      [rutaVolver]="'/cuentas-por-cobrar'">
    </app-reporte-rango-fechas>
  `
})
export class ReportePS5023Component {}
