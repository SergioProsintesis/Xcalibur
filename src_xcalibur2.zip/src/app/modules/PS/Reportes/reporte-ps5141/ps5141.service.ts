import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../../environments/environment';
import { AuthService } from '../../../../core/services/auth.service';
import { PS5141Response, FaingobsRecord } from './ps5141.interface';

@Injectable({
  providedIn: 'root'
})
export class Ps5141Service {
  private http = inject(HttpClient);
  private auth = inject(AuthService);

  // ==================== CONSULTAS EMERGENTES ====================

  /**
   * Obtiene lista de compañías
   */
  getCECompanias(): Observable<PS5141Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECompanias?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<PS5141Response>(url);
  }

  /**
   * Obtiene compañía en evento Leave
   */
  getLeaveCia(pcCompania: number): Observable<PS5141Response> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCia_ps5141?pcCompania=${encodeURIComponent(pcCompania.toString())}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    return this.http.get<PS5141Response>(url);
  }

  // ==================== CRUD OPERATIONS ====================

  /**
   * Actualiza registros de observaciones en inglés
   */
  updateFaingobs(record: FaingobsRecord): Observable<PS5141Response> {
    const url = `${environment.apiUrl}/Updatefaingobs_PS5141`;
    return this.http.put<PS5141Response>(url, { tfaingobs: [record] });
  }
}
