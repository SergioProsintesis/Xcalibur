// PS5141 - PARAMETROS OBSERVACIONES EN INGLES Interfaces

export interface FaingobsRecord {
  'cia': number;
  'codigo': string;
  'nombre-obs': string;
  'descripcion'?: string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface CompaniaRecord {
  'cia': number;
  'nombre-cia': string;
  'nit': string;
  'date-ctrl'?: string;
  'login-ctrl'?: string;
  'tparent'?: string;
}

export interface PS5141Response {
  'dsRespuesta': {
    'tfaingobs'?: FaingobsRecord[];
    'tgecias'?: CompaniaRecord[];
  };
}
