import { Component } from '@angular/core';
import { ReporteRangoFechasComponent } from '../../../CC/Reportes/reporte-rango-fechas/reporte-rango-fechas.component';

@Component({
  selector: 'app-reporte-ps5068',
  standalone: true,
  imports: [ReporteRangoFechasComponent],
  template: `
    <app-reporte-rango-fechas
      [pcPrograma]="'ps5068'"
      [titulo]="'Reporte Relación de Facturas'"
      [rutaVolver]="'/cuentas-por-cobrar'">
    </app-reporte-rango-fechas>
  `
})
export class ReportePS5068Component {}
