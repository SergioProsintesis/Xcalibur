import { Component } from '@angular/core';
import { ReporteRangoFechasComponent } from '../../../CC/Reportes/reporte-rango-fechas/reporte-rango-fechas.component';

@Component({
  selector: 'app-reporte-ps5001',
  standalone: true,
  imports: [ReporteRangoFechasComponent],
  template: `
    <app-reporte-rango-fechas
      [pcPrograma]="'ps5001'"
      [titulo]="'Reporte Moneda Extranjera DANE'"
      [rutaVolver]="'/cuentas-por-cobrar'">
    </app-reporte-rango-fechas>
  `
})
export class ReportePS5001Component {}
