import { Component, OnInit, OnDestroy, NgZone, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { Ge0057Service, Perfil, Opcion, Menu } from './ge0057.service';
import { AuthService } from '../../../../core/services/auth.service';

export interface Usuario {
  login: string;
  nombre: string;
  codper?: string;
}

@Component({
  selector: 'app-ge0057-asignacion-opciones',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './ge0057-asignacion-opciones.component.html',
  styleUrls: ['./ge0057-asignacion-opciones.component.css']
})
export class Ge0057AsignacionOpcionesComponent implements OnInit, OnDestroy {
  // Modal de usuarios
  usuarios: Usuario[] = [];
  usuarioSeleccionado: Usuario | null = null;
  mostrarModalUsuarios = false;
  cargandoUsuarios = false;
  usuarioInput: string = '';

  // Menús/Sistemas
  menus: Menu[] = [];
  menusFiltrados: Menu[] = [];
  menuSeleccionado: Menu | null = null;
  cargandoMenus = false;
  filtroMenus: string = '';

  // Datos principales
  perfiles: Perfil[] = [];
  opciones: Opcion[] = [];
  opcionesFiltradas: Opcion[] = [];
  
  perfilSeleccionado: Perfil | null = null;
  cargandoPerfiles = false;
  cargandoOpciones = false;
  guardando = false;
  filtroOpciones: string = '';
  
  errorMensaje: string = '';
  exitoMensaje: string = '';
  filtroUsuario: string = '';

  // Parámetros de sesión (estos deberían venir de AuthService)
  pcLoginP = 'USER';
  pcSistema = 'GE';
  pcSuper = '1';
  pcToken = '';

  private destroy$ = new Subject<void>();
  private filtroUsuarios$ = new Subject<string>();

  constructor(
    private ge0057Service: Ge0057Service,
    private authService: AuthService,
    private ngZone: NgZone,
    private cdr: ChangeDetectorRef
  ) {
    // Suscribirse a cambios en el filtro del modal con debounce
    this.filtroUsuarios$
      .pipe(
        debounceTime(300),
        distinctUntilChanged(),
        takeUntil(this.destroy$)
      )
      .subscribe(filtro => {
        if (filtro && filtro.trim().length > 0) {
          this.buscarUsuariosEnServidor(filtro);
        }
      });
  }

  ngOnInit(): void {
    // Obtener datos del usuario autenticado
    const usuarioActual = this.authService.user();
    if (usuarioActual) {
      this.pcLoginP = usuarioActual.pcLogin || usuarioActual.username || 'USER';
      this.pcToken = usuarioActual.pcToken || '';
    }
    this.cargarUsuarios();
  }

  /**
   * Carga la lista de usuarios disponibles
   */
  cargarUsuarios(): void {
    this.cargandoUsuarios = true;
    this.errorMensaje = '';
    this.cdr.detectChanges(); // Mostrar spinner inmediatamente
    
    // Hacer la llamada HTTP fuera de ngZone
    this.ngZone.runOutsideAngular(() => {
      this.ge0057Service.obtenerPerfiles(
        this.pcLoginP,
        this.pcSuper,
        this.pcToken
      )
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (data: any[]) => {
          this.ngZone.run(() => {
            // Convertir usuarios del response a nuestra interfaz Usuario
            // Solo incluir usuarios donde Perfil === true
            const usuariosMap = new Map<string, Usuario>();
            data.forEach((user: any) => {
              if (user.login && user.Perfil === true && !usuariosMap.has(user.login)) {
                usuariosMap.set(user.login, {
                  login: user.login,
                  nombre: user['nombre-clav'] || user.nombre || user.login,
                  codper: user.Codper
                });
              }
            });
            this.usuarios = Array.from(usuariosMap.values()).sort((a, b) => 
              a.nombre.localeCompare(b.nombre)
            );
            this.cargandoUsuarios = false;
            this.cdr.detectChanges();
            
            // Seleccionar automáticamente el primer usuario
            if (this.usuarios.length > 0) {
              this.seleccionarUsuario(this.usuarios[0]);
            }
          });
        },
        error: (error) => {
          this.ngZone.run(() => {
            console.error('Error al cargar usuarios:', error);
            this.errorMensaje = 'Error al cargar la lista de usuarios';
            this.cargandoUsuarios = false;
            this.cdr.detectChanges();
          });
        }
      });
    });
  }

  /**
   * Selecciona un usuario del modal y cierra el modal
   */
  seleccionarUsuario(usuario: Usuario): void {
    this.usuarioSeleccionado = usuario;
    this.mostrarModalUsuarios = false;
    this.perfiles = [];
    this.opciones = [];
    this.opcionesFiltradas = [];
    this.menus = [];
    this.menusFiltrados = [];
    this.menuSeleccionado = null;
    this.perfilSeleccionado = null;
    this.filtroUsuario = '';
    this.cargarMenus();
  }

  /**
   * Carga los menús/sistemas disponibles para el usuario seleccionado
   */
  cargarMenus(): void {
    this.cargandoMenus = true;
    this.errorMensaje = '';
    this.filtroMenus = '';
    this.cdr.detectChanges(); // Mostrar spinner inmediatamente
    
    this.ge0057Service.obtenerMenus(
      this.pcLoginP,
      this.usuarioSeleccionado?.login || '',
      this.pcSuper,
      this.pcToken
    )
    .pipe(takeUntil(this.destroy$))
    .subscribe({
      next: (data: any) => {
        try {
          if (!Array.isArray(data)) {
            console.warn('⚠️ Data no es array, asignando array vacío');
            this.menus = [];
            this.menusFiltrados = [];
          } else {
            // Ordenar alfabéticamente por nombre
            const menusOrdenados = data.sort((a: any, b: any) => 
              (a.nombre || a.sistema || '').localeCompare(b.nombre || b.sistema || '')
            );
            this.menus = menusOrdenados;
            this.menusFiltrados = menusOrdenados; // Cachear resultado
          }
          
          this.cargandoMenus = false;
          
          // Forzar que Angular detecte el cambio
          this.ngZone.run(() => {
            this.cdr.detectChanges();
          });
        } catch (e) {
          console.error('💥 ERROR en el procesamiento de menus:', e);
          this.cargandoMenus = false;
          this.errorMensaje = 'Error al procesar los menús';
          this.ngZone.run(() => this.cdr.detectChanges());
        }
      },
      error: (error) => {
        console.error('❌ ERROR al cargar menús:', error);
        this.errorMensaje = 'Error al cargar la lista de menús/sistemas';
        this.cargandoMenus = false;
        this.ngZone.run(() => this.cdr.detectChanges());
      }
    });
  }

  /**
   * Busca usuarios en el servidor según el filtro ingresado en el modal
   */
  buscarUsuariosEnServidor(filtro: string): void {
    this.cargandoUsuarios = true;
    
    this.ge0057Service.obtenerPerfiles(
      this.pcLoginP,
      this.pcSuper,
      this.pcToken,
      filtro
    )
    .pipe(takeUntil(this.destroy$))
    .subscribe({
      next: (data: any[]) => {
        const usuariosMap = new Map<string, Usuario>();
        data.forEach((user: any) => {
          // Solo incluir usuarios donde Perfil === true
          if (user.login && user.Perfil === true && !usuariosMap.has(user.login)) {
            usuariosMap.set(user.login, {
              login: user.login,
              nombre: user['nombre-clav'] || user.nombre || user.login,
              codper: user.Codper
            });
          }
        });
        this.usuarios = Array.from(usuariosMap.values()).sort((a, b) => 
          a.nombre.localeCompare(b.nombre)
        );
        this.cargandoUsuarios = false;
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error al buscar usuarios:', error);
        this.cargandoUsuarios = false;
        this.cdr.detectChanges();
      }
    });
  }

  /**
   * Dispara la búsqueda cuando el usuario escribe en el filtro del modal
   */
  onFiltroChange(valor: string): void {
    this.filtroUsuarios$.next(valor);
  }

  /**
   * Selecciona un menú/sistema y carga las opciones
   */
  seleccionarMenu(menu: Menu): void {
    this.menuSeleccionado = menu;
    this.pcSistema = menu.sistema;
    this.opciones = [];
    this.cargarOpciones();
  }

  /**
   * Carga las opciones disponibles para el menú seleccionado
   */
  cargarOpciones(): void {
    if (!this.menuSeleccionado || !this.usuarioSeleccionado) {
      this.errorMensaje = 'Debe seleccionar un sistema y usuario';
      return;
    }

    // Guardar en variables locales para TypeScript
    const usuarioLogin = this.usuarioSeleccionado.login;
    const sistema = this.menuSeleccionado.sistema;

    this.cargandoOpciones = true;
    this.errorMensaje = '';
    this.filtroOpciones = '';
    this.opciones = [];
    this.opcionesFiltradas = [];
    this.cdr.detectChanges(); // Mostrar spinner inmediatamente
    
    console.log('🔄 INICIANDO cargarOpciones');
    
    this.ge0057Service.obtenerOpciones(
      usuarioLogin,
      sistema,
      this.pcLoginP,
      this.pcSuper,
      this.pcToken
    )
    .pipe(takeUntil(this.destroy$))
    .subscribe({
      next: (data: any) => {
        console.log('✅ OPCIONES RECIBIDAS:', data);
        // El servicio retorna opciones mapeadas
        if (data && Array.isArray(data)) {
          // Ordenar alfabéticamente por nombre
          const opcionesOrdenadas = data.sort((a, b) => 
            (a.nombreOpcion || a.nombre || a.pcOpcion).localeCompare(b.nombreOpcion || b.nombre || b.pcOpcion)
          );
          this.opciones = opcionesOrdenadas;
          this.opcionesFiltradas = opcionesOrdenadas; // Cachear resultado
        }
        this.cargandoOpciones = false;
        console.log('🎯 cargandoOpciones = false, opciones.length =', this.opciones.length);
        
        // Forzar que Angular detecte el cambio
        this.ngZone.run(() => {
          this.cdr.detectChanges();
        });
      },
      error: (error) => {
        console.error('❌ ERROR al cargar opciones:', error);
        this.errorMensaje = 'Error al cargar las opciones del sistema';
        this.cargandoOpciones = false;
        console.log('🎯 cargandoOpciones = false (después del error)');
        this.ngZone.run(() => this.cdr.detectChanges());
      }
    });
  }

  /**
   * Carga la lista de perfiles para el usuario y menú seleccionados
   */
  cargarPerfilesPorUsuario(): void {
    if (!this.usuarioSeleccionado) {
      this.errorMensaje = 'Debe seleccionar un usuario';
      this.mostrarModalUsuarios = true;
      return;
    }

    if (!this.menuSeleccionado) {
      this.errorMensaje = 'Debe seleccionar un menú/sistema';
      return;
    }

    this.cargandoPerfiles = true;
    this.errorMensaje = '';
    
    // Cargar perfiles para el usuario seleccionado
    this.ge0057Service.obtenerPerfiles(
      this.pcLoginP,
      this.pcSuper,
      this.pcToken
    )
    .pipe(takeUntil(this.destroy$))
    .subscribe({
      next: (data: any) => {
        this.perfiles = Array.isArray(data) ? data : [data];
        this.cargandoPerfiles = false;
      },
      error: (error) => {
        console.error('Error al cargar perfiles:', error);
        this.errorMensaje = 'Error al cargar la lista de perfiles del usuario';
        this.cargandoPerfiles = false;
      }
    });
  }

  /**
   * Abre el modal de usuarios nuevamente
   */
  cambiarUsuario(): void {
    this.mostrarModalUsuarios = true;
    this.filtroUsuario = '';
  }

  /**
   * Obtiene usuarios filtrados por búsqueda
   */
  getUsuariosFiltrados(): Usuario[] {
    if (!this.filtroUsuario) {
      return this.usuarios;
    }
    const filtro = this.filtroUsuario.toLowerCase();
    return this.usuarios.filter(u => 
      u.login.toLowerCase().includes(filtro) || 
      u.nombre.toLowerCase().includes(filtro)
    );
  }

  /**
   * Guarda las opciones seleccionadas para el menú
   * Recorre todas las opciones seleccionadas y las guarda
   */
  guardarOpciones(): void {
    if (!this.usuarioSeleccionado) {
      this.errorMensaje = 'Debe seleccionar un usuario';
      return;
    }

    if (!this.menuSeleccionado) {
      this.errorMensaje = 'Debe seleccionar un sistema/menú';
      return;
    }

    if (this.opciones.length === 0) {
      this.errorMensaje = 'No hay opciones para guardar';
      return;
    }

    // Recorrer todas las opciones seleccionadas
    const opcionesSeleccionadas = this.opciones
      .filter(op => op.seleccionada)
      .map(op => ({
        nombre: op.nombreOpcion,
        codigo: op.pcOpcion,
        asignado: true
      }));

    if (opcionesSeleccionadas.length === 0) {
      this.errorMensaje = 'Debe seleccionar al menos una opción para guardar';
      return;
    }

    console.log('Guardando opciones:', {
      usuario: this.usuarioSeleccionado,
      menu: this.menuSeleccionado,
      opciones: opcionesSeleccionadas
    });

    this.guardando = true;
    this.errorMensaje = '';
    this.exitoMensaje = '';

    this.ge0057Service.guardarOpcionesPerfil(
      this.usuarioSeleccionado.login,
      this.menuSeleccionado.sistema,
      this.pcLoginP,
      this.pcSuper,
      this.pcToken,
      opcionesSeleccionadas.map(o => o.codigo)
    )
    .pipe(takeUntil(this.destroy$))
    .subscribe({
      next: (respuesta: any) => {
        this.guardando = false;
        this.exitoMensaje = `Se guardaron ${opcionesSeleccionadas.length} opciones correctamente para el sistema "${this.menuSeleccionado?.nombre}"`;
        setTimeout(() => {
          this.exitoMensaje = '';
        }, 4000);
      },
      error: (error) => {
        console.error('Error al guardar opciones:', error);
        this.errorMensaje = 'Error al guardar las opciones: ' + (error.error?.mensaje || error.message);
        this.guardando = false;
      }
    });
  }

  /**
   * Limpia la selección de opciones
   */
  limpiar(): void {
    this.opciones.forEach(op => op.seleccionada = false);
    this.errorMensaje = '';
    this.exitoMensaje = '';
  }

  /**
   * Selecciona o deselecciona todas las opciones
   */
  toggleTodasOpciones(event: any): void {
    const esSeleccionado = event.target.checked;
    this.opciones.forEach(op => op.seleccionada = esSeleccionado);
  }

  /**
   * Verifica si todas las opciones están seleccionadas
   */
  todasSeleccionadas(): boolean {
    return this.opciones.length > 0 && this.opciones.every(op => op.seleccionada);
  }

  /**
   * Verifica si hay opciones sin seleccionar
   */
  algunaSeleccionada(): boolean {
    return this.opciones.some(op => op.seleccionada);
  }

  /**
   * Obtiene el conteo de opciones seleccionadas
   */
  conteoSeleccionadas(): number {
    return this.opciones.filter(op => op.seleccionada).length;
  }

  /**
   * Cierra el modal de selección de usuario
   */
  cerrarModal(): void {
    this.mostrarModalUsuarios = false;
  }

  /**
   * Abre el modal de selección de usuario
   */
  abrirModalUsuarios(): void {
    this.mostrarModalUsuarios = true;
    this.filtroUsuario = '';
    this.usuarioInput = '';
  }

  /**
   * Busca un usuario por el texto ingresado en el input
   */
  buscarUsuarioPorInput(): void {
    if (!this.usuarioInput.trim()) {
      this.errorMensaje = 'Por favor ingresa un usuario';
      return;
    }

    const usuarioEncontrado = this.usuarios.find(u => 
      u.login.toLowerCase() === this.usuarioInput.toLowerCase() ||
      u.nombre.toLowerCase().includes(this.usuarioInput.toLowerCase())
    );

    if (usuarioEncontrado) {
      this.seleccionarUsuario(usuarioEncontrado);
      this.usuarioInput = '';
    } else {
      this.errorMensaje = `No se encontró un usuario con "${this.usuarioInput}"`;
      this.usuarioSeleccionado = null;
      this.perfiles = [];
      this.opciones = [];
    }
  }

  /**
   * Selecciona un usuario del modal por filtro (Enter key)
   */
  seleccionarUsuarioPorFiltro(): void {
    const usuariosFiltrados = this.getUsuariosFiltrados();
    if (usuariosFiltrados.length === 1) {
      this.seleccionarUsuario(usuariosFiltrados[0]);
    } else if (usuariosFiltrados.length === 0) {
      this.errorMensaje = 'No se encontró el usuario en el modal';
    } else {
      this.errorMensaje = 'Hay múltiples usuarios que coinciden. Selecciona uno de la lista';
    }
  }

  /**
   * Limpia la selección de usuario y vuelve al estado inicial
   */
  limpiarUsuario(): void {
    this.usuarioSeleccionado = null;
    this.usuarioInput = '';
    this.filtroUsuario = '';
    this.perfiles = [];
    this.opciones = [];
    this.perfilSeleccionado = null;
    this.errorMensaje = '';
    this.exitoMensaje = '';
    this.abrirModalUsuarios();
  }

  /**
   * TrackBy para usuarios - mejora el rendimiento del *ngFor
   */
  trackByUsuario(index: number, usuario: Usuario): string {
    return usuario.login;
  }

  /**
   * TrackBy para menús - mejora el rendimiento del *ngFor
   */
  trackByMenu(index: number, menu: Menu): string {
    return menu.sistema;
  }

  /**
   * TrackBy para opciones - mejora el rendimiento del *ngFor
   */
  trackByOpcion(index: number, opcion: Opcion): string {
    return opcion.pcOpcion;
  }

  /**
   * Filtra menus según el texto ingresado
   */
  getMenusFiltrados(): Menu[] {
    return this.menusFiltrados;
  }

  /**
   * Actualiza el caché de menús filtrados
   */
  actualizarFiltroMenus(): void {
    if (!this.filtroMenus || this.filtroMenus.trim().length === 0) {
      this.menusFiltrados = this.menus;
    } else {
      const filtro = this.filtroMenus.toLowerCase();
      this.menusFiltrados = this.menus.filter(menu => 
        (menu.nombre || '').toLowerCase().includes(filtro) ||
        (menu.sistema || '').toLowerCase().includes(filtro) ||
        (menu.descripcion || '').toLowerCase().includes(filtro)
      );
    }
  }

  /**
   * Actualiza el caché de opciones filtradas
   */
  actualizarFiltroOpciones(): void {
    if (!this.filtroOpciones || this.filtroOpciones.trim().length === 0) {
      this.opcionesFiltradas = this.opciones;
    } else {
      const filtro = this.filtroOpciones.toLowerCase();
      this.opcionesFiltradas = this.opciones.filter(opcion => 
        (opcion.nombreOpcion || '').toLowerCase().includes(filtro) ||
        (opcion.pcOpcion || '').toLowerCase().includes(filtro) ||
        (opcion.clase || '').toLowerCase().includes(filtro)
      );
    }
  }

  /**
   * Filtra opciones según el texto ingresado
   */
  getOpcionesFiltradas(): Opcion[] {
    return this.opcionesFiltradas;
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
