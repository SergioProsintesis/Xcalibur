import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export interface Perfil {
  pcLogin: string;
  nombrePerfil: string;
  estado?: string;
}

export interface Opcion {
  pcOpcion: string;
  nombreOpcion: string;
  clase?: string;
  asignado?: boolean;
  seleccionada: boolean;
}

export interface Menu {
  sistema: string;
  nombre: string;
  descripcion: string;
  nombreCompleto?: string;
}

export interface RespuestaLeaveOpciones {
  opciones: Opcion[];
}

export interface RespuestaUpdateGeacceso {
  success: boolean;
  mensaje?: string;
}

@Injectable({
  providedIn: 'root'
})
export class Ge0057Service {
  private baseUrl = 'http://184.168.30.44:8810/XcaliburWeb/rest/ServiciosXcaliburWeb';

  constructor(private http: HttpClient) { }

  /**
   * Obtiene la lista de perfiles de usuarios con filtro opcional
   * Parámetros requeridos: pcLogin, pcSuper, pcToken
   */
  obtenerPerfiles(
    pcLogin: string,
    pcSuper: string,
    pcToken: string,
    pcFiltro?: string
  ): Observable<any[]> {
    let params = new HttpParams()
      .set('pcLogin', pcLogin)
      .set('pcSuper', pcSuper)
      .set('pcToken', pcToken);

    // Si hay filtro, agregarlo a los parámetros
    if (pcFiltro && pcFiltro.trim()) {
      params = params.set('pcFiltro', pcFiltro);
    }

    return this.http.get<any>(
      `${this.baseUrl}/GetCEUsuarios`,
      { params }
    ).pipe(
      map(response => {
        // El API retorna un objeto con dsRespuesta que contiene tgeclaves2
        if (response && response.dsRespuesta && response.dsRespuesta.tgeclaves2 && Array.isArray(response.dsRespuesta.tgeclaves2)) {
          return response.dsRespuesta.tgeclaves2;
        }
        // Si está directamente en tgeclaves2
        if (response && response.tgeclaves2 && Array.isArray(response.tgeclaves2)) {
          return response.tgeclaves2;
        }
        // Si no está en ninguno, devolver el response original si es un array
        if (Array.isArray(response)) {
          return response;
        }
        // Si no es un array, devolver array vacío
        return [];
      })
    );
  }

  /**
   * Obtiene los sistemas/menús disponibles para un usuario
   * Parámetros: pcLogin (usuario autenticado), pLoginP (usuario seleccionado), pcSuper, pcToken
   */
  obtenerMenus(
    pcLogin: string,
    pLoginP: string,
    pcSuper: string,
    pcToken: string
  ): Observable<Menu[]> {
    let params = new HttpParams()
      .set('pcLogin', pcLogin)
      .set('pcLoginP', pLoginP)
      .set('pcSuper', pcSuper)
      .set('pcToken', pcToken);

    console.log('🌐 HTTP GET: GetLeaveLogin-GE0057 con params:', {
      pcLogin, pLoginP, pcSuper, pcToken
    });

    return this.http.get<any>(
      `${this.baseUrl}/GetLeaveLogin-GE0057`,
      { params }
    ).pipe(
      map(response => {
        console.log('📨 RESPUESTA RAW de GetLeaveLogin-GE0057:', response);
        
        // Intentar múltiples rutas de acceso a los datos
        let items: any[] = [];
        
        if (response && response.dsRespuesta && Array.isArray(response.dsRespuesta.tgetabsis2)) {
          items = response.dsRespuesta.tgetabsis2;
          console.log('✓ Items encontrados en dsRespuesta.tgetabsis2');
        } else if (response && Array.isArray(response.tgetabsis2)) {
          items = response.tgetabsis2;
          console.log('✓ Items encontrados en tgetabsis2');
        } else if (Array.isArray(response)) {
          items = response;
          console.log('✓ Response es directamente un array');
        } else {
          console.log('⚠️ No se encontró estructura esperada en response');
        }
        
        console.log(`📦 Items antes de map: ${items.length} items`);
        
        if (!items || items.length === 0) {
          console.log('⚠️ Items vacío, retornando array vacío');
          return [];
        }
        
        // Mapear a la interfaz Menu
        const mappedMenus = items.map((item: any) => ({
          sistema: item.sistema || '',
          nombre: item['nombre-sis'] || item.nombre || '',
          descripcion: item['text-sis'] || item.descripcion || '',
          nombreCompleto: `${item.sistema || ''} - ${item['nombre-sis'] || item.nombre || ''}`
        }));
        
        console.log('🎯 Menus mapeados:', mappedMenus);
        return mappedMenus;
      })
    );
  }

  /**
   * Obtiene las opciones disponibles para un sistema y usuario
   */
  obtenerOpciones(
    pcLoginP: string,
    pcSistema: string,
    pcLogin: string,
    pcSuper: string,
    pcToken: string
  ): Observable<any[]> {
    const params = new HttpParams()
      .set('pcLoginP', pcLoginP)
      .set('pcSistema', pcSistema)
      .set('pcLogin', pcLogin)
      .set('pcSuper', pcSuper)
      .set('pcToken', pcToken);

    return this.http.get<any>(
      `${this.baseUrl}/GetLeaveOpciones-GE0057`,
      { params }
    ).pipe(
      map(response => {
        // El API retorna { dsRespuesta: { topciones: [...] } } o un array directo
        let items: any[] = [];
        
        if (response && response.dsRespuesta && Array.isArray(response.dsRespuesta.topciones)) {
          items = response.dsRespuesta.topciones;
        } else if (response && Array.isArray(response.topciones)) {
          items = response.topciones;
        } else if (Array.isArray(response)) {
          items = response;
        }
        
        // Mapear opciones a nuestra interfaz Opcion con los campos reales: Nombre, Clase, Asignado
        return items.map((item: any) => ({
          pcOpcion: item.Programa || item.pcOpcion || item.Clase || '',
          nombreOpcion: item.Nombre || item.nombreOpcion || '',
          clase: item.Clase || '',
          asignado: item.Asignado === true || item.asignado === true,
          seleccionada: item.Asignado === true || item.asignado === true
        }));
      })
    );
  }

  /**
   * Guarda las opciones asignadas a un perfil
   */
  guardarOpcionesPerfil(
    pcLoginP: string,
    pcSistema: string,
    pcLogin: string,
    pcSuper: string,
    pcToken: string,
    opcionesSeleccionadas: string[]
  ): Observable<RespuestaUpdateGeacceso> {
    const params = new HttpParams()
      .set('pcLoginP', pcLoginP)
      .set('pcSistema', pcSistema)
      .set('pcLogin', pcLogin)
      .set('pcSuper', pcSuper)
      .set('pcToken', pcToken);

    const payload = {
      opciones: opcionesSeleccionadas
    };

    return this.http.put<RespuestaUpdateGeacceso>(
      `${this.baseUrl}/UpdateGeacceso_GE0057`,
      payload,
      { params }
    );
  }
}
