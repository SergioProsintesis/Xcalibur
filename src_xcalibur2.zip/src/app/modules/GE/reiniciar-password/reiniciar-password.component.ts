import { Component, OnInit, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpParams } from '@angular/common/http';

import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { ModalService } from '../../../core/services/modal.service';
import { ConfirmationDialogComponent } from "../../../shared/components/confirmation-dialog";
import { GeclavesService } from '../../../core/services/geclaves.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';


@Component({
  selector: 'app-reiniciar-password',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, ConfirmationDialogComponent],
  templateUrl: './reiniciar-password.component.html',
  styleUrls: ['./reiniciar-password.component.css']
})
export class ReiniciarPasswordComponent implements OnInit {
  private programContext = inject(ProgramContextService);

  form: FormGroup;
  isLoading = signal(false);
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Reiniciar Password`);

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private authService: AuthService,
    private toastService: ToastService,
    private geclavesService: GeclavesService,
    private loading: LoadingService
  ) {
    this.form = this.fb.group({
      fechaProceso: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadFechaProceso();
  }

  /** 🔹 Carga la fecha actual desde el servicio GET */
  loadFechaProceso(): void {
    this.isLoading.set(true);
    this.loading.show();
    this.geclavesService.getFechaProceso().subscribe({
      next: (rec) => {
        this.isLoading.set(false);
        this.loading.hide();

        const fecha = rec?.['fecini-clav'] || rec?.['Fecpass'] || null;
        if (fecha) {
          this.form.patchValue({ fechaProceso: fecha });
          this.toastService.showSuccess('Fecha cargada correctamente');
        } else {
          this.toastService.showInfo('No se encontró una fecha válida, seleccione una nueva.');
        }
      },
      error: (err) => {
        this.isLoading.set(false);
        this.loading.hide();
        console.error('❌ Error al obtener fecha', err);
        this.toastService.showError('Error al cargar la fecha de proceso');
      }
    });
  }

  /** 🔹 Actualiza la fecha usando PUT */
  onSubmit(): void {
    if (this.form.invalid) {
      this.toastService.showWarning('Debe seleccionar una fecha válida');
      return;
    }
    const fecha = this.form.get('fechaProceso')?.value;
    this.isLoading.set(true);
    this.loading.show();
    this.geclavesService.reiniciar(fecha).subscribe({
      next: (rec) => {
        this.isLoading.set(false);
        this.loading.hide();
        const mensaje = rec?.terrores?.[0]?.descripcion || 'Actualización exitosa';
        this.toastService.showSuccess(mensaje);
      },
      error: (err) => {
        this.isLoading.set(false);
        this.loading.hide();
        console.error('❌ Error al actualizar fecha', err);
        this.toastService.showError('Error al actualizar la fecha de proceso');
      }
    });
  }

  /** 🔹 Limpia el campo */
  onClear(): void {
    this.form.reset();
  }
}
