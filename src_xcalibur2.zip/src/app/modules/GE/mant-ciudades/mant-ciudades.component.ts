import { Component, inject, signal, OnInit, computed } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { AuthService } from '../../../core/services/auth.service';
import { GeclavesCiudadService } from '../../../core/services/geclaves-ciudad.service';
import { CiudadRecord, PaisRecord } from '../../../core/interfaces/ge-ciudad.interface';
import { PaisModalComponent } from './pais-modal/pais-modal.component';
import { CiudadModalComponent } from './ciudad-modal/ciudad-modal.component';

@Component({
  selector: 'app-mant-ciudades',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, PaisModalComponent, CiudadModalComponent],
  templateUrl: './mant-ciudades.component.html',
  styleUrls: ['./mant-ciudades.component.css']
})
export class MantCiudadesComponent implements OnInit {
  private fb = inject(FormBuilder);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private auth = inject(AuthService);
  private geclavesCiudadService = inject(GeclavesCiudadService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);

  ciudadForm!: FormGroup;
  createCiudadForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Ciudad`);
  loadingState = signal<boolean>(false);

  // Datos actuales
  paisSeleccionado = signal<PaisRecord | null>(null);
  ciudadSeleccionada = signal<CiudadRecord | null>(null);

  // Control de modales y formularios
  showCreateModal = signal(false);
  showPaisModal = signal(false);
  showCiudadModal = signal(false);
  showReportModal = signal(false);
  isEditMode = signal(false);
  paisesDisponibles = signal<PaisRecord[]>([]);
  ciudadesDisponibles = signal<CiudadRecord[]>([]);

  // Datos de reporte
  reportResponse: any = null;

  ngOnInit() {
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    this.cargarPaises();
  }

  private initializeForm(): void {
    this.ciudadForm = this.fb.group({
      pais: ['', [Validators.required]],
      'nombre-pai': [{ value: '', disabled: true }],
      ciudad: ['', [Validators.required]],
      'nombre-ciu': ['', [Validators.required]],
      'text-ciu': [''],

      'date-ctrl': [{ value: '', disabled: true }],
      'login-ctrl': [{ value: '', disabled: true }],
      'tparent': [{ value: '', disabled: true }]
    });

    this.createCiudadForm = this.fb.group({
      pais: ['', [Validators.required]],
      'nombre-pai': [{ value: '', disabled: true }],
      ciudad: ['', [Validators.required, Validators.pattern(/^[0-9]+$/)]],
      'nombre-ciu': ['', [Validators.required]],
      'text-ciu': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string, formGroup: FormGroup = this.ciudadForm): boolean {
    const field = formGroup.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string, formGroup: FormGroup = this.ciudadForm): string {
    const field = formGroup.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['pattern']) return 'Solo se aceptan números';
    
    return 'Campo inválido';
  }

  // ==================== CARGA DE DATOS ====================
  private cargarPaises(): void {
    this.loadingState.set(true);
    this.geclavesCiudadService.getCEPais().subscribe({
      next: (res) => {
        this.paisesDisponibles.set(res?.dsRespuesta?.tgepais || []);
        this.loadingState.set(false);
      },
      error: (err) => {
        this.toastService.showError('Error al cargar países');
        this.loadingState.set(false);
      }
    });
  }

  private cargarCiudades(pais: string): void {
    this.loadingState.set(true);
    this.geclavesCiudadService.getCECiudad(pais).subscribe({
      next: (res) => {
        this.ciudadesDisponibles.set(res?.dsRespuesta?.tgeciudad || []);
        this.loadingState.set(false);
      },
      error: (err) => {
        this.toastService.showError('Error al cargar ciudades');
        this.loadingState.set(false);
      }
    });
  }

  // ==================== EVENTOS DEL FORMULARIO ====================
  async openPaisModal(): Promise<void> {
    try {
      this.loadingState.set(true);
      
      // Cargar países si no están disponibles
      if (this.paisesDisponibles().length === 0) {
        const response = await this.geclavesCiudadService.getCEPais().toPromise();
        const paises = response?.dsRespuesta?.tgepais || [];
        this.paisesDisponibles.set(paises);
      }
      
      // Abrir modal
      this.showPaisModal.set(true);
    } catch (error) {
      console.error('Error loading paises:', error);
      this.toastService.showError('Error al cargar los países');
    } finally {
      this.loadingState.set(false);
    }
  }

  closePaisModal(): void {
    this.showPaisModal.set(false);
  }

  onPaisSelected(pais: PaisRecord): void {
    this.paisSeleccionado.set(pais);
    this.ciudadForm.patchValue({
      pais: pais.pais,
      'nombre-pai': pais['nombre-pai']
    });
    this.cargarCiudades(pais.pais);
    this.limpiarCiudad();
    this.closePaisModal();
  }

  // ==================== MODAL DE CIUDAD ====================
  async openCiudadModal(): Promise<void> {
    const paisValue = this.ciudadForm.get('pais')?.value;
    
    if (!paisValue) {
      this.toastService.showWarning('Seleccione primero un país');
      return;
    }

    try {
      this.loadingState.set(true);
      
      // Cargar ciudades si no están disponibles
      if (this.ciudadesDisponibles().length === 0) {
        const response = await this.geclavesCiudadService.getCECiudad(paisValue).toPromise();
        const ciudades = response?.dsRespuesta?.tgeciudad || [];
        this.ciudadesDisponibles.set(ciudades);
      }
      
      // Abrir modal
      this.showCiudadModal.set(true);
    } catch (error) {
      console.error('Error loading ciudades:', error);
      this.toastService.showError('Error al cargar las ciudades');
    } finally {
      this.loadingState.set(false);
    }
  }

  closeCiudadModal(): void {
    this.showCiudadModal.set(false);
  }

  onCiudadSelected(ciudad: CiudadRecord): void {
    this.ciudadSeleccionada.set(ciudad);
    this.ciudadForm.patchValue({
      ciudad: ciudad.ciudad,
      'nombre-ciu': ciudad['nombre-ciu'],
      'text-ciu': ciudad['text-ciu'],
      'date-ctrl': ciudad['date-ctrl'] || '',
      'login-ctrl': ciudad['login-ctrl'] || '',
      'tparent': ciudad['tparent'] || ''
    });
    this.isEditMode.set(true);
    this.closeCiudadModal();
  }

  async onPaisLeave(): Promise<void> {
    const paisValue = this.ciudadForm.get('pais')?.value;
    
    if (!paisValue) {
      this.limpiarPais();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.geclavesCiudadService.getLeavePais(paisValue).toPromise();
      
      if (response?.dsRespuesta?.tgepais && response.dsRespuesta.tgepais.length > 0) {
        const pais = response.dsRespuesta.tgepais[0];
        this.paisSeleccionado.set(pais);
        this.ciudadForm.patchValue({
          'nombre-pai': pais['nombre-pai']
        });
        this.cargarCiudades(paisValue);
        this.limpiarCiudad();
      } else {
        this.toastService.showError('País no encontrado');
        this.limpiarPais();
      }
    } catch (error) {
      console.error('Error al buscar país:', error);
      this.toastService.showError('Error al buscar el país');
      this.limpiarPais();
    } finally {
      this.loadingState.set(false);
    }
  }

  async onCiudadLeave(): Promise<void> {
    const paisValue = this.ciudadForm.get('pais')?.value;
    const ciudadValue = this.ciudadForm.get('ciudad')?.value;
    
    if (!paisValue || !ciudadValue) {
      this.limpiarCiudad();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.geclavesCiudadService.getLeaveCiudad(paisValue, ciudadValue).toPromise();
      
      if (response?.dsRespuesta?.tgeciudad && response.dsRespuesta.tgeciudad.length > 0) {
        const ciudad = response.dsRespuesta.tgeciudad[0];
        this.ciudadSeleccionada.set(ciudad);
        this.isEditMode.set(true);
        this.ciudadForm.patchValue({
          'nombre-ciu': ciudad['nombre-ciu'],
          'text-ciu': ciudad['text-ciu'],
          'date-ctrl': ciudad['date-ctrl'] || '',
          'login-ctrl': ciudad['login-ctrl'] || '',
          'tparent': ciudad['tparent'] || ''
        });
      } else {
        this.toastService.showError('Ciudad no encontrada');
        this.limpiarCiudad();
      }
    } catch (error) {
      console.error('Error al buscar ciudad:', error);
      this.toastService.showError('Error al buscar la ciudad');
      this.limpiarCiudad();
    } finally {
      this.loadingState.set(false);
    }
  }

  private limpiarPais(): void {
    this.paisSeleccionado.set(null);
    this.ciudadForm.patchValue({
      'nombre-pai': '',
      ciudad: '',
      'nombre-ciu': ''
    });
    this.ciudadesDisponibles.set([]);
    this.limpiarCiudad();
  }

  private limpiarCiudad(): void {
    this.ciudadSeleccionada.set(null);
    this.isEditMode.set(false);
    this.ciudadForm.patchValue({
      ciudad: '',
      'nombre-ciu': '',
      'text-ciu': '',
      'idioma-ciu': '',
      'agrega-ciud': '',
      'date-ctrl': '',
      'login-ctrl': '',
      'tparent': ''
    });
  }

  // ==================== CRUD OPERATIONS ====================
  onSubmit(): void {
    if (this.ciudadForm.invalid || !this.isEditMode()) {
      this.toastService.showWarning('Complete los campos requeridos');
      return;
    }

    this.loadingState.set(true);
    const formValue = this.ciudadForm.getRawValue();
    
    const payload = {
      tgeciudad: [{
        'ciudad': formValue.ciudad,
        'date-ctrl': formValue['date-ctrl'] || new Date().toISOString().split('T')[0],
        'login-ctrl': formValue['login-ctrl'] || this.auth.user()?.pcLogin || '',
        'nombre-ciu': formValue['nombre-ciu'],
        'pais': formValue.pais,
        'nombre-pai': formValue['nombre-pai'],
        'text-ciu': formValue['text-ciu'] || '',
        'tparent': formValue['tparent'] || this.auth.user()?.pcSuper || ''
      }]
    };

    this.geclavesCiudadService.updateCiudad(payload).subscribe({
      next: (res) => {
        this.toastService.showSuccess('Ciudad actualizada correctamente');
        this.cargarCiudades(formValue.pais);
        this.loadingState.set(false);
      },
      error: (err) => {
        this.toastService.showError('Error al actualizar ciudad');
        this.loadingState.set(false);
      }
    });
  }

  onDelete(): void {
    if (!this.isEditMode()) {
      this.toastService.showWarning('Seleccione una ciudad para eliminar');
      return;
    }

    if (!confirm('¿Está seguro que desea eliminar esta ciudad?')) {
      return;
    }

    this.loadingState.set(true);
    const paisValue = this.ciudadForm.get('pais')?.value;
    const ciudadValue = this.ciudadForm.get('ciudad')?.value;

    this.geclavesCiudadService.deleteCiudad(paisValue, ciudadValue).subscribe({
      next: (res) => {
        this.toastService.showSuccess('Ciudad eliminada correctamente');
        this.onClear();
        this.cargarCiudades(paisValue);
        this.loadingState.set(false);
      },
      error: (err) => {
        this.toastService.showError('Error al eliminar ciudad');
        this.loadingState.set(false);
      }
    });
  }

  onClear(): void {
    this.ciudadForm.reset();
    this.limpiarCiudad();
  }

  // ==================== MODALES ====================
  openCreateModal(): void {
    if (!this.ciudadForm.get('pais')?.value) {
      this.toastService.showWarning('Seleccione un país primero');
      return;
    }

    this.createCiudadForm.patchValue({
      pais: this.ciudadForm.get('pais')?.value,
      'nombre-pai': this.ciudadForm.get('nombre-pai')?.value
    });
    this.showCreateModal.set(true);
  }

  closeCreateModal(): void {
    this.showCreateModal.set(false);
    this.createCiudadForm.reset();
  }

  onCreateSubmit(): void {
    if (this.createCiudadForm.invalid) {
      this.toastService.showWarning('Complete los campos requeridos correctamente');
      return;
    }

    this.loadingState.set(true);
    const formValue = this.createCiudadForm.getRawValue();
    
    const payload = {
      tgeciudad: [{
        'ciudad': formValue.ciudad,
        'date-ctrl': new Date().toISOString().split('T')[0],
        'login-ctrl': this.auth.user()?.pcLogin || '',
        'nombre-ciu': formValue['nombre-ciu'],
        'pais': formValue.pais,
        'nombre-pai': formValue['nombre-pai'],
        'text-ciu': formValue['text-ciu'] || '',
        'tparent': this.auth.user()?.pcSuper || ''
      }]
    };

    this.geclavesCiudadService.updateCiudad(payload).subscribe({
      next: (res) => {
        this.toastService.showSuccess('Ciudad creada correctamente');
        this.closeCreateModal();
        const paisValue = this.ciudadForm.get('pais')?.value;
        this.cargarCiudades(paisValue);
        this.loadingState.set(false);
      },
      error: (err) => {
        this.toastService.showError('Error al crear ciudad');
        this.loadingState.set(false);
      }
    });
  }

  // ==================== REPORTE GE2012 - REPORTE DE CIUDADES ====================
  /**
   * Genera el reporte de ciudades en formato CSV o PDF
   * Consume el endpoint GE2012 que retorna archivos en base64
   */
  async onGenerateReport(): Promise<void> {
    const paisValue = this.ciudadForm.get('pais')?.value;
    
    if (!paisValue) {
      this.toastService.showWarning('Seleccione un país para generar el reporte');
      return;
    }

    try {
      this.loadingState.set(true);
      
      // Usar la fecha actual en formato YYYY-MM-DD
      const hoy = new Date();
      const pcFecha = `${hoy.getFullYear()}-${String(hoy.getMonth() + 1).padStart(2, '0')}-${String(hoy.getDate()).padStart(2, '0')}`;
      
      const response = await this.geclavesCiudadService.getGe2012Report(pcFecha).toPromise();
      
      // Acceder a response.response porque la API devuelve estructura anidada
      if (response?.response?.pcArchPDF || response?.response?.pcArchCSV) {
        this.reportResponse = response.response;
        this.showReportModal.set(true);
      } else {
        console.error('Estructura de respuesta inesperada:', response);
        this.toastService.showError('No se pudo generar el reporte');
      }
    } catch (error) {
      console.error('Error generando reporte:', error);
      this.toastService.showError('Error al generar el reporte');
    } finally {
      this.loadingState.set(false);
    }
  }

  downloadReportPDF(): void {
    if (!this.reportResponse?.pcArchPDF) {
      this.toastService.showError('No se pudo generar el reporte PDF');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchPDF, 'reporte-ciudades.pdf', 'application/pdf');
    this.toastService.showSuccess('Reporte PDF descargado exitosamente');
    this.showReportModal.set(false);
  }

  downloadReportCSV(): void {
    if (!this.reportResponse?.pcArchCSV) {
      this.toastService.showError('No se pudo generar el reporte CSV');
      return;
    }

    this.downloadFile(this.reportResponse.pcArchCSV, 'reporte-ciudades.csv', 'text/csv');
    this.toastService.showSuccess('Reporte CSV descargado exitosamente');
    this.showReportModal.set(false);
  }

  closeReportModal(): void {
    this.showReportModal.set(false);
    this.reportResponse = null;
  }

  /**
   * Descarga un archivo desde su contenido en base64
   * @param base64Content Contenido del archivo en base64
   * @param fileName Nombre del archivo a descargar
   * @param mimeType Tipo MIME del archivo
   */
  private downloadFile(base64Content: string, fileName: string, mimeType: string): void {
    try {
      // Decodificar base64 a bytes
      const byteCharacters = atob(base64Content);
      const byteNumbers = new Array(byteCharacters.length);
      
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      
      const byteArray = new Uint8Array(byteNumbers);
      
      // Crear Blob con el tipo MIME apropiado
      const blob = new Blob([byteArray], { type: mimeType });
      
      // Crear URL de descarga
      const url = window.URL.createObjectURL(blob);
      
      // Crear elemento <a> y simular clic
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      
      // Limpiar recursos
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error procesando archivo base64:', error);
      throw error;
    }
  }

  // ==================== NAVEGACIÓN ====================
  goBack(): void {
    this.router.navigate(['/dashboard']);
  }
}
