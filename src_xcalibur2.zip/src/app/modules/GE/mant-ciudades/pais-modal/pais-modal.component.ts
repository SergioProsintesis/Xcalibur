import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeclavesCiudadService } from '../../../../core/services/geclaves-ciudad.service';
import { PaisRecord } from '../../../../core/interfaces/ge-ciudad.interface';

@Component({
  selector: 'app-pais-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="modal-backdrop" *ngIf="show" (click)="onClose()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h2 class="modal-title">Buscar País</h2>
          <button type="button" class="close-btn" (click)="onClose()">&times;</button>
        </div>

        <div class="modal-body">
          <form class="search-form">
            <div class="search-field">
              <label class="field-label">Buscar por código o nombre</label>
              <input 
                type="text" 
                [(ngModel)]="searchTerm" 
                (input)="filterPaises()" 
                [ngModelOptions]="{standalone: true}"
                class="search-input" 
                placeholder="Escriba para buscar...">
            </div>
          </form>

          <div class="paises-grid" *ngIf="filteredPaises.length > 0; else noResults">
            <div class="grid-header">
              <div class="header-cell">Código</div>
              <div class="header-cell">Nombre</div>
              <div class="header-cell">Acción</div>
            </div>
            <div class="grid-body">
              <div class="grid-row" *ngFor="let pais of filteredPaises; trackBy: trackByPais">
                <div class="grid-cell">{{ pais.pais }}</div>
                <div class="grid-cell">{{ pais['nombre-pai'] }}</div>
                <div class="grid-cell">
                  <button type="button" class="select-btn" (click)="onSelectPais(pais)">
                    Seleccionar
                  </button>
                </div>
              </div>
            </div>
          </div>

          <ng-template #noResults>
            <div class="no-results" *ngIf="!isLoading">
              <p>No se encontraron países</p>
            </div>
          </ng-template>

          <div class="loading-indicator" *ngIf="isLoading">
            <div class="spinner"></div>
            <span>Cargando países...</span>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn-secondary" (click)="onClose()">Cancelar</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .modal-backdrop {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 1000;
    }

    .modal-content {
      background: white;
      border-radius: 12px;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 600px;
      max-height: 80vh;
      display: flex;
      flex-direction: column;
      animation: slideIn 0.3s ease-out;
    }

    @keyframes slideIn {
      from {
        transform: translateY(-50px);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .modal-title {
      margin: 0;
      font-size: 1.25rem;
      font-weight: 600;
      color: #1f2937;
    }

    .close-btn {
      background: none;
      border: none;
      font-size: 1.5rem;
      color: #6b7280;
      cursor: pointer;
      width: 2rem;
      height: 2rem;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 4px;
      transition: all 0.2s;
    }

    .close-btn:hover {
      background: #f3f4f6;
      color: #1f2937;
    }

    .modal-body {
      padding: 1.5rem;
      overflow-y: auto;
      flex: 1;
    }

    .search-form {
      margin-bottom: 1.5rem;
    }

    .search-field {
      display: flex;
      flex-direction: column;
    }

    .field-label {
      font-weight: 500;
      color: #374151;
      margin-bottom: 0.5rem;
    }

    .search-input {
      border: 1px solid #d1d5db;
      border-radius: 8px;
      padding: 0.75rem;
      font-size: 0.95rem;
      transition: all 0.2s;
    }

    .search-input:focus {
      outline: none;
      border-color: #003087;
      box-shadow: 0 0 0 2px rgba(0, 48, 135, 0.15);
    }

    .paises-grid {
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      overflow: hidden;
    }

    .grid-header {
      display: grid;
      grid-template-columns: 100px 1fr 120px;
      background: #f9fafb;
      border-bottom: 1px solid #e5e7eb;
    }

    .header-cell {
      padding: 0.75rem;
      font-weight: 600;
      font-size: 0.875rem;
      color: #374151;
      border-right: 1px solid #e5e7eb;
    }

    .header-cell:last-child {
      border-right: none;
    }

    .grid-body {
      max-height: 300px;
      overflow-y: auto;
    }

    .grid-row {
      display: grid;
      grid-template-columns: 100px 1fr 120px;
      border-bottom: 1px solid #f3f4f6;
    }

    .grid-row:hover {
      background: #f9fafb;
    }

    .grid-cell {
      padding: 0.75rem;
      font-size: 0.875rem;
      color: #4b5563;
      border-right: 1px solid #f3f4f6;
    }

    .grid-cell:last-child {
      border-right: none;
    }

    .select-btn {
      background: #003087;
      color: white;
      border: none;
      padding: 0.4rem 0.8rem;
      border-radius: 4px;
      font-size: 0.75rem;
      cursor: pointer;
      transition: all 0.2s;
      white-space: nowrap;
    }

    .select-btn:hover {
      background: #002060;
      transform: translateY(-1px);
    }

    .select-btn:active {
      transform: translateY(0);
    }

    .no-results {
      text-align: center;
      padding: 2rem;
      color: #6b7280;
      font-size: 0.95rem;
    }

    .loading-indicator {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }

    .spinner {
      width: 40px;
      height: 40px;
      border: 3px solid #e5e7eb;
      border-top: 3px solid #003087;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
      margin-bottom: 1rem;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .modal-footer {
      display: flex;
      justify-content: flex-end;
      gap: 0.75rem;
      padding: 1.5rem;
      border-top: 1px solid #e5e7eb;
    }

    .btn-secondary {
      background-color: #f3f4f6;
      color: #374151;
      border: 1px solid #d1d5db;
      padding: 0.6rem 1.5rem;
      border-radius: 8px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
    }

    .btn-secondary:hover {
      background-color: #e5e7eb;
    }
  `]
})
export class PaisModalComponent implements OnChanges {
  @Input() show = false;
  @Input() paises: PaisRecord[] = [];
  @Output() close = new EventEmitter<void>();
  @Output() select = new EventEmitter<PaisRecord>();

  filteredPaises: PaisRecord[] = [];
  searchTerm = '';
  isLoading = false;

  constructor(private geclavesCiudadService: GeclavesCiudadService) {}

  ngOnChanges(changes: SimpleChanges): void {
    // Si recibimos datos ya cargados, los usamos directamente
    if (changes['paises'] && this.paises && this.paises.length > 0) {
      this.filteredPaises = [...this.paises];
    }
    
    // Si no recibimos datos pero el modal se abre, intentamos cargar (fallback)
    if (changes['show'] && this.show && this.paises.length === 0) {
      this.loadPaises();
    }
  }

  private loadPaises(): void {
    this.isLoading = true;
    this.geclavesCiudadService.getCEPais().subscribe({
      next: (response) => {
        this.paises = response?.dsRespuesta?.tgepais || [];
        this.filteredPaises = [...this.paises];
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading paises:', error);
        this.paises = [];
        this.filteredPaises = [];
        this.isLoading = false;
      }
    });
  }

  filterPaises(): void {
    const term = this.searchTerm.toLowerCase().trim();
    
    if (!term) {
      this.filteredPaises = [...this.paises];
      return;
    }

    this.filteredPaises = this.paises.filter(pais =>
      pais.pais.toString().toLowerCase().includes(term) ||
      pais['nombre-pai'].toLowerCase().includes(term)
    );
  }

  onSelectPais(pais: PaisRecord): void {
    this.select.emit(pais);
    this.onClose();
  }

  onClose(): void {
    this.close.emit();
    this.searchTerm = '';
    this.filteredPaises = [...this.paises];
  }

  trackByPais(index: number, pais: PaisRecord): string {
    return pais.pais;
  }
}
