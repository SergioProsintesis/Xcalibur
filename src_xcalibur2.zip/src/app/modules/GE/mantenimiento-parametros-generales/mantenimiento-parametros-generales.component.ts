import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { GeparameService } from '../../../core/services/geparame.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { GeparameRecord } from '../../../core/interfaces/geparame.interface';
import { HelpIconComponent } from '../../../shared/components/help-icon/help-icon.component';

@Component({
  selector: 'app-mantenimiento-parametros-generales',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, HelpIconComponent],
  templateUrl: './mantenimiento-parametros-generales.component.html',
  styleUrls: ['./mantenimiento-parametros-generales.component.css']
})
export class MantenimientoParametrosGeneralesComponent implements OnInit {
  private fb = inject(FormBuilder);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private geparameService = inject(GeparameService);
  private programContext = inject(ProgramContextService);
  
  parametrosForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento de Parámetros Generales`);
  loadingState = signal<boolean>(false);

  constructor() {
    // Form initialization moved to ngOnInit
  }

  ngOnInit(): void {
    this.initializeForm();
    this.loadParametros();
  }

  private initializeForm(): void {
    this.parametrosForm = this.fb.group({
      // Mapea los campos según API
      'bgcolfil-gen': [null, [Validators.required, Validators.pattern(/^\d{1,3}$/), Validators.min(0), Validators.max(999)]],
      'bgcolfra-gen': [null, [Validators.required, Validators.pattern(/^\d{1,3}$/), Validators.min(0), Validators.max(999)]],
      'bgcoltex-gen': [null, [Validators.required, Validators.pattern(/^\d{1,3}$/), Validators.min(0), Validators.max(999)]],
      'decimal-gen': ['NO', [Validators.required]], // SI/NO
      'Dias-Aviso': [null, [Validators.required, Validators.pattern(/^\d{1,3}$/), Validators.min(0), Validators.max(999)]],
      'Dias-Pass': [null, [Validators.required, Validators.pattern(/^\d{1,3}$/), Validators.min(0), Validators.max(999)]],
      'fgcolfil-gen': [null, [Validators.required, Validators.pattern(/^\d{1,3}$/), Validators.min(0), Validators.max(999)]],
      'fgcolfra-gen': [null, [Validators.required, Validators.pattern(/^\d{1,3}$/), Validators.min(0), Validators.max(999)]],
      'fgcolre1-gen': [null, [Validators.required, Validators.pattern(/^\d{1,3}$/), Validators.min(0), Validators.max(999)]],
      'fgcolre2-gen': [null, [Validators.required, Validators.pattern(/^\d{1,3}$/), Validators.min(0), Validators.max(999)]],
      'fgcoltex-gen': [null, [Validators.required, Validators.pattern(/^\d{1,3}$/), Validators.min(0), Validators.max(999)]],
      'fueenc-gen': ['NO', [Validators.required]],
      'Historia': [null, [Validators.required, Validators.pattern(/^\d{1,3}$/), Validators.min(0), Validators.max(999)]],
      'idioma-gen': ['ESPAÑOL', [Validators.required]],
      'Intentos': [null, [Validators.required, Validators.pattern(/^\d{1,3}$/), Validators.min(0), Validators.max(999)]],
      'runlog-gen': ['SI', [Validators.required]],
      'runpel-gen': ['SI', [Validators.required]],
      'runson-gen': ['SI', [Validators.required]],
      'agrega-RepPDF': [''],
      'agrega-login': [''],
      'tparent': ['']
    });
  }

  /** Carga los parámetros generales desde el API real */
  private loadParametros(): void {
    this.loadingState.set(true);
    this.geparameService.getParams().subscribe({
      next: (record) => {
        this.loadingState.set(false);
        if (record) {
          const formValue = this.apiRecordToForm(record);
          this.parametrosForm.patchValue(formValue);
          this.toastService.showSuccess('Parámetros cargados');
        } else {
          this.toastService.showWarning('No se encontraron parámetros');
        }
      },
      error: () => {
        this.loadingState.set(false);
        this.toastService.showError('Error al cargar parámetros');
      }
    });
  }

  /** Envía actualización de parámetros mediante UpdateGeparame-ge0055 */
  onSubmit(): void {
    if (this.parametrosForm.invalid) {
      this.toastService.showWarning('Verifique los campos requeridos y numéricos');
      this.parametrosForm.markAllAsTouched();
      return;
    }

    const record = this.formToApiRecord();
    this.loadingState.set(true);
    this.geparameService.updateParams(record).subscribe({
      next: (res) => {
        this.loadingState.set(false);
        if (res) {
          const msg = res.terrores && res.terrores.length > 0 ? res.terrores[0].descripcion : 'Parámetros actualizados';
          this.toastService.showSuccess(msg);
        } else {
          this.toastService.showWarning('No se confirmó la actualización');
        }
      },
      error: () => {
        this.loadingState.set(false);
        this.toastService.showError('Error al actualizar');
      }
    });
  }

  /** Limpia el formulario */
  onClear(): void {
    this.parametrosForm.reset({ 'idioma-gen': 'ESPAÑOL', 'decimal-gen': 'NO', 'fueenc-gen': 'NO', 'runlog-gen': 'SI', 'runpel-gen': 'SI', 'runson-gen': 'SI' });
  }

  // Helpers: conversiones entre API y Formulario (SI/NO ↔ boolean)
  private boolToSiNo(b: boolean | null | undefined): 'SI' | 'NO' {
    return b ? 'SI' : 'NO';
  }
  private siNoToBool(v: any): boolean {
    return String(v).toUpperCase() === 'SI';
  }

  private apiRecordToForm(rec: GeparameRecord): any {
    return {
      'bgcolfil-gen': rec['bgcolfil-gen'],
      'bgcolfra-gen': rec['bgcolfra-gen'],
      'bgcoltex-gen': rec['bgcoltex-gen'],
      'decimal-gen': this.boolToSiNo(rec['decimal-gen']),
      'Dias-Aviso': rec['Dias-Aviso'],
      'Dias-Pass': rec['Dias-Pass'],
      'fgcolfil-gen': rec['fgcolfil-gen'],
      'fgcolfra-gen': rec['fgcolfra-gen'],
      'fgcolre1-gen': rec['fgcolre1-gen'],
      'fgcolre2-gen': rec['fgcolre2-gen'],
      'fgcoltex-gen': rec['fgcoltex-gen'],
      'fueenc-gen': this.boolToSiNo(rec['fueenc-gen']),
      'Historia': rec['Historia'],
      'idioma-gen': rec['idioma-gen'] || 'ESPAÑOL',
      'Intentos': rec['Intentos'],
      'runlog-gen': this.boolToSiNo(rec['runlog-gen']),
      'runpel-gen': this.boolToSiNo(rec['runpel-gen']),
      'runson-gen': this.boolToSiNo(rec['runson-gen']),
      'agrega-RepPDF': rec['agrega-RepPDF'] || '',
      'agrega-login': rec['agrega-login'] || '',
      'tparent': rec['tparent'] || ''
    };
  }

  private formToApiRecord(): GeparameRecord {
    const v = this.parametrosForm.value as any;
    const rec: GeparameRecord = {
      "Agrega-Para": "",
      "bgcolfil-gen": Number(v['bgcolfil-gen'] || 0),
      "bgcolfra-gen": Number(v['bgcolfra-gen'] || 0),
      "bgcoltex-gen": Number(v['bgcoltex-gen'] || 0),
      "decimal-gen": this.siNoToBool(v['decimal-gen']),
      "Dias-Aviso": Number(v['Dias-Aviso'] || 0),
      "Dias-Pass": Number(v['Dias-Pass'] || 0),
      "fgcolfil-gen": Number(v['fgcolfil-gen'] || 0),
      "fgcolfra-gen": Number(v['fgcolfra-gen'] || 0),
      "fgcolre1-gen": Number(v['fgcolre1-gen'] || 0),
      "fgcolre2-gen": Number(v['fgcolre2-gen'] || 0),
      "fgcoltex-gen": Number(v['fgcoltex-gen'] || 0),
      "fueenc-gen": this.siNoToBool(v['fueenc-gen']),
      "Historia": Number(v['Historia'] || 0),
      "idioma-gen": v['idioma-gen'] || 'ESPAÑOL',
      "Intentos": Number(v['Intentos'] || 0),
      "runlog-gen": this.siNoToBool(v['runlog-gen']),
      "runpel-gen": this.siNoToBool(v['runpel-gen']),
      "runson-gen": this.siNoToBool(v['runson-gen']),
      "agrega-RepPDF": v['agrega-RepPDF'] || "",
      "agrega-login": v['agrega-login'] || "",
      "tparent": v['tparent'] || ""
    };
    return rec;
  }

  // Validación UI
  isInvalid(controlName: string): boolean {
    const c = this.parametrosForm.get(controlName);
    return !!(c && c.invalid && (c.touched || c.dirty));
  }

  errorMessage(controlName: string): string {
    const c = this.parametrosForm.get(controlName);
    if (!c || !c.errors) return '';
    if (c.errors['required']) return 'Campo obligatorio';
    if (c.errors['pattern']) return 'Solo números (0-999)';
    if (c.errors['min'] || c.errors['max']) return 'Rango permitido: 0 - 999';
    return 'Valor inválido';
  }
}
