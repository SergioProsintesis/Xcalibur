import { Component, OnDestroy, OnInit, computed, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { debounceTime, distinctUntilChanged, filter, Subject, takeUntil } from 'rxjs';

import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { GeclavesService } from '../../../core/services/geclaves.service';
import { ProgramContextService } from '../../../core/services/program-context.service';

@Component({
  selector: 'app-cambio-de-password',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './cambio-de-password.component.html',
  styleUrls: ['./cambio-de-password.component.css']
})
export class CambioDePasswordComponent implements OnInit, OnDestroy {
  private programContext = inject(ProgramContextService);
  
  form: FormGroup;
  isLoading = signal(false);
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Cambio de Contraseña`);
  passwordChecks = signal<string[]>([]);
  fechaError = signal<string>('');
  private destroy$ = new Subject<void>();

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private toast: ToastService,
    private loading: LoadingService,
    private geclaves: GeclavesService
  ) {
    this.form = this.fb.group({
      currentPassword: ['', Validators.required],
      newPassword1: ['', [Validators.required, Validators.minLength(7)]],
      newPassword2: ['', Validators.required],
      fechaInicio: ['', Validators.required]
    }, { validators: this.passwordsMatchValidator });
  }

  ngOnInit(): void {
    // Fecha por defecto: hoy (YYYY-MM-DD)
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    this.form.patchValue({ fechaInicio: `${yyyy}-${mm}-${dd}` });

    // Validación dinámica de newPassword2 (reglas de complejidad)
    this.form.get('newPassword2')!.valueChanges.pipe(
      takeUntil(this.destroy$),
      debounceTime(400),
      distinctUntilChanged(),
      filter(v => !!v)
    ).subscribe(value => this.checkPasswordComplexity(value));

    // Validación de fechaInicio con backend
    this.form.get('fechaInicio')!.valueChanges.pipe(
      takeUntil(this.destroy$),
      debounceTime(300),
      distinctUntilChanged(),
      filter(v => !!v)
    ).subscribe(value => this.checkFechaInicio(value));
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private passwordsMatchValidator = (group: FormGroup) => {
    const p1 = group.get('newPassword1')?.value;
    const p2 = group.get('newPassword2')?.value;
    return p1 && p2 && p1 === p2 ? null : { passwordMismatch: true };
  };

  private checkPasswordComplexity(value: string) {
    const user = this.auth.user();
    const pcLoginP = user?.pcLogin || '';
    this.geclaves.validarNuevaPassword(pcLoginP, value).subscribe(recList => {
      const msgs = (recList?.flatMap(r => r.terrores ?? []) || []).map(t => t.descripcion);
      this.passwordChecks.set(msgs);
    });
  }

  private checkFechaInicio(value: string) {
    const user = this.auth.user();
    const pcLoginP = user?.pcLogin || '';
    this.geclaves.validarFechaInicio(pcLoginP, value).subscribe(rec => {
      const err = rec?.terrores?.[0]?.descripcion || '';
      this.fechaError.set(err);
      const ctrl = this.form.get('fechaInicio');
      if (err) {
        ctrl?.setErrors({ backend: err });
      } else {
        if (ctrl?.hasError('backend')) {
          const errs = { ...(ctrl.errors || {}) };
          delete errs['backend'];
          ctrl.setErrors(Object.keys(errs).length ? errs : null);
        }
      }
    });
  }

  getPasswordStrengthClass(): string {
    const password = this.form.get('newPassword1')?.value || '';
    const strength = this.calculatePasswordStrength(password);
    
    if (strength < 2) return 'weak';
    if (strength < 4) return 'medium';
    return 'strong';
  }

  getPasswordStrengthText(): string {
    const password = this.form.get('newPassword1')?.value || '';
    const strength = this.calculatePasswordStrength(password);
    
    if (strength < 2) return 'Débil 🔴';
    if (strength < 4) return 'Media 🟡';
    return 'Fuerte 🟢';
  }

  private calculatePasswordStrength(password: string): number {
    let strength = 0;
    
    if (password.length >= 7) strength++;
    if (password.length >= 10) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;
    
    return strength;
  }

  onSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.toast.showWarning('Revise los errores antes de continuar');
      return;
    }
    const user = this.auth.user();
    const pcLoginP = user?.pcLogin || '';
    const { newPassword1, newPassword2, fechaInicio } = this.form.value;

    this.isLoading.set(true);
    this.loading.show();
    this.geclaves.actualizarPassword({ pcLoginP, pcNPassword1: newPassword1, pcNPassword2: newPassword2, pcFechaInicio: fechaInicio })
      .subscribe({
        next: (rec) => {
          this.isLoading.set(false);
          this.loading.hide();
          const mensaje = rec?.terrores?.[0]?.descripcion || 'Contraseña actualizada';
          this.toast.showSuccess(mensaje);
          this.form.reset();
        },
        error: (err) => {
          this.isLoading.set(false);
          this.loading.hide();
          console.error('❌ Error al actualizar contraseña', err);
          this.toast.showError('No se pudo actualizar la contraseña');
        }
      });
  }
}
