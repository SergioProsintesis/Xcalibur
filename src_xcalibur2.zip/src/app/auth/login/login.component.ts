import { Component, signal, effect } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../core/services/auth.service';
import { LoginCredentials } from '../../core/interfaces/auth.interface';
import { LOGIN_CONFIG } from './login.config';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  public readonly isLoading = signal<boolean>(false);
  public readonly showPassword = signal<boolean>(false);
  public loginForm!: FormGroup;
  public config = LOGIN_CONFIG;

  constructor(
    public authService: AuthService,
    private router: Router
    ,private fb: FormBuilder
  ) {
    this.initializeForm();

    // Load remembered username if the user chose "Recuérdame" (guard for SSR / non-browser envs)
    try {
      const ls = (globalThis as any).localStorage;
      if (ls && typeof ls.getItem === 'function') {
        const remembered = ls.getItem('login.rememberMe');
        if (remembered === 'true') {
          const savedUser = ls.getItem('login.username');
          if (savedUser) {
            this.loginForm.patchValue({ username: savedUser, rememberMe: true });
          } else {
            this.loginForm.patchValue({ rememberMe: true });
          }
        }
      }
    } catch (e) {
      // ignore storage errors (e.g., in private mode or SSR)
      console.warn('localStorage not available for remember-me', e);
    }

    // Redirect if already authenticated
    effect(() => {
      if (this.authService.isAuthenticated()) {
        this.router.navigate(['/dashboard']);
      }
    });
  }
  
  // Expose friendly validation messages used by the template
  public get usernameError(): string {
    const control = this.loginForm.get('username');
    if (!control || !control.touched || !control.errors) return '';
    if (control.hasError('required')) return 'El usuario es requerido.';
    if (control.hasError('email')) return 'Ingresa un correo válido.';
    return '';
  }

  public get passwordError(): string {
    const control = this.loginForm.get('password');
    if (!control || !control.touched || !control.errors) return '';
    if (control.hasError('required')) return 'La contraseña es requerida.';
    if (control.hasError('minlength')) return `La contraseña debe tener al menos ${this.config.passwordPolicy?.minLength ?? 0} caracteres.`;
    if (control.hasError('pattern')) return 'La contraseña debe contener mayúsculas, minúsculas y números.';
    return '';
  }
  private initializeForm(): void {
    const usernameValidators = [Validators.required];
    if (this.config.usernameIsEmail) {
      usernameValidators.push(Validators.email);
    }

    const passwordValidators = [Validators.required];
    const minLen = this.config.passwordPolicy?.minLength ?? 0;
    if (minLen && minLen > 0) {
      passwordValidators.push(Validators.minLength(minLen));
    }
    if (this.config.passwordPolicy?.requireComplexity) {
      // Require at least one lowercase, one uppercase and one number
      passwordValidators.push(Validators.pattern(/(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+/));
    }

    this.loginForm = this.fb.group({
      username: ['', usernameValidators],
      password: ['', passwordValidators],
      rememberMe: [false]
    });
  }

  public togglePasswordVisibility(): void {
    this.showPassword.update(v => !v);
  }

  public onSubmit(): void {
    if (!this.loginForm.valid) {
      this.loginForm.markAllAsTouched();
      return;
    }

    const credentials: LoginCredentials = {
      username: this.loginForm.get('username')?.value,
      password: this.loginForm.get('password')?.value
    };

    console.log('🔐 Login attempt:', {
      username: credentials.username,
      timestamp: new Date().toISOString(),
      userAgent: navigator.userAgent
    });

    this.isLoading.set(true);

    this.authService.login(credentials).subscribe({
      next: (success) => {
        if (success) {
          console.log('✅ Login successful for user:', credentials.username);

          // Persist username if rememberMe is checked
          try {
            if (this.loginForm.get('rememberMe')?.value) {
              localStorage.setItem('login.rememberMe', 'true');
              localStorage.setItem('login.username', credentials.username);
            } else {
              localStorage.removeItem('login.rememberMe');
              localStorage.removeItem('login.username');
            }
          } catch (e) {
            console.warn('localStorage not available to persist remember-me', e);
          }

          this.router.navigate(['/dashboard']);
        } else {
          console.log('❌ Login failed for user:', credentials.username);
        }
        this.isLoading.set(false);
      },
      error: (error) => {
        console.error('❌ Login error:', error);
        this.isLoading.set(false);
      }
    });
  }
}