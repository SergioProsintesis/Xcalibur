export interface LoginConfig {
  usernameIsEmail: boolean;
  passwordPolicy?: {
    minLength?: number;
    requireComplexity?: boolean; // uppercase + lowercase + number
  };
}

// Default config: allow non-email usernames (useful for tests), and password policy optional
export const LOGIN_CONFIG: LoginConfig = {
  usernameIsEmail: false,
  passwordPolicy: {
    minLength: 0,
    requireComplexity: false
  }
};
