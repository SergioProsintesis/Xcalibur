import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class VeracodeService {
  private apiId = '';
  private apiKey = '';

  constructor() {
    this.validateCredentials();
  }

  /**
   * Obtiene el ID de la API de Veracode
   */
  getApiId(): string {
    return this.apiId;
  }

  /**
   * Obtiene la clave de la API de Veracode
   */
  getApiKey(): string {
    return this.apiKey;
  }

  /**
   * Valida que las credenciales estén configuradas
   */
  private validateCredentials(): void {
    if (!this.apiId || !this.apiKey) {
      console.warn(
        'Advertencia: Credenciales de Veracode no configuradas. ' +
        'Asegúrese de que VERACODE_API_ID y VERACODE_API_KEY están definidas en .env'
      );
    }
  }

  /**
   * Verifica si las credenciales están disponibles
   */
  isConfigured(): boolean {
    return !!this.apiId && !!this.apiKey;
  }

  /**
   * Retorna las credenciales como objeto para peticiones HTTP
   */
  getCredentials() {
    return {
      apiId: this.apiId,
      apiKey: this.apiKey
    };
  }
}
