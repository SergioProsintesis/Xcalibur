import { Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { MainLayoutComponent } from './layout/main-layout.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { authGuard } from './core/guards/auth.guard';

import { CompanyMaintenanceComponent } from './modules/CC/company-maintenance/company-maintenance.component';
import { TransactionLoadComponent } from './modules/CC/transaction-load/transaction-load.component';
import { BalanceComprobacionComponent } from './modules/CG/balance-comprobacion/balance-comprobacion.component';
import { Ge0057AsignacionOpcionesComponent } from './modules/companies/cuentas-por-cobrar/asignacion-de-opciones-x-perfil/ge0057-asignacion-opciones.component';

import { MantenimientoUsuariosComponent } from './modules/GE/mantenimiento-usuarios/mantenimiento-usuarios.component';
import { MantenimientoParametrosGeneralesComponent } from './modules/GE/mantenimiento-parametros-generales/mantenimiento-parametros-generales.component';
import { ReiniciarPasswordComponent } from './modules/GE/reiniciar-password/reiniciar-password.component';
import { CambioDePasswordComponent } from './modules/GE/cambio-de-password/cambio-de-password.component';
import { MantCiudadesComponent } from './modules/GE/mant-ciudades/mant-ciudades.component';
import { MantRetencionComponent } from './modules/CC/mant-retencion/mant-retencion.component';
import { MantContableTipoDocumentoComponent } from './modules/CC/mant-contable-tipo-documento/mant-contable-tipo-documento.component';
import { MantenimientoDeCuentasComponent } from './modules/CC/mantenimiento-de-cuentas/mant-cuentas-contables.component';

import { ConsultaFacturasClienteComponent } from './modules/CC/consulta-facturas-cliente/consulta-facturas-cliente.component';
import { CargaComprobantesComponent } from './modules/CG/carga-comprobantes/carga-comprobantes.component';
import { ReporteMovimientoDelDiaComponent } from './modules/CC/reporte-movimiento-del-dia/reporte-movimiento-del-dia.component';
import { ConversionMonetariaComponent } from './modules/CC/Reportes/conversion-monetaria/conversion-monetaria.component';
import { ReporteMovimientoMensualComponent } from './modules/CC/Reportes/reporte-movimiento-mensual/reporte-movimiento-mensual.component';
import { ReportePS5001Component } from './modules/PS/Reportes/reporte-ps5001/reporte-ps5001.component';
import { ReportePS5023Component } from './modules/PS/Reportes/reporte-ps5023/reporte-ps5023.component';
import { ReportesNotasComponent } from './modules/CC/reportes-notas/reportes-notas.component';
import { EstadoDeCuentaPendienteComponent } from './modules/CC/estado-de-cuenta-pendiente/estado-de-cuenta-pendiente.component';
import { EstadoDeCuentaHistoricoEnOtrMonedaComponent } from './modules/CC/estado-de-cuenta-historico-en-otr-moneda/estado-de-cuenta-historico-en-otr-moneda.component';
import { ResumenCuentasPorCobrarComponent } from './modules/CC/resumen-cuentas-por-cobrar/resumen-cuentas-por-cobrar.component';
import { EstadoCthhistConsolidadoComponent } from './modules/CC/estado-ctahist-consolidado/estado-ctahist-consolidado.component';
import { EstadoCtaPendConsolidadoComponent } from './modules/CC/estado-cta-pend-consolidado/estado-cta-pend-consolidado.component';
import { MovimientoPorLoteComponent } from './modules/CC/movimiento-por-lote/movimiento-por-lote.component';
import { MovimientoPorLoteMensualComponent } from './modules/CC/movimiento-por-lote-mensual/movimiento-por-lote-mensual.component';
import { MovimientoPorLoteSelectivoComponent } from './modules/CC/movimiento-por-lote-selectivo/movimiento-por-lote-selectivo.component';
import { ReportePS5034Component } from './modules/PS/Reportes/reporte-ps5034/reporte-ps5034.component';
import { ReportePS5035Component } from './modules/PS/Reportes/reporte-ps5035/reporte-ps5035.component';
import { ReportePS5057Component } from './modules/PS/Reportes/reporte-ps5057/reporte-ps5057.component';
import { ReportePS5068Component } from './modules/PS/Reportes/reporte-ps5068/reporte-ps5068.component';
import { MantTipoDeClienteComponent } from './modules/CC/mant-tipo-de-cliente/mant-tipo-de-cliente.component';
import { MantTipoDeDocumentoComponent } from './modules/CC/mant-tipo-de-documento/mant-tipo-de-documento.component';
import { MantClasificacionVentaComponent } from './modules/CC/mant-clasificacion-venta/mant-clasificacion-venta.component';
import { MantBancoTarjetaComponent } from './modules/CC/mant-bancotarjeta/mant-bancotarjeta.component';
import { MantCausaDeSuspensionComponent } from './modules/CC/mant-causa-de-suspension/mant-causa-de-suspension.component';
import { MantenimientoDetallesGeneralesComponent } from './modules/CC/mantenimiento-detalles-generales/mantenimiento-detalles-generales.component';
import { MantVendedorComponent } from './modules/CC/mant-vendedor/mant-vendedor.component';
import { MantZonaDeVentaComponent } from './modules/CC/mant-zona-de-venta/mant-zona-de-venta.component';
import { MantTipoDeNegocioComponent } from './modules/CC/mant-tipo-de-negocio/mant-tipo-de-negocio.component';
import { MantLocalidadesComponent } from './modules/CC/mant-localidades/mant-localidades.component';
import { MantCondicionesDePagoComponent } from './modules/CC/mant-condiciones-de-pago/mant-condiciones-de-pago.component';
import { MantDescuentosComponent } from './modules/CC/mant-descuentos/mant-descuentos.component';
import { MantTablas15Component } from './modules/CC/mant-tablas-1-5/mant-tablas-1-5.component';
import { MantTablasGeneralesComponent } from './modules/CC/mant-tablas-generales/mant-tablas-generales.component';
import { CargaCobranzaComponent } from './modules/CC/procesos-principales/carga-cobranza/carga-cobranza.component';
import { ConsultaClientesComponent } from './modules/CC/procesos-principales/consulta-clientes/consulta-clientes.component';
import { AuditoriaCorreosFacturacionComponent } from './modules/CC/procesos-principales/auditoria-correos-facturacion/auditoria-correos-facturacion.component';
import { MantenimientoContactosComponent } from './modules/CC/procesos-principales/mantenimiento-contactos/mantenimiento-contactos.component';
import { ReporteARG0288Component } from './modules/CC/reportes-principales/reporte-arg0288/reporte-arg0288.component';
import { ReportePS2000Component } from './modules/CC/reportes-principales/reporte-ps2000/reporte-ps2000.component';
import { ReportePS2001Component } from './modules/CC/reportes-principales/reporte-ps2001/reporte-ps2001.component';
import { ReporteCC2205Component } from './modules/CC/reportes-principales/reporte-cc2205/reporte-cc2205.component';
import { MantParametrosObservacionesComponent } from './modules/CC/parametros-observaciones-ingles/mant-parametros-observaciones.component';
import { MantParametrosFacturacionComponent } from './modules/CC/mantenimiento-parametros-facturacion/mant-parametros-facturacion.component';
import { MantDistribucionFacturasComponent } from './modules/CC/mantenimiento-distribucion-facturas/mant-distribucion-facturas.component';
import { OtrosDatosFacturacionComponent } from './modules/CC/otros-datos-facturacion-electronica/otros-datos-facturacion.component';
import { MantResolucionesFacturacionComponent } from './modules/CC/mant-resoluciones-facturacion/mant-resoluciones-facturacion.component';
import { MantDescuentosFacturacionComponent } from './modules/CC/mant-descuentos-facturacion/mant-descuentos-facturacion.component';
import { MantDatosCompraComponent } from './modules/CC/mant-datos-compra/mant-datos-compra.component';
import { MantClientesComponent } from './modules/CC/mant-clientes/mant-clientes.component';
import { ReporteFacturacionFechaComponent } from './modules/CC/reporte-facturacion-fecha/reporte-facturacion-fecha.component';
import { ReporteNotasFechaComponent } from './modules/CC/reporte-notas-fecha/reporte-notas-fecha.component';
import { MantCentrosCostosComponent } from './modules/CC/mant-centros-costos/mant-centros-costos.component';
import { MantBasesLiquidacionComponent } from './modules/CC/mant-bases-liquidacion/mant-bases-liquidacion.component';
import { ReporteIngresosTrimestresComponent } from './modules/CC/reporte-ingresos-trimestre/reporte-ingresos-trimestre.component';
import { Arg5014Component } from './modules/CC/generacion-archivo-factura-electronica/arg5014.component';
import { Ps5018Component } from './modules/CC/reporte-gastos-de-facturacion/ps5018.component';
import { Ps5113CufeComponent } from './modules/CC/reporte-de-facturas-sin-codigo-cufe-ubl2-dic-19/ps5113-cufe.component';
import { ReporteDeFacturacionRecurrenteComponent } from './modules/CC/reporte-de-facturacion-recurrente/reporte-de-facturacion-recurrente.component';
import { ReimpresionDeFacturasComponent } from './modules/CC/reimpresion-de-facturas/reimpresion-de-facturas.component';
import { ObservacionGeneralesComponent } from './modules/CC/observacion-generales/observacion-generales.component';
import { ConfiguracionClientesElectronicosComponent } from './modules/CC/configuracion-clientes-electronicos-x-cia/configuracion-clientes-electronicos.component';
import { ParametrosObservacionesEnInglesComponent } from './modules/CC/parametros-observaciones-en-ingles/parametros-observaciones-en-ingles.component';
import { GenArchivosFactnotasYCartComponent } from './modules/CC/gen-archivos-factnotas-y-cart/gen-archivos-factnotas-y-cart.component';

// Import Demo Secondary Menu Component
import { DemoSecondaryMenuComponent } from './demo-secondary-menu/demo-secondary-menu.component';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  {
    path: '',
    component: MainLayoutComponent,
    canActivate: [authGuard],
    children: [
      { path: 'dashboard', component: DashboardComponent },

      // Administrador del Sistema routes
      // { path: 'administrador', component: AdministratorComponent },

      // Compañías routes
      // { path: 'administrador/companias', component: CompaniesComponent },
      { path: 'administrador/companias/mantenimiento-companias', component: CompanyMaintenanceComponent },
      // Autorización a usuarios
      { path: 'administrador/autorizacion-usuarios/mantenimiento-usuarios', component: MantenimientoUsuariosComponent },

      { path: 'contabilidad-general/reportes-principales/balance-comprobacion', component: BalanceComprobacionComponent },

      // Transacciones routes
      { path: 'transacciones', component: TransactionLoadComponent },

      // Procesos principales - Solo la ruta que existe
      { path: 'cuentas-por-cobrar/procesos-principales/consulta-facturas-cliente', component: ConsultaFacturasClienteComponent },
      { path: 'cuentas-por-cobrar/procesos-principales/carga-cobranza', component: CargaCobranzaComponent },
      { path: 'cuentas-por-cobrar/procesos-principales/consulta-clientes', component: ConsultaClientesComponent },
      { path: 'cuentas-por-cobrar/procesos-principales/mantenimiento-contactos', component: MantenimientoContactosComponent },
      { path: 'cuentas-por-cobrar/auditoria-correos-facturacion-electronica', component: AuditoriaCorreosFacturacionComponent },
      { path: 'cuentas-por-pagar/procesos-principales/carga-comprobantes', component: CargaComprobantesComponent },

      // Reportes CC
      { path: 'cuentas-por-cobrar/reporte-movimiento-del-dia', component: ReporteMovimientoDelDiaComponent },
      { path: 'cuentas-por-cobrar/conversion-monetaria', component: ConversionMonetariaComponent },
      { path: 'cuentas-por-cobrar/reporte-movimiento-mensual', component: ReporteMovimientoMensualComponent },
      { path: 'cuentas-por-cobrar/reporte-diferencia-en-cambio-cxc-detallado', component: ReporteCC2205Component },
      { path: 'cuentas-por-cobrar/notas-rango-de-fechas', component: ReportesNotasComponent },
      { path: 'cuentas-por-cobrar/estado-de-cuenta-pendiente', component: EstadoDeCuentaPendienteComponent },
      { path: 'cuentas-por-cobrar/estado-de-cuenta-historico-en-otr-moneda', component: EstadoDeCuentaHistoricoEnOtrMonedaComponent },
      { path: 'cuentas-por-cobrar/resumen-cuentas-por-cobrar', component: ResumenCuentasPorCobrarComponent },
      { path: 'cuentas-por-cobrar/estado-ctahist-consolidado', component: EstadoCthhistConsolidadoComponent },
      { path: 'cuentas-por-cobrar/estado-cta-pend-consolidado', component: EstadoCtaPendConsolidadoComponent },
      { path: 'cuentas-por-cobrar/movimiento-por-lote', component: MovimientoPorLoteComponent },
      { path: 'cuentas-por-cobrar/movimiento-por-lote-mensual', component: MovimientoPorLoteMensualComponent },
      { path: 'cuentas-por-cobrar/movimiento-por-lote-selectivo', component: MovimientoPorLoteSelectivoComponent },
      { path: 'cuentas-por-cobrar/facturacion-rango-de-fechas', component: ReportePS5035Component },
      { path: 'cuentas-por-cobrar/reporte-moneda-extranjera-dane', component: ReportePS5001Component },
      { path: 'cuentas-por-cobrar/reporte-facturacion-ofa-por-rango-de-fecha', component: ReportePS5023Component },
      { path: 'cuentas-por-cobrar/reporte-facturacin-ofa-por-rango-de-fecha', component: ReportePS5023Component },
      { path: 'cuentas-por-cobrar/reporte-relacion-de-facturas', component: ReportePS5068Component },
      { path: 'cuentas-por-cobrar/reporte-cc2205', component: ReporteCC2205Component },
      { path: 'cuentas-por-cobrar/informe-de-ingresos-por-trimestre-pg', component: ReporteARG0288Component },
      { path: 'cuentas-por-cobrar/repfact-y-recaudo-por-ciudad-y-pg', component: ReportePS2000Component },
      { path: 'cuentas-por-cobrar/rep-fact-y-recaudo-por-pg', component: ReportePS2001Component },
      { path: 'cuentas-por-cobrar/estado-de-cuenta-historico', component: ReporteCC2205Component },

      // Reportes PS (Presupuesto-Sueldos)
      { path: 'presupuesto-sueldos/reporte-ps5001', component: ReportePS5001Component },
      { path: 'presupuesto-sueldos/reporte-ps5023', component: ReportePS5023Component },
      { path: 'presupuesto-sueldos/reporte-ps5034', component: ReportePS5034Component },
      { path: 'presupuesto-sueldos/reporte-ps5035', component: ReportePS5035Component },
      { path: 'presupuesto-sueldos/reporte-ps5057', component: ReportePS5057Component },
      { path: 'presupuesto-sueldos/reporte-ps5068', component: ReportePS5068Component },

      // Mantenimiento Tipo de Cliente CC
      { path: 'cuentas-por-cobrar/mant-tipo-de-cliente', component: MantTipoDeClienteComponent },
      
      // Mantenimiento Tipo de Documento CC
      { path: 'cuentas-por-cobrar/mant-tipo-de-documento', component: MantTipoDeDocumentoComponent },
      
      // Mantenimiento Clasificación de Ventas CC
      { path: 'cuentas-por-cobrar/mant-clasificacion-venta', component: MantClasificacionVentaComponent },
      
      // Mantenimiento Banco/Tarjeta CC
      { path: 'cuentas-por-cobrar/mant-bancotarjeta', component: MantBancoTarjetaComponent },

      // Mantenimiento Causa de Suspensión CC
      { path: 'cuentas-por-cobrar/mant-causa-de-suspension', component: MantCausaDeSuspensionComponent },

      // Mantenimiento Detalles Generales (FA5156) CC
      { path: 'cuentas-por-cobrar/mantenimiento-detalles-generales', component: MantenimientoDetallesGeneralesComponent },

      // Mantenimiento Vendedor CC
      { path: 'cuentas-por-cobrar/mant-vendedor', component: MantVendedorComponent },

      // Mantenimiento Zona de Venta CC
      { path: 'cuentas-por-cobrar/mant-zona-de-venta', component: MantZonaDeVentaComponent },

      // Mantenimiento Tipo de Negocio CC
      { path: 'cuentas-por-cobrar/mant-tipo-de-negocio', component: MantTipoDeNegocioComponent },

      // Mantenimiento Localidades CC
      { path: 'cuentas-por-cobrar/mant-localidades', component: MantLocalidadesComponent },

      // Mantenimiento Condiciones de Pago CC
      { path: 'cuentas-por-cobrar/mant-condiciones-de-pago', component: MantCondicionesDePagoComponent },

      // Mantenimiento Descuentos CC
      { path: 'cuentas-por-cobrar/mant-descuentos', component: MantDescuentosComponent },

      // Mantenimiento Ciudades GE0012
      { path: 'cuentas-por-cobrar/mant-ciudades', component: MantCiudadesComponent },

      // Mantenimiento Retención CC0049
      { path: 'cuentas-por-cobrar/mant-retencion', component: MantRetencionComponent },

      // Mantenimiento Contable Tipo Documento CC0026
      { path: 'cuentas-por-cobrar/mant-contable-tipo-documento', component: MantContableTipoDocumentoComponent },

      // Mantenimiento Cuentas Contables CG5002
      { path: 'cuentas-por-cobrar/mantenimiento-de-cuentas', component: MantenimientoDeCuentasComponent },

      // Mantenimiento Tablas 1-5 CC0032
      { path: 'cuentas-por-cobrar/mant-tablas-1-5', component: MantTablas15Component },

      // Mantenimiento Tablas Generales (Tablas 1-5) - CC0008-CC0012
      { path: 'cuentas-por-cobrar/mant-tablas-generales', component: MantTablasGeneralesComponent },

      // Parámetros Observaciones en Inglés (PS5141)
      { path: 'cuentas-por-cobrar/parametros-observaciones-en-ingles', component: MantParametrosObservacionesComponent },
      
      // Parámetros de Facturación (FA0001)
      { path: 'cuentas-por-cobrar/parametros-de-facturacion', component: MantParametrosFacturacionComponent },
      
      // Modificación Detalle Facturas (ARG0284)
      { path: 'cuentas-por-cobrar/modificacion-detalle-facturas', component: MantDistribucionFacturasComponent },
      { path: 'cuentas-por-cobrar/mantenimiento-distribucion-facturas', component: MantDistribucionFacturasComponent },
      { path: 'cuentas-por-cobrar/otros-datos-facturacion-electronica', component: OtrosDatosFacturacionComponent },
      { path: 'cuentas-por-cobrar/mantenimiento-resoluciones-facturacion', component: MantResolucionesFacturacionComponent },
      { path: 'cuentas-por-cobrar/mantenimiento-descuentos-facturacion', component: MantDescuentosFacturacionComponent },
      { path: 'cuentas-por-cobrar/mantenimiento-datos-compra', component: MantDatosCompraComponent },
      { path: 'cuentas-por-cobrar/mantenimiento-clientes', component: MantClientesComponent },
      { path: 'cuentas-por-cobrar/reporte-facturacion-fecha', component: ReporteFacturacionFechaComponent },
      { path: 'cuentas-por-cobrar/reporte-notas-fecha', component: ReporteNotasFechaComponent },
      { path: 'cuentas-por-cobrar/mantenimiento-centros-costos', component: MantCentrosCostosComponent },
      { path: 'cuentas-por-cobrar/mantenimiento-bases-liquidacion', component: MantBasesLiquidacionComponent },
      { path: 'cuentas-por-cobrar/reporte-ingresos-trimestre', component: ReporteIngresosTrimestresComponent },
      
      // Nuevos componentes de facturación (ARG5014, PS5018, PS5113)
      { path: 'cuentas-por-cobrar/generacion-archivo-factura-electronica', component: Arg5014Component },
      { path: 'cuentas-por-cobrar/reporte-gastos-de-facturacin', component: Ps5018Component },
      { path: 'cuentas-por-cobrar/reporte-gastos-de-facturacion', component: Ps5018Component },
      { path: 'cuentas-por-cobrar/reporte-de-facturas-sin-codigo-cufe-ubl2-dic-19', component: Ps5113CufeComponent },

      // Componentes de facturación (FA5220, FA5212, FA5003, FA5001)
      { path: 'cuentas-por-cobrar/reporte-de-facturacion-recurrente', component: ReporteDeFacturacionRecurrenteComponent },
      { path: 'cuentas-por-cobrar/reimpresion-de-facturas', component: ReimpresionDeFacturasComponent },
      { path: 'cuentas-por-cobrar/observacion-generales', component: ObservacionGeneralesComponent },
      { path: 'cuentas-por-cobrar/configuracion-clientes-electronicos-x-cia', component: ConfiguracionClientesElectronicosComponent },
      { path: 'cuentas-por-cobrar/procesos-facturacion/configuracion-clientes-electronicos-x-cia', component: ConfiguracionClientesElectronicosComponent },
      { path: 'cuentas-por-cobrar/parametros-observaciones-en-ingles', component: ParametrosObservacionesEnInglesComponent },
      { path: 'cuentas-por-cobrar/procesos-facturacion/parametros-observaciones-en-ingles', component: ParametrosObservacionesEnInglesComponent },
      { path: 'cuentas-por-cobrar/genarchivos-factnotas-y-cartx-lectarchivo', component: GenArchivosFactnotasYCartComponent },

  // Mantenimiento Parámetros Generales (ubicación indicada por el usuario)
  { path: 'cuentas-por-cobrar/mantenimiento-parametros', component: MantenimientoParametrosGeneralesComponent },

    // Reiniciar Password (GE0056)
    { path: 'cuentas-por-cobrar/reiniciar-password', component: ReiniciarPasswordComponent },

      // Cambio de Password (GE0058)
      { path: 'cuentas-por-cobrar/cambio-de-password', component: CambioDePasswordComponent },

      // Asignación de Opciones x Perfil (GE0057)
      { path: 'cuentas-por-cobrar/asignacion-de-opciones-x-perfil', component: Ge0057AsignacionOpcionesComponent },

      // Demo Secondary Menu
      { path: 'demo-secondary-menu', component: DemoSecondaryMenuComponent },

      { path: '', redirectTo: '/dashboard', pathMatch: 'full' }
    ]
  }
];
