import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, lastValueFrom } from 'rxjs';
import { catchError, map, timeout } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { AuthService } from './auth.service';
import { CompaniasResponse, CompaniaRecord, ReportesResponse, ConversionMonetariaResponse, ReporteOption, GenerarReporteResponse, TipoClienteResponse, TipoClienteRecord, TipoDocumentoRecord, TipoDocumentoResponse, ClasificacionVentaRecord, ClasificacionVentaResponse, BancoTarjetaRecord, BancoTarjetaResponse } from '../interfaces/cc.interface';

@Injectable({ providedIn: 'root' })
export class CCService {
  constructor(private http: HttpClient, private auth: AuthService) {}

  /** Obtener parámetros de autenticación */
  getAuthParams(): { pcLogin: string; pcSuper: string; pcToken: string } {
    const user = this.auth.user();
    return {
      pcLogin: user?.pcLogin || '',
      pcSuper: user?.pcSuper || '',
      pcToken: user?.pcToken || ''
    };
  }

  /** CC2201: Buscar todas las compañías disponibles */
  getCompanias(): Observable<CompaniaRecord[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECompanias?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<CompaniasResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tgecias || []),
      catchError(err => {
        console.error('Error getCompanias', err);
        return of([]);
      })
    );
  }

  /** CC2201: Validar compañía específica */
  validateCompania(pcCompania: string): Observable<CompaniaRecord | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveGEcias?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<CompaniasResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tgecias?.[0] || null),
      catchError(err => {
        console.error('Error validateCompania', err);
        return of(null);
      })
    );
  }

  /** Obtener opciones de reportes para una compañía y fecha */
  getReportesOptions(pcCompania: string, pcFecha: string, pcPrograma: string = 'cc2201'): Observable<ReporteOption[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetSelectorReportesPD?pcCompania=${encodeURIComponent(pcCompania)}&pcPrograma=${encodeURIComponent(pcPrograma)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - getReportesOptions called with:', { pcCompania, pcFecha, pcPrograma, url });

    return this.http.get<ReportesResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tSelect || []),
      catchError(err => {
        console.error('Error getReportesOptions', err);
        return of([]);
      })
    );
  }

  /** CC2201: Generar reporte con parámetros específicos */
  generarReporte(pcCompania: string, pcFecha: string, pcReporte: string): Observable<GenerarReporteResponse['response'] | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetGeneraReportesPD?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcReporte=${encodeURIComponent(pcReporte)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response || null),
      catchError(err => {
        console.error('Error generarReporte', err);
        return of(null);
      })
    );
  }

  // ============ MÉTODOS PARA TIPOS DE CLIENTE (CC0013) ============

  /** CC0013: Consulta emergente de tipos de cliente */
  async getCETipoCliente(pcCompania: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCETipoCliente?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getCETipoCliente', error);
      return null;
    }
  }

  /** CC0013: Evento Leave del campo Tipo de Cliente */
  async getLeaveTipoCliente(pcCompania: string, pcTipoCli: string | number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveTipoCliente-cc0013?pcCompania=${encodeURIComponent(pcCompania)}&pcTipoCli=${encodeURIComponent(pcTipoCli)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeaveTipoCliente', error);
      return null;
    }
  }

  /** CC0013: Obtener todos los tipos de cliente para una compañía */
  getTiposCliente(pcCompania: string): Observable<TipoClienteRecord[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCETipoCliente?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<TipoClienteResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tcctipcli || []),
      catchError(err => {
        console.error('Error getTiposCliente', err);
        return of([]);
      })
    );
  }

  /** CC0013: Validar tipo de cliente específico */
  validateTipoCliente(pcCompania: string, pcTipoCli: string): Observable<TipoClienteRecord | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveTipoCliente-cc0013?pcCompania=${encodeURIComponent(pcCompania)}&pcTipoCli=${encodeURIComponent(pcTipoCli)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<TipoClienteResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tcctipcli?.[0] || null),
      catchError(err => {
        console.error('Error validateTipoCliente', err);
        return of(null);
      })
    );
  }

  /** CC0013: Crear tipo de cliente (async version) */
  async createTipoClienteAsync(payload: any): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    // Preparar el body como dataset con estructura similar a las respuestas
    const requestBody = {
      dsRespuesta: {
        tcctipcli: [{
          ...payload,
          'login-ctrl': pcLogin
        }]
      },
      pcLogin,
      pcSuper,
      pcToken
    };

    const url = `${environment.apiUrl}/InsertCctipcli-cc0013`;

    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    try {
      return await this.http.post<any>(url, requestBody, { headers }).toPromise();
    } catch (error) {
      console.error('Error createTipoClienteAsync', error);
      throw error;
    }
  }

  /** CC0013: Crear o actualizar tipo de cliente (async version) */
  async updateTipoClienteAsync(payload: any): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    // Los parámetros de autenticación van en la URL como query parameters
    const url = `${environment.apiUrl}/UpdateCctipcli-cc0013?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    // El body contiene SOLO la estructura de datos sin parámetros de autenticación
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    try {
      console.log('📤 Enviando updateTipoClienteAsync - URL:', url);
      console.log('📤 Enviando updateTipoClienteAsync - Body:', JSON.stringify(payload, null, 2));
      
      const response = await this.http.put<any>(url, payload, { headers }).toPromise();
      
      console.log('📥 Respuesta updateTipoClienteAsync:', JSON.stringify(response, null, 2));
      return response;
    } catch (error) {
      console.error('❌ Error updateTipoClienteAsync', error);
      throw error;
    }
  }

  /** CC0013: Eliminar tipo de cliente (async version) */
  async deleteTipoClienteAsync(pcCompania: string, pcTipoCli: string | number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/DeleteCctipcli-cc0013?pcCompania=${encodeURIComponent(pcCompania)}&pcTipoCli=${encodeURIComponent(pcTipoCli)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.delete<any>(url).toPromise();
    } catch (error) {
      console.error('Error deleteTipoClienteAsync', error);
      throw error;
    }
  }

  /** CC0030: Crear tipo de documento (async version) */
  async createTipoDocumentoAsync(payload: any): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    // Preparar el body como dataset con estructura similar a las respuestas
    const requestBody = {
      dsRespuesta: {
        tcctipdoc: [{
          ...payload,
          'login-ctrl': pcLogin
        }]
      },
      pcLogin,
      pcSuper,
      pcToken
    };

    const url = `${environment.apiUrl}/InsertCctipdoc-cc0030`;

    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    try {
      return await this.http.post<any>(url, requestBody, { headers }).toPromise();
    } catch (error) {
      console.error('Error createTipoDocumentoAsync', error);
      throw error;
    }
  }

  /** CC0004: Crear tipo de negocio (async version) */
  async createTipoNegocioAsync(payload: any): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    // Preparar el body como dataset con estructura similar a las respuestas
    const requestBody = {
      dsRespuesta: {
        tccnegocio: [{
          ...payload,
          'login-ctrl': pcLogin
        }]
      },
      pcLogin,
      pcSuper,
      pcToken
    };

    const url = `${environment.apiUrl}/InsertCcnegocio-cc0004`;

    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    try {
      return await this.http.post<any>(url, requestBody, { headers }).toPromise();
    } catch (error) {
      console.error('Error createTipoNegocioAsync', error);
      throw error;
    }
  }

  /** CC0017: Crear zona de venta (async version) */
  async createZonaVentaAsync(payload: any): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    // Preparar el body con estructura correcta para CC0017
    const requestBody = {
      tcczona: [{
        cia: payload.cia,
        zona: payload.zona,
        'nombre-zon': payload['nombre-zon'],
        'text-zon': payload['text-zon'],
        'login-ctrl': pcLogin,
        'date-ctrl': new Date().toISOString().split('T')[0],
        tparent: pcLogin
      }]
    };

    const url = `${environment.apiUrl}/Updatecczona-CC0017?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    try {
      const response = await this.http.put<any>(url, requestBody, { headers }).toPromise();
      return response;
    } catch (error) {
      console.error('❌ Error createZonaVentaAsync', error);
      throw error;
    }
  }

  /** CC0046: Crear descuento (async version) */
  async createDescuentoAsync(payload: any): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    // Preparar el body como dataset con estructura similar a las respuestas
    const requestBody = {
      tcctabdes: [{
        cia: payload.cia,
        'descue-tdes': payload['descue-tdes'],
        'nombre-tdes': payload['nombre-tdes'],
        'porcen-tdes': payload['porcen-tdes'],
        gravable: payload.gravable || false,
        cuenta: payload.cuenta || '',
        ubicacion: payload.ubicacion || 0,
        centro: payload.centro || 0,
        auxiliar: payload.auxiliar || 0,
        'text-tdes': payload['text-tdes'] || '',
        'Agrega-Tabd': ''
      }]
    };

    const url = `${environment.apiUrl}/UpdateCctabdes-cc0046`;

    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    const body = {
      pcLogin,
      pcSuper,
      pcToken,
      dsRespuesta: requestBody
    };

    try {
      return await this.http.put<any>(url, body, { headers }).toPromise();
    } catch (error) {
      console.error('Error createDescuentoAsync', error);
      throw error;
    }
  }

  /** CC0013: Actualizar/Insertar tipo de cliente */
  updateTipoCliente(tipoClienteData: Partial<TipoClienteRecord>): Observable<TipoClienteRecord | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    // Preparar el body como dataset con estructura similar a las respuestas
    const requestBody = {
      dsRespuesta: {
        tcctipcli: [{
          ...tipoClienteData,
          'login-ctrl': pcLogin
        }]
      },
      pcLogin,
      pcSuper,
      pcToken
    };

    const url = `${environment.apiUrl}/UpdateCctipcli-cc0013`;

    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    console.log('Enviando datos a updateTipoCliente:', requestBody);
    console.log('Headers:', headers);
    console.log('URL completa:', url);

    return this.http.put<TipoClienteResponse>(url, requestBody, { headers }).pipe(
      timeout(15000), // Timeout de 15 segundos
      map(res => {
        console.log('Respuesta updateTipoCliente:', res);
        return res?.dsRespuesta?.tcctipcli?.[0] || null;
      }),
      catchError(err => {
        console.error('Error updateTipoCliente', err);
        if (err.name === 'TimeoutError') {
          console.error('Timeout en updateTipoCliente');
        }
        return of(null);
      })
    );
  }

  /** CC0013: Eliminar tipo de cliente */
  deleteTipoCliente(pcCompania: string, pcTipoCli: string): Observable<TipoClienteRecord | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/DeleteCctipcli-cc0013?pcCompania=${encodeURIComponent(pcCompania)}&pcTipoCli=${encodeURIComponent(pcTipoCli)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.delete<TipoClienteResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tcctipcli?.[0] || null),
      catchError(err => {
        console.error('Error deleteTipoCliente', err);
        return of(null);
      })
    );
  }

  /** CC2013: Generar reporte de tipos de cliente */
  generarReporteTipoCliente(pcCompania: string, pcFecha: string): Observable<{ pcArchPDF: string; pcArchCSV: string } | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Getcc2013?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - generarReporteTipoCliente URL:', url);

    return this.http.get<{ response: { pcArchPDF: string; pcArchCSV: string } }>(url).pipe(
      map(res => res?.response || null),
      catchError(err => {
        console.error('Error generarReporteTipoCliente', err);
        return of(null);
      })
    );
  }

  // ========== MÉTODOS PARA TIPOS DE DOCUMENTO (CC0014) ==========

  /** CC0014: Obtener todos los tipos de documento para una compañía */
  getTiposDocumento(pcCompania: string): Observable<TipoDocumentoRecord[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCETipoDoc-cc0014?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<TipoDocumentoResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tcctipdoc || []),
      catchError(err => {
        console.error('Error getTiposDocumento', err);
        return of([]);
      })
    );
  }

  /** CC0014: Validar tipo de documento específico */
  validateTipoDocumento(pcCompania: string, pcTipodoc: string): Observable<TipoDocumentoRecord | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveTipoDoc-cc0014?pcCompania=${encodeURIComponent(pcCompania)}&pcTipodoc=${encodeURIComponent(pcTipodoc)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<TipoDocumentoResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tcctipdoc?.[0] || null),
      catchError(err => {
        console.error('Error validateTipoDocumento', err);
        return of(null);
      })
    );
  }

  /** CC0014: Actualizar tipo de documento */
  async updateTipoDocumento(payload: any): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    try {
      const url = `${environment.apiUrl}/UpdateCctipdoc-cc0014?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
      console.log('📝 updateTipoDocumento - URL:', url);
      console.log('📝 updateTipoDocumento - Payload:', JSON.stringify(payload, null, 2));
      const response = await lastValueFrom(this.http.put<any>(url, payload));
      console.log('✅ updateTipoDocumento - Respuesta:', response);
      return response;
    } catch (error) {
      console.error('❌ Error updateTipoDocumento:', error);
      return null;
    }
  }

  /** CC0014: Eliminar tipo de documento */
  deleteTipoDocumento(pcCompania: string, pcTipodoc: string): Observable<TipoDocumentoRecord | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/DeleteCctipdoc-cc0014?pcCompania=${encodeURIComponent(pcCompania)}&pcTipodoc=${encodeURIComponent(pcTipodoc)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.delete<TipoDocumentoResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tcctipdoc?.[0] || null),
      catchError(err => {
        console.error('Error deleteTipoDocumento', err);
        return of(null);
      })
    );
  }

  /** CC0014: Generar reporte de tipos de documento */
  generarReporteTipoDocumento(pcCompania: string, pcFecha: string, formato: 'pdf' | 'csv' = 'pdf'): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Getcc2014?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error generarReporteTipoDocumento', err);
        return of(null);
      })
    );
  }

  /** CAUSA DE SUSPENSIÓN (CC2003) */
  generarReporteCausaSuspension(pcCompania: string, pcFecha: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Getcc2003?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - generarReporteCausaSuspension URL:', url);

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error generarReporteCausaSuspension', err);
        return of(null);
      })
    );
  }

  /** TIPO DE NEGOCIO (CC2006) */
  generarReporteTipoNegocio(pcCompania: string, pcFecha: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCC2007?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - generarReporteTipoNegocio URL:', url);

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error generarReporteTipoNegocio', err);
        return of(null);
      })
    );
  }

  /** VENDEDOR (CC2016) */
  generarReporteVendedor(pcCompania: string, pcFecha: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCC2016?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - generarReporteVendedor URL:', url);

    return this.http.get<any>(url).pipe(
      map(res => res?.response || null),
      catchError(err => {
        console.error('Error generarReporteVendedor', err);
        return of(null);
      })
    );
  }

  /** RETENCION (CC2049) */
  generarReporteRetencion(pcCompania: string, pcFecha: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCC2049?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - generarReporteRetencion URL:', url);

    return this.http.get<any>(url).pipe(
      map(res => res?.response || null),
      catchError(err => {
        console.error('Error generarReporteRetencion', err);
        return of(null);
      })
    );
  }

  /** ZONA DE VENTA (CC2017) */
  generarReporteZonaVenta(pcCompania: string, pcFecha: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCC2017?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - generarReporteZonaVenta URL:', url);

    return this.http.get<any>(url).pipe(
      map(res => res?.response || null),
      catchError(err => {
        console.error('Error generarReporteZonaVenta', err);
        return of(null);
      })
    );
  }

  // ================== CLASIFICACION DE VENTAS (CC0032) ==================

  /** CC0032: Obtener todas las clasificaciones de venta para una compañía */
  getClasificacionesVenta(pcCompania: string): Observable<ClasificacionVentaRecord[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEClaven-cc0032?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<ClasificacionVentaResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tccclaven || []),
      catchError(err => {
        console.error('Error getClasificacionesVenta', err);
        return of([]);
      })
    );
  }

  /** CC0032: Validar clasificación de venta específica */
  validateClasificacionVenta(pcCompania: string, pcClaVen: string): Observable<ClasificacionVentaRecord | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveClaven-cc0032?pcCompania=${encodeURIComponent(pcCompania)}&pcClaVen=${encodeURIComponent(pcClaVen)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<ClasificacionVentaResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tccclaven?.[0] || null),
      catchError(err => {
        console.error('Error validateClasificacionVenta', err);
        return of(null);
      })
    );
  }

  /** CC0032: Actualizar clasificación de venta */
  updateClasificacionVenta(clasificacionData: ClasificacionVentaRecord): Observable<ClasificacionVentaRecord | null> {
    const url = `${environment.apiUrl}/UpdateCcclaven-cc0032`;
    
    const payload = {
      tccclaven: [clasificacionData]
    };

    return this.http.put<ClasificacionVentaResponse>(url, payload).pipe(
      map(res => res?.dsRespuesta?.tccclaven?.[0] || null),
      catchError(err => {
        console.error('Error updateClasificacionVenta', err);
        return of(null);
      })
    );
  }

  /** CC0032: Eliminar clasificación de venta */
  deleteClasificacionVenta(pcCompania: string, pcClaVen: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Delccclaven-cc0032?pcCompania=${encodeURIComponent(pcCompania)}&pcClaVen=${encodeURIComponent(pcClaVen)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.delete<ClasificacionVentaResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tccclaven?.[0] || null),
      catchError(err => {
        console.error('Error deleteClasificacionVenta', err);
        return of(null);
      })
    );
  }

  /** CC0032: Generar reporte de clasificaciones de venta */
  generarReporteClasificacionVenta(pcCompania: string, pcFecha: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Getcc2032?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error generarReporteClasificacionVenta', err);
        return of(null);
      })
    );
  }

  // ============ MÉTODOS PARA BANCO/TARJETA ============

  /** CC0042: Buscar todos los bancos/tarjetas disponibles para una compañía */
  getBancosTarjetas(pcCompania: string): Observable<BancoTarjetaRecord[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEBantar-cc0042?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<BancoTarjetaResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tccbantar || []),
      catchError(err => {
        console.error('Error getBancosTarjetas', err);
        return of([]);
      })
    );
  }

  /** CC0042: Validar banco/tarjeta específico */
  validateBancoTarjeta(pcCompania: string, pcBantar: string): Observable<BancoTarjetaRecord | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveBantar-cc0042?pcCompania=${encodeURIComponent(pcCompania)}&pcBantar=${encodeURIComponent(pcBantar)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<BancoTarjetaResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tccbantar?.[0] || null),
      catchError(err => {
        console.error('Error validateBancoTarjeta', err);
        return of(null);
      })
    );
  }

  /** CC0042: Crear o actualizar banco/tarjeta */
  updateBancoTarjeta(bancoTarjeta: BancoTarjetaRecord): Observable<BancoTarjetaRecord | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/UpdateCcbantar-cc0042?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    
    const payload = {
      tccbantar: [bancoTarjeta]
    };

    return this.http.put<BancoTarjetaResponse>(url, payload).pipe(
      map(res => res?.dsRespuesta?.tccbantar?.[0] || null),
      catchError(err => {
        console.error('Error updateBancoTarjeta', err);
        return of(null);
      })
    );
  }

  /** CC0042: Eliminar banco/tarjeta */
  deleteBancoTarjeta(pcCompania: string, pcBantar: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Delccbantar-cc0042?pcCompania=${encodeURIComponent(pcCompania)}&pcBantar=${encodeURIComponent(pcBantar)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.delete<BancoTarjetaResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tccbantar?.[0] || null),
      catchError(err => {
        console.error('Error deleteBancoTarjeta', err);
        return of(null);
      })
    );
  }

  /** CC2042: Generar reporte de bancos/tarjetas */
  generarReporteBancoTarjeta(pcCompania: string, pcFecha: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Getcc2042?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error generarReporteBancoTarjeta', err);
        return of(null);
      })
    );
  }

  // ============ MÉTODOS PARA CAUSA DE SUSPENSIÓN (CC0003) ============

  /** CC0003: Obtener compañía por leave */
  async getLeaveCompania(pcCompania: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveGEcias?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeaveCompania', error);
      return null;
    }
  }

  /** CC0003: Consulta emergente de causas de suspensión */
  async getCECausaSuspension(pcCompania: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECausasusp?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getCECausaSuspension', error);
      return null;
    }
  }

  /** CC0003: Evento Leave del campo Causa de Suspensión */
  async getLeaveCausaSuspension(pcCompania: string, pcCausaSus: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCausaSusp?pcCompania=${encodeURIComponent(pcCompania)}&pcCausaSus=${encodeURIComponent(pcCausaSus)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeaveCausaSuspension', error);
      return null;
    }
  }

  /** CC0003: Crear o actualizar causa de suspensión */
  async updateCausaSuspension(payload: any): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    // Inyectar credenciales en el payload - siguiendo el mismo patrón que otros updates
    if (payload.tcccausus && payload.tcccausus.length > 0) {
      payload.tcccausus[0]['login-ctrl'] = pcLogin;
    }

    const url = `${environment.apiUrl}/UpdateCccausus-cc0003?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - updateCausaSuspension payload:', payload);

    try {
      return await this.http.put<any>(url, payload).toPromise();
    } catch (error) {
      console.error('Error updateCausaSuspension', error);
      throw error;
    }
  }

  /** CC0003: Eliminar causa de suspensión */
  async deleteCausaSuspension(pcCompania: string, pcCausaSus: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/DelCccausus-cc0003?pcCompania=${encodeURIComponent(pcCompania)}&pcCausaSus=${encodeURIComponent(pcCausaSus)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.delete<any>(url).toPromise();
    } catch (error) {
      console.error('Error deleteCausaSuspension', error);
      return null;
    }
  }

  // ============ MÉTODOS PARA VENDEDOR (CC5016) ============

  /** CC5016: Obtener compañía por leave */
  async getLeaveCompaniaVendedor(pcCompania: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveGEciasCxC?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeaveCompaniaVendedor', error);
      return null;
    }
  }

  /** CC5016: Consulta emergente de vendedores */
  async getCEVendedor(pcCompania: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEVendedor?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getCEVendedor', error);
      return null;
    }
  }

  /** CC5016: Evento Leave del campo Vendedor */
  async getLeaveVendedor(pcCompania: string, pcVendedor: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveVendedor?pcCompania=${encodeURIComponent(pcCompania)}&pcVendedor=${encodeURIComponent(pcVendedor)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeaveVendedor', error);
      return null;
    }
  }

  /** CC5016: Consulta emergente del campo Supervisor */
  async getCECodesuper(pcCompania: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECodsuper_cc5016?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getCECodesuper', error);
      return null;
    }
  }

  /** CC5016: Evento Leave del campo Supervisor */
  async getLeaveCodsuper(pcCompania: string, pcSupervisor: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCodsuper_cc5016?pcCompania=${encodeURIComponent(pcCompania)}&pcSupervisor=${encodeURIComponent(pcSupervisor)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeaveCodsuper', error);
      return null;
    }
  }

  /** CC5016: Consulta emergente del campo Ubicación */
  async getCEUbicacion(pcCompania: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEUbicacionCxC?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getCEUbicacion', error);
      return null;
    }
  }

  /** CC5016: Consulta emergente del campo Centro de Costo */
  async getCECentro(pcCompania: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECentroCCxC?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getCECentro', error);
      return null;
    }
  }

  /** CC5016: Evento Leave del campo Centro */
  async getLeavecentro(pcCompania: string, pcCentro: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCentro-cc0046?pcCompania=${encodeURIComponent(pcCompania)}&pcCentro=${encodeURIComponent(pcCentro)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeavecentro', error);
      return null;
    }
  }

  /** CC5016: Consulta emergente del campo Zona */
  async getCEZonaVendedor(pcCompania: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEZona?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getCEZonaVendedor', error);
      return null;
    }
  }

  /** CC5016: Crear o actualizar vendedor */
  async updateVendedor(payload: any): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    // Inyectar credenciales en el payload - siguiendo el mismo patrón que otros updates
    if (payload.tccvended && payload.tccvended.length > 0) {
      payload.tccvended[0]['login-ctrl'] = pcLogin;
    }

    const url = `${environment.apiUrl}/Updateccvended_cc5016?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - updateVendedor payload:', payload);

    try {
      return await this.http.put<any>(url, payload).toPromise();
    } catch (error) {
      console.error('Error updateVendedor', error);
      throw error;
    }
  }

  /** CC5016: Eliminar vendedor */
  async deleteVendedor(pcCompania: string, pcVendedor: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/DelCcvended_cc5016?pcCompania=${encodeURIComponent(pcCompania)}&pcVendedor=${encodeURIComponent(pcVendedor)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.delete<any>(url).toPromise();
    } catch (error) {
      console.error('Error deleteVendedor', error);
      return null;
    }
  }

  // ==================== CC0017: ZONA DE VENTA ====================

  /** CC0017: Consulta emergente del campo Zona */
  async getCEZona(pcCompania: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEZona?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getCEZona', error);
      return null;
    }
  }

  /** CC0017: Evento Leave del campo Zona */
  async getLeaveZona(pcCompania: string, pcZona: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveZona?pcCompania=${encodeURIComponent(pcCompania)}&pcZona=${encodeURIComponent(pcZona)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeaveZona', error);
      return null;
    }
  }

  /** CC0017: Crear o actualizar un registro de Zona */
  async updateZonaVenta(payload: any): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    // Inyectar credenciales en el payload
    if (payload.tcczona && payload.tcczona.length > 0) {
      payload.tcczona[0]['login-ctrl'] = pcLogin;
    }

    const url = `${environment.apiUrl}/Updatecczona-CC0017?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.put<any>(url, payload).toPromise();
    } catch (error) {
      console.error('Error updateZonaVenta', error);
      return null;
    }
  }

  /** CC0017: Eliminar un registro de Zona */
  async deleteZonaVenta(pcCompania: string, pcZona: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Delcczona-cc0017?pcCompania=${encodeURIComponent(pcCompania)}&pcZona=${encodeURIComponent(pcZona)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.delete<any>(url).toPromise();
    } catch (error) {
      console.error('Error deleteZonaVenta', error);
      return null;
    }
  }

  // ==================== CC0007: TIPO DE NEGOCIO ====================

  /** CC0007: Consulta emergente del campo Negocio */
  async getCENegocio(pcCompania: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEGenegocio?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getCENegocio', error);
      return null;
    }
  }

  /** CC0007: Evento Leave del campo Negocio */
  async getLeaveNegocio(pcCompania: string, pcNegocio: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveNegocio?pcCompania=${encodeURIComponent(pcCompania)}&pcNegocio=${encodeURIComponent(pcNegocio)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeaveNegocio', error);
      return null;
    }
  }

  /** CC0007: Crear o actualizar un registro de Negocio */
  async updateTipoNegocio(payload: any): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    // Inyectar credenciales en el payload
    if (payload.tccnegoci && payload.tccnegoci.length > 0) {
      payload.tccnegoci[0]['login-ctrl'] = pcLogin;
    }

    const url = `${environment.apiUrl}/Updatecnegoci-CC0007?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.put<any>(url, payload).toPromise();
    } catch (error) {
      console.error('Error updateTipoNegocio', error);
      return null;
    }
  }

  /** CC0007: Eliminar un registro de Negocio */
  async deleteTipoNegocio(pcCompania: string, pcNegocio: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/DelCcnegoci-cc0007?pcCompania=${encodeURIComponent(pcCompania)}&pcNegocio=${encodeURIComponent(pcNegocio)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.delete<any>(url).toPromise();
    } catch (error) {
      console.error('Error deleteTipoNegocio', error);
      return null;
    }
  }

  // ==================== CC0006: LOCALIDADES ====================

  /** CC0006: Consulta emergente del campo Localidad */
  async getCELocalidad(pcCompania: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCELocalidad?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('🔍 getCELocalidad:', { pcCompania, url });
    try {
      const response = await this.http.get<any>(url).toPromise();
      console.log('✅ getCELocalidad Response:', response);
      return response;
    } catch (error) {
      console.error('❌ Error getCELocalidad', error);
      return null;
    }
  }

  /** CC0006: Evento Leave del campo Localidad */
  async getLeaveLocalidad(pcCompania: string, pcLocalidad: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeavelocalidad-cc0006?pcCompania=${encodeURIComponent(pcCompania)}&pcLocalidad=${encodeURIComponent(pcLocalidad)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeaveLocalidad', error);
      return null;
    }
  }

  /** CC0006: Crear o actualizar un registro de Localidad */
  async updateLocalidad(payload: any): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    // Inyectar credenciales en el payload
    if (payload.tcclocali && payload.tcclocali.length > 0) {
      payload.tcclocali[0]['login-ctrl'] = pcLogin;
    }

    const url = `${environment.apiUrl}/UpdateCclocali-CC0006?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.put<any>(url, payload).toPromise();
    } catch (error) {
      console.error('Error updateLocalidad', error);
      return null;
    }
  }

  /** CC0006: Eliminar un registro de Localidad */
  async deleteLocalidad(pcCompania: string, pcLocalidad: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Delcclocali-cc0006?pcCompania=${encodeURIComponent(pcCompania)}&pcLocalidad=${encodeURIComponent(pcLocalidad)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.delete<any>(url).toPromise();
    } catch (error) {
      console.error('Error deleteLocalidad', error);
      return null;
    }
  }

  // ==================== CC0005: CONDICIONES DE PAGO ====================
  
  /** CC0005: Consulta emergente de condiciones de pago */
  async getCECondPago(pcCompania: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECondPago?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      console.log('📋 getCECondPago - URL:', url);
      const response = await lastValueFrom(this.http.get<any>(url));
      console.log('✅ getCECondPago - Encontradas:', response?.dsRespuesta?.tccconpag?.length || 0, 'condiciones');
      return response;
    } catch (error) {
      console.error('❌ Error getCECondPago:', error);
      return null;
    }
  }

  /** CC0005: Validación al salir del campo condición de pago */
  async getLeaveCondPago(pcCompania: string, pcCondPago: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCondpago-cc0005?pcCompania=${encodeURIComponent(pcCompania)}&pcCondpago=${encodeURIComponent(pcCondPago)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      console.log('🔍 getLeaveCondPago - URL:', url);
      const response = await lastValueFrom(this.http.get<any>(url));
      console.log('✅ getLeaveCondPago - Respuesta recibida:', response?.dsRespuesta?.tccconpag?.[0]?.['nombre-cpag']);
      return response;
    } catch (error) {
      console.error('❌ Error getLeaveCondPago:', error);
      return null;
    }
  }

  /** CC0005: Guardar condición de pago */
  async updateCondicionPago(payload: any): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    try {
      const url = `${environment.apiUrl}/UpdateCcconpag-CC0005?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
      console.log('📝 updateCondicionPago - URL:', url);
      console.log('📝 updateCondicionPago - Payload:', JSON.stringify(payload, null, 2));
      const response = await lastValueFrom(this.http.put<any>(url, payload));
      console.log('✅ updateCondicionPago - Respuesta:', response);
      return response;
    } catch (error) {
      console.error('❌ Error updateCondicionPago:', error);
      return null;
    }
  }

  /** CC0005: Eliminar condición de pago */
  async deleteCondicionPago(pcCompania: string, pcCondPago: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Delccconpag-cc0005?pcCompania=${encodeURIComponent(pcCompania)}&pcCondpago=${encodeURIComponent(pcCondPago)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      console.log('🗑️ deleteCondicionPago - URL:', url);
      const response = await lastValueFrom(this.http.delete<any>(url));
      console.log('✅ deleteCondicionPago - Respuesta:', response);
      return response;
    } catch (error) {
      console.error('❌ Error deleteCondicionPago:', error);
      return null;
    }
  }

  /** CC0005: Reporte de Condiciones de Pago */
  async getReporteCondicionesPago(pcCompania: string, pcFecha: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    try {
      const url = `${environment.apiUrl}/GetCC2005?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
      const response = await lastValueFrom(this.http.get<any>(url));
      return response?.response || response;
    } catch (error) {
      console.error('Error getReporteCondicionesPago', error);
      return null;
    }
  }

  async getReporteLocalidades(pcCompania: string, pcFecha: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    try {
      const url = `${environment.apiUrl}/Getcc2006?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
      const response = await lastValueFrom(this.http.get<any>(url));
      return response?.response || response;
    } catch (error) {
      console.error('Error getReporteLocalidades', error);
      return null;
    }
  }

  // ==================== CC0046: DESCUENTOS ====================
  
  /** CC0046: Consulta emergente de descuentos */
  async getCEDescuento(pcCompania: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEdescue-tdes-cc0046?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getCEDescuento', error);
      return null;
    }
  }

  /** CC0046: Validación al salir del campo descuento */
  async getLeaveDescuento(pcCompania: string, pcDescuetdes: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeavedescue-tdes-cc0046?pcCompania=${encodeURIComponent(pcCompania)}&pcDescuetdes=${encodeURIComponent(pcDescuetdes)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeaveDescuento', error);
      return null;
    }
  }

  /** CC0046: Validación al salir del campo cuenta */
  async getLeaveCuenta(pcCompania: string, pcCuenta: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCuenta-cc0046?pcCompania=${encodeURIComponent(pcCompania)}&pcCuenta=${encodeURIComponent(pcCuenta)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeaveCuenta', error);
      return null;
    }
  }

  /** CC0046: Validación al salir del campo ubicación */
  async getLeaveUbicacion(pcCompania: string, pcUbicacion: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveUbicacion-cc0046?pcCompania=${encodeURIComponent(pcCompania)}&pcUbicacion=${encodeURIComponent(pcUbicacion)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeaveUbicacion', error);
      return null;
    }
  }

  /** CC0046: Validación al salir del campo centro */
  async getLeaveCentro(pcCompania: string, pcCentro: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCentro-cc0046?pcCompania=${encodeURIComponent(pcCompania)}&pcCentro=${encodeURIComponent(pcCentro)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeaveCentro', error);
      return null;
    }
  }

  /** CC0046: Validación al salir del campo auxiliar */
  async getLeaveAuxiliar(pcCompania: string, pcCuenta: string, pcAuxiliar: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveAuxiliar-cc0046?pcCompania=${encodeURIComponent(pcCompania)}&pcCuenta=${encodeURIComponent(pcCuenta)}&pcAuxiliar=${encodeURIComponent(pcAuxiliar)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getLeaveAuxiliar', error);
      return null;
    }
  }

  /** CC0046: Consulta emergente de cuentas */
  async getCECuentaCCxC(pcCompania?: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    let url = `${environment.apiUrl}/GetCECuentaCCxC?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    if (pcCompania) {
      url = `${environment.apiUrl}/GetCECuentaCCxC?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;
    }

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getCECuentaCCxC', error);
      return null;
    }
  }

  /** CC0046: Consulta emergente de auxiliares */
  async getCEAuxiliarCxC(pcCompania: string, pcCuenta: string): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEAuxiliarCxC?pcCompania=${encodeURIComponent(pcCompania)}&pcCuenta=${encodeURIComponent(pcCuenta)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.get<any>(url).toPromise();
    } catch (error) {
      console.error('Error getCEAuxiliarCxC', error);
      return null;
    }
  }

  /** CC0046: Guardar descuento */
  async updateDescuento(payload: any): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/UpdateCctabdes-cc0046?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.put<any>(url, payload).toPromise();
    } catch (error) {
      console.error('Error updateDescuento', error);
      return null;
    }
  }

  /** CC0046: Eliminar descuento */
  async deleteDescuento(pcCompania: string, pcDescuetdes: number): Promise<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/DeleteCctabdes-cc0046?pcCompania=${encodeURIComponent(pcCompania)}&pcDescuetdes=${encodeURIComponent(pcDescuetdes)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    try {
      return await this.http.delete<any>(url).toPromise();
    } catch (error) {
      console.error('Error deleteDescuento', error);
      return null;
    }
  }

  // ============ MÉTODOS PARA CARGA DE COBRANZA (CC0019) ============

  /** CC0019: Obtener empresas para Carga de Cobranza */
  getEmpresasCargaCobranza(pcCompania: string): Observable<any[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    // Consumir GetCEEmpresa - retorna tcczona con información de zonas/empresas
    const url = `${environment.apiUrl}/GetCEEmpresa?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      map(res => {
        console.log('Respuesta GetCEEmpresa:', res);
        
        // Intentar tccempres2 primero (si el endpoint lo retorna)
        let empresas = res?.dsRespuesta?.tccempres2 || [];
        
        // Si no hay tccempres2, intentar con tcczona (estructura estándar de GetCEEmpresa)
        if (!empresas || empresas.length === 0) {
          empresas = res?.dsRespuesta?.tcczona || [];
        }
        
        // Si aún no hay datos, intentar tccempresCC
        if (!empresas || empresas.length === 0) {
          empresas = res?.dsRespuesta?.tccempresCC || [];
        }
        
        // Si aún no hay datos, retornar array vacío
        if (!empresas || empresas.length === 0) {
          console.warn('No se encontraron empresas en la respuesta');
          return [];
        }
        
        console.log(`Empresas encontradas: ${empresas.length}`);
        
        // Mapear para asegurar que tienen los campos necesarios
        return empresas.map((emp: any) => ({
          empresa: emp.empresa || emp.zona,
          'nombre-emp': emp['nombre-emp'] || emp['nombre-zon'],
          nit: emp.nit,
          'email-emp': emp['email-emp'],
          'direc-emp': emp['direc-emp'],
          'telefo-emp': emp['telefo-emp'],
          'text-emp': emp['text-emp'],
          ...emp
        }));
      }),
      catchError(err => {
        console.error('Error getEmpresasCargaCobranza - GetCEEmpresa:', err);
        return of([]);
      })
    );
  }

  /** CC0019: Obtener documentos para Carga de Cobranza */
  getDocumentosCargaCobranza(pcCompania: string, pcEmpresa: string): Observable<any[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEccdocumeCxC?pcCompania=${encodeURIComponent(pcCompania)}&pcEmpresa=${encodeURIComponent(pcEmpresa)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      map(res => res?.dsRespuesta?.tccdocume || []),
      catchError(err => {
        console.error('Error getDocumentosCargaCobranza', err);
        return of([]);
      })
    );
  }

  /** CC0019: Obtener tipos de documento para Carga de Cobranza */
  getTiposDocCargaCobranza(pcCompania: string): Observable<any[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCETipodoc?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      map(res => res?.dsRespuesta?.tcctipdoc || []),
      catchError(err => {
        console.error('Error getTiposDocCargaCobranza', err);
        return of([]);
      })
    );
  }

  /** CC0019: Obtener cobradores para Carga de Cobranza */
  getCobradores(pcCompania: string): Observable<any[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECobrador?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      map(res => res?.dsRespuesta?.tcccobrad || []),
      catchError(err => {
        console.error('Error getCobradores', err);
        return of([]);
      })
    );
  }

  /** CC0019: Obtener lote de Carga de Cobranza */
  getLoteCargaCobranza(pcCompania: string, pcFechaPeriodo: string, pcLote: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveLote_cc0019?pcCompania=${encodeURIComponent(pcCompania)}&pcFechaPeriodo=${encodeURIComponent(pcFechaPeriodo)}&pcLote=${encodeURIComponent(pcLote)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error getLoteCargaCobranza', err);
        return of(null);
      })
    );
  }

  /** CC0019: Guardar Carga de Cobranza */
  saveCargaCobranza(data: any): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const body = {
      pcLogin,
      pcSuper,
      pcToken,
      dsRespuesta: { tcchistorCob: [data] }
    };

    const url = `${environment.apiUrl}/UpdateCchistorCont_cc0019`;

    return this.http.put<any>(url, body).pipe(
      catchError(err => {
        console.error('Error saveCargaCobranza', err);
        return of(null);
      })
    );
  }

  /** CC0019: Eliminar lote de Carga de Cobranza */
  deleteLoteCargaCobranza(pcCompania: string, pcLote: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/DelCcmovaut_cc0019?pcCompania=${encodeURIComponent(pcCompania)}&pcLote=${encodeURIComponent(pcLote)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.delete<any>(url).pipe(
      catchError(err => {
        console.error('Error deleteLoteCargaCobranza', err);
        return of(null);
      })
    );
  }

  /** CC0022: Consulta de Clientes - Obtener estadísticas de empresa */
  getEmpresasEstadisticas(pcCompania: string, pcEmpresa: string, pcPeriodo: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECcestadi-cc0022?pcCompania=${encodeURIComponent(pcCompania)}&pcEmpresa=${encodeURIComponent(pcEmpresa)}&pcPeriodo=${encodeURIComponent(pcPeriodo)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error getEmpresasEstadisticas', err);
        return of({ dsRespuesta: { tccestadiCC: [] } });
      })
    );
  }

  /** CC0022: Consulta de Clientes - Obtener datos de empresa (Leave event) */
  getLeaveEmpresa(pcCompania: string, pcEmpresa: string, pcPeriodo: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveEmpresa-cc0022?pcCompania=${encodeURIComponent(pcCompania)}&pcEmpresa=${encodeURIComponent(pcEmpresa)}&pcPeriodo=${encodeURIComponent(pcPeriodo)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error getLeaveEmpresa', err);
        return of({ dsRespuesta: { tccempresCC: [] } });
      })
    );
  }

  /** CC0022: Obtener documentos con saldo para balance */
  getDocumentosBalance(pcCompania: string, pcEmpresa: string, pcClase: string, pcFechaD: string, pcFechaH: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECcdocume-cc0022?pcCompania=${encodeURIComponent(pcCompania)}&pcEmpresa=${encodeURIComponent(pcEmpresa)}&pcClase=${encodeURIComponent(pcClase)}&pcVeninicio=${encodeURIComponent(pcFechaD)}&pcVenfin=${encodeURIComponent(pcFechaH)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error getDocumentosBalance', err);
        return of({ dsRespuesta: { tccdocume: [] } });
      })
    );
  }

  /** CC0022: Obtener cheques devueltos */
  getChequeDevuelto(pcCompania: string, pcEmpresa: string, pcClase: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECchistor-cc0022?pcCompania=${encodeURIComponent(pcCompania)}&pcEmpresa=${encodeURIComponent(pcEmpresa)}&pcClase=${encodeURIComponent(pcClase)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error getChequeDevuelto', err);
        return of({ dsRespuesta: { tcchistor: [] } });
      })
    );
  }

  /** CC0022: Obtener lista de vendedores */
  getVendedores(pcCompania: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEVendedor?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error getVendedores', err);
        return of({ dsRespuesta: { tccvended: [] } });
      })
    );
  }

  /** CC0022: Obtener condiciones de pago */
  getCondicionesPago(pcCompania: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECondPago?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error getCondicionesPago', err);
        return of({ dsRespuesta: { tccconpag: [] } });
      })
    );
  }

  /** CC0022: Obtener histórico de documentos */
  getHistoricoDocumentos(pcCompania: string, pcEmpresa: string, pcFechaD: string, pcFechaH: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECchistorDoc-cc0022?pcCompania=${encodeURIComponent(pcCompania)}&pcEmpresa=${encodeURIComponent(pcEmpresa)}&pcFechaD=${encodeURIComponent(pcFechaD)}&pcFechaH=${encodeURIComponent(pcFechaH)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error getHistoricoDocumentos', err);
        return of({ dsRespuesta: { tcchistorCC: [] } });
      })
    );
  }

  /** CC5062: Obtener datos de auditoría de correos */
  getCC5062Data(pcCompania: string, pcFecha: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCC5062?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      timeout(30000),
      catchError(err => {
        console.error('Error getCC5062Data', err);
        return of({ dsRespuesta: { tccaudit: [] } });
      })
    );
  }

  /** CC5062: Generar y enviar reporte de auditoría */
  getCC5062Report(pcCompania: string, pcFecha: string, pcEmail: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCC5062?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcEmail=${encodeURIComponent(pcEmail)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      timeout(30000),
      catchError(err => {
        console.error('Error getCC5062Report', err);
        return of({ response: { pcArchCSV: '' } });
      })
    );
  }

  // ==================== CC0047: CONVERSIÓN MONETARIA ====================

  /** CC0047: Obtener opciones de reportes de conversión monetaria */
  getReportesConversion(pcCompania: string, pcFecha: string, pcActualiza: string): Observable<ReporteOption[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';
    const pcPrograma = 'cc0047';

    const url = `${environment.apiUrl}/GetSelectorReportesConvPD?pcCompania=${encodeURIComponent(pcCompania)}&pcPrograma=${encodeURIComponent(pcPrograma)}&pcFecha=${encodeURIComponent(pcFecha)}&pcActualiza=${encodeURIComponent(pcActualiza)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - getReportesConversion called with:', { pcCompania, pcFecha, pcActualiza, url });

    return this.http.get<ConversionMonetariaResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tSelectConv || []),
      catchError(err => {
        console.error('Error getReportesConversion', err);
        return of([]);
      })
    );
  }

  /** CC0047: Generar reporte de conversión monetaria con parámetros específicos */
  generarReporteConversion(pcCompania: string, pcFecha: string, pcReporte: string, pcActualiza: string): Observable<GenerarReporteResponse['response'] | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetGeneraReportesConvPD?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcReporte=${encodeURIComponent(pcReporte)}&pcActualiza=${encodeURIComponent(pcActualiza)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - generarReporteConversion called with:', { pcCompania, pcFecha, pcReporte, pcActualiza, url });

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response || null),
      catchError(err => {
        console.error('Error generarReporteConversion', err);
        return of(null);
      })
    );
  }

  /** GENÉRICO: Obtener opciones de reportes para cualquier programa */
  getReportesGenerico(pcCompania: string, pcFecha: string, pcActualiza: string, pcPrograma: string): Observable<ReporteOption[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetSelectorReportesConvPD?pcCompania=${encodeURIComponent(pcCompania)}&pcPrograma=${encodeURIComponent(pcPrograma)}&pcFecha=${encodeURIComponent(pcFecha)}&pcActualiza=${encodeURIComponent(pcActualiza)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - getReportesGenerico called with:', { pcCompania, pcFecha, pcActualiza, pcPrograma, url });

    return this.http.get<ConversionMonetariaResponse>(url).pipe(
      map(res => res?.dsRespuesta?.tSelectConv || []),
      catchError(err => {
        console.error('Error getReportesGenerico', err);
        return of([]);
      })
    );
  }

  /** GENÉRICO: Generar reporte con parámetros específicos y programa */
  // Métodos específicos para tablas generales (CC2008-CC2012)
  generarReporteTabla1(pcCompania: string, pcFecha: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Getcc2008?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - generarReporteTabla1 (CC2008) URL:', url);
    return this.http.get<any>(url);
  }

  generarReporteTabla2(pcCompania: string, pcFecha: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Getcc2009?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - generarReporteTabla2 (CC2009) URL:', url);
    return this.http.get<any>(url);
  }

  generarReporteTabla3(pcCompania: string, pcFecha: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Getcc2010?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - generarReporteTabla3 (CC2010) URL:', url);
    return this.http.get<any>(url);
  }

  generarReporteTabla4(pcCompania: string, pcFecha: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Getcc2011?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - generarReporteTabla4 (CC2011) URL:', url);
    return this.http.get<any>(url);
  }

  generarReporteTabla5(pcCompania: string, pcFecha: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Getcc2012?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - generarReporteTabla5 (CC2012) URL:', url);
    return this.http.get<any>(url);
  }

  generarReporteGenerico(pcCompania: string, pcFecha: string, pcReporte: string, pcActualiza: string, pcPrograma: string): Observable<GenerarReporteResponse['response'] | null> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetGeneraReportesPD?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcReporte=${encodeURIComponent(pcReporte)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC Service - generarReporteGenerico called with:', { pcCompania, pcFecha, pcReporte, pcActualiza, pcPrograma, url });

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response || null),
      catchError(err => {
        console.error('Error generarReporteGenerico', err);
        return of(null);
      })
    );
  }

  /** RANGO DE FECHAS: Generar reporte por rango de fechas */
  generarReporteRangoFechas(
    pcCompania: string,
    fechaInicio: string,
    fechaFin: string,
    formato: 'excel' | 'pdf' | 'pantalla',
    pcPrograma: string,
    pcLogin?: string,
    pcSuper?: string,
    pcToken?: string
  ): Observable<GenerarReporteResponse['response'] | null> {
    const user = this.auth.user();
    const login = pcLogin || user?.pcLogin || '';
    const super_ = pcSuper || user?.pcSuper || '';
    const token = pcToken || user?.pcToken || '';

    // Endpoint genérico para reportes de rango de fechas
    // Adapta según tu backend real
    const url = `${environment.apiUrl}/GetGeneraReporteRangoFechas?pcCompania=${encodeURIComponent(pcCompania)}&fechaInicio=${encodeURIComponent(fechaInicio)}&fechaFin=${encodeURIComponent(fechaFin)}&pcPrograma=${encodeURIComponent(pcPrograma)}&pcFormato=${encodeURIComponent(formato)}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - generarReporteRangoFechas called with:', { pcCompania, fechaInicio, fechaFin, pcPrograma, formato, url });

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response || null),
      catchError(err => {
        console.error('Error generarReporteRangoFechas', err);
        return of(null);
      })
    );
  }

  // ============ MÉTODOS ESPECÍFICOS PARA REPORTES DE RANGO DE FECHAS ============

  /** PS5034: Reporte de Notas por Rango de Fechas */
  getPS5034(pcCompania: string, pcFechaD: string, pcFechaH: string): Observable<string | null> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetPS5034?pcCompania=${encodeURIComponent(pcCompania)}&pcFechaD=${encodeURIComponent(pcFechaD)}&pcFechaH=${encodeURIComponent(pcFechaH)}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getPS5034 called with:', { pcCompania, pcFechaD, pcFechaH, url });

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response?.pcArchXLS || null),
      catchError(err => {
        console.error('Error getPS5034', err);
        return of(null);
      })
    );
  }

  /** PS5035: Reporte de Facturación por Rango de Fechas */
  getPS5035(pcCompania: string, pcFechaD: string, pcFechaH: string, pcCiudad?: string, pcCodServ?: string, pcIndConsol?: string): Observable<string | null> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    // IMPORTANTE: Los parámetros opcionales SIEMPRE se envían, aunque sean vacíos
    const url = `${environment.apiUrl}/GetPS5035?pcCompania=${encodeURIComponent(pcCompania)}&pcFechaD=${encodeURIComponent(pcFechaD)}&pcFechaH=${encodeURIComponent(pcFechaH)}&pcCiudad=${encodeURIComponent(pcCiudad || '')}&pcCodServ=${encodeURIComponent(pcCodServ || '')}&pcIndConsol=${encodeURIComponent(pcIndConsol || '')}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getPS5035 called with:', { pcCompania, pcFechaD, pcFechaH, pcCiudad, pcCodServ, pcIndConsol, url });

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response?.pcArchCSV || null),
      catchError(err => {
        console.error('Error getPS5035', err);
        return of(null);
      })
    );
  }

  /** PS5035: Obtener listado de ciudades para búsqueda */
  getCiudadesPS5035(pcCompania: string): Observable<any> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECiudad?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getCiudadesPS5035 called with:', { pcCompania, url });

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error getCiudadesPS5035', err);
        return of({ dsRespuesta: { tCiudad: [] } });
      })
    );
  }

  /** PS5035: Validar ciudad seleccionada con GetLeaveCiudad_ps5035 */
  getLeaveCiudadPS5035(pcCompania: string, pcCiudad: string): Observable<any> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCiudad_ps5035?pcCompania=${encodeURIComponent(pcCompania)}&pcCiudad=${encodeURIComponent(pcCiudad)}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getLeaveCiudadPS5035 called with:', { pcCompania, pcCiudad, url });

    return this.http.get<any>(url).pipe(
      catchError(err => {
        console.error('Error getLeaveCiudadPS5035', err);
        return of({ dsRespuesta: { tCiudad: [] } });
      })
    );
  }

  /** CC2205: Reporte Diferencia en Cambio CxC Detallado */
  getCC2205(pcCompania: string, pcEmpresaD: string, pcEmpresaH: string, pcFechaD: string, pcFechaH: string): Observable<GenerarReporteResponse['response'] | null> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    const url = `${environment.apiUrl}/Getcc2205?pcCompania=${encodeURIComponent(pcCompania)}&pcEmpresaD=${encodeURIComponent(pcEmpresaD)}&pcEmpresaH=${encodeURIComponent(pcEmpresaH)}&pcFechaD=${encodeURIComponent(pcFechaD)}&pcFechaH=${encodeURIComponent(pcFechaH)}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getCC2205 called with:', { pcCompania, pcEmpresaD, pcEmpresaH, pcFechaD, pcFechaH, url });

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response || null),
      catchError(err => {
        console.error('Error getCC2205', err);
        return of(null);
      })
    );
  }

  /** CC2221: Resumen de Cuentas por Cobrar */
  getCC2221(pcCompania: string, pcFecha: string, pcOpcion: string): Observable<GenerarReporteResponse['response'] | null> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCC2221?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcOpcion=${encodeURIComponent(pcOpcion)}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getCC2221 called with:', { pcCompania, pcFecha, pcOpcion, url });

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response || null),
      catchError(err => {
        console.error('Error getCC2221', err);
        return of(null);
      })
    );
  }

  /** CC2224: Estado de Cuenta Histórico Consolidado */
  getCC2224(pcCompania: string, pcEmpresa: string, pcFecha: string, pcOpcion: string): Observable<GenerarReporteResponse['response'] | null> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCC2224?pcCompania=${encodeURIComponent(pcCompania)}&pcEmpresa=${encodeURIComponent(pcEmpresa)}&pcFecha=${encodeURIComponent(pcFecha)}&pcOpcion=${encodeURIComponent(pcOpcion)}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getCC2224 called with:', { pcCompania, pcEmpresa, pcFecha, pcOpcion, url });

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response || null),
      catchError(err => {
        console.error('Error getCC2224', err);
        return of(null);
      })
    );
  }

  /** CC2225: Estado de Cuenta Pendiente Consolidado */
  getCC2225(pcCompania: string, pcEmpresa: string, pcFecha: string, pcOpcion: string): Observable<GenerarReporteResponse['response'] | null> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCC2225?pcCompania=${encodeURIComponent(pcCompania)}&pcEmpresa=${encodeURIComponent(pcEmpresa)}&pcFecha=${encodeURIComponent(pcFecha)}&pcOpcion=${encodeURIComponent(pcOpcion)}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getCC2225 called with:', { pcCompania, pcEmpresa, pcFecha, pcOpcion, url });

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response || null),
      catchError(err => {
        console.error('Error getCC2225', err);
        return of(null);
      })
    );
  }

  /** CC2242: Movimiento por Lote */
  getCC2242(pcCompania: string, pcFecha: string): Observable<GenerarReporteResponse['response'] | string | null> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCC2242?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getCC2242 called with:', { pcCompania, pcFecha, url });

    return this.http.get<GenerarReporteResponse | string>(url).pipe(
      map(res => {
        if (typeof res === 'string') {
          return res;
        }
        return res?.response || null;
      }),
      catchError(err => {
        console.error('Error getCC2242', err);
        return of(null);
      })
    );
  }

  /** CC2243: Movimiento por Lote Mensual */
  getCC2243(pcCompania: string, pcFecha: string): Observable<GenerarReporteResponse['response'] | string | null> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCC2243?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getCC2243 called with:', { pcCompania, pcFecha, url });

    return this.http.get<GenerarReporteResponse | string>(url).pipe(
      map(res => {
        if (typeof res === 'string') {
          return res;
        }
        return res?.response || null;
      }),
      catchError(err => {
        console.error('Error getCC2243', err);
        return of(null);
      })
    );
  }

  /** CC2241: Movimiento por Lote Selectivo */
  getCC2241(pcCompania: string, pcLoteD: string, pcLoteH: string, pcLoteDia: string, pcFecha: string): Observable<GenerarReporteResponse['response'] | null> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCC2241?pcCompania=${encodeURIComponent(pcCompania)}&pcLoteD=${encodeURIComponent(pcLoteD)}&pcLoteH=${encodeURIComponent(pcLoteH)}&pcLoteDia=${encodeURIComponent(pcLoteDia)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getCC2241 called with:', { pcCompania, pcLoteD, pcLoteH, pcLoteDia, pcFecha, url });

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response || null),
      catchError(err => {
        console.error('Error getCC2241', err);
        return of(null);
      })
    );
  }

  /** PS5001: Reporte Moneda Extranjera DANE */
  getPS5001(pcCompania: string, pcFechaD: string, pcFechaH: string): Observable<string | null> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetPS5001?pcCompania=${encodeURIComponent(pcCompania)}&pcFechaD=${encodeURIComponent(pcFechaD)}&pcFechaH=${encodeURIComponent(pcFechaH)}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getPS5001 called with:', { pcCompania, pcFechaD, pcFechaH, url });

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response?.pcArchXLS || null),
      catchError(err => {
        console.error('Error getPS5001', err);
        return of(null);
      })
    );
  }

  /** PS5023: Reporte Facturación OFA por Rango de Fecha */
  getPS5023(pcCompania: string, pcFechaD: string, pcFechaH: string, pcRecurr?: string, pcNormal?: string): Observable<string | null> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetPS5023?pcCompania=${encodeURIComponent(pcCompania)}&pcFechaD=${encodeURIComponent(pcFechaD)}&pcFechaH=${encodeURIComponent(pcFechaH)}${pcRecurr ? `&pcRecurr=${encodeURIComponent(pcRecurr)}` : ''}${pcNormal ? `&pcNormal=${encodeURIComponent(pcNormal)}` : ''}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getPS5023 called with:', { pcCompania, pcFechaD, pcFechaH, pcRecurr, pcNormal, url });

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response?.pcArchCSV || null),
      catchError(err => {
        console.error('Error getPS5023', err);
        return of(null);
      })
    );
  }

  /** PS5068: Reporte Relación de Facturas */
  getPS5068(pcCompania: string, pcFechaD: string, pcFechaH: string): Observable<string | null> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetPS5068?pcCompania=${encodeURIComponent(pcCompania)}&pcFechaD=${encodeURIComponent(pcFechaD)}&pcFechaH=${encodeURIComponent(pcFechaH)}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getPS5068 called with:', { pcCompania, pcFechaD, pcFechaH, url });

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response?.pcArchCSV || null),
      catchError(err => {
        console.error('Error getPS5068', err);
        return of(null);
      })
    );
  }

  /** CC2046: Reporte Tabla de Descuentos */
  getCC2046(pcCompania: string, pcFecha: string): Observable<GenerarReporteResponse['response'] | null> {
    const user = this.auth.user();
    const login = user?.pcLogin || '';
    const super_ = user?.pcSuper || '';
    const token = user?.pcToken || '';

    const url = `${environment.apiUrl}/Getcc2046?pcCompania=${encodeURIComponent(pcCompania)}&pcFecha=${encodeURIComponent(pcFecha)}&pcLogin=${encodeURIComponent(login)}&pcSuper=${encodeURIComponent(super_)}&pcToken=${encodeURIComponent(token)}`;

    console.log('CC Service - getCC2046 called with:', { pcCompania, pcFecha, url });

    return this.http.get<GenerarReporteResponse>(url).pipe(
      map(res => res?.response || null),
      catchError(err => {
        console.error('Error getCC2046', err);
        return of(null);
      })
    );
  }

  // ============ MÉTODOS PARA MANTENIMIENTO DE CONTACTOS (WCCEMPCON) ============

  /** WCCEMPCON: Obtener lista de contactos */
  getContactos(pcCompania: string, pcEmpresa: string): Observable<any[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCccempcon_wccempcon?pcCompania=${encodeURIComponent(pcCompania)}&pcEmpresa=${encodeURIComponent(pcEmpresa)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      map(res => res?.dsRespuesta?.tccempcon || []),
      catchError(err => {
        console.error('Error getContactos', err);
        return of([]);
      })
    );
  }

  /** WCCEMPCON: Obtener compañías */
  getCECompanias(): Observable<any[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECompanias?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      map(res => res?.dsRespuesta?.tcecompan || []),
      catchError(err => {
        console.error('Error getCECompanias', err);
        return of([]);
      })
    );
  }

  /** WCCEMPCON: Obtener empresas */
  getCEEmpresa(pcCompania: string): Observable<any[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEEmpresa?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      map(res => {
        console.log('[getCEEmpresa] Response:', res);
        
        // Intentar tceempresa primero
        let empresas = res?.dsRespuesta?.tceempresa || [];
        
        // Si no hay tceempresa, intentar tccempres2
        if (!empresas || empresas.length === 0) {
          empresas = res?.dsRespuesta?.tccempres2 || [];
        }
        
        // Si no hay tccempres2, intentar tcczona
        if (!empresas || empresas.length === 0) {
          empresas = res?.dsRespuesta?.tcczona || [];
        }
        
        // Si no hay tcczona, intentar tccempresCC
        if (!empresas || empresas.length === 0) {
          empresas = res?.dsRespuesta?.tccempresCC || [];
        }
        
        if (!empresas || empresas.length === 0) {
          console.warn('[getCEEmpresa] No empresas found in response');
          return [];
        }
        
        console.log(`[getCEEmpresa] Found ${empresas.length} empresas`);
        return empresas;
      }),
      catchError(err => {
        console.error('[getCEEmpresa] Error:', err);
        return of([]);
      })
    );
  }

  /** WCCEMPCON: Obtener conceptos */
  getCEConceptos(pcCompania: string): Observable<any[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECcconcon_wccempcon?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      map(res => {
        console.log('[getCEConceptos] Response:', res);
        
        // Intentar tccconcon primero
        let conceptos = res?.dsRespuesta?.tccconcon || [];
        
        // Si no hay tccconcon, intentar tcctipconce
        if (!conceptos || conceptos.length === 0) {
          conceptos = res?.dsRespuesta?.tcctipconce || [];
        }
        
        // Si no hay tcctipconce, intentar directamente en dsRespuesta como objeto único
        if (!conceptos || conceptos.length === 0) {
          const respuesta = res?.dsRespuesta;
          // Si dsRespuesta es un objeto con los campos esperados (tipoconce, nombre-conce), convertirlo a array
          if (respuesta && typeof respuesta === 'object' && respuesta.tipoconce !== undefined) {
            conceptos = [respuesta];
          } else if (Array.isArray(respuesta)) {
            conceptos = respuesta;
          }
        }
        
        if (!conceptos || conceptos.length === 0) {
          console.warn('[getCEConceptos] No conceptos found in response');
          return [];
        }
        
        console.log(`[getCEConceptos] Found ${conceptos.length} conceptos`);
        return conceptos;
      }),
      catchError(err => {
        console.error('[getCEConceptos] Error:', err);
        return of([]);
      })
    );
  }

  /** WCCEMPCON: Obtener gerentes y socios */
  getCEVendedores(pcCompania: string): Observable<any[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECcvended2_wccempcon?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      map(res => res?.dsRespuesta?.tccvended || []),
      catchError(err => {
        console.error('Error getCEVendedores', err);
        return of([]);
      })
    );
  }

  /** CCCC00: Obtener clientes para Consulta de Clientes */
  getClientes(pcCompania: string): Observable<any[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    console.log('🔍 [getClientes] Iniciando request a GetCEEmpresa:', {
      pcCompania,
      pcLogin,
      pcSuper,
      hasToken: !!pcToken
    });

    // Usar GetCEEmpresa endpoint (no GetCCCliente)
    const url = `${environment.apiUrl}/GetCEEmpresa?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      map(res => {
        console.log('📥 [getClientes] Response recibida de GetCEEmpresa:', res);
        console.log('📊 [getClientes] Estructura respuesta:', {
          hasOuter: !!res,
          hasDsRespuesta: !!res?.dsRespuesta,
          dsRespuestaKeys: res?.dsRespuesta ? Object.keys(res.dsRespuesta) : [],
        });
        
        // Buscar el array de empresas en diferentes posibles nombres
        let empresas: any[] = 
          res?.dsRespuesta?.tccempres ||      // Posible nombre 1
          res?.dsRespuesta?.tccempres2 ||     // Posible nombre 2
          res?.dsRespuesta?.tcczona ||        // Lo que dice el documento (pero probablemente sea error)
          res?.dsRespuesta?.TCCEMPRES ||      // UPPERCASE
          res?.dsRespuesta?.['TCCEMPRES'] ||  // bracket notation
          [];
        
        // Si no hay array, intentar como objeto único
        if ((!empresas || empresas.length === 0) && res?.dsRespuesta) {
          const respuesta = res.dsRespuesta;
          // Si dsRespuesta es un objeto con los campos esperados, convertirlo a array
          if (respuesta && typeof respuesta === 'object' && 
              (respuesta.empresa !== undefined || respuesta['nombre-emp'] !== undefined) && 
              !Array.isArray(respuesta)) {
            console.log('ℹ️ [getClientes] Converting single object to array');
            empresas = [respuesta];
          } else if (Array.isArray(respuesta)) {
            console.log('ℹ️ [getClientes] dsRespuesta is already an array');
            empresas = respuesta;
          }
        }
        
        // Debug: si aún no hay empresas, mostrar toda la estructura
        if (!empresas || empresas.length === 0) {
          console.warn('⚠️ [getClientes] No empresas found, full response:', JSON.stringify(res, null, 2));
          return [];
        }
        
        console.log(`✅ [getClientes] Found ${empresas.length} empresas`, {
          firstEmpresa: empresas[0],
          keys: empresas[0] ? Object.keys(empresas[0]) : []
        });
        return empresas;
      }),
      catchError(err => {
        console.error('❌ [getClientes] Error calling GetCEEmpresa:', err);
        return of([]);
      })
    );
  }

  /** WCCEMPCON: Obtener gerentes (específico para GerenteModalComponent) */
  getCEGerentes(pcCompania: string): Observable<any[]> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECcvended3_wccempcon?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      map(res => {
        console.log('[getCEGerentes] Response:', res);
        
        // Intentar tccvended primero
        let gerentes = res?.dsRespuesta?.tccvended || [];
        
        // Si no hay tccvended, intentar tccvendedor
        if (!gerentes || gerentes.length === 0) {
          gerentes = res?.dsRespuesta?.tccvendedor || [];
        }
        
        // Si no hay tccvendedor, intentar directamente en dsRespuesta como objeto único
        if (!gerentes || gerentes.length === 0) {
          const respuesta = res?.dsRespuesta;
          // Si dsRespuesta es un objeto con los campos esperados (vendedor, nombre-vend), convertirlo a array
          if (respuesta && typeof respuesta === 'object' && respuesta.vendedor !== undefined) {
            gerentes = [respuesta];
          } else if (Array.isArray(respuesta)) {
            gerentes = respuesta;
          }
        }
        
        if (!gerentes || gerentes.length === 0) {
          console.warn('[getCEGerentes] No gerentes found in response');
          return [];
        }
        
        console.log(`[getCEGerentes] Found ${gerentes.length} gerentes`);
        return gerentes;
      }),
      catchError(err => {
        console.error('[getCEGerentes] Error:', err);
        return of([]);
      })
    );
  }

  /** WCCEMPCON: Guardar contacto (crear o actualizar) */
  saveContacto(contactoData: any, pcLogin: string, pcSuper: string, pcToken: string): Observable<any> {
    const requestBody = {
      dsRespuesta: {
        tccempcon: [contactoData]
      }
    };

    const url = `${environment.apiUrl}/Updateccempcon_wccempcon?pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    return this.http.put<any>(url, requestBody, { headers }).pipe(
      catchError(err => {
        console.error('Error saveContacto', err);
        return of(null);
      })
    );
  }

  /** WCCEMPCON: Eliminar contacto */
  deleteContacto(pcCompania: string, pcEmpresa: string, pcTipoconce: string, pcLogin: string, pcSuper: string, pcToken: string): Observable<any> {
    const url = `${environment.apiUrl}/DelCcempcon_wccempcon?pcCompania=${encodeURIComponent(pcCompania)}&pcEmpresa=${encodeURIComponent(pcEmpresa)}&pcTipoconce=${encodeURIComponent(pcTipoconce)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.delete<any>(url).pipe(
      catchError(err => {
        console.error('Error deleteContacto', err);
        return of(null);
      })
    );
  }

  /** ARG0288: Reporte Informe de Ingresos Por Trimestre */
  getARG0288Report(params: any): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetARG0288?` +
      `pcCompania=${encodeURIComponent(params.pcCompania)}&` +
      `pcFechaD=${encodeURIComponent(params.pcFechaD)}&` +
      `pcFechaH=${encodeURIComponent(params.pcFechaH)}&` +
      `pcOpcionIVA=${encodeURIComponent(params.pcOpcionIVA)}&` +
      `pcOpcionTipo=${encodeURIComponent(params.pcOpcionTipo)}&` +
      `pcOpcionTipo2=${encodeURIComponent(params.pcOpcionTipo2)}&` +
      `pcOpcionDetalle=${encodeURIComponent(params.pcOpcionDetalle)}&` +
      `pcLogin=${encodeURIComponent(pcLogin)}&` +
      `pcSuper=${encodeURIComponent(pcSuper)}&` +
      `pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      timeout(60000),
      catchError(err => {
        console.error('Error getARG0288Report', err);
        return of(null);
      })
    );
  }

  /** PS2000: Rep.Fact y Recaudo por Ciudad y PG */
  getPS2000Report(params: any): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetPS2000?` +
      `pcCompania=${encodeURIComponent(params.pcCompania)}&` +
      `pcFecha=${encodeURIComponent(params.pcFecha)}&` +
      `pcLogin=${encodeURIComponent(pcLogin)}&` +
      `pcSuper=${encodeURIComponent(pcSuper)}&` +
      `pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      timeout(60000),
      catchError(err => {
        console.error('Error getPS2000Report', err);
        return of(null);
      })
    );
  }

  /** PS2001: Reporte Facturación y Recaudo PG */
  getPS2001Report(params: any): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetPS2001?` +
      `pcCompania=${encodeURIComponent(params.pcCompania)}&` +
      `pcFechaD=${encodeURIComponent(params.pcFechaD)}&` +
      `pcFechaH=${encodeURIComponent(params.pcFechaH)}&` +
      `pcLogin=${encodeURIComponent(pcLogin)}&` +
      `pcSuper=${encodeURIComponent(pcSuper)}&` +
      `pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      timeout(60000),
      catchError(err => {
        console.error('Error getPS2001Report', err);
        return of(null);
      })
    );
  }

  /** CC2205: Reporte Estado de Cuenta Histórico */
  getCC2205Report(params: any): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/Getcc2205?` +
      `pcCompania=${encodeURIComponent(params.pcCompania)}&` +
      `pcEmpresaD=${encodeURIComponent(params.pcEmpresaDesde)}&` +
      `pcEmpresaH=${encodeURIComponent(params.pcEmpresaHasta)}&` +
      `pcFechaD=${encodeURIComponent(params.pcFechaDesde)}&` +
      `pcFechaH=${encodeURIComponent(params.pcFechaHasta)}&` +
      `pcLogin=${encodeURIComponent(pcLogin)}&` +
      `pcSuper=${encodeURIComponent(pcSuper)}&` +
      `pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC2205 Report - URL:', url);
    console.log('CC2205 Report - Params:', params);

    return this.http.get<any>(url).pipe(
      timeout(60000),
      catchError(err => {
        console.error('Error getCC2205Report', err);
        return of(null);
      })
    );
  }

  getCC2206Report(params: any): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCC2206?` +
      `pcCompania=${encodeURIComponent(params.pcCompania)}&` +
      `pcEmpresaD=${encodeURIComponent(params.pcEmpresaD)}&` +
      `pcEmpresaH=${encodeURIComponent(params.pcEmpresaH)}&` +
      `pcFecha=${encodeURIComponent(params.pcFecha)}&` +
      `pcLogin=${encodeURIComponent(pcLogin)}&` +
      `pcSuper=${encodeURIComponent(pcSuper)}&` +
      `pcToken=${encodeURIComponent(pcToken)}`;

    console.log('CC2206 Report - URL:', url);
    console.log('CC2206 Report - Params:', params);

    return this.http.get<any>(url).pipe(
      timeout(60000),
      catchError(err => {
        console.error('Error getCC2206Report', err);
        return of(null);
      })
    );
  }

  /** Validate Empresa method */
  validateEmpresa(compania: string, empresa: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveEmpresaCxC?` +
      `pcCompania=${encodeURIComponent(compania)}&` +
      `pcEmpresa=${encodeURIComponent(empresa)}&` +
      `pcLogin=${encodeURIComponent(pcLogin)}&` +
      `pcSuper=${encodeURIComponent(pcSuper)}&` +
      `pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      timeout(30000),
      map(response => {
        // Extraer el primer elemento del array tccempresT
        if (response?.dsRespuesta?.tccempresT && response.dsRespuesta.tccempresT.length > 0) {
          return response.dsRespuesta.tccempresT[0];
        }
        return null;
      }),
      catchError(err => {
        console.error('Error validateEmpresa - GetLeaveEmpresaCxC', err);
        return of(null);
      })
    );
  }

  // ============ MÉTODOS DE CONSULTA EMERGENTE PARA VENDEDOR (CC5016) ============
  
  /** CC5016: Consulta emergente de supervisores */
  getCESupervisores(pcCompania: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECodsuper_cc5016?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      timeout(30000),
      catchError(err => {
        console.error('Error getCESupervisores', err);
        return of({ dsRespuesta: { tccvendedSup: [] } });
      })
    );
  }

  /** CC5016: Leave event para supervisores */
  getLeaveSupervisor(pcCompania: string, pcSupervisor: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCodsuper_cc5016?pcCompania=${encodeURIComponent(pcCompania)}&pcSupervisor=${encodeURIComponent(pcSupervisor)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      timeout(30000),
      catchError(err => {
        console.error('Error getLeaveSupervisor', err);
        return of({ dsRespuesta: { tccvendedSup: [] } });
      })
    );
  }

  /** CC5016: Consulta emergente de zonas (para modal create) */
  getCEZonasCreate(pcCompania: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEZona?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      timeout(30000),
      catchError(err => {
        console.error('Error getCEZonasCreate', err);
        return of({ dsRespuesta: { tcczona: [] } });
      })
    );
  }

  /** CC5016: Leave event para zonas (para modal create) */
  getLeaveZonaCreate(pcCompania: string, pcZona: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveZona?pcCompania=${encodeURIComponent(pcCompania)}&pcZona=${encodeURIComponent(pcZona)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      timeout(30000),
      catchError(err => {
        console.error('Error getLeaveZonaCreate', err);
        return of({ dsRespuesta: { tcczona: [] } });
      })
    );
  }

  /** CC5016: Consulta emergente de ubicaciones (para modal create) */
  getCEUbicacionesCreate(pcCompania: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCEUbicacionCxC?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      timeout(30000),
      catchError(err => {
        console.error('Error getCEUbicacionesCreate', err);
        return of({ dsRespuesta: { tcgubicac: [] } });
      })
    );
  }

  /** CC5016: Leave event para ubicaciones (para modal create) */
  getLeaveUbicacionCreate(pcCompania: string, pcUbicacion: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveUbicacion-cc0046?pcCompania=${encodeURIComponent(pcCompania)}&pcUbicacion=${encodeURIComponent(pcUbicacion)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      timeout(30000),
      catchError(err => {
        console.error('Error getLeaveUbicacionCreate', err);
        return of({ dsRespuesta: { tcgubicac: [] } });
      })
    );
  }

  /** CC5016: Consulta emergente de centros de costo (para modal create) */
  getCECentrosCreate(pcCompania: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetCECentroCCxC?pcCompania=${encodeURIComponent(pcCompania)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      timeout(30000),
      catchError(err => {
        console.error('Error getCECentrosCreate', err);
        return of({ dsRespuesta: { tgecencos: [] } });
      })
    );
  }

  /** CC5016: Leave event para centros de costo (para modal create) */
  getLeaveCentroCreate(pcCompania: string, pcCentro: string): Observable<any> {
    const user = this.auth.user();
    const pcLogin = user?.pcLogin || '';
    const pcSuper = user?.pcSuper || '';
    const pcToken = user?.pcToken || '';

    const url = `${environment.apiUrl}/GetLeaveCentro-cc0046?pcCompania=${encodeURIComponent(pcCompania)}&pcCentro=${encodeURIComponent(pcCentro)}&pcLogin=${encodeURIComponent(pcLogin)}&pcSuper=${encodeURIComponent(pcSuper)}&pcToken=${encodeURIComponent(pcToken)}`;

    return this.http.get<any>(url).pipe(
      timeout(30000),
      catchError(err => {
        console.error('Error getLeaveCentroCreate', err);
        return of({ dsRespuesta: { tgecencos: [] } });
      })
    );
  }
}
