import { Component, OnInit, inject, signal, computed, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { MantResolucionesFacturacionService } from './mant-resoluciones-facturacion.service';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { Company } from './mant-resoluciones-facturacion.interface';

@Component({
  selector: 'app-mant-resoluciones-facturacion',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './mant-resoluciones-facturacion.component.html',
  styleUrl: './mant-resoluciones-facturacion.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MantResolucionesFacturacionComponent implements OnInit {
  private fb = inject(FormBuilder);
  private service = inject(MantResolucionesFacturacionService);
  private authService = inject(AuthService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);

  form!: FormGroup;
  companies = signal<Company[]>([]);
  selectedCompany = signal<Company | null>(null);
  loadingState = signal(false);
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}Mantenimiento Resoluciones Facturación`);

  ngOnInit(): void {
    console.log('🔄 MantResolucionesFacturacionComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initForm();
    this.loadCompanies();
    console.log('✅ MantResolucionesFacturacionComponent inicializado correctamente');
  }

  private initForm(): void {
    this.form = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      obser1_obs: ['', [Validators.required]],
      obser2_obs: ['', [Validators.required]],
      obser3_obs: [''],
      obser4_obs: [''],
      obser5_obs: [''],
      obser6_obs: [''],
      obser7_obs: [''],
      teobser7_obs: ['']
    });
  }

  private async loadCompanies(): Promise<void> {
    try {
      const user = this.authService.user();
      if (user && user.pcLogin && user.pcSuper && user.pcToken) {
        const response = await this.service.getCompanies(user.pcLogin, user.pcSuper, user.pcToken);
        this.companies.set(response.dsRespuesta.tgecias);
      }
    } catch (error) {
      console.error('Error loading companies:', error);
      this.toastService.showError('Error al cargar las compañías');
    }
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (!field?.errors) return '';
    if (field.errors['required']) return 'Este campo es requerido';
    if (field.errors['min']) return `Valor mínimo: ${field.errors['min'].min}`;
    return 'Error en el campo';
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.form.get('cia')?.value;
    if (!ciaValue) {
      return;
    }
    const company = this.companies().find((c: Company) => c.cia.toString() === ciaValue.toString());
    if (company) {
      this.selectedCompany.set(company);
      this.form.patchValue({ 'nombre-cia': company.nombre_cia });
      await this.loadData();
    } else {
      this.toastService.showError('Compañía no encontrada');
      this.form.patchValue({ cia: '' });
      this.selectedCompany.set(null);
    }
  }

  buscarCompania(): void {
    const ciaValue = this.form.get('cia')?.value;
    if (!ciaValue || this.companies().length === 0) {
      this.toastService.showWarning('No hay compañías disponibles');
      return;
    }
    const company = this.companies().find((c: Company) => c.cia.toString() === ciaValue.toString());
    if (company) {
      this.selectedCompany.set(company);
      this.form.patchValue({ 'nombre-cia': company.nombre_cia });
      this.toastService.showSuccess('Compañía seleccionada');
    } else {
      this.toastService.showError('Compañía no encontrada. Intente de nuevo.');
    }
  }

  private async loadData(): Promise<void> {
    try {
      const ciaValue = this.form.get('cia')?.value;
      const user = this.authService.user();
      if (ciaValue && user && user.pcLogin && user.pcSuper && user.pcToken) {
        this.loadingState.set(true);
        const response = await this.service.getLeaveData(ciaValue, user.pcLogin, user.pcSuper, user.pcToken);
        if (response.dsRespuesta.tfaobsgen.length > 0) {
          const data = response.dsRespuesta.tfaobsgen[0];
          this.form.patchValue({
            obser1_obs: data.obser1_obs || '',
            obser2_obs: data.obser2_obs || '',
            obser3_obs: data.obser3_obs || '',
            obser4_obs: data.obser4_obs || '',
            obser5_obs: data.obser5_obs || '',
            obser6_obs: data.obser6_obs || '',
            obser7_obs: data.obser7_obs || '',
            teobser7_obs: data.teobser7_obs || ''
          });
        }
      }
    } catch (error) {
      console.error('Error loading data:', error);
      this.toastService.showError('Error al cargar los datos');
    } finally {
      this.loadingState.set(false);
    }
  }

  async onSave(): Promise<void> {
    if (this.form.invalid) {
      this.toastService.showError('Por favor complete todos los campos requeridos');
      return;
    }
    try {
      this.loadingState.set(true);
      const user = this.authService.user();
      if (user && user.pcLogin && user.pcSuper && user.pcToken) {
        const formValue = this.form.getRawValue();
        const data = {
          cia: parseInt(formValue.cia),
          nombre_cia: this.companies().find(c => c.cia === parseInt(formValue.cia))?.nombre_cia || '',
          obser1_obs: formValue.obser1_obs,
          obser2_obs: formValue.obser2_obs,
          obser3_obs: formValue.obser3_obs,
          obser4_obs: formValue.obser4_obs,
          obser5_obs: formValue.obser5_obs,
          obser6_obs: formValue.obser6_obs,
          obser7_obs: formValue.obser7_obs,
          teobser7_obs: formValue.teobser7_obs
        };
        await this.service.updateData(data, user.pcLogin, user.pcSuper, user.pcToken);
        this.toastService.showSuccess('Datos guardados correctamente');
      }
    } catch (error) {
      console.error('Error saving data:', error);
      this.toastService.showError('Error al guardar los datos');
    } finally {
      this.loadingState.set(false);
    }
  }

  onClear(): void {
    this.form.reset();
    this.selectedCompany.set(null);
    this.toastService.showInfo('Formulario limpiado');
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }
}
