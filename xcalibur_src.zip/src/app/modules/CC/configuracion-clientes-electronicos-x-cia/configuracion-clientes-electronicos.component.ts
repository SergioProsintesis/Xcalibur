import { Component, inject, signal, OnInit, computed, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ModalService } from '../../../core/services/modal.service';
import { ToastService } from '../../../core/services/toast.service';
import { LoadingService } from '../../../core/services/loading.service';
import { ProgramContextService } from '../../../core/services/program-context.service';
import { CompaniaModalComponent } from '../reporte-movimiento-del-dia/compania-modal/compania-modal.component';
import { ConfiguracionClientesElectronicosService } from './configuracion-clientes-electronicos.service';
import { CompaniaRecord, ConfiguracionClienteElectronicoRecord } from './configuracion-clientes-electronicos.interface';

@Component({
  selector: 'app-configuracion-clientes-electronicos',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, CompaniaModalComponent],
  templateUrl: './configuracion-clientes-electronicos.component.html',
  styleUrls: ['./configuracion-clientes-electronicos.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ConfiguracionClientesElectronicosComponent implements OnInit {
  private fb = inject(FormBuilder);
  private modalService = inject(ModalService);
  private toastService = inject(ToastService);
  private loadingService = inject(LoadingService);
  private service = inject(ConfiguracionClientesElectronicosService);
  private router = inject(Router);
  private programContext = inject(ProgramContextService);
  private cdr = inject(ChangeDetectorRef);

  configuracionForm!: FormGroup;
  pageTitle = computed(() => `${this.programContext.getTitlePrefixSignal()()}FA5001 - Configuración Clientes Electrónicos x CIA`);
  loadingState = signal<boolean>(false);

  // Datos actuales
  companiaSeleccionada = signal<CompaniaRecord | null>(null);
  configuraciones = signal<ConfiguracionClienteElectronicoRecord[]>([]);
  configuracionEditando = signal<ConfiguracionClienteElectronicoRecord | null>(null);

  // Control de modales
  showCompaniaModal = signal(false);
  isEditMode = signal(false);

  // Opciones
  formatosFactura = ['PDF', 'UBL2.0', 'XML'];
  frecuenciasEnvio = ['Diaria', 'Semanal', 'Mensual'];

  ngOnInit() {
    console.log('🔄 ConfiguracionClientesElectronicosComponent - ngOnInit iniciado');
    this.loadingState.set(false);
    this.loadingService.hide();
    this.initializeForm();
    console.log('✅ ConfiguracionClientesElectronicosComponent inicializado correctamente');
  }

  private initializeForm(): void {
    this.configuracionForm = this.fb.group({
      cia: ['', [Validators.required, Validators.min(1)]],
      'nombre-cia': [{ value: '', disabled: true }],
      'codigo-config': [{ value: '', disabled: true }],
      'cliente-electronico': [false],
      'habilitado': [true],
      'email-notificacion': ['', [Validators.email]],
      'frecuencia-envio': [''],
      'formato-factura': ['']
    });
  }

  // ==================== VALIDACIONES ====================
  isInvalid(fieldName: string): boolean {
    const field = this.configuracionForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  errorMessage(fieldName: string): string {
    const field = this.configuracionForm.get(fieldName);
    if (!field?.errors) return '';
    
    const errors = field.errors;
    if (errors['required']) return 'Este campo es requerido';
    if (errors['min']) return `Valor mínimo: ${errors['min'].min}`;
    if (errors['email']) return 'Correo electrónico inválido';
    
    return 'Campo inválido';
  }

  // ==================== MODAL DE COMPAÑÍAS ====================
  buscarCompania(): void {
    this.showCompaniaModal.set(true);
  }

  closeCompaniaModal(): void {
    this.showCompaniaModal.set(false);
  }

  onCompaniaSelected(compania: CompaniaRecord): void {
    this.companiaSeleccionada.set(compania);
    this.configuracionForm.patchValue({
      cia: compania.cia,
      'nombre-cia': compania['nombre-cia']
    });
    this.closeCompaniaModal();
    this.loadConfiguraciones();
  }

  async onCompaniaLeave(): Promise<void> {
    const ciaValue = this.configuracionForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.limpiarCompania();
      return;
    }

    try {
      this.loadingState.set(true);
      const response = await this.service.getLeaveCompania(ciaValue);
      
      if (response?.dsRespuesta?.tgecias && response.dsRespuesta.tgecias.length > 0) {
        const compania = response.dsRespuesta.tgecias[0];
        this.companiaSeleccionada.set(compania);
        this.configuracionForm.patchValue({
          'nombre-cia': compania['nombre-cia']
        });
        this.loadConfiguraciones();
      } else {
        this.toastService.showError('Compañía no encontrada');
        this.limpiarCompania();
      }
    } catch (error) {
      console.error('Error al buscar compañía:', error);
      this.toastService.showError('Error al buscar la compañía');
      this.limpiarCompania();
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  private limpiarCompania(): void {
    this.companiaSeleccionada.set(null);
    this.configuraciones.set([]);
    this.configuracionForm.patchValue({
      cia: '',
      'nombre-cia': ''
    });
  }

  // ==================== CARGAR DATOS ====================
  private async loadConfiguraciones(): Promise<void> {
    const ciaValue = this.configuracionForm.get('cia')?.value;
    
    if (!ciaValue) {
      this.configuraciones.set([]);
      return;
    }

    try {
      this.loadingState.set(true);
      const configuraciones = await this.service.getConfiguraciones(ciaValue);
      this.configuraciones.set(configuraciones);
    } catch (error) {
      console.error('Error al cargar configuraciones:', error);
      this.toastService.showError('Error al cargar las configuraciones');
      this.configuraciones.set([]);
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  // ==================== EDICIÓN ====================
  onEditar(config: ConfiguracionClienteElectronicoRecord): void {
    this.isEditMode.set(true);
    this.configuracionEditando.set(config);
    this.configuracionForm.patchValue({
      'codigo-config': config['codigo-config'],
      'cliente-electronico': config['cliente-electronico'],
      'habilitado': config.habilitado,
      'email-notificacion': config['email-notificacion'],
      'frecuencia-envio': config['frecuencia-envio'],
      'formato-factura': config['formato-factura']
    });
    this.cdr.markForCheck();
  }

  onNuevo(): void {
    this.isEditMode.set(false);
    this.configuracionEditando.set(null);
    this.configuracionForm.patchValue({
      'codigo-config': '',
      'cliente-electronico': false,
      'habilitado': true,
      'email-notificacion': '',
      'frecuencia-envio': '',
      'formato-factura': ''
    });
    this.cdr.markForCheck();
  }

  // ==================== ACCIONES ====================
  onLimpiar(): void {
    this.configuracionForm.patchValue({
      'codigo-config': '',
      'cliente-electronico': false,
      'habilitado': true,
      'email-notificacion': '',
      'frecuencia-envio': '',
      'formato-factura': ''
    });
    this.isEditMode.set(false);
    this.configuracionEditando.set(null);
    this.cdr.markForCheck();
  }

  onGuardar(): void {
    if (this.configuracionForm.invalid) {
      this.toastService.showError('Por favor, complete los campos requeridos correctamente');
      return;
    }

    const ciaValue = this.configuracionForm.get('cia')?.value;

    const configuracion: ConfiguracionClienteElectronicoRecord = {
      'codigo-config': this.isEditMode() ? this.configuracionEditando()?.['codigo-config'] || '' : `CONFIG-${Date.now()}`,
      cia: ciaValue,
      'nombre-cia': this.configuracionForm.get('nombre-cia')?.value,
      'cliente-electronico': this.configuracionForm.get('cliente-electronico')?.value || false,
      'habilitado': this.configuracionForm.get('habilitado')?.value || true,
      'email-notificacion': this.configuracionForm.get('email-notificacion')?.value || '',
      'frecuencia-envio': this.configuracionForm.get('frecuencia-envio')?.value || '',
      'formato-factura': this.configuracionForm.get('formato-factura')?.value || ''
    };

    this.guardarConfiguracion(configuracion);
  }

  private async guardarConfiguracion(configuracion: ConfiguracionClienteElectronicoRecord): Promise<void> {
    try {
      this.loadingState.set(true);
      await this.service.saveConfiguracion(configuracion);
      this.toastService.showSuccess(`Configuración ${this.isEditMode() ? 'actualizada' : 'creada'} correctamente`);
      this.loadConfiguraciones();
      this.onLimpiar();
    } catch (error) {
      console.error('Error al guardar configuración:', error);
      this.toastService.showError('Error al guardar la configuración');
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  onEliminar(config: ConfiguracionClienteElectronicoRecord): void {
    if (confirm('¿Está seguro de que desea eliminar esta configuración?')) {
      this.eliminarConfiguracion(config['codigo-config'], config.cia);
    }
  }

  private async eliminarConfiguracion(codigoConfig: string, cia: number): Promise<void> {
    try {
      this.loadingState.set(true);
      await this.service.deleteConfiguracion(codigoConfig, cia);
      this.toastService.showSuccess('Configuración eliminada correctamente');
      this.loadConfiguraciones();
    } catch (error) {
      console.error('Error al eliminar configuración:', error);
      this.toastService.showError('Error al eliminar la configuración');
    } finally {
      this.loadingState.set(false);
      this.cdr.markForCheck();
    }
  }

  onVolver(): void {
    this.router.navigate(['/cuentas-por-cobrar']);
  }
}
