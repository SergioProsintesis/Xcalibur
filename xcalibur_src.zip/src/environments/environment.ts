export const environment = {
  production: false,
  apiBaseUrl: 'http://184.168.30.44:8810',
  apiServicePath: '/XcaliburWeb/rest/ServiciosXcaliburWeb',
  apiUrl: 'http://184.168.30.44:8810/XcaliburWeb/rest/ServiciosXcaliburWeb',
  veracode: {
    apiId: process.env['VERACODE_API_ID'] || '',
    apiKey: process.env['VERACODE_API_KEY'] || ''
  }
};
