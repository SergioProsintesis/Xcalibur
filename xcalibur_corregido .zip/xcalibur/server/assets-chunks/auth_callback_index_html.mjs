export default `<!DOCTYPE html><html lang="en"><head>
  <meta charset="utf-8">
  <title>Xcalibur</title>
  <base href="/">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="assets/favicon/favicon.ico">
  <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="assets/favicon/favicon-16x16.png">
  <link rel="apple-touch-icon" sizes="180x180" href="assets/favicon/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="192x192" href="assets/favicon/android-chrome-192x192.png">
  <link rel="icon" type="image/png" sizes="512x512" href="assets/favicon/android-chrome-512x512.png">
<link rel="stylesheet" href="styles.css"><style ng-app-id="ng">

.loading-overlay[_ngcontent-ng-c1007795490] {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}
.loading-spinner[_ngcontent-ng-c1007795490] {
  background: white;
  padding: 2rem;
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}
.loader-svg[_ngcontent-ng-c1007795490] {
  width: 100px;
  height: 100px;
}
.loading-message[_ngcontent-ng-c1007795490] {
  margin: 0;
  color: #033481;
  font-size: 1rem;
  font-weight: 500;
}
/*# sourceMappingURL=/loading.component.css.map */</style><style ng-app-id="ng">

.callback-container[_ngcontent-ng-c709315243] {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background:
    linear-gradient(
      135deg,
      #e6f0ff 0%,
      #ffffff 100%);
}
.loading[_ngcontent-ng-c709315243] {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
  padding: 2rem;
}
.spinner[_ngcontent-ng-c709315243] {
  width: 3rem;
  height: 3rem;
  border: 4px solid #e5e7eb;
  border-top: 4px solid #0b5ed7;
  border-radius: 50%;
  animation: _ngcontent-ng-c709315243_spin 1s linear infinite;
}
p[_ngcontent-ng-c709315243] {
  color: #6b7280;
  font-size: 1rem;
  margin: 0;
}
.status-text[_ngcontent-ng-c709315243] {
  font-size: 0.875rem;
  font-weight: 500;
  min-height: 1.25rem;
}
.status-text.processing[_ngcontent-ng-c709315243] {
  color: #3b82f6;
}
.status-text.success[_ngcontent-ng-c709315243] {
  color: #10b981;
}
.status-text.error[_ngcontent-ng-c709315243] {
  color: #ef4444;
}
@keyframes _ngcontent-ng-c709315243_spin {
  to {
    transform: rotate(360deg);
  }
}
/*# sourceMappingURL=/callback.component.css.map */</style></head>
<body><!--nghm-->
  <app-root ng-version="20.1.3" ngh="2" ng-server-context="ssg"><router-outlet></router-outlet><app-auth-callback _nghost-ng-c709315243="" ngh="0"><div _ngcontent-ng-c709315243="" class="callback-container"><div _ngcontent-ng-c709315243="" class="loading"><div _ngcontent-ng-c709315243="" class="spinner"></div><p _ngcontent-ng-c709315243="">Error: Usuario no identificado</p><p _ngcontent-ng-c709315243="" class="status-text error">Usuario no identificado</p></div></div></app-auth-callback><!--container--><app-loading _nghost-ng-c1007795490="" ngh="1"><!--container--></app-loading></app-root>
<script src="main.js" type="module"></script>

<script id="ng-state" type="application/json">{"3212315283":{"b":{"azureAd":{"clientId":"e7ff9613-fa27-4e00-96af-355b65c165a4","tenantId":"513294a0-3e20-41b2-a970-6d30bf1546fa","redirectUri":"http://localhost:4200/auth/callback"},"api":{"baseUrl":"http://u2zepcaosswv002.pwcglb.com:8443","servicePath":"/XcaliburWeb/rest/ServiciosXcaliburWeb"}},"h":{},"s":200,"st":"OK","u":"/config.json","rt":"json"},"__nghData__":[{},{"t":{"0":"t0"},"c":{"0":[]}},{"c":{"0":[{"i":"c709315243","r":1}]}}]}</script></body></html>`;