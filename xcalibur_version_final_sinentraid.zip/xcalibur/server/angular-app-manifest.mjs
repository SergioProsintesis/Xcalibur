
export default {
  bootstrap: () => import('./main.server.mjs').then(m => m.default),
  inlineCriticalCss: true,
  baseHref: '/',
  locale: undefined,
  routes: [
  {
    "renderMode": 2,
    "redirectTo": "/login",
    "route": "/"
  },
  {
    "renderMode": 2,
    "route": "/login"
  },
  {
    "renderMode": 2,
    "route": "/dashboard"
  },
  {
    "renderMode": 2,
    "route": "/administrador/companias/mantenimiento-companias"
  },
  {
    "renderMode": 2,
    "route": "/administrador/autorizacion-usuarios/mantenimiento-usuarios"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-de-usuarios-con-perfil"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-de-opcion-con-perfil"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/procesos-principales/consulta-facturas-cliente"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/procesos-principales/carga-cobranza"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/procesos-principales/consulta-clientes"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/procesos-principales/mantenimiento-contactos"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/auditoria-correos-facturacion-electronica"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-movimiento-del-dia"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/conversion-monetaria"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-movimiento-mensual"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-diferencia-en-cambio-cxc-detallado"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/notas-rango-de-fechas"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/estado-de-cuenta-pendiente"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/estado-de-cuenta-historico-en-otr-moneda"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/resumen-cuentas-por-cobrar"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/estado-ctahist-consolidado"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/estado-cta-pend-consolidado"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/movimiento-por-lote"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/movimiento-por-lote-mensual"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/movimiento-por-lote-selectivo"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/facturacion-rango-de-fechas"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-moneda-extranjera-dane"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-facturacion-ofa-por-rango-de-fecha"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-facturacin-ofa-por-rango-de-fecha"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-relacion-de-facturas"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-cc2205"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/informe-de-ingresos-por-trimestre-pg"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/repfact-y-recaudo-por-ciudad-y-pg"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/rep-fact-y-recaudo-por-pg"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/estado-de-cuenta-historico"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-tipo-de-cliente"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-tipo-de-documento"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-clasificacion-venta"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-bancotarjeta"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-causa-de-suspension"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mantenimiento-detalles-generales"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-vendedor"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-zona-de-venta"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-tipo-de-negocio"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-localidades"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-condiciones-de-pago"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-descuentos"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-ciudades"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-retencion"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-contable-tipo-documento"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mantenimiento-de-cuentas"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-tablas-1-5"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mant-tablas-generales"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/parametros-observaciones-en-ingles"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/parametros-de-facturacion"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/modificacion-detalle-facturas"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mantenimiento-distribucion-facturas"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/otros-datos-facturacion-electronica"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mantenimiento-resoluciones-facturacion"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mantenimiento-descuentos-facturacion"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mantenimiento-datos-compra"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mantenimiento-clientes"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-facturacion-fecha"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-notas-fecha"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mantenimiento-centros-costos"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mantenimiento-bases-liquidacion"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-ingresos-trimestre"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/generacion-archivo-factura-electronica"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-gastos-de-facturacin"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-gastos-de-facturacion"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-de-facturas-sin-codigo-cufe-ubl2-dic-19"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reporte-de-facturacion-recurrente"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reimpresion-de-facturas"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/observacion-generales"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/configuracion-clientes-electronicos-x-cia"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/procesos-facturacion/configuracion-clientes-electronicos-x-cia"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/procesos-facturacion/parametros-observaciones-en-ingles"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/genarchivos-factnotas-y-cartx-lectarchivo"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/mantenimiento-parametros"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/reiniciar-password"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/cambio-de-password"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-cobrar/asignacion-de-opciones-x-perfil"
  },
  {
    "renderMode": 2,
    "route": "/contabilidad-general/reportes-principales/balance-comprobacion"
  },
  {
    "renderMode": 2,
    "route": "/transacciones"
  },
  {
    "renderMode": 2,
    "route": "/cuentas-por-pagar/procesos-principales/carga-comprobantes"
  },
  {
    "renderMode": 2,
    "route": "/presupuesto-sueldos/reporte-ps5001"
  },
  {
    "renderMode": 2,
    "route": "/presupuesto-sueldos/reporte-ps5023"
  },
  {
    "renderMode": 2,
    "route": "/presupuesto-sueldos/reporte-ps5034"
  },
  {
    "renderMode": 2,
    "route": "/presupuesto-sueldos/reporte-ps5035"
  },
  {
    "renderMode": 2,
    "route": "/presupuesto-sueldos/reporte-ps5057"
  },
  {
    "renderMode": 2,
    "route": "/presupuesto-sueldos/reporte-ps5068"
  },
  {
    "renderMode": 2,
    "route": "/demo-secondary-menu"
  }
],
  entryPointToBrowserMapping: undefined,
  assets: {
    'index.csr.html': {size: 3655, hash: 'fd6d902e1c7d0b735503309f03574eac66eaaf8a65115d513b5bf344bc66af33', text: () => import('./assets-chunks/index_csr_html.mjs').then(m => m.default)},
    'index.server.html': {size: 1438, hash: '844fc2d87da6eac66594804d48aec32076325601ecb538c9e0594abaab91c203', text: () => import('./assets-chunks/index_server_html.mjs').then(m => m.default)},
    'login/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/login_index_html.mjs').then(m => m.default)},
    'dashboard/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/dashboard_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-de-opcion-con-perfil/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-de-opcion-con-perfil_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/procesos-principales/mantenimiento-contactos/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_procesos-principales_mantenimiento-contactos_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-movimiento-del-dia/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-movimiento-del-dia_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-movimiento-mensual/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-movimiento-mensual_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/estado-de-cuenta-historico-en-otr-moneda/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_estado-de-cuenta-historico-en-otr-moneda_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/notas-rango-de-fechas/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_notas-rango-de-fechas_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-de-usuarios-con-perfil/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-de-usuarios-con-perfil_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/estado-ctahist-consolidado/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_estado-ctahist-consolidado_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/movimiento-por-lote-selectivo/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_movimiento-por-lote-selectivo_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/movimiento-por-lote/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_movimiento-por-lote_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-facturacin-ofa-por-rango-de-fecha/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-facturacin-ofa-por-rango-de-fecha_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/repfact-y-recaudo-por-ciudad-y-pg/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_repfact-y-recaudo-por-ciudad-y-pg_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-moneda-extranjera-dane/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-moneda-extranjera-dane_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-cc2205/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-cc2205_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-tipo-de-documento/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-tipo-de-documento_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/estado-de-cuenta-historico/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_estado-de-cuenta-historico_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-bancotarjeta/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-bancotarjeta_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mantenimiento-detalles-generales/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mantenimiento-detalles-generales_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-zona-de-venta/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-zona-de-venta_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-retencion/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-retencion_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mantenimiento-de-cuentas/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mantenimiento-de-cuentas_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-localidades/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-localidades_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-descuentos/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-descuentos_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-tablas-generales/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-tablas-generales_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mantenimiento-distribucion-facturas/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mantenimiento-distribucion-facturas_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mantenimiento-resoluciones-facturacion/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mantenimiento-resoluciones-facturacion_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mantenimiento-datos-compra/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mantenimiento-datos-compra_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/parametros-de-facturacion/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_parametros-de-facturacion_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-facturacion-fecha/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-facturacion-fecha_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mantenimiento-centros-costos/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mantenimiento-centros-costos_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-ingresos-trimestre/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-ingresos-trimestre_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-gastos-de-facturacin/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-gastos-de-facturacin_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-de-facturas-sin-codigo-cufe-ubl2-dic-19/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-de-facturas-sin-codigo-cufe-ubl2-dic-19_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reimpresion-de-facturas/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reimpresion-de-facturas_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/procesos-facturacion/parametros-observaciones-en-ingles/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_procesos-facturacion_parametros-observaciones-en-ingles_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/configuracion-clientes-electronicos-x-cia/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_configuracion-clientes-electronicos-x-cia_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/cambio-de-password/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_cambio-de-password_index_html.mjs').then(m => m.default)},
    'contabilidad-general/reportes-principales/balance-comprobacion/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/contabilidad-general_reportes-principales_balance-comprobacion_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mantenimiento-parametros/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mantenimiento-parametros_index_html.mjs').then(m => m.default)},
    'cuentas-por-pagar/procesos-principales/carga-comprobantes/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-pagar_procesos-principales_carga-comprobantes_index_html.mjs').then(m => m.default)},
    'presupuesto-sueldos/reporte-ps5035/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/presupuesto-sueldos_reporte-ps5035_index_html.mjs').then(m => m.default)},
    'presupuesto-sueldos/reporte-ps5023/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/presupuesto-sueldos_reporte-ps5023_index_html.mjs').then(m => m.default)},
    'presupuesto-sueldos/reporte-ps5068/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/presupuesto-sueldos_reporte-ps5068_index_html.mjs').then(m => m.default)},
    'administrador/companias/mantenimiento-companias/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/administrador_companias_mantenimiento-companias_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/procesos-principales/carga-cobranza/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_procesos-principales_carga-cobranza_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/auditoria-correos-facturacion-electronica/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_auditoria-correos-facturacion-electronica_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/resumen-cuentas-por-cobrar/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_resumen-cuentas-por-cobrar_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-diferencia-en-cambio-cxc-detallado/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-diferencia-en-cambio-cxc-detallado_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/informe-de-ingresos-por-trimestre-pg/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_informe-de-ingresos-por-trimestre-pg_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-facturacion-ofa-por-rango-de-fecha/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-facturacion-ofa-por-rango-de-fecha_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-tipo-de-cliente/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-tipo-de-cliente_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/movimiento-por-lote-mensual/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_movimiento-por-lote-mensual_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-tipo-de-negocio/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-tipo-de-negocio_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-causa-de-suspension/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-causa-de-suspension_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mantenimiento-descuentos-facturacion/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mantenimiento-descuentos-facturacion_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-ciudades/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-ciudades_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-tablas-1-5/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-tablas-1-5_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/modificacion-detalle-facturas/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_modificacion-detalle-facturas_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-notas-fecha/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-notas-fecha_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-de-facturacion-recurrente/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-de-facturacion-recurrente_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/procesos-facturacion/configuracion-clientes-electronicos-x-cia/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_procesos-facturacion_configuracion-clientes-electronicos-x-cia_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/generacion-archivo-factura-electronica/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_generacion-archivo-factura-electronica_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reiniciar-password/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reiniciar-password_index_html.mjs').then(m => m.default)},
    'presupuesto-sueldos/reporte-ps5034/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/presupuesto-sueldos_reporte-ps5034_index_html.mjs').then(m => m.default)},
    'transacciones/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/transacciones_index_html.mjs').then(m => m.default)},
    'demo-secondary-menu/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/demo-secondary-menu_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/conversion-monetaria/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_conversion-monetaria_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/procesos-principales/consulta-facturas-cliente/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_procesos-principales_consulta-facturas-cliente_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/estado-cta-pend-consolidado/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_estado-cta-pend-consolidado_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-condiciones-de-pago/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-condiciones-de-pago_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-relacion-de-facturas/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-relacion-de-facturas_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/parametros-observaciones-en-ingles/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_parametros-observaciones-en-ingles_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/genarchivos-factnotas-y-cartx-lectarchivo/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_genarchivos-factnotas-y-cartx-lectarchivo_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/reporte-gastos-de-facturacion/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_reporte-gastos-de-facturacion_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mantenimiento-clientes/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mantenimiento-clientes_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-clasificacion-venta/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-clasificacion-venta_index_html.mjs').then(m => m.default)},
    'administrador/autorizacion-usuarios/mantenimiento-usuarios/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/administrador_autorizacion-usuarios_mantenimiento-usuarios_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/estado-de-cuenta-pendiente/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_estado-de-cuenta-pendiente_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/rep-fact-y-recaudo-por-pg/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_rep-fact-y-recaudo-por-pg_index_html.mjs').then(m => m.default)},
    'presupuesto-sueldos/reporte-ps5001/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/presupuesto-sueldos_reporte-ps5001_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-contable-tipo-documento/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-contable-tipo-documento_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mantenimiento-bases-liquidacion/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mantenimiento-bases-liquidacion_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/asignacion-de-opciones-x-perfil/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_asignacion-de-opciones-x-perfil_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/procesos-principales/consulta-clientes/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_procesos-principales_consulta-clientes_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/observacion-generales/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_observacion-generales_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/facturacion-rango-de-fechas/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_facturacion-rango-de-fechas_index_html.mjs').then(m => m.default)},
    'presupuesto-sueldos/reporte-ps5057/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/presupuesto-sueldos_reporte-ps5057_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/mant-vendedor/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_mant-vendedor_index_html.mjs').then(m => m.default)},
    'cuentas-por-cobrar/otros-datos-facturacion-electronica/index.html': {size: 22379, hash: '4e584afba9916b179f0278cefff277d790e6435d768f85cf22e008da747aad43', text: () => import('./assets-chunks/cuentas-por-cobrar_otros-datos-facturacion-electronica_index_html.mjs').then(m => m.default)},
    'styles-DIIVNORW.css': {size: 38387, hash: 'p+R/PhyA5RY', text: () => import('./assets-chunks/styles-DIIVNORW_css.mjs').then(m => m.default)}
  },
};
