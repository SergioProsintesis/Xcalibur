# Configuración de Credentials de Azure AD

El archivo `config.json` en la carpeta `public/` contiene los credentials de Azure AD que se cargan dinámicamente cuando se inicia la aplicación.

## Cambiar Credentials Sin Recompilar

Para cambiar el **Client ID** y **Tenant ID** sin necesidad de hacer un nuevo build:

1. Edita el archivo `public/config.json`
2. Cambia los valores de `azureAd.clientId` y `azureAd.tenantId`
3. Guarda el archivo
4. Actualiza el navegador (Ctrl+F5) - **¡Listo!** La aplicación cargará los nuevos valores

## Valores Actuales

```json
{
  "azureAd": {
    "clientId": "e7ff9613-fa27-4e00-96af-355b65c165a4",
    "tenantId": "513294a0-3e20-41b2-a970-6d30bf1546fa"
  }
}
```

## Estructura del Archivo

```json
{
  "azureAd": {
    "clientId": "tu-app-id-aqui",
    "tenantId": "tu-tenant-id-aqui"
  },
  "api": {
    "baseUrl": "http://your-server-url:port",
    "servicePath": "/your-api-path"
  }
}
```

## Cómo Funciona

1. **app.config.ts**: En el startup de la aplicación, se ejecuta un `APP_INITIALIZER` que carga `config.json`
2. **ConfigService**: Servicio que proporciona acceso a los valores de configuración
3. **azure-ad.config.ts**: Genera dinámicamente la configuración de Azure AD usando valores del `ConfigService`
4. **oauth2.service.ts**: Usa automáticamente los valores configurados

## Para Producción

En la carpeta `dist/` después de hacer build, asegúrate de que:
- El archivo `config.json` esté en la raíz del servidor web
- Tenga los valores correctos para tu ambiente de producción
- No necesitas recompilar, solo cambiar el JSON
