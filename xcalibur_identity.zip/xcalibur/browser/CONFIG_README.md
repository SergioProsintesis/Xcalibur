# Configuración de Credentials de Azure AD

El archivo `config.json` en la carpeta `public/` contiene los credentials de Azure AD que se cargan dinámicamente cuando se inicia la aplicación.

## Cambiar Credentials Sin Recompilar

Para cambiar el **Client ID**, **Tenant ID** y **Redirect URI** sin necesidad de hacer un nuevo build:

1. Edita el archivo `public/config.json`
2. Cambia los valores de `azureAd.clientId`, `azureAd.tenantId` y `azureAd.redirectUri`
3. Guarda el archivo
4. Actualiza el navegador (Ctrl+F5) - **¡Listo!** La aplicación cargará los nuevos valores

## Valores Actuales

```json
{
  "azureAd": {
    "clientId": "e7ff9613-fa27-4e00-96af-355b65c165a4",
    "tenantId": "513294a0-3e20-41b2-a970-6d30bf1546fa",
    "redirectUri": "http://localhost:4200/auth/callback"
  }
}
```

## Estructura del Archivo

```json
{
  "azureAd": {
    "clientId": "tu-app-id-aqui",
    "tenantId": "tu-tenant-id-aqui",
    "redirectUri": "https://tu-dominio.com/auth/callback"
  },
  "api": {
    "baseUrl": "http://your-server-url:port",
    "servicePath": "/your-api-path"
  }
}
```

## 🔑 Configurar Redirect URI para IIS

### Paso 1: Determina tu URL en IIS
- Si tu app está en `https://mi-dominio.com` → redirectUri debe ser `https://mi-dominio.com/auth/callback`
- Si está en una carpeta como `https://mi-dominio.com/xcalibur` → entonces `https://mi-dominio.com/xcalibur/auth/callback`

### Paso 2: Actualiza config.json en IIS
```json
{
  "azureAd": {
    "clientId": "e7ff9613-fa27-4e00-96af-355b65c165a4",
    "tenantId": "513294a0-3e20-41b2-a970-6d30bf1546fa",
    "redirectUri": "https://tu-dominio-en-iis.com/auth/callback"
  },
  "api": {
    "baseUrl": "http://u2zepcaosswv002.pwcglb.com:8443",
    "servicePath": "/XcaliburWeb/rest/ServiciosXcaliburWeb"
  }
}
```

### Paso 3: Registra el Redirect URI en Azure AD
Debes ir a **Azure Portal** → **Entra ID** → **App registrations** → Tu aplicación y:
1. Ve a **Authentication**
2. En **Redirect URIs**, agrega exactamente la misma URL que pusiste en config.json
3. Asegúrate de que sea **Web** (no Mobile/Desktop)
4. Haz clic en **Save**

**IMPORTANTE**: El Redirect URI en Azure AD DEBE coincidir exactamente con el que está en config.json. Si no coinciden, Azure no permitirá el login.

## Cómo Funciona

1. **app.config.ts**: En el startup de la aplicación, se ejecuta un `APP_INITIALIZER` que carga `config.json`
2. **ConfigService**: Servicio que proporciona acceso a los valores de configuración
3. **azure-ad.config.ts**: Genera dinámicamente la configuración de Azure AD usando valores del `ConfigService`
4. **oauth2.service.ts**: Usa automáticamente los valores configurados

## Para Producción

En la carpeta `dist/` después de hacer build, asegúrate de que:
- El archivo `config.json` esté en la raíz del servidor web (en IIS sería en wwwroot o similar)
- Tenga los valores correctos para tu ambiente de producción
- **El `redirectUri` debe estar registrado en Azure AD**
- No necesitas recompilar, solo cambiar el JSON

## Troubleshooting

### "Se abre en localhost pero no en IIS"
- Verifica que el `redirectUri` en config.json sea correcto
- Verifica que ese mismo URI está registrado en Azure AD
- Usa HTTPS en IIS (Azure AD requiere HTTPS excepto para localhost)

### "Aparece error en Azure AD"
- El error típico es que el redirectUri no está registrado
- Abre la consola del navegador (F12) y verifica qué URL está intentando usar
- Compárala con la que está en Azure AD

