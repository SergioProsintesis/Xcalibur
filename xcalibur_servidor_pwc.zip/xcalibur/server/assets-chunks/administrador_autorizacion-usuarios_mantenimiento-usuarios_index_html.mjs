export default `<!DOCTYPE html><html lang="en"><head>
  <meta charset="utf-8">
  <title>Xcalibur</title>
  <base href="/">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="assets/favicon/favicon.ico">
  <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="assets/favicon/favicon-16x16.png">
  <link rel="apple-touch-icon" sizes="180x180" href="assets/favicon/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="192x192" href="assets/favicon/android-chrome-192x192.png">
  <link rel="icon" type="image/png" sizes="512x512" href="assets/favicon/android-chrome-512x512.png">
<link rel="stylesheet" href="styles.css"><style ng-app-id="ng">

.loading-overlay[_ngcontent-ng-c1007795490] {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}
.loading-spinner[_ngcontent-ng-c1007795490] {
  background: white;
  padding: 2rem;
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}
.loader-svg[_ngcontent-ng-c1007795490] {
  width: 100px;
  height: 100px;
}
.loading-message[_ngcontent-ng-c1007795490] {
  margin: 0;
  color: #033481;
  font-size: 1rem;
  font-weight: 500;
}
/*# sourceMappingURL=/loading.component.css.map */</style><style ng-app-id="ng">

[_nghost-ng-c3436838166], 
.login-container[_ngcontent-ng-c3436838166] {
  --color-primary: #0b5ed7;
  --color-primary-dark: #0a4db0;
  --color-primary-light: #e6f0ff;
  --color-primary-hover: #7893c0;
  --color-white: #ffffff;
  --color-error: #ef4444;
  --color-error-light: #fee2e2;
  --border-medium: #e5e7eb;
  --border-light: #f3f4f6;
  --text-primary: #111827;
  --text-secondary: #6b7280;
  --text-tertiary: #9ca3af;
  --shadow-xl: 0 20px 25px -5px rgba(0,0,0,0.1);
}
.login-container[_ngcontent-ng-c3436838166] {
  min-height: 100vh;
  position: relative;
  display: flex;
  flex-direction: column;
  background:
    linear-gradient(
      135deg,
      var(--color-primary-light) 0%,
      var(--color-white) 100%);
  overflow: hidden;
}
.login-background[_ngcontent-ng-c3436838166] {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background:
    linear-gradient(
      135deg,
      var(--color-primary-light) 0%,
      var(--color-white) 100%);
  z-index: 1;
}
.login-background[_ngcontent-ng-c3436838166]::before {
  content: "";
  position: absolute;
  top: 0;
  right: 0;
  width: 50%;
  height: 100%;
  background:
    radial-gradient(
      circle at 80% 20%,
      rgba(255, 255, 255, 0.8) 0%,
      transparent 50%),
    radial-gradient(
      circle at 60% 60%,
      rgba(135, 206, 250, 0.3) 0%,
      transparent 50%);
  z-index: 2;
}
.login-header[_ngcontent-ng-c3436838166] {
  position: relative;
  z-index: 10;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 10px 40px 0px 40px;
  width: 100%;
}
.xcalibur-logo[_ngcontent-ng-c3436838166] {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}
.logo-image[_ngcontent-ng-c3436838166] {
  height: 72px;
  width: auto;
}
.xcalibur-logo[_ngcontent-ng-c3436838166], 
.prosintesis-logo[_ngcontent-ng-c3436838166] {
  position: relative;
  transition: transform 0.28s ease, filter 0.28s ease;
}
.xcalibur-logo[_ngcontent-ng-c3436838166]::after, 
.prosintesis-logo[_ngcontent-ng-c3436838166]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: 6px;
  pointer-events: none;
  background:
    radial-gradient(
      circle at 10% 20%,
      rgba(255, 255, 255, 0.8),
      rgba(255, 255, 255, 0) 30%);
  opacity: 0;
  transition: opacity 0.35s ease, transform 0.35s ease;
}
.xcalibur-logo[_ngcontent-ng-c3436838166]:hover, 
.prosintesis-logo[_ngcontent-ng-c3436838166]:hover {
  transform: translateY(-4px) scale(1.02);
  filter: drop-shadow(0 6px 12px rgba(74, 144, 226, 0.12));
}
.xcalibur-logo[_ngcontent-ng-c3436838166]:hover::after, 
.prosintesis-logo[_ngcontent-ng-c3436838166]:hover::after {
  opacity: 1;
  transform: translateY(-6px);
}
@keyframes _ngcontent-ng-c3436838166_shimmer {
  0% {
    transform: translateX(-100%);
    opacity: 0;
  }
  50% {
    transform: translateX(0%);
    opacity: 0.65;
  }
  100% {
    transform: translateX(100%);
    opacity: 0;
  }
}
@keyframes _ngcontent-ng-c3436838166_fadeIn {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
.animate-fade-in[_ngcontent-ng-c3436838166] {
  animation: _ngcontent-ng-c3436838166_fadeIn 420ms cubic-bezier(.2, .9, .3, 1) both;
}
.xcalibur-logo.shimmer[_ngcontent-ng-c3436838166]::after {
  content: "";
  position: absolute;
  inset: 0;
  background:
    linear-gradient(
      90deg,
      rgba(255, 255, 255, 0) 0%,
      rgba(255, 255, 255, 0.35) 50%,
      rgba(255, 255, 255, 0) 100%);
  transform: translateX(-120%);
  animation: _ngcontent-ng-c3436838166_shimmer 1.2s linear infinite;
  pointer-events: none;
}
.logo-text[_ngcontent-ng-c3436838166] {
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--color-primary-dark);
  letter-spacing: -0.025em;
}
.logo-text[_ngcontent-ng-c3436838166]   sup[_ngcontent-ng-c3436838166] {
  font-size: 0.6rem;
  color: var(--color-primary);
}
.prosintesis-logo[_ngcontent-ng-c3436838166] {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}
.prosintesis-icon[_ngcontent-ng-c3436838166] {
  margin-top: 20px;
  height: 40px;
  width: auto;
}
.prosintesis-text[_ngcontent-ng-c3436838166] {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
.prosintesis-name[_ngcontent-ng-c3436838166] {
  font-size: 1.25rem;
  font-weight: 700;
  color: var(--color-primary-dark);
  letter-spacing: -0.025em;
}
.prosintesis-tagline[_ngcontent-ng-c3436838166] {
  font-size: 0.75rem;
  color: var(--color-primary);
  font-weight: 500;
  margin-top: 0.125rem;
}
.login-panel[_ngcontent-ng-c3436838166] {
  position: relative;
  z-index: 10;
  background: var(--color-white);
  border-radius: 1rem;
  box-shadow: var(--shadow-xl);
  padding: 3rem;
  max-width: 28rem;
  width: 100%;
  margin: 0 auto;
  margin-top: 2rem;
}
.login-screen[_ngcontent-ng-c3436838166] {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
}
.login-panel[_ngcontent-ng-c3436838166]   form[_ngcontent-ng-c3436838166] {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
.input-with-icon[_ngcontent-ng-c3436838166] {
  display: flex;
  align-items: center;
  gap: 0.625rem;
  position: relative;
}
.input-with-icon[_ngcontent-ng-c3436838166]::before {
  content: "";
  position: absolute;
  left: 0.7rem;
  width: 20px;
  height: 20px;
  background-size: contain;
  background-repeat: no-repeat;
  pointer-events: none;
}
.input-with-icon[_ngcontent-ng-c3436838166]   input[_ngcontent-ng-c3436838166] {
  padding-left: 2.5rem;
}
.input-with-icon.password-with-icon[_ngcontent-ng-c3436838166]   input[_ngcontent-ng-c3436838166] {
  padding-right: 0;
}
.password-with-icon[_ngcontent-ng-c3436838166] {
  gap: 0;
}
.password-with-icon[_ngcontent-ng-c3436838166]   input[_ngcontent-ng-c3436838166] {
  flex: 1;
  padding-right: 2.5rem;
}
.btn-eye[_ngcontent-ng-c3436838166] {
  position: absolute;
  right: 0.5rem;
  background: transparent !important;
  border: none !important;
  color: var(--color-primary);
  font-size: 0.75rem;
  font-weight: 500;
  cursor: pointer;
  padding: 0.4rem 0.5rem !important;
  border-radius: 0.3rem;
}
.btn-eye[_ngcontent-ng-c3436838166]:hover, 
.btn-eye[_ngcontent-ng-c3436838166]:focus {
  background: rgba(0, 0, 0, 0.05) !important;
}
.btn-eye-icon[_ngcontent-ng-c3436838166] {
  position: absolute;
  right: 0.5rem;
  top: 50%;
  transform: translateY(-50%);
  background: transparent;
  border: none;
  padding: 0.15rem;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}
.btn-eye-icon[_ngcontent-ng-c3436838166]   img[_ngcontent-ng-c3436838166] {
  width: 20px;
  height: 20px;
  display: block;
}
.input-with-icon[_ngcontent-ng-c3436838166] {
  position: relative;
}
.pwc-logo[_ngcontent-ng-c3436838166]::after {
  content: "";
  position: absolute;
  right: -6px;
  top: -6px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background:
    linear-gradient(
      45deg,
      #ffd23f,
      #ff6b35);
  box-shadow: 0 4px 8px rgba(255, 147, 64, 0.18);
}
.password-with-icon[_ngcontent-ng-c3436838166]   .btn-link[_ngcontent-ng-c3436838166] {
  flex: 0 0 auto;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0.35rem 0.45rem;
}
.login-panel[_ngcontent-ng-c3436838166]   input[type=text][_ngcontent-ng-c3436838166], 
.login-panel[_ngcontent-ng-c3436838166]   input[type=email][_ngcontent-ng-c3436838166], 
.login-panel[_ngcontent-ng-c3436838166]   input[type=password][_ngcontent-ng-c3436838166] {
  width: 100%;
  padding: 0.62rem 0.7rem;
  border: 1px solid var(--border-medium);
  border-radius: 0.5rem;
  font-size: 0.93rem;
  background: var(--color-white);
  transition:
    box-shadow 0.15s,
    border-color 0.15s,
    transform 0.08s;
}
.login-panel[_ngcontent-ng-c3436838166]   input[_ngcontent-ng-c3436838166]::placeholder {
  color: var(--text-tertiary);
}
.login-panel[_ngcontent-ng-c3436838166]   input[_ngcontent-ng-c3436838166]:focus {
  outline: none;
  border-color: var(--color-primary);
  box-shadow: 0 0 0 4px rgba(135, 206, 250, 0.12);
  transform: translateY(-0.5px);
}
.password-row[_ngcontent-ng-c3436838166] {
  display: flex;
  gap: 0.5rem;
  align-items: center;
}
.password-row[_ngcontent-ng-c3436838166]   input[_ngcontent-ng-c3436838166] {
  flex: 1 1 auto;
}
.btn-link[_ngcontent-ng-c3436838166] {
  background: transparent;
  border: none;
  color: var(--color-primary);
  font-size: 0.875rem;
  cursor: pointer;
  padding: 0.25rem 0.5rem;
  border-radius: 0.4rem;
}
.btn-link[_ngcontent-ng-c3436838166]:hover, 
.btn-link[_ngcontent-ng-c3436838166]:focus {
  background: rgba(0, 0, 0, 0.03);
}
.btn-eye[_ngcontent-ng-c3436838166] {
  font-size: 1.1rem;
}
.remember[_ngcontent-ng-c3436838166] {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.875rem;
  color: var(--text-secondary);
}
.error[_ngcontent-ng-c3436838166] {
  color: var(--color-error);
  font-size: 0.825rem;
  background: transparent;
  margin-top: -0.25rem;
}
.error[_ngcontent-ng-c3436838166]   small[_ngcontent-ng-c3436838166] {
  display: block;
  margin-top: 0.25rem;
}
.sr-only[_ngcontent-ng-c3436838166] {
  position: absolute !important;
  width: 1px !important;
  height: 1px !important;
  padding: 0 !important;
  margin: -1px !important;
  overflow: hidden !important;
  clip: rect(0, 0, 0, 0) !important;
  white-space: nowrap !important;
  border: 0 !important;
}
.login-button[_ngcontent-ng-c3436838166]   .loading-spinner[_ngcontent-ng-c3436838166] {
  margin-right: 0.5rem;
}
input[_ngcontent-ng-c3436838166]:focus-visible, 
button[_ngcontent-ng-c3436838166]:focus-visible {
  outline: 3px solid rgba(135, 206, 250, 0.18);
  outline-offset: 2px;
}
.pwc-logo[_ngcontent-ng-c3436838166] {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
}
.pwc-icon[_ngcontent-ng-c3436838166] {
  position: relative;
  margin-top: -12px;
  width: 160px;
  height: auto;
}
.pwc-logo[_ngcontent-ng-c3436838166] {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: transform 300ms ease, box-shadow 300ms ease;
}
.pwc-logo[_ngcontent-ng-c3436838166]:hover {
  transform: translateY(-6px) scale(1.03);
  box-shadow: 0 12px 24px rgba(11, 93, 215, 0.08);
}
.form-group.floating[_ngcontent-ng-c3436838166] {
  position: relative;
  display: block;
}
.form-group.floating[_ngcontent-ng-c3436838166]   .form-label[_ngcontent-ng-c3436838166] {
  position: absolute;
  left: 0.9rem;
  top: 50%;
  transform: translateY(-50%);
  background: var(--color-white);
  padding: 0 0.35rem;
  color: var(--text-secondary);
  font-size: 0.85rem;
  pointer-events: none;
  transition: all 180ms ease;
  border-radius: 0.25rem;
  z-index: 2;
}
.form-group.floating[_ngcontent-ng-c3436838166]   input[_ngcontent-ng-c3436838166]:focus    + .form-label[_ngcontent-ng-c3436838166], 
.form-group.floating[_ngcontent-ng-c3436838166]   input[_ngcontent-ng-c3436838166]:not(:placeholder-shown)    + .form-label[_ngcontent-ng-c3436838166] {
  top: -0.5rem;
  transform: translateY(0);
  font-size: 0.72rem;
  color: var(--color-primary-dark);
  box-shadow: 0 2px 6px rgba(16, 24, 40, 0.04);
}
.form-group.floating[_ngcontent-ng-c3436838166]   .input-with-icon[_ngcontent-ng-c3436838166]   input[_ngcontent-ng-c3436838166] {
  padding-top: 1.05rem;
  padding-bottom: 0.65rem;
}
.pwc-square[_ngcontent-ng-c3436838166] {
  width: 1.5rem;
  height: 1.5rem;
  background:
    linear-gradient(
      45deg,
      #ff6b35,
      #f7931e,
      #ffd23f,
      #8b4513);
  border-radius: 0.25rem;
  position: absolute;
  top: 0.25rem;
  left: 0.25rem;
}
.pwc-text[_ngcontent-ng-c3436838166] {
  font-size: 1.5rem;
  font-weight: 400;
  color: var(--text-primary);
  letter-spacing: -0.025em;
}
.welcome-section[_ngcontent-ng-c3436838166] {
  text-align: center;
  margin-bottom: 2rem;
}
.welcome-title[_ngcontent-ng-c3436838166] {
  font-size: 1.25rem;
  font-weight: 700;
  color: #000;
  margin-bottom: 0.5rem;
}
.welcome-subtitle[_ngcontent-ng-c3436838166] {
  font-size: 0.875rem;
  color: var(--text-tertiary);
  margin: 0;
}
.error-message[_ngcontent-ng-c3436838166] {
  background: var(--color-error-light);
  border: 1px solid var(--color-error);
  border-radius: 0.5rem;
  padding: 0.75rem;
  margin-bottom: 1.5rem;
}
.error-message[_ngcontent-ng-c3436838166]   p[_ngcontent-ng-c3436838166] {
  color: var(--color-error);
  font-size: 0.875rem;
  margin: 0;
}
.login-form[_ngcontent-ng-c3436838166] {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}
.form-group[_ngcontent-ng-c3436838166] {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}
.form-label[_ngcontent-ng-c3436838166] {
  font-size: 0.875rem;
  font-weight: 500;
  color: var(--text-secondary);
}
.password-header[_ngcontent-ng-c3436838166] {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.forgot-password[_ngcontent-ng-c3436838166] {
  font-size: 0.75rem;
  color: var(--text-tertiary);
  text-decoration: none;
  transition: color 0.2s;
}
.forgot-password[_ngcontent-ng-c3436838166]:hover {
  color: var(--text-secondary);
}
.form-input[_ngcontent-ng-c3436838166] {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid var(--border-medium);
  border-radius: 0.5rem;
  font-size: 0.875rem;
  transition: all 0.2s;
  background: var(--color-white);
}
.form-input[_ngcontent-ng-c3436838166]:focus {
  outline: none;
  border-color: var(--color-primary);
  box-shadow: 0 0 0 3px var(--color-primary-light);
}
.form-input[_ngcontent-ng-c3436838166]:disabled {
  background-color: var(--bg-secondary);
  cursor: not-allowed;
}
.azure-ad-login-button[_ngcontent-ng-c3436838166] {
  width: 100%;
  background: #ffffff;
  color: var(--text-primary);
  border: 1px solid var(--border-medium);
  border-radius: 0.5rem;
  padding: 0.75rem 1rem;
  font-size: 0.875rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  margin-bottom: 1.5rem;
}
.azure-ad-login-button[_ngcontent-ng-c3436838166]:hover {
  background: var(--border-light);
  border-color: #0078d4;
  box-shadow: 0 1px 3px rgba(0, 120, 212, 0.12);
}
.azure-ad-login-button[_ngcontent-ng-c3436838166]:active {
  background: #f0f0f0;
}
.microsoft-icon[_ngcontent-ng-c3436838166] {
  width: 1.25rem;
  height: 1.25rem;
  object-fit: contain;
}
.divider[_ngcontent-ng-c3436838166] {
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 1rem 0;
  font-size: 0.875rem;
  color: var(--text-secondary);
}
.divider[_ngcontent-ng-c3436838166]::before, 
.divider[_ngcontent-ng-c3436838166]::after {
  content: "";
  flex: 1;
  height: 1px;
  background: var(--border-medium);
}
.divider[_ngcontent-ng-c3436838166]   span[_ngcontent-ng-c3436838166] {
  padding: 0 1rem;
}
.login-button[_ngcontent-ng-c3436838166] {
  width: 100%;
  background: var(--color-primary-dark);
  color: var(--text-inverse);
  border: none;
  border-radius: 0.5rem;
  padding: 0.75rem 1rem;
  font-size: 0.875rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
}
.login-button[_ngcontent-ng-c3436838166]:hover:not(:disabled) {
  background: var(--color-primary-hover);
}
.login-button[_ngcontent-ng-c3436838166]:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
.loading-spinner[_ngcontent-ng-c3436838166] {
  width: 1rem;
  height: 1rem;
  border: 2px solid transparent;
  border-top: 2px solid currentColor;
  border-radius: 50%;
  animation: _ngcontent-ng-c3436838166_spin 1s linear infinite;
}
@keyframes _ngcontent-ng-c3436838166_spin {
  to {
    transform: rotate(360deg);
  }
}
.support-links[_ngcontent-ng-c3436838166] {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  margin-top: 2rem;
  padding-top: 1.5rem;
  border-top: 1px solid var(--border-light);
}
.support-link[_ngcontent-ng-c3436838166] {
  font-size: 0.75rem;
  color: var(--text-tertiary);
  text-decoration: none;
  transition: color 0.2s;
}
.support-link[_ngcontent-ng-c3436838166]:hover {
  color: var(--text-secondary);
}
.support-contact[_ngcontent-ng-c3436838166] {
  color: var(--color-primary);
  font-weight: 500;
}
.support-contact[_ngcontent-ng-c3436838166]:hover {
  color: var(--color-primary-hover);
}
@media (max-width: 768px) {
  .login-header[_ngcontent-ng-c3436838166] {
    padding: 0.5rem 1rem;
    flex-direction: row;
    gap: 1rem;
    align-items: center;
  }
  .xcalibur-logo[_ngcontent-ng-c3436838166], 
   .prosintesis-logo[_ngcontent-ng-c3436838166] {
    justify-content: center;
  }
  .logo-image[_ngcontent-ng-c3436838166] {
    height: 50px;
    width: auto;
  }
  .prosintesis-icon[_ngcontent-ng-c3436838166] {
    margin-top: 0;
    height: 35px;
    width: auto;
  }
  .login-panel[_ngcontent-ng-c3436838166] {
    margin-top: 1rem;
  }
  .pwc-icon[_ngcontent-ng-c3436838166] {
    margin-top: -45px;
    width: 140px;
  }
  .welcome-section[_ngcontent-ng-c3436838166] {
    margin-bottom: 1rem;
  }
  .login-panel-container[_ngcontent-ng-c3436838166] {
    overflow: auto;
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
  }
}
/*# sourceMappingURL=/login.component.css.map */</style></head>
<body><!--nghm--><script type="text/javascript" id="ng-event-dispatch-contract">(()=>{function p(t,n,r,o,e,i,f,m){return{eventType:t,event:n,targetElement:r,eic:o,timeStamp:e,eia:i,eirp:f,eiack:m}}function u(t){let n=[],r=e=>{n.push(e)};return{c:t,q:n,et:[],etc:[],d:r,h:e=>{r(p(e.type,e,e.target,t,Date.now()))}}}function s(t,n,r){for(let o=0;o<n.length;o++){let e=n[o];(r?t.etc:t.et).push(e),t.c.addEventListener(e,t.h,r)}}function c(t,n,r,o,e=window){let i=u(t);e._ejsas||(e._ejsas={}),e._ejsas[n]=i,s(i,r),s(i,o,!0)}window.__jsaction_bootstrap=c;})();
</script><script>window.__jsaction_bootstrap(document.body,"ng",["click"],[]);</script>
  <app-root ng-version="20.1.3" ngh="2" ng-server-context="ssg"><router-outlet></router-outlet><app-login _nghost-ng-c3436838166="" ngh="0"><div _ngcontent-ng-c3436838166="" class="login-container"><div _ngcontent-ng-c3436838166="" class="login-background"></div><div _ngcontent-ng-c3436838166="" class="login-header"><div _ngcontent-ng-c3436838166="" class="xcalibur-logo shimmer"><img _ngcontent-ng-c3436838166="" src="assets/images/xcalibur_LOGO FLAT.png" alt="XCALIBUR" class="logo-image"></div><div _ngcontent-ng-c3436838166="" class="prosintesis-logo"><img _ngcontent-ng-c3436838166="" src="assets/images/LOGO PROSINTESIS SVG.png" alt="PROSINTESIS" class="prosintesis-icon"></div></div><div _ngcontent-ng-c3436838166="" class="login-panel-container"><div _ngcontent-ng-c3436838166="" class="login-panel animate-fade-in"><div _ngcontent-ng-c3436838166="" class="pwc-logo"><img _ngcontent-ng-c3436838166="" src="assets/images/pwc.png" alt="PWC" class="pwc-icon"></div><div _ngcontent-ng-c3436838166="" class="welcome-section"><h1 _ngcontent-ng-c3436838166="" class="welcome-title">Bienvenido</h1><p _ngcontent-ng-c3436838166="" class="welcome-subtitle">Inicia sesión con tu cuenta de correo electrónico</p></div><!--container--><button _ngcontent-ng-c3436838166="" type="button" aria-label="Iniciar sesión con Microsoft" class="azure-ad-login-button" jsaction="click:;"><img _ngcontent-ng-c3436838166="" src="assets/icons/microsoft-logo.svg" alt="Microsoft" class="microsoft-icon"><span _ngcontent-ng-c3436838166="">Iniciar sesión con Microsoft</span></button><!--container--></div></div></div></app-login><!--container--><app-loading _nghost-ng-c1007795490="" ngh="1"><!--container--></app-loading></app-root>
<script src="main.js" type="module"></script>

<script id="ng-state" type="application/json">{"__nghData__":[{"t":{"16":"t0","17":"t1"},"c":{"16":[],"17":[{"i":"t1","r":1}]}},{"t":{"0":"t2"},"c":{"0":[]}},{"c":{"0":[{"i":"c3436838166","r":1}]}}]}</script></body></html>`;